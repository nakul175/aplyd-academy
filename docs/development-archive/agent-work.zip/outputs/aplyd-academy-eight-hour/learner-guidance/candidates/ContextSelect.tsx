'use client';
import {useId} from 'react';
import {Select,SelectTrigger,SelectValue,SelectContent,SelectItem} from '@/components/ui/select';
import {roleOptions} from './academy-context-select';

/** Replace the existing ContextSelect function in its current file and retain
 * its roleOptions export. The import above is only illustrative for a standalone
 * review; remove it when replacing the function in academy-context-select.tsx.
 */
export function ContextSelect({value,onChange,label,hint}:{value:string;onChange:(value:string)=>void;label?:string;hint?:string}){
 const id=useId(),labelId=id+'-label',hintId=id+'-hint';
 return <div className={label||hint?'guidance-browse':undefined}>{label&&<label id={labelId} htmlFor={id}>{label}</label>}<Select value={value} onValueChange={onChange}><SelectTrigger id={id} aria-label={label?undefined:'Your work context'} aria-labelledby={label?labelId:undefined} aria-describedby={hint?hintId:undefined} className="context-select"><SelectValue/></SelectTrigger><SelectContent>{roleOptions.map(p=><SelectItem key={p.id} value={p.id}>{p.label}</SelectItem>)}</SelectContent></Select>{hint&&<p id={hintId} className="form-hint">{hint}</p>}</div>;
}
