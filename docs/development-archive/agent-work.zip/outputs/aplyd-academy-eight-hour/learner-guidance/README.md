# Learner guidance refinement candidate

Reviewed phase-one checkout `77852f1`. This is a bounded candidate outside the app, ready for root review. It changes no authority, schema, command, API, provider integration or content pin. Nothing here was published or field-tested.

The existing `NextActionCard` already has the main start/resume/review/appeal logic. Replace its presentation rather than adding a competing card. The candidate adds short state-specific explanations, an actual first shared-workspace cohort destination, specific support destinations, and a supported personal offline-navigation option. The existing page still performs enrollment, fresh access checks, save confirmation and all commands.

## Concrete findings and proposed changes

| Current source | Learner confusion | Minimal change |
| --- | --- | --- |
| `app/academy.tsx:89`, `app/academy-context-select.tsx:5`, `lib/academy-plan.ts:396` | Overview's context selector changes its featured pathway while the next-step card continues to follow the saved profile/plan. Its accessible label implies an enduring personal preference. | Label the Overview control **Browse featured learning for**. Add a short explanation that it changes the featured suggestion only. The next-step card says **Based on your saved learning and private plan**. Preserve saved-context selection in `learnerNextAction`. |
| `app/academy.tsx:93` | Catalog's context selector changes `role`, but catalog results use the separate `filter`; choosing Farmer can still leave all pathways visible. | Remove this extra ContextSelect from Catalog. Keep its real filter and give it the visible label **Show learning for**. Do not silently change the saved profile. |
| `app/academy.tsx:89` and `:92` | New learners see broad aspiration titles on the feature/card while the actual task-based title appears only after opening it. | Use `displaySelected?.title` for the Overview feature and `shown?.title` for cards, keeping actual summaries. Missing saved editions keep the unavailable title and retained-work message. No added impact/competence claim. |
| `app/academy.tsx:86` | Topbar says **Saved privately / Workspace saved** while unsent input is being typed. | Change the steady text to **Saved learning loaded**. Keep existing Saving/Opening/Retry states and actual command acknowledgements. Add the candidate notice beside the actual draft Save buttons. |
| `app/academy-plan.tsx:14–15` | Plan-page card links back to the current plan; fallback calls a settings destination “support & preferences.” | Hide the duplicate plan link on PlanView and when the chosen action already goes to plan. Use the real Support & help destination for format help. |

Overview suggested control text:

```tsx
<ContextSelect value={role} onChange={setRole}
 label="Browse featured learning for"
 hint={team
  ? 'Changes the featured suggestion only. Your own saved learning and plan choose the next step.'
  : 'Changes the featured suggestion only. Save your main work context in Preferences & privacy.'}/>
```

Use `ContextSelect.tsx` as a function replacement in its current file, preserving `roleOptions`; remove its illustrative self-file import. The optional label/hint let existing settings/cohort uses keep their current behavior.

## Integration contract

`candidates/NextActionCard-integration.tsx.txt` shows the small wrapper replacement in the existing plan component. `NextUsefulStep` consumes its real `learnerNextAction` and exact accepted `resolvePinned` result. This avoids a circular import back to `usePlanOptions`. Place the model and its declaration beside `lib/academy-plan.ts`; the declaration uses that existing type.

All original action kind/tab/enrollment/program/lesson/time/block fields remain as returned by the existing model. The only primary destination change is an active shared first session without enrollment: it opens the existing cohort list, where actual capacity/content/role checks apply. Staff without learner access stay on browse plus support. Inactive membership, withdrawn history, unavailable pins, pause, pending assessment, appeal, exhaustion and suspension keep their original priority and destinations. Missing pin information adds a help note; it never selects newer content or relabels an appeal as a new lesson.

Personal/global/English `0.1-review-draft` lesson or practical states may show **Prepare for a connection gap**, which only opens Offline practice. Shared/private editions, inactive/nonlearner/blocked states, feedback/appeal states and unknown editions do not receive it. OfflineView remains responsible for its independent fresh read, scope, expiry, local protection and explicit draft-only acknowledgement. This helper starts no download or save.

The notice compares explicit current activity fields against the last accepted saved copy; it prints no response value, answer choice or field name. It says matching/changed/new/pending rather than asserting a whole workspace or submission was saved. Keep the exact-string comparison because the actual draft commands preserve input text.

In `Lesson`, add beside Save practice draft **only when `!done`**:

```tsx
<OwnDraftSaveNotice local={{practice,answers}}
 saved={{practice:e.lessonDrafts?.[l.id]?.practice??'',
  answers:e.lessonDrafts?.[l.id]?.answers??l.quiz.map(()=>null)}}
 keys={['practice','answers']} hasSavedDraft={!!e.lessonDrafts?.[l.id]}
 saveLabel="Save practice draft"/>
```

In `Practical`, add beside Save draft:

```tsx
<OwnDraftSaveNotice local={fields} saved={e.draft}
 keys={p.practicalAssessment.submissionPrompts.map((f:any)=>f.id)}
 hasSavedDraft={p.practicalAssessment.submissionPrompts.some((f:any)=>Object.hasOwn(e.draft,f.id))}
 saveLabel="Save draft"/>
```

Use raw context `saving` for pending status, not `busy`, because `busy` also includes inactive membership. The accepted saved-copy comparison is deliberately distinct from a fresh server read and from the return value of the most recent command. A later directory read failure must not relabel an acknowledged save as failed; a lost response must not announce success. Existing error/retry behavior remains responsible for those conditions.

`role="status"` with polite/atomic announcement changes only when the status category changes. Instructions remain visibly next to the control. Decorative icons are hidden from assistive technology; existing navigation handles focus on main. Small CSS additions preserve wrapping/full-width card buttons and constrain the browse helper at narrow widths. No new dialog or focus mechanism.

## Validation and remaining checks

`tests/guidance.test.mjs` executes pure candidate cases against the existing prebundled real engine/plan functions: personal first session; shared learner/nonlearner; lesson resume; exact unavailable pin; unavailable content with pending review/appeal; pause/inactive membership; sample versus assigned reviews; practical versus exhausted/suspended feedback; private/shared offline exclusion; planned self-reported practice; pending/unknown/matching/changed/blank draft notices; exact quiz/whitespace comparison and nonmutation. `pure-test-result.json` records counts, source/cache hashes and the actual revision. This is pure evidence, not browser/UAT evidence or an app compile.

After root integrates and creates a stable build, the bounded browser check should cover just these changes:

1. A new personal learner can browse an actual task-based pathway, read its fictional task and explicitly start it; changing the featured context does not alter the saved profile or an existing enrollment.
2. Catalog has one context filter with visible label; changing it changes results, and search/clear remain usable by keyboard.
3. A new active shared learner opens Cohorts; staff without learner role sees accurate access help; removed membership remains history only. No helper automatically posts/enrolls.
4. Existing lesson opens the exact pinned lesson; pending review/appeal goes to feedback; missing pins expose retained-work/help and never a latest edition. Pause/exhaustion/suspension retain gates.
5. Draft notice goes new → changed/matching after an accepted draft acknowledgement. Text edits, changed quiz choice and trailing whitespace change its status; timeout does not announce success; acknowledged save plus directory failure does not announce “not saved.” Submitted history/capture confirmation remains unchanged.
6. At 390px and 200% text, card and helper buttons wrap without horizontal overflow; visible labels/descriptions are exposed. Tab/Enter navigation works, main receives navigation focus, and polite draft status does not repeat on every keystroke after its category stabilizes.

No server, browser, API, provider, real account or field-user action was used in this refinement workstream. Root owns integration and publication.
