# Focused learner guidance browser verification

Executed on the root-authorized stable M2 Worker, session 47804. For future runs, do not execute until root explicitly signals a stable build and permits browser/API work. Root owns the Worker and all build/restart/publication actions. The harness itself creates no server, edits no checkout file, makes no provider call and uses no existing or real learner account.

Run `guidance-browser.mjs` with the bundled Node runtime after the stable signal. Default target is `http://127.0.0.1:8787`; the runtime rejects nonloopback targets. Chrome and Playwright use the existing bundled/native runtime. All synthetic identities start with `guidance-` and have `@academy.test` email addresses, distinct from other workstreams. Source/build hashes, check names, fixture limitations and results are written to this directory. Contexts and the browser close in `finally`.

Readiness waits use `[data-save-state="loaded"]`, never the retired **Saved privately / Workspace saved** wording. For intentional connection errors, wait for the existing retry control plus the local draft status rather than asserting loaded state prematurely. Successful refresh waits for that attribute again.

The script covers:

1. Overview's visibly labelled browsing control changes only the featured suggestion, sends no command, and keeps the saved preference. Actual Settings save changes the durable preference; a later accepted read restores it. One next-step card remains.
2. Catalog's actual filter changes real results and has a visible label. The ineffective second featured-context control is absent. Search and Clear filters remain usable.
3. Two own enrollments demonstrate saved-profile/plan selection versus transient featured browsing. Resume uses the exact lesson ID/source text and moves focus to main. Offline is only a navigation offer for supported exact personal seeds.
4. Local notice before any online draft, real pending save before acknowledgement, accepted matching draft, exact whitespace/quiz changes, actual committed write with lost browser acknowledgement, retained current text, read-only reconciliation and no automatic POST retry. Pin/completion/submission/record invariants are checked.
5. 390px/768px with 100%/200% CSS-root text: no horizontal overflow, actual larger textarea text, keyboard Enter on resume, navigation focus, and two phone screenshots.
6. Actual local content pause, sample pending review and sample appeal keep their established destinations/action gates. Unknown pin is a clearly labelled intercepted **GET-only browser display fixture**; the real server record is compared before/after and remains unchanged. No latest-edition substitution is performed.
7. Actual shared first-session cohort navigation without enrollment. Real shared draft acknowledgement followed by a deliberately failed **directory GET** must retain matching accepted text and a neutral attention message. The stored draft and pin are checked independently. Removing the synthetic owner's learner role leaves actual history/access guidance and no offline offer.

Personal writes currently do not refresh the directory after saving. That failure vector therefore uses the actual shared save path; claiming to have tested it on the personal path would be misleading.

Fixture setup uses actual local commands to create only fictional enrollments, source-check responses, sample decisions/appeals and one shared cohort. No staff identity outside the personal sample workflow is impersonated. The shared owner reviews no learner evidence. Lesson/answer-key file hashes and exact content references are recorded and checked; the harness changes no curriculum, key or access rule.

This is bounded local UI/runtime evidence. It is not hosted authentication, external provider readiness, field-user UAT, manual screen-reader assessment or genuine browser zoom certification. Stop and report a product failure before expanding the run or proposing a fix. Source edits, recompiles and Worker restarts remain root-only.

## Executed result

73 selected passing assertions: 58 from the main run and 15 from a focused completion of the remaining shared vector. These are assertions, not 73 independent cases. `consolidated-result.json` records the exact evidence selection and unchanged source/build hashes. No product failure was found in the exercised guidance flows. All contexts, browsers and Node sessions are closed.

The full run stopped after an external fixture enrollment because a hash-only navigation did not fetch accepted state again. The reusable full script now refreshes that fixture. The focused shared completion used actual UI enrollment and initially selected the dialog FormError title instead of the global banner title; that test-only selector was corrected. The partial and initial focused results are retained for audit, and their duplicate assertions are not added to the final count. The passed earlier scope was not broadly repeated.

The shared save committed and was acknowledged before its directory GET deliberately returned 503. The accepted draft stayed matching, the stored text/pin agreed, the neutral **Your work needs attention** banner appeared, and read recovery performed no repeated write. Removed learner permission produced history guidance with no offline offer. The two phone screenshots were visually inspected; enlarged text wrapped within the layout. The transient intentional lost-ack error toast remained visible in those screenshots while the loaded status had recovered.
