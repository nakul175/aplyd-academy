import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
export {chromium} from '/Users/athena/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
export const output=path.dirname(fileURLToPath(import.meta.url));
export const app=path.resolve(process.env.ACADEMY_APP_PATH??'/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/work/aplyd-academy');
export const base=process.env.ACADEMY_LOCAL_URL??'http://127.0.0.1:8787';
assert.ok(['localhost','127.0.0.1','[::1]'].includes(new URL(base).hostname),'Loopback synthetic checks only');
export const browserOptions={executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true};
export const curriculum=JSON.parse(fs.readFileSync(path.join(app,'lib/curriculum.json'),'utf8'));
export const program=curriculum.pathways[1];
export const identity=role=>({id:'guidance-'+role+'-'+crypto.randomUUID(),email:'guidance-'+role+'-'+crypto.randomUUID()+'@academy.test',name:'Fictional guidance '+role});
export const headers=user=>({'Content-Type':'application/json','oai-authenticated-user-id':user.id,'oai-authenticated-user-email':user.email,'oai-authenticated-user-full-name':encodeURIComponent(user.name),'oai-authenticated-user-full-name-encoding':'percent-encoded-utf-8'});
export const sha=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
export const jsonSha=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
export async function get(user){const response=await fetch(base+'/api/academy',{headers:headers(user)});assert.equal(response.status,200);return response.json();}
export async function command(user,value){const current=await get(user),response=await fetch(base+'/api/academy',{method:'POST',headers:headers(user),body:JSON.stringify({revision:current.revision,actionId:crypto.randomUUID(),command:value})});assert.equal(response.status,200,'Synthetic personal fixture command '+value.type);return response.json();}
export async function getTeam(user,id){const response=await fetch(base+'/api/teams?id='+encodeURIComponent(id),{headers:headers(user)});assert.equal(response.status,200);return response.json();}
export async function teamCommand(user,id,value){const current=id?await getTeam(user,id):{revision:0},response=await fetch(base+'/api/teams',{method:'POST',headers:headers(user),body:JSON.stringify({...(id?{teamId:id}:{}),revision:current.revision,actionId:crypto.randomUUID(),command:value})});assert.equal(response.status,200,'Synthetic shared fixture command '+value.type);return response.json();}
export async function enroll(user,complete=false){let result=await command(user,{type:'enroll',programId:program.id}),id=result.state.enrollments[0].id;if(complete)for(const lesson of program.lessons)result=await command(user,{type:'lesson',enrollmentId:id,lessonId:lesson.id,practice:'Fictional source checking removes unsupported promises and retains human approval.',answers:lesson.quiz.map(q=>q.correctOptionIndex)});return {id,state:result};}
export const fictionalFields=()=>Object.fromEntries(program.practicalAssessment.submissionPrompts.map(prompt=>[prompt.id,'Fictional source checking removes unsupported claims and keeps the human approval route.']));
export const button=(page,name)=>page.getByRole('button',{name,exact:true});
export const settled=page=>page.locator('[data-save-state="loaded"]').waitFor();
export async function navigate(page,hash){await page.evaluate(value=>location.hash=value,hash);await page.locator('#main').waitFor();}
export async function textSize(page,double){await page.evaluate(value=>document.documentElement.style.fontSize=value?'32px':'16px',double);}
export async function noOverflow(page,ok,label){ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),label+' fits viewport horizontally');}
export async function focusMain(page,ok,label){await page.waitForTimeout(75);ok(await page.locator('#main').evaluate(element=>element===document.activeElement),label+' focuses main');}
export function reporter(name='guidance-browser'){const names=[],errors=[],fixtureNotes=[],sourceFiles=['app/academy.tsx','app/academy-context-select.tsx','app/academy-plan.tsx','app/academy-learning.tsx','app/academy-learner-guidance.tsx','lib/academy-learner-guidance.mjs','lib/academy-plan.ts','lib/academy-engine.ts','lib/curriculum.json','app/globals.css'],buildFiles=['dist/server/wrangler.json','dist/server/index.js'];let passed=false;const initialHashes=Object.fromEntries(sourceFiles.filter(file=>fs.existsSync(path.join(app,file))).map(file=>[file,sha(path.join(app,file))]));return {errors,fixtureNotes,ok(value,label){assert.ok(value,label);names.push(label);},pass(){passed=true;},finish(){const finalHashes=Object.fromEntries(Object.keys(initialHashes).map(file=>[file,sha(path.join(app,file))]));const result={passed,at:new Date().toISOString(),head:execFileSync('git',['rev-parse','HEAD'],{cwd:app,encoding:'utf8'}).trim(),worker:base,checks:names.length,checkNames:names,errors,fixtureNotes,sourceHashes:initialHashes,sourceUnchanged:JSON.stringify(initialHashes)===JSON.stringify(finalHashes),buildHashes:Object.fromEntries(buildFiles.filter(file=>fs.existsSync(path.join(app,file))).map(file=>[file,{sha256:sha(path.join(app,file)),mtime:fs.statSync(path.join(app,file)).mtime.toISOString()}])),limits:['Synthetic trusted-header local accounts only; no hosted sign-in, field users or external delivery.','Text enlargement is CSS-root resizing and responsive layout inspection, not manual VoiceOver or genuine browser zoom certification.','Missing-pin browser check, when used, is a clearly labelled intercepted local read fixture; saved server records are not corrupted.']};fs.writeFileSync(path.join(output,name+'-result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({passed,checks:names.length,errors,sourceUnchanged:result.sourceUnchanged,output:path.join(output,name+'-result.json')}));}};}
