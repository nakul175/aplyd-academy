Actual-root template QA kit. No application changes.
Pure root compiler/tests executed33groups successfully; source hashes and counts in runtime. API/browser scripts syntax checked but NOT RUN: automatic approval review rejected launch before any process or request, and root is seeking explicit user permission. Do not execute gated scripts until the user answers Allow and root confirms the same stable Worker.

Portable copies live under repository-tests for tests/job-template-qa adoption. Portable output defaults .sites-runtime/job-template-qa, imports current root tests/local-qa.mjs guarded synthetic helpers and browser runtime, and contains no absolute hardcoded path. Source and original curriculum/library files are never modified. Fake response tests change only local browser delivery after actual one-time synthetic API save.

Pure:
node <kit>/build-actual-model.mjs
node --test <kit>/actual-model.test.mjs

After required user approval and root stable Worker confirmation only:
ACADEMY_TEMPLATE_WORKER_READY=1 node <kit>/template-api.mjs
ACADEMY_TEMPLATE_WORKER_READY=1 node <kit>/template-browser.mjs

API12scenarios cover current owner, exact fields, unknown mappings, one activity/draft, action replay/mismatch, stale CAS/real same-revision race, learner/directory/personal snapshot privacy, independent review/publication/private exact pin/old pin, role loss and24retained capacity. Browser8scenarios cover explicit saved new drafts without publication, independent-review Escape focus, held-create input lock, four distinct role drafts/active capacity, six normal/true200% layouts, revoked canonical draft with own scratch restoration, uncertain acknowledgement with no automatic second create.
There is no actual API/browser evidence until result JSON records a completed run. No published/partner/provider/real learner is touched.
