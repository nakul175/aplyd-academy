Aplyd Academy implementation readiness — observed checkpoint audit

The working product covers the central learn–practise–submit–review–appeal journey
for three fictional farmer/MSME/public-service pathways. It also has protected
shared cohorts, private content publishing, discussion/moderation, opted-in cohort
networking and sessions, own plans/reflections, personal offline drafts and private
practice-record checks. This is a substantial working pilot.

The wider original BRD is not fully implemented or accepted. Partner identity and
delivery are local simulations; recognized certification and full credential
lifecycle are absent; all current editions are English; diagnostics, mentor
requests, renewal and commerce are unimplemented. No representative field learner
or actual hosted recipient has accepted the product. No live AI service is called.

Published baseline: 0.12.0, main 1fea626a611f11403bd9db7e88977a619f49c360.
Native checkpoint version 13 succeeded 2026-10-05T20:30:18.807637+00:00 at
https://aplyd-academy.nakul1729233.chatgpt.site/. The audience remains owner-private.
Native publication is separate from hosted account/application acceptance.

The 0.13 local candidate adds content attention, learner-selected own help details
and a read-only partner inspector. It remains unpublished in this audit. The
streaming-body reader is deferred after an oversized-upload/immediate-next-request
503 sequence. Retained baseline routes passed 32 native read-only cases/193
assertions. Post-deferral rule output has 635 entries; older checkpoint 665 includes
the stream candidate. Fixed-log mocked checks are separate 27 groups/309 assertions.
Focus regression has passed in a later report, while the older checkpoint status
still lists it as pending. Root is reconciling exact final source and publication.

The audit separates four kinds of evidence:
  1. Source/model proof: actual rule modules and exact source hashes.
  2. Local execution: fictional loopback API/browser and intercepted display/race
     checks, with each run's scope and counts retained separately.
  3. Hosted proof: native deployment success/audience only; actual recipient,
     identity, anonymous/direct-file authorization and feature journeys NOT RUN.
  4. Field/user evidence: task usefulness, real staff delivery, inclusive access,
     sector approval and measured work impact NOT RUN.

Files:
  requirement-matrix.tsv / .json — all 46 original BR-01 through BR-46 mapped to
    current behavior, source, executed evidence and remaining acceptance.
    “Bounded” means the actual pilot behavior exists; it is not full original
    requirement signoff. No development percentage is inferred from row counts.
  evidence-register.json — E01–E14 preserve source, historical/current execution,
    publication and candidate boundaries. Historical evidence is not described
    as a new current-version hosted test.
  launch-gaps.tsv / .json — exactly 10 gaps ordered by real dependency and impact.
    The immediate candidate gate is followed by access, approved content, named
    independent staff, field/access UAT, partner/issuer claims and real operations.
  audit-manifest.json — read-only audit source/output hashes and scope.
  before-start/ — one optional, bounded pre-enrollment presentation addition,
    staged outside checkout with an exact UI patch and12 passing pure checks.

This audit edits no checkout, starts no application build/Worker/browser/API and
sends no external messages. Explicit fictional mutation-test approval remains
pending after automatic-review rejection; no alternate fixture route was tried.
The separate live-AI credential decision remains pending. Provider-backed design,
code and testing remain stopped. Embedded AI was optional later scope in the
original baseline, so it is not itself a prerequisite for useful static practice.

The original FSD/HLD/LLD/API/schema files remain proposed target designs. Current
as-built specifications govern the actual account/header, workspace aggregate,
seven-table D1, command/CAS/idempotency and private record behavior. They do not
implement the entire original /api/v1 relational/outbox/public-credential contract.
Final release documentation should identify that difference, rather than claim
all original planned test cases ran.
