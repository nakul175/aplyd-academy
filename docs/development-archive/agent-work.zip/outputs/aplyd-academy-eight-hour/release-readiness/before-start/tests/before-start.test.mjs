import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {deriveBeforeStartSummary} from '../lib/academy-before-start.mjs';
const manifest=JSON.parse(await readFile(new URL('../source-manifest.json',import.meta.url),'utf8'));
const seed=JSON.parse(await readFile(`${manifest.root}/lib/curriculum-versions/0.1-review-draft.json`,'utf8'));
const authoring=await readFile(`${manifest.root}/lib/academy-authoring.ts`,'utf8');
const policyLiteral=authoring.match(/policy:(\{minimumWeightedScore:[^}]+\})/)?.[1];
assert.ok(policyLiteral,'The current publication must retain its explicit validated policy');
const privatePolicy=JSON.parse(policyLiteral.replace(/([{,])([A-Za-z]\w*):/g,'$1"$2":').replace(/'([^']*)'/g,'"$1"'));
const globalSnapshot=program=>({ref:{scope:'global',programId:program.id,versionId:seed.contentVersion},program});
const privateSnapshot=(program=structuredClone(seed.pathways[0]))=>({ref:{scope:'tw-'+ 'a'.repeat(24),programId:program.id,versionId:'v-old'},program,policy:structuredClone(privatePolicy)});

test('every actual archived pathway shows its own prerequisites and exact stored pass wording',()=>{
  for(const program of seed.pathways){const result=deriveBeforeStartSummary({snapshot:globalSnapshot(program),globalSeed:seed});assert.deepEqual(result.prerequisites,program.prerequisites);assert.equal(result.passRule,seed.assessmentPolicy.passingRule);}
});
test('the actual publication policy produces the current rule and total rubric score',()=>{
  const snapshot=privateSnapshot(),result=deriveBeforeStartSummary({snapshot,globalSeed:seed});
  assert.equal(privatePolicy.minimumWeightedScore,seed.assessmentPolicy.minimumWeightedScore);
  assert.equal(privatePolicy.criticalGates,'all');assert.equal(snapshot.program.practicalAssessment.rubric.reduce((s,r)=>s+r.weight,0),100);
  assert.equal(result.passRule,'At least 70 out of 100, and every critical safety check must pass. A failed safety check cannot be averaged away.');
});
test('an edited private edition displays its own prerequisites rather than the global seed',()=>{
  const snapshot=privateSnapshot();snapshot.program.prerequisites=['Private edition instruction'];assert.deepEqual(deriveBeforeStartSummary({snapshot,globalSeed:seed}).prerequisites,['Private edition instruction']);
});
test('an older resolved private edition is not replaced by a newer same-program document',()=>{
  const old=privateSnapshot();old.program.prerequisites=['Older approved edition requirement'];
  const newer=structuredClone(seed);newer.pathways[0].prerequisites=['Newer requirement'];
  assert.deepEqual(deriveBeforeStartSummary({snapshot:old,globalSeed:newer}).prerequisites,['Older approved edition requirement']);
});
test('unknown global editions cannot borrow the archived global pass rule',()=>{
  const snapshot=globalSnapshot(seed.pathways[0]);snapshot.ref.versionId='unavailable-newer';assert.equal(deriveBeforeStartSummary({snapshot,globalSeed:seed}),null);
});
test('an unavailable resolution and missing source never fall back to seed content',()=>{
  assert.equal(deriveBeforeStartSummary({snapshot:null,globalSeed:seed}),null);assert.equal(deriveBeforeStartSummary({globalSeed:seed}),null);
});
test('mismatched program identity and malformed or foreign reference shape are omitted',()=>{
  for(const alter of [s=>s.ref.programId='different',s=>s.ref.scope='partner',s=>s.ref.versionId='',s=>s.ref.scope='tw-short']){const snapshot=privateSnapshot();alter(snapshot);assert.equal(deriveBeforeStartSummary({snapshot,globalSeed:seed}),null);}
});
test('missing private policy preserves prerequisites but never borrows global rule',()=>{
  const snapshot=privateSnapshot();delete snapshot.policy;const result=deriveBeforeStartSummary({snapshot,globalSeed:seed});assert.deepEqual(result.prerequisites,snapshot.program.prerequisites);assert.equal(result.passRule,null);
});
test('invalid policy or rubric cannot invent a passing threshold or averaged safety rule',()=>{
  for(const alter of [s=>s.policy.minimumWeightedScore=NaN,s=>s.policy.minimumWeightedScore=101,s=>s.policy.criticalGates='average',s=>s.policy.scoreMaximum=0,s=>s.program.practicalAssessment.rubric[0].weight=-1]){const snapshot=privateSnapshot();alter(snapshot);assert.equal(deriveBeforeStartSummary({snapshot,globalSeed:seed}).passRule,null);}
});
test('private rule is derived from its policy and rubric without a hardcoded numerical threshold',()=>{
  const snapshot=privateSnapshot();snapshot.policy.minimumWeightedScore=75;snapshot.program.practicalAssessment.rubric.forEach(r=>r.weight*=2);assert.equal(deriveBeforeStartSummary({snapshot,globalSeed:seed}).passRule,'At least 75 out of 200, and every critical safety check must pass. A failed safety check cannot be averaged away.');
});
test('projection detaches prerequisites and mutates neither snapshot nor canonical seed',()=>{
  const snapshot=privateSnapshot(),before=JSON.stringify(snapshot),seedBefore=JSON.stringify(seed),result=deriveBeforeStartSummary({snapshot,globalSeed:seed});result.prerequisites.push('Local display change');assert.equal(JSON.stringify(snapshot),before);assert.equal(JSON.stringify(seed),seedBefore);
});
test('malformed prerequisites are not displayed as invented readiness facts',()=>{
  for(const prerequisites of [undefined,'Read this',[null],[' ']]){const snapshot=privateSnapshot();snapshot.program.prerequisites=prerequisites;assert.equal(deriveBeforeStartSummary({snapshot,globalSeed:seed}),null);}
});
