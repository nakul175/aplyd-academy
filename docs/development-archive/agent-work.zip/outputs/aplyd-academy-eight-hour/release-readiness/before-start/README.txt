Before you start — outside-checkout presentation candidate

Adoption files:
  lib/academy-before-start.mjs
  lib/academy-before-start.d.mts
  existing-root-ui.patch (only app/academy-learning.tsx)

The existing resolved snapshot remains authoritative. Its own prerequisites are
displayed before enrollment. Global assessment wording is read from the exact
archived seed's assessmentPolicy.passingRule; a different global version is not
mapped to that seed. A private edition reads only its snapshot.policy and its own
rubric total. Missing/invalid private policy produces an unavailable-rule notice,
with no global-policy fallback. Unknown or mismatched sources produce no block.

No registry lookup, latest-edition replacement, command, role, permission, saved
preference, enrollment gate, provider, external call or new API is added. The
existing unavailable-pin early return and enrollment button are unchanged.

Executed: 12 meaningful pure projection groups, zero failures. Tests read the
actual archived curriculum and the actual publication-policy literal in the
root authoring source. Checks cover own private prerequisites, retained edition,
unknown/mismatched sources, missing/invalid policy, derived rather than hardcoded
thresholds, detached results and unchanged input. pure-result.txt preserves output.

Not executed: adoption, TypeScript, app build, browser, API, hosted acceptance or
field UAT. Root must review/adopt and validate the rendered exact-source block.
source-manifest.json records the source hashes used to prepare this patch.
