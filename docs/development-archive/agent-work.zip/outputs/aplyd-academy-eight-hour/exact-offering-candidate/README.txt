Exact catalog offering → course preview candidate

Current defect was reproduced in M4 read-only acceptance: one private program has two current exact publications/cohorts. The catalog Map's last eligible cohort supplies revised title; LearningView independently chooses the first open cohort and shows earlier title/prerequisites. Both editions are properly resolved, but the journey surprises the learner.

Candidate behavior:
- Keep the existing one catalog and canonical program documents. A typed pure read model pairs each existing private catalog selection with only its current workspace/cohort/full content reference. Own active enrollment keeps precedence and emits no alternative offering target.
- Private card shows “Preview: <cohort title>” and passes that exact metadata through existing go('learn', programId, {offering}). No command, enrollment, publication or progress change occurs on navigation.
- Bounded hash: #learn/<programId>/offering/<workspaceId>/<cohortId>/<scope>/<versionId>. The parser accepts only current ID syntax, exact fields and exactly7 segments, <=700characters; malformed offering syntax remains an explicit unavailable intent instead of falling through to an unrelated first cohort.
- Preview validates intent against the currently accepted workspace, cohort and actual pinnedRef. Cohort removal/repointing, cross-workspace metadata, unknown pins and malformed fields never choose another/newer edition.
- Current own active enrollment remains first. If an offering URL would select something else, learner sees: “You’re continuing your enrolled edition. Your saved course has not changed.” No saved pin is upgraded.
- Manual picker selection updates existing learningTarget + bounded hash via selectPreviewOffering, preserving the mounted selector and existing focus. Generic go's scroll/main focus and all existing lesson/practical/feedback direct URLs/callbacks remain unchanged. Reload/back/forward preserve the explicit edition; no localStorage or additional persistent state.
- URL is only navigation metadata. Start still requires current active learner membership, exact available source, open cohort/content, a real remaining place, plus existing busy/paused gates. Server role/access/capacity/CAS remains untouched and authoritative. Only a separate explicit Start click sends the existing enrollment command. Catalog click can preselect an eligible private cohort; it never performs enrollment.

Files/adoption:
integration.patch contains minimal proposed changes to current app/academy.tsx and app/academy-learning.tsx plus new lib/academy-offering-navigation.ts. App files in this kit are review snapshots only; apply reviewed hunks, never overwrite subsequent parent edits. Root sole checkout writer/build/publication owner.
tests/build-model.mjs uses actual root curriculum/pin functions and pure team/authoring fixtures, strict-checks the helper, parses the two TSX candidates, records14 used input hashes. It does not build the app.
tests/offering.test.mjs:30/30 passing groups (fetch disabled), exact pins/catalog priority/hash parsing/history/races/adverse client gates/no mutation.
tests/browser-readonly.mjs:21 candidate cases (15 journeys +6 normal/true200%body layouts), syntax checked NOT RUN. Uses approved existing fictional reader IDs and actual pure-domain memory-only GET display projections; blocks all mutating/external network. Includes exact card→preview, reload, manual picker/hash/back/forward, current GET removal/repoint, cross-workspace URL, own-enrollment notice, malformed URL, revoked/nonlearner/closed/paused/full, keyboard focus, state/revision unchanged.
tests/read-only-routing.mjs wraps EVERY broad and specific intercept before fetch/continue, so Playwright's last-registered specific routes cannot bypass the read-only filter. Specific fetches use maxRedirects0 to avoid following an unexpected external redirect outside the page route filter. tests/read-only-routing.test.mjs passes20 fake-route groups without a browser or any network; rejected POST/DELETE/external GET/HEAD calls have zero handler/fetch/continue calls, including team-query delegation. Product candidate module/UI remain frozen; this correction changes only QA harness files.

Commands from workspace (Node environment already present):
node outputs/aplyd-academy-eight-hour/exact-offering-candidate/tests/build-model.mjs
node --test outputs/aplyd-academy-eight-hour/exact-offering-candidate/tests/offering.test.mjs
node --test outputs/aplyd-academy-eight-hour/exact-offering-candidate/tests/read-only-routing.test.mjs
For root adoption, tests can live under tests/exact-offering-qa; default model/evidence output then .sites-runtime/exact-offering-qa. Set ACADEMY_APP_PATH / ACADEMY_OFFERING_QA_OUTPUT explicitly when reviewing outside checkout or regenerating an isolated artifact.

Browser runs require a NEW parent stable Worker after adopting/building this feature, ACADEMY_EXACT_OFFERING_WORKER_READY=1, ACADEMY_QA_WORKER=<root session>, ACADEMY_OFFERING_RUNTIME_DIST=<frozen dist>, ACADEMY_READONLY_FIXTURES=<already approved fixtures JSON>, fresh ACADEMY_OFFERING_BROWSER_OUTPUT. Do not run against hosted Site, mutate fictional data or bypass pending human approval for fixture-creating suites.

Limits:
Staged only outside checkout. Typed helper +30 pure groups +UI syntax are passing; actual integrated UI/typecheck/build/browser proof awaits parent adoption and new stable Worker. No app source, Git, SQL, running Worker, external provider, library original or saved enrollment was changed by this work.
