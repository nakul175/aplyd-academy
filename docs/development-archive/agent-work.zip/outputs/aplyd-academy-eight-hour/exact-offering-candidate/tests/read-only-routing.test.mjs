import test from 'node:test';
import assert from 'node:assert/strict';
import {withReadOnlyRoute} from './read-only-routing.mjs';
const origin='http://127.0.0.1:8787';
function fakeRoute(method,url){
 const calls={abort:0,fetch:0,continue:0,handle:0};
 const route={request:()=>({method:()=>method,url:()=>url}),abort:async reason=>{assert.equal(reason,'blockedbyclient');calls.abort++;},fetch:async options=>{assert.equal(options?.maxRedirects,0);calls.fetch++;return {json:async()=>({display:true})};},continue:async()=>{calls.continue++;},fulfill:async()=>{}};
 return {route,calls};
}
const behaviors={fallback:route=>route.continue(),personal:async route=>{const response=await route.fetch({maxRedirects:0});return route.fulfill({response,json:await response.json()});},team:async route=>{const url=new URL(route.request().url());if(url.searchParams.get('id')!=='approved-existing')return route.continue();const response=await route.fetch({maxRedirects:0});return route.fulfill({response,json:await response.json()});}};
for(const [name,handler]of Object.entries(behaviors)){
 for(const [label,method,url]of [['local mutation','POST',origin+'/api/'+(name==='personal'?'academy':'teams')+'?id=approved-existing'],['external GET','GET','https://unrelated.example/api/teams?id=approved-existing'],['external HEAD','HEAD','https://unrelated.example/api/teams?id=approved-existing'],['local delete','DELETE',origin+'/api/teams']])test(name+' blocks '+label+' before any downstream operation',async()=>{
  const {route,calls}=fakeRoute(method,url),forbidden=[];
  await withReadOnlyRoute(route,origin,forbidden,async safe=>{calls.handle++;return handler(safe);});
  assert.deepEqual(calls,{abort:1,fetch:0,continue:0,handle:0});assert.equal(forbidden.length,1);
 });
 for(const method of ['GET','HEAD'])test(name+' allows same-origin '+method+' only after the explicit guard',async()=>{
  const {route,calls}=fakeRoute(method,origin+'/api/teams?id=approved-existing'),forbidden=[];
  await withReadOnlyRoute(route,origin,forbidden,async safe=>{calls.handle++;return handler(safe);});
  assert.equal(calls.abort,0);assert.equal(calls.handle,1);assert.equal(calls.fetch+calls.continue,1);assert.deepEqual(forbidden,[]);
 });
}
test('specific team handler also guards unrelated-query continue before delegation',async()=>{
 for(const [method,url,allowed]of [['GET',origin+'/api/teams?other=value',true],['POST',origin+'/api/teams?other=value',false],['GET','https://unrelated.example/api/teams?other=value',false]]){
  const {route,calls}=fakeRoute(method,url),forbidden=[];await withReadOnlyRoute(route,origin,forbidden,behaviors.team);assert.equal(calls.fetch,0);assert.equal(calls.continue,allowed?1:0);assert.equal(calls.abort,allowed?0:1);
 }
});
test('protocol-relative same hostname with foreign scheme or port is a different forbidden origin',async()=>{
 for(const url of ['https://127.0.0.1:8787/api/academy','http://127.0.0.1:9999/api/academy']){const {route,calls}=fakeRoute('GET',url),forbidden=[];await withReadOnlyRoute(route,origin,forbidden,behaviors.personal);assert.equal(calls.abort,1);assert.equal(calls.fetch,0);}
});
