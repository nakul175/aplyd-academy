/** Every intercept must run this before fetch/continue; specific routes outrank broad routes. */
export async function withReadOnlyRoute(route,allowedOrigin,forbidden,handle){
 const request=route.request(),url=new URL(request.url()),method=request.method();
 if(url.origin!==allowedOrigin||!['GET','HEAD'].includes(method)){
  forbidden.push({method,path:url.pathname,origin:url.origin});
  return route.abort('blockedbyclient');
 }
 return handle(route);
}
