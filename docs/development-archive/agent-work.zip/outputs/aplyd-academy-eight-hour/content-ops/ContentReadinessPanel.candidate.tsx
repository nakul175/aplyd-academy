'use client';
import {useState} from 'react';
import {FileCheck2,LifeBuoy,ShieldCheck} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Checkbox} from '@/components/ui/checkbox';
import type {ContentReadiness,ReadinessDestination,LearningHelpDraft,OwnLearningHelpInput} from './academy-content-readiness.candidate';
import {prepareOwnLearningHelp} from './academy-content-readiness.candidate';

const date=(v:string|null)=>v?new Date(v).toLocaleString('en-IN'):'Date unavailable';
const states={retired:'Retired publication',publication_review_elapsed:'Content review date elapsed',publication_review_soon:'Content review within seven days',publication_date_unknown:'Review date needs checking',awaiting_review:'Awaiting independent owner review',approved:'Approved draft · final publication checks remain'};

/** Candidate for Workspace operations. Model prop comes only from the current
 * permitted team projection; buttons navigate and never perform protected writes. */
export function ContentReadinessPanel({model,onOpen}:{model:ContentReadiness|null;onOpen:(target:ReadinessDestination)=>void}){
  if(!model)return <section className="panel operations-panel mt"><h2>Content and learning access</h2><p className="mt">A current permitted workspace snapshot is needed. Refresh access before opening this view.</p></section>;
  const owner=model.audience==='owner',c=model.counts;
  return <section className="panel operations-panel mt" aria-labelledby="readiness-title">
    <div className="section-title no-top"><h2 id="readiness-title"><FileCheck2 size={21}/> Content and learning access</h2><span className="form-hint">Observed {date(model.asOf)}</span></div>
    <p>{c.contentEnrollmentBlocked} scoped cohorts have content enrollment closed in the saved snapshot · {c.pausedCohorts} cohorts are paused.</p>
    <p className="form-hint mt">Review dates below use this observation time. Refresh before an action; the server checks current dates and authority. Existing learners retain their exact saved course edition. Retirement and review dates do not pause current learning automatically.</p>
    {c.contentStatusUnknown>0&&<p className="operations-warning">{c.contentStatusUnknown} cohort content states are unavailable and need a current owner check.</p>}
    <ul className="operations-list">{model.cohorts.filter(co=>co.state==='paused'||co.newContentEnrollment!=='allowed_in_snapshot'||!co.exactContentReferenceKnown).map(co=><li key={co.id} data-content-readiness-cohort-id={co.id}><h3>{co.title}</h3><p>{co.state==='paused'?'Learning and review actions are paused.':co.newContentEnrollment==='blocked_in_snapshot'?co.contentNotice??'New content enrollment is unavailable.':co.newContentEnrollment==='unknown'?'Content enrollment status is unavailable.':'This saved content reference needs checking.'}</p><p className="form-hint">{owner?'Open the cohort to review the exact content or arrange a deliberate pause.':'Ask a current workspace owner to review content or arrange a pause. Facilitator access does not grant either action.'}</p><Button size="sm" variant="outline" onClick={()=>onOpen(co.destination)}>Open cohort</Button></li>)}</ul>
    {model.content.visible&&<><div className="section-title"><h3>Private content attention</h3><span className="form-hint">{c.retiredPublications} retired · {c.elapsedPublicationReviews} review dates elapsed · {c.pendingDraftReviews} waiting for review</span></div><ul className="operations-list">{model.content.items.map(item=><li key={item.kind+item.id} data-content-readiness-item-id={item.id}><h4>{item.title}</h4><p><strong>{states[item.state]}</strong></p><p className="form-hint">{item.kind==='publication'?'Content review date: '+date(item.reviewDueAt):item.waitingDays===null?'Recorded waiting date is unavailable.':'Last draft update '+item.waitingDays+' elapsed days ago. This is not a response deadline.'}</p>{item.reasons.length>0&&<ul className="mt">{item.reasons.map(reason=><li key={reason}>{reason}</li>)}</ul>}{item.affectedCohorts.length>0&&<p className="mt">Pinned cohorts: {item.affectedCohorts.map(co=>co.title+(co.newEnrollmentBlocked?' · new enrollment closed in snapshot':'')).join('; ')}.</p>}<p className="form-hint mt">{item.nextStep}</p><Button size="sm" variant="outline" onClick={()=>onOpen(item.destination)}>Open exact content</Button></li>)}</ul>{model.content.totalAttention>model.content.items.length&&<p className="form-hint">Showing {model.content.items.length} of {model.content.totalAttention}. Open the content studio for the full retained list.</p>}{!model.content.totalAttention&&<p className="mt">No retained publications or submitted/approved drafts need attention in this view. This observation is not sector approval.</p>}</>}
    <div className="section-title"><h3><LifeBuoy size={18}/> Help requests within your authority</h3><span className="form-hint">{model.support.totalOpen} open · {c.supportNeedsHandler} need a handler</span></div>
    {owner&&<p className="form-hint">{c.openAccessRequests} open accessibility-category requests. Private language and help preferences are not counted or exposed; requests may concern other access needs.</p>}
    <ul className="operations-list">{model.support.items.map(r=><li key={r.id} data-content-readiness-support-id={r.id}><h4>{r.category==='accessibility'?'Accessibility request':r.category==='content'?'Content concern':r.category==='learning'?'Learning request':'Workspace support request'}</h4><p>{r.cohortTitle} · {r.openedDaysAgo===null?'Opening date unavailable':'Opened '+r.openedDaysAgo+' elapsed days ago'}.</p><p className="form-hint">{r.needsHandler?r.independentHandlerAvailable?'Awaiting a current eligible independent handler.':'Another eligible independent handler must be arranged.':'A current handler is assigned.'}</p><Button size="sm" variant="outline" onClick={()=>onOpen(r.destination)}>Open permitted support queue</Button></li>)}</ul>
    {!model.support.totalOpen&&<p className="mt">No open support requests are visible within your current authority. This does not establish that everyone’s language or access needs are met.</p>}
    <div className="notice mt"><ShieldCheck size={21}/><div><strong>Confirm who can stop and who can help.</strong><p>Current workspace owners can pause an Academy cohort. Authority to stop a workplace tool, its named escalation contact, a working channel and a backup contact are not recorded here. Confirm them with the responsible organization before a frontline exercise.</p><p className="mt">A critical concern needs the approved workplace escalation route. The ordinary Academy help queue promises no emergency response or staffed turnaround. A language or reading-help preference remains a private request until its learner deliberately includes it in a support request.</p></div></div>
  </section>;
}

/** Optional block inside the ordinary Support Intake. Show only to the requester
 * using their own profile. All disclosure choices start false. No command/send. */
export function OwnLearningHelpDisclosure({scopeKey,input,onPrepare}:{scopeKey:string;input:Omit<OwnLearningHelpInput,'choices'>;onPrepare:(draft:LearningHelpDraft)=>void}){
  // Root supplies the authenticated account/workspace tuple. Changing account,
  // workspace, selected course or saved preference resets disclosure immediately.
  return <OwnLearningHelpDisclosureBody key={JSON.stringify([scopeKey,input.preferences,input.course])} input={input} onPrepare={onPrepare}/>;
}
function OwnLearningHelpDisclosureBody({input,onPrepare}:{input:Omit<OwnLearningHelpInput,'choices'>;onPrepare:(draft:LearningHelpDraft)=>void}){
  const [choices,setChoices]=useState({includeRequestedLanguage:false,includeAssistancePreference:false,includeCourse:false}),[error,setError]=useState('');
  const toggle=(key:keyof typeof choices,value:boolean)=>setChoices(c=>({...c,[key]:value}));
  return <section className="source-packet mt" aria-labelledby="learning-help-disclosure-title"><h3 id="learning-help-disclosure-title">Choose what to include in your request</h3><p className="form-hint">Saved preferences stay private. You can add only the details you choose to the unsent support description, review its audience and then submit the ordinary request.</p>
    <label className="check-line"><Checkbox checked={choices.includeRequestedLanguage} onCheckedChange={v=>toggle('includeRequestedLanguage',v===true)}/>Include my requested language: {input.preferences.preferredLanguage}</label>
    <label className="check-line"><Checkbox checked={choices.includeAssistancePreference} onCheckedChange={v=>toggle('includeAssistancePreference',v===true)}/>Include my saved reading or response-capture help request.</label>
    {input.course&&<label className="check-line"><Checkbox checked={choices.includeCourse} onCheckedChange={v=>toggle('includeCourse',v===true)}/>Include this saved course title and language.</label>}
    {error&&<p role="alert">{error}</p>}<Button type="button" variant="outline" className="mt" onClick={()=>{try{const draft=prepareOwnLearningHelp({...input,choices});setError('');onPrepare(draft);}catch(e){setError(e instanceof Error?e.message:'Review what you want to include before continuing.');}}}>Prepare my unsent access request</Button>
    <p className="form-hint mt">This does not contact a helper, expose private evidence, create a translation or approve an accommodation. The existing support audience acknowledgement is still required.</p>
  </section>;
}
