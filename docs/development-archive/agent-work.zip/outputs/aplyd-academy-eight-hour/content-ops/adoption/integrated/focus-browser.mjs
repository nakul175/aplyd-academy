import assert from 'node:assert/strict';
import path from 'node:path';
import {chromium,browserOptions,requireStable,fixtures,report,guardedContext,getSaved,jsonSha,out,base,loaded,button,frames,navigate} from './runtime.mjs';

// Run only on the parent's rebuilt stable Worker. No RAF monkeypatch, React
// internal hook, backend mutation, protected submit or new account is used.
requireStable();
const f=fixtures(),r=report('focus-browser'),browser=await chromium.launch(browserOptions),contexts=[],before={},after={};
const description=d=>d.getByRole('textbox',{name:'Request description',exact:true});
const title=d=>d.getByRole('textbox',{name:'Request title',exact:true});
const prepare=d=>button(d,'Add chosen details to my unsent description');
const marker='UNSENT_M3_FOCUS_GUARD_OWN_A';
const savedStamp=j=>({revision:j.revision,state:j.state,content:j.team?.content,support:j.team?.support});
const settle=async p=>{await frames(p);await p.waitForTimeout(50);};
async function intake(){
 const {page:p,context:c}=await guardedContext(browser,f.a,r);contexts.push(c);
 await p.goto(base+'/?workspace='+encodeURIComponent(f.teamId)+'#support');await loaded(p);await button(p,'Request help').click();
 const d=p.getByRole('dialog',{name:'Request help in this workspace',exact:true});await d.waitFor();
 await title(d).fill('Synthetic focus guard question');await description(d).fill(marker);
 await d.getByText('Add saved learning-help details (optional)',{exact:true}).click();
 return {p,c,d};
}
async function privateBoundary(d,label){
 r.ok((await description(d).inputValue()).startsWith(marker+'\n\n'),'Current own description prefix survives '+label);
 r.ok(await title(d).inputValue()==='Synthetic focus guard question','Current own title survives '+label);
 r.ok(!(await d.getByRole('checkbox',{name:'I understand the request audience and kept private records out.',exact:true}).isChecked()),'Acknowledgement is unchecked after '+label);
 r.ok(await button(d,'Submit help request').isDisabled(),'Protected submit remains disabled after '+label);
}
try{
 before.a=savedStamp(await getSaved(f.a,f.teamId));before.owner=savedStamp(await getSaved(f.owner,f.teamId));
 await r.scenario('keyboard preparation reaches current connected description','actual adopted guard with keyboard Enter',async()=>{
  const {p,c,d}=await intake();await prepare(d).focus();await p.keyboard.press('Enter');await settle(p);
  r.ok(await description(d).evaluate(node=>node.isConnected&&node===document.activeElement&&node.closest('[role="dialog"]')?.getAttribute('data-state')==='open'),'Keyboard Enter reaches description in same open dialog after settled remount');
  await privateBoundary(d,'keyboard preparation');await c.close();
 });
 await r.scenario('new title focus before frame is preserved','synchronous local click and deliberate focus event',async()=>{
  const {p,c,d}=await intake();await prepare(d).evaluate(node=>{node.click();document.getElementById('support-subject')?.focus();});await settle(p);
  r.ok(await title(d).evaluate(node=>node===document.activeElement),'Prepared callback respects deliberate title focus');await privateBoundary(d,'new user focus');await c.close();
 });
 await r.scenario('new keyboard intent cancels pending description reclaim','local DOM keyboard event before frame',async()=>{
  const {p,c,d}=await intake();await prepare(d).evaluate(node=>{node.click();document.getElementById('support-subject')?.dispatchEvent(new KeyboardEvent('keydown',{key:'Tab',bubbles:true}));});await settle(p);
  r.ok(!(await description(d).evaluate(node=>node===document.activeElement)),'New keyboard event before frame cancels prepared focus');await privateBoundary(d,'new keyboard intent');await c.close();
 });
 await r.scenario('Cancel before frame closes dialog and returns focus without old reclaim','synchronous actual prepare and Cancel controls',async()=>{
  const {p,c,d}=await intake();await prepare(d).evaluate(node=>{node.click();const dialog=node.closest('[role="dialog"]');const cancel=[...dialog.querySelectorAll('button')].find(button=>button.textContent?.trim()==='Cancel');cancel?.click();});
  await d.waitFor({state:'hidden'});await settle(p);
  r.ok(await button(p,'Request help').evaluate(node=>node===document.activeElement),'Cancel return focus is not stolen by pending description callback');
  await button(p,'Request help').click();const replacement=p.getByRole('dialog',{name:'Request help in this workspace',exact:true});await replacement.waitFor();await settle(p);
  r.ok(!(await description(replacement).evaluate(node=>node===document.activeElement)),'Newly mounted replacement dialog keeps its own initial focus');
  await privateBoundary(replacement,'cancel/replacement dialog');await c.close();
 });
 await r.scenario('navigation before frame removes old dialog and preserves main/new-dialog focus','local hash navigation and actual controls',async()=>{
  const {p,c,d}=await intake();await prepare(d).evaluate(node=>{node.click();location.hash='#home';});await d.waitFor({state:'hidden'});await settle(p);
  r.ok(await p.locator('#main').evaluate(node=>node===document.activeElement),'Unmounted preparation cannot reclaim focus from new main destination');
  await navigate(p,'support');await button(p,'Request help').click();const replacement=p.getByRole('dialog',{name:'Request help in this workspace',exact:true});await replacement.waitFor();await settle(p);
  r.ok(!(await description(replacement).evaluate(node=>node===document.activeElement)),'Navigation replacement dialog keeps its own initial focus');
  await privateBoundary(replacement,'navigation replacement');await c.close();
 });
 after.a=savedStamp(await getSaved(f.a,f.teamId));after.owner=savedStamp(await getSaved(f.owner,f.teamId));
 r.ok(jsonSha(before.a)===jsonSha(after.a)&&jsonSha(before.owner)===jsonSha(after.owner),'Focused guard checks change no saved learner/owner state/revision/content/support');
 r.ok(r.attemptedWrites.length===0&&r.blockedExternal.length===0,'Focused guard checks attempt no writes or external requests');r.ok(r.pageErrors.length===0,'Focused guard checks produce no page exceptions');r.pass();
}catch(error){
 for(const [n,c]of contexts.entries())for(const p of c.pages())await p.screenshot({path:path.join(out,'focus-failure-'+n+'.png'),fullPage:false}).catch(()=>{});
 throw error;
}finally{
 for(const c of contexts)await c.close().catch(()=>{});await browser.close();
 if(before.a&&!after.a)after.a=savedStamp(await getSaved(f.a,f.teamId));if(before.owner&&!after.owner)after.owner=savedStamp(await getSaved(f.owner,f.teamId));
 r.finish({browsersClosed:true,focusedLimits:['New-focus/cancel event races use synchronous actual local control clicks and DOM focus/key events before the normal browser frame. No artificial RAF scheduler is installed.','Scope/audience/extra-dialog/disconnected-target race refusals additionally have 19 exact candidate synthetic DOM/RAF checks; this script does not fabricate a server membership or accommodation change.'],savedBeforeHashes:Object.fromEntries(Object.entries(before).map(([k,v])=>[k,jsonSha(v)])),savedAfterHashes:Object.fromEntries(Object.entries(after).map(([k,v])=>[k,jsonSha(v)]))});
}
