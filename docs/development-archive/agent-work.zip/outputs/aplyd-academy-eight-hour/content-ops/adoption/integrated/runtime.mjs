import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
export {chromium} from '/Users/athena/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

export const out=path.dirname(fileURLToPath(import.meta.url));
export const app=path.resolve(out,'../../../../../work/aplyd-academy');
export const fixtureFile=path.resolve(out,'../../../record-verification/integrated/evidence/fixtures.json');
export const base=process.env.ACADEMY_LOCAL_URL??'http://127.0.0.1:8787';
export const previewDist=process.env.ACADEMY_PREVIEW_DIST?path.resolve(process.env.ACADEMY_PREVIEW_DIST):null;
const localHosts=new Set(['127.0.0.1','localhost','[::1]']);
export const browserOptions={executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true};
export const sha=value=>createHash('sha256').update(value).digest('hex');
export const jsonSha=value=>sha(JSON.stringify(value));
export const headers=user=>({'Content-Type':'application/json','oai-authenticated-user-id':user.id,'oai-authenticated-user-email':user.email,'oai-authenticated-user-full-name':encodeURIComponent(user.name),'oai-authenticated-user-full-name-encoding':'percent-encoded-utf-8'});

// No calls, fixture creation or writes occur at import time. The parent supplies
// this flag only after freezing a fully adopted, stable M3 build and Worker.
export function requireStable(){
 assert.equal(process.env.ACADEMY_M3_READONLY_STABLE,'1','Wait for root stable M3 signal; syntax checks need no flag.');
 assert.ok(process.env.ACADEMY_M3_WORKER,'Record the root-owned Worker session in ACADEMY_M3_WORKER.');
 const url=new URL(base);assert.ok(localHosts.has(url.hostname)&&url.protocol==='http:','Loopback HTTP only');
 assert.equal(url.pathname,'/','Use Worker origin only');
 if(previewDist)assert.ok(previewDist.startsWith('/private/tmp/academy-m3-preview-')&&path.basename(previewDist)==='dist','Only explicitly root-owned M3 frozen preview directory');
}
export function fixtures(){
 const f=JSON.parse(fs.readFileSync(fixtureFile,'utf8'));
 for(const key of ['a','b','owner','person','other','reviewer']){
  assert.ok(f[key]?.id.startsWith('qa-')&&f[key]?.email.endsWith('@academy.test'),'Existing fictional identity '+key);
 }
 assert.ok(f.teamId?.startsWith('tw-')&&f.personTeam?.id?.startsWith('tw-'));
 return f;
}
export async function getSaved(user,workspace){
 const target=new URL(workspace?'/api/teams?id='+encodeURIComponent(workspace):'/api/academy',base);
 assert.ok(localHosts.has(target.hostname));
 const res=await fetch(target,{method:'GET',headers:headers(user),redirect:'error'});
 assert.equal(res.status,200,'Existing saved fixture read '+user.name);
 return res.json();
}
export const frames=p=>p.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
export const loaded=p=>p.locator('[data-save-state="loaded"]').waitFor();
export const button=(p,name)=>p.getByRole('button',{name,exact:true});
export async function navigate(p,hash){await p.evaluate(value=>location.hash='#'+value,hash);await frames(p);}
export async function pick(p,label,name){await p.getByRole('combobox',{name:label,exact:true}).click();const page=typeof p.page==='function'?p.page():p;await page.getByRole('option',{name,exact:true}).click();}
export async function text200(p){await p.addStyleTag({content:'html{font-size:200% !important}'});await frames(p);}
export async function noOverflow(p,ok,label){ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),label+' fits viewport');}
export async function noMarkerStorage(p,ok,marker){ok(await p.evaluate(value=>!JSON.stringify({...localStorage}).includes(value)&&!JSON.stringify({...sessionStorage}).includes(value),marker),'Own unsent intake text is absent from browser persistent storage');}

export function report(name='readonly-browser'){
 const checks=[],cases=[],pageErrors=[],attemptedWrites=[],blockedExternal=[],requests=[],displayFixtures=[];
 const selectedCases=process.env.ACADEMY_M3_CASES?process.env.ACADEMY_M3_CASES.split(',').map(Number):null;
 if(selectedCases)assert.ok(selectedCases.length>0&&selectedCases.every(n=>Number.isSafeInteger(n)&&n>=1&&n<=13),'Choose scenario numbers 1-13 only');
 const sourceFiles=['app/academy.tsx','app/academy-context.tsx','app/academy-support.tsx','app/academy-learning-help-disclosure.tsx','app/academy-operations.tsx','app/academy-content-readiness.tsx','app/academy-acceptance.ts','app/globals.css','lib/academy-content-readiness.ts','lib/academy-content-readiness-adoption.mjs','lib/academy-inclusive-learning.ts','lib/academy-authoring.ts'];
 const buildFiles=['dist/server/wrangler.json','dist/server/index.js'];
 const fileHashes=files=>Object.fromEntries(files.filter(f=>fs.existsSync(path.join(app,f))).map(f=>[f,sha(fs.readFileSync(path.join(app,f)))]));
 const sources=fileHashes(sourceFiles),build=fileHashes(buildFiles);
 const runtimeFiles=['server/wrangler.json','server/index.js'];
 const runtimeHashes=()=>previewDist?Object.fromEntries(runtimeFiles.filter(f=>fs.existsSync(path.join(previewDist,f))).map(f=>[f,sha(fs.readFileSync(path.join(previewDist,f)))])):null;
 const previewHashes=runtimeHashes();
 let passed=false,scenarioNumber=0;
 return {checks,cases,pageErrors,attemptedWrites,blockedExternal,requests,displayFixtures,
  ok(value,label){assert.ok(value,label);checks.push(label);},
  async scenario(name,kind,fn){const number=++scenarioNumber;if(selectedCases&&!selectedCases.includes(number)){cases.push({number,name,kind,skipped:true,assertions:0});return;}const start=checks.length;try{await fn();cases.push({number,name,kind,passed:true,assertions:checks.length-start});console.log(name+': passed');}catch(error){cases.push({number,name,kind,passed:false,assertions:checks.length-start,error:String(error)});throw error;}},
  pass(){passed=true;},
  finish(extra={}){
   const result={passed,at:new Date().toISOString(),rootHead:execFileSync('git',['rev-parse','HEAD'],{cwd:app,encoding:'utf8'}).trim(),worker:process.env.ACADEMY_M3_WORKER,base,selectedCases:selectedCases??'all',assertions:checks.length,checks,cases,executedScenarios:cases.filter(c=>c.number&&typeof c.passed==='boolean').length,pageErrors,attemptedWrites,blockedExternal,requests,displayFixtures,sourceHashes:sources,buildHashes:build,previewDist,previewRuntimeHashes:previewHashes,previewRuntimeUnchanged:JSON.stringify(previewHashes)===JSON.stringify(runtimeHashes()),copiedBundleMatchesRootBuild:previewHashes?previewHashes['server/index.js']===build['dist/server/index.js']:null,sourceUnchanged:JSON.stringify(sources)===JSON.stringify(fileHashes(sourceFiles)),buildUnchanged:JSON.stringify(build)===JSON.stringify(fileHashes(buildFiles)),fixtureFileSha256:sha(fs.readFileSync(fixtureFile)),...extra,limits:['Read-only existing synthetic trusted-header loopback accounts. No POST, protected write, new fixture, provider, third-party message, production call or hosted authentication proof.','Interceptions modify only permitted local GET display copies; display-only orphan, missing-pin and language vectors are not proof of a stored server condition.','Unsent retention is navigation/authority remount memory only; this does not claim retention through browser close or reload.','390px and CSS-root 200% text checks plus keyboard/focus are bounded layout checks; no human screen-reader conformance or farmer/MSME field usability claim.']};
   fs.writeFileSync(path.join(out,name+'-result.json'),JSON.stringify(result,null,2)+'\n');
   console.log(JSON.stringify({passed,assertions:result.assertions,scenarios:result.executedScenarios,attemptedWrites:attemptedWrites.length,pageErrors:pageErrors.length,sourceUnchanged:result.sourceUnchanged,buildUnchanged:result.buildUnchanged,previewRuntimeUnchanged:result.previewRuntimeUnchanged,copiedBundleMatchesRootBuild:result.copiedBundleMatchesRootBuild}));
   return result;
  }
 };
}

/** One router blocks every non-read method and external origin. Transforms apply
 * only to an authenticated existing fixture's own /api/teams?id=... GET copy. */
export async function guardedContext(browser,user,r,{viewport={width:1440,height:1000},transform=null}={}){
 const context=await browser.newContext({extraHTTPHeaders:headers(user),viewport,serviceWorkers:'block'});
 await context.route('**/*',async route=>{
  const req=route.request(),url=new URL(req.url()),entry={method:req.method(),path:url.pathname};r.requests.push(entry);
  if(!localHosts.has(url.hostname)||url.origin!==new URL(base).origin){r.blockedExternal.push(entry);return route.abort('blockedbyclient');}
  if(!['GET','HEAD'].includes(req.method())){r.attemptedWrites.push(entry);return route.abort('blockedbyclient');}
  if(transform&&req.method()==='GET'&&url.pathname==='/api/teams'&&url.searchParams.has('id')){
   const response=await route.fetch({maxRedirects:0});
   if(response.status()!==200)return route.fulfill({response});
   const json=await response.json();
   await transform(json,{url,request:req});
   return route.fulfill({response,json});
  }
  return route.continue();
 });
 const page=await context.newPage();page.setDefaultTimeout(15000);
 page.on('pageerror',error=>r.pageErrors.push(error.message));
 return {context,page};
}
