import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {chromium,browserOptions,requireStable,fixtures,report,guardedContext,getSaved,jsonSha,out,base,loaded,button,navigate,pick,frames,text200,noOverflow,noMarkerStorage,headers} from './runtime.mjs';

requireStable();
const f=fixtures(),r=report(),browser=await chromium.launch(browserOptions),openContexts=[];
const focusSnapshots=[];
const existingReads=[['learner-a',f.a,f.teamId],['learner-b',f.b,f.teamId],['owner',f.owner,f.teamId],['person-team',f.person,f.personTeam.id],['person-lab',f.person,null],['other-lab',f.other,null]];
const savedBefore={},savedAfter={};
const savedStamp=j=>({revision:j.revision,state:j.state,content:j.team?.content,support:j.team?.support});
const ackName='I understand the request audience and kept private records out.';
const summaryName='Add saved learning-help details (optional)';
const prepareName='Add chosen details to my unsent description';
const genericPrefix='I would like help with access to learning.';
const disclosure=d=>d.locator('details').filter({has:d.getByText(summaryName,{exact:true})});
const ack=d=>d.getByRole('checkbox',{name:ackName,exact:true});
const submit=d=>button(d,'Submit help request');
const title=d=>d.getByRole('textbox',{name:'Request title',exact:true});
const body=d=>d.getByRole('textbox',{name:'Request description',exact:true});
const language=d=>d.getByRole('checkbox',{name:/^Include my requested learning language:/});
const assistance=d=>d.getByRole('checkbox',{name:/^Include my saved help request:/});
const courseCheck=d=>d.getByRole('checkbox',{name:/^Include this saved course title and language:/});
const preferredCopy=j=>{
 if(j.team?.id===f.teamId&&j.team?.currentUserId===f.a.id)
  j.state.learningAccess={schemaVersion:1,preferredLanguage:'hi',readAloudMode:'ask',assistancePreference:'capture-response'};
};
async function session(user=f.a,{workspace=f.teamId,view='support',viewport,transform=preferredCopy}={}){
 const ctx=await guardedContext(browser,user,r,{viewport,transform});openContexts.push(ctx.context);
 await ctx.page.goto(base+'/'+(workspace?'?workspace='+encodeURIComponent(workspace):'')+'#'+view);
 await loaded(ctx.page);return ctx;
}
async function intake(p){await button(p,'Request help').click();const d=p.getByRole('dialog',{name:'Request help in this workspace',exact:true});await d.waitFor();return d;}
async function expanded(d){await d.getByText(summaryName,{exact:true}).click();await language(d).waitFor();return disclosure(d);}
async function prepare(d){if(!(await button(d,prepareName).isVisible()))await expanded(d);await button(d,prepareName).click();await frames(d.page());await d.page().waitForTimeout(50);focusSnapshots.push(await d.evaluate(node=>{const active=document.activeElement,target=node.querySelector('#support-body');return {activeTag:active?.tagName,activeId:active?.id,activeRole:active?.getAttribute('role'),isDescription:active===target,isDialog:active===node,insideDialog:!!active&&node.contains(active),descriptionConnected:target?.isConnected===true,descriptionStillInExactDialog:target?.closest('[role="dialog"]')===node};}));}
async function allUnchecked(d,label){
 r.ok(!(await ack(d).isChecked()),label+' audience acknowledgement is unchecked');
 r.ok(!(await d.getByRole('checkbox',{name:/^Include my requested learning language:/,includeHidden:true}).isChecked())&&!(await d.getByRole('checkbox',{name:/^Include my saved help request:/,includeHidden:true}).isChecked()),label+' preference choices are unchecked');
 r.ok(await d.getByRole('checkbox',{name:/^Include this saved course title and language:/,includeHidden:true}).count()===0,label+' course details are not selected implicitly');
 r.ok(await submit(d).isDisabled(),label+' submit requires explicit acknowledgement');
}
async function unchangedFields(d,expected,label){
 r.ok(await title(d).inputValue()===expected.title,label+' preserves current title');
 r.ok((await d.getByRole('combobox',{name:'Support category',exact:true}).innerText())===expected.category,label+' preserves current category');
 r.ok((await d.getByRole('combobox',{name:'Cohort for support',exact:true}).innerText())===expected.cohort,label+' preserves current cohort');
}
async function localNoWrite(label){r.ok(r.attemptedWrites.length===0,label+' attempted no protected write');r.ok(r.blockedExternal.length===0,label+' made no external request');}
async function assertAckReset(d,label){r.ok(!(await ack(d).isChecked()),label+' clears acknowledgement');r.ok(await submit(d).isDisabled(),label+' disables submission');}
async function openOriginal(d){await pick(d,'Cohort for support','Original private record circle');await expanded(d);}
async function chooseOriginal(d){await pick(d,'My saved course in this selected cohort',f.firstPrivate.program.title);await courseCheck(d).waitFor();}
async function lifecycleRefresh(p,predicate){
 const response=p.waitForResponse(resp=>{const u=new URL(resp.url());return resp.request().method()==='GET'&&u.pathname==='/api/teams'&&u.searchParams.get('id')===f.teamId;});
 await p.evaluate(()=>document.dispatchEvent(new Event('visibilitychange')));
 await response;await frames(p);if(predicate)await predicate();
}
async function refreshRequests(p){const response=p.waitForResponse(resp=>{const u=new URL(resp.url());return resp.request().method()==='GET'&&u.pathname==='/api/teams'&&u.searchParams.get('id')===f.teamId;});await button(p,'Refresh requests').click();await(await response).finished();await frames(p);await loaded(p);}

try{
 for(const [key,user,workspace]of existingReads)savedBefore[key]=savedStamp(await getSaved(user,workspace));
 r.displayFixtures.push('Preference checks use only a local own GET copy for existing learner-a: Hindi/ask/capture-response. The saved preference is never changed.');

 await r.scenario('optional unchecked preparation preserves fields and excludes unchosen private details','existing own state plus preference display copy',async()=>{
  const {page:p,context:c}=await session(),d=await intake(p);
  await title(d).fill('General synthetic access question');await body(d).fill('Existing fictional description remains verbatim.');
  await pick(d,'Support category','Privacy');await openOriginal(d);await allUnchecked(d,'Fresh help intake');
  const expected={title:'General synthetic access question',category:'Privacy',cohort:'Original private record circle'};
  await ack(d).check();await prepare(d);
  const value=await body(d).inputValue();
  r.ok(value.startsWith('Existing fictional description remains verbatim.\n\n'+genericPrefix),'Unchecked preparation appends after existing text without replacement');
  r.ok(!value.includes('language: hi')&&!value.includes('read back')&&!value.includes(f.firstPrivate.program.title),'Unchecked preparation includes no private preferences or course title');
  await unchangedFields(d,expected,'Unchecked preparation');await assertAckReset(d,'Preparation');
  r.ok(await body(d).evaluate(n=>n===document.activeElement),'Preparation returns keyboard focus to current description');
  r.ok(!(await d.innerText()).includes('PRIVATE_RECORD_EVIDENCE')&&!(await d.innerText()).includes('PRIVATE_RECORD_PRACTICE'),'Disclosure does not copy course evidence or saved answers');
  await localNoWrite('Unchecked preparation');await c.close();
 });

 await r.scenario('explicit own exact course adds only chosen language/help/course details and resets choices','existing pinned edition plus preference display copy',async()=>{
  const {page:p,context:c}=await session(),d=await intake(p);
  await title(d).fill('Synthetic learning support');await body(d).fill('Keep this source text exactly.');await openOriginal(d);
  r.ok(await d.getByRole('combobox',{name:'My saved course in this selected cohort',exact:true}).innerText()==='My saved course in this selected cohort','Course starts with explicit empty selection');
  await chooseOriginal(d);await language(d).check();await assistance(d).check();await courseCheck(d).check();await ack(d).check();
  const expected={title:'Synthetic learning support',category:'Learning help',cohort:'Original private record circle'};
  await prepare(d);const value=await body(d).inputValue();
  r.ok(value.startsWith('Keep this source text exactly.\n\n'),'Explicit preparation retains the current description prefix');
  r.ok(value.includes('My requested learning language: hi.'),'Explicitly selected own language is included');
  r.ok(value.includes('my meaning read back to me'),'Explicitly selected own capture help is included');
  r.ok(value.includes('Course: '+f.firstPrivate.program.title+'. Saved course language: en.'),'Only the original exact selected enrollment title and language are included');
  r.ok(!value.includes(f.secondPrivate.program.title),'Preparation does not substitute the newer published edition');
  await unchangedFields(d,expected,'Chosen preparation');await allUnchecked(d,'After body preparation');
  r.ok(!value.includes('PRIVATE_RECORD_'),'Preparation includes no learner assessment evidence');
  await localNoWrite('Chosen preparation');await c.close();
 });

 await r.scenario('description boundary accepts exactly 2000 and refuses overflow without truncation','local typing and preparation only',async()=>{
  const {page:p,context:c}=await session(),d=await intake(p);await expanded(d);
  await title(d).fill('Synthetic bounded description');await body(d).fill('');
  await prepare(d);const prepared=await body(d).inputValue();r.ok(prepared.length>0&&prepared.length<2000,'Generic prepared text has a bounded measurable length');
  const prefix='x'.repeat(2000-prepared.length-2);await body(d).fill(prefix);await prepare(d);
  r.ok((await body(d).inputValue()).length===2000,'Exactly 2000 characters are accepted');
  r.ok(await body(d).inputValue()===prefix+'\n\n'+prepared,'Boundary append preserves all characters and separators');
  const tooLong='y'.repeat(2000-prepared.length-1);await body(d).fill(tooLong);await prepare(d);
  await d.getByRole('alert').filter({hasText:'2,000-character description limit'}).waitFor();
  r.ok(await body(d).inputValue()===tooLong,'Overflow leaves the original description untruncated');
  r.ok(await title(d).inputValue()==='Synthetic bounded description','Overflow leaves the original title');
  await assertAckReset(d,'Overflow attempt');await localNoWrite('Boundary preparation');await c.close();
 });

 await r.scenario('each input and own-help intent edit requires a fresh audience acknowledgement','local UI edits only',async()=>{
  const {page:p,context:c}=await session(),d=await intake(p);await title(d).fill('Synthetic audience question');await body(d).fill('Fictional description for audience checking.');await openOriginal(d);
  for(const [label,edit]of [
   ['title',()=>title(d).fill('Changed synthetic audience question')],
   ['description',()=>body(d).fill('Changed fictional description for audience checking.')],
   ['category',()=>pick(d,'Support category','Content concern')],
   ['cohort',()=>pick(d,'Cohort for support','Local customer practice circle')],
  ]){await ack(d).check();r.ok(!(await submit(d).isDisabled()),label+' starts from deliberately acknowledged intake');await edit();await assertAckReset(d,label+' edit');}
  await expanded(d).catch(()=>{}); // Details may stay open across keyed body refresh.
  if(!(await language(d).isVisible()))await expanded(d);
  await ack(d).check();await language(d).check();await assertAckReset(d,'Learning language disclosure intent');
  await ack(d).check();await assistance(d).check();await assertAckReset(d,'Assistance disclosure intent');
  await ack(d).check();await pick(d,'My saved course in this selected cohort',f.globalProgram.title);await assertAckReset(d,'Explicit own course choice');
  await ack(d).check();await courseCheck(d).check();await assertAckReset(d,'Course disclosure intent');
  await ack(d).check();await title(d).fill('Another synthetic title');await title(d).fill('Changed synthetic audience question');await assertAckReset(d,'Edit and undo');
  await localNoWrite('Acknowledgement edits');await c.close();
 });

 await r.scenario('audience change invalidates acknowledgement but retains own unsent text','intercepted own audience display reduction',async()=>{
  let changed=false;const transform=j=>{preferredCopy(j);if(changed&&j.team?.currentUserId===f.a.id){const cohort=j.team.cohorts.find(co=>co.id===f.sharedState.state.enrollments.find(e=>e.id===f.firstPrivate.enrollmentId).cohortId);cohort.status='paused';}};
  r.displayFixtures.push('Audience vector changes only the selected cohort status to paused in learner-a own GET copy; no server cohort or permission is changed.');
  const {page:p,context:c}=await session(f.a,{transform}),d=await intake(p);
  await title(d).fill('Synthetic retained audience title');await body(d).fill('Synthetic retained audience description.');await openOriginal(d);await ack(d).check();
  changed=true;await lifecycleRefresh(p,()=>ack(d).isChecked().then(checked=>assert.equal(checked,false)));
  await assertAckReset(d,'New accepted audience snapshot');
  r.ok(await title(d).inputValue()==='Synthetic retained audience title'&&await body(d).inputValue()==='Synthetic retained audience description.','Audience refresh keeps own unsent title and body');
  r.ok((await d.getByRole('combobox',{name:'Cohort for support',exact:true}).innerText())==='Original private record circle','Audience refresh does not retarget the chosen cohort');
  await localNoWrite('Audience display change');await c.close();
 });

 await r.scenario('same-account navigation and authority remount retain scoped input with acknowledgement reset','existing account plus deliberate denied-read fixture',async()=>{
  const {page:p,context:c}=await session(),d=await intake(p),marker='UNSENT_M3_EXISTING_A_PRIVATE';
  await title(d).fill('Synthetic retained intake title');await body(d).fill(marker);await openOriginal(d);await pick(d,'Support category','Accessibility');await ack(d).check();
  await p.keyboard.press('Escape');await navigate(p,'home');await navigate(p,'support');const reopened=await intake(p);
  r.ok(await title(reopened).inputValue()==='Synthetic retained intake title'&&await body(reopened).inputValue()===marker,'Same-account navigation remount retains title/body');
  r.ok((await reopened.getByRole('combobox',{name:'Support category',exact:true}).innerText())==='Accessibility','Navigation retains support category');
  r.ok((await reopened.getByRole('combobox',{name:'Cohort for support',exact:true}).innerText())==='Original private record circle','Navigation retains explicit cohort');await assertAckReset(reopened,'Navigation remount');
  await p.keyboard.press('Escape');let denied=true;const denyRoute=async route=>{if(denied){denied=false;return route.fulfill({status:403,contentType:'application/json',json:{error:'Synthetic read-only authority refresh check.'}});}return route.fallback();};
  await p.route('**/api/teams?id='+encodeURIComponent(f.teamId),denyRoute);
  await button(p,'Refresh requests').click();await p.getByRole('alert').first().waitFor();
  r.ok(!(await p.locator('main').innerText()).includes(marker),'Masked access does not expose retained unsent text');
  await p.unroute('**/api/teams?id='+encodeURIComponent(f.teamId),denyRoute);await button(p,'Retry connection').click();await loaded(p);const recovered=await intake(p);
  r.ok(await title(recovered).inputValue()==='Synthetic retained intake title'&&await body(recovered).inputValue()===marker,'Same-account authority remount recovers own scoped unsent inputs');await assertAckReset(recovered,'Authority remount');
  await noMarkerStorage(p,r.ok.bind(r),marker);await localNoWrite('Own unsent retention');await c.close();
 });

 await r.scenario('other account in same workspace cannot inherit prior intake scratch','existing learner-a then existing learner-b',async()=>{
  const {page:p,context:c}=await session(),d=await intake(p),marker='UNSENT_M3_ACCOUNT_A_ONLY';await title(d).fill('Synthetic account a only');await body(d).fill(marker);await ack(d).check();await p.keyboard.press('Escape');
  await c.setExtraHTTPHeaders(headers(f.b));await refreshRequests(p);const fresh=await intake(p);
  r.ok(await title(fresh).inputValue()===''&&await body(fresh).inputValue()==='','Accepted account change clears the former account title/body');
  r.ok((await fresh.getByRole('combobox',{name:'Cohort for support',exact:true}).innerText())==='Workspace access / not enrolled','Accepted account change does not inherit prior cohort choice');
  await assertAckReset(fresh,'Other account');r.ok(!(await p.locator('body').innerText()).includes(marker),'Other account renders no former unsent text');
  await noMarkerStorage(p,r.ok.bind(r),marker);await localNoWrite('Account boundary');await c.close();
 });

 await r.scenario('workspace navigation separates input and returns the same account own memory','existing personal lab and existing blank team',async()=>{
  const {page:p,context:c}=await session(f.person,{workspace:f.personTeam.id,transform:null}),d=await intake(p),marker='UNSENT_M3_PERSON_TEAM_ONLY';
  await title(d).fill('Synthetic workspace specific question');await body(d).fill(marker);await p.keyboard.press('Escape');
  await pick(p,'Choose Academy workspace','Personal practice lab');await loaded(p);await navigate(p,'support');
  r.ok(!(await p.locator('main').innerText()).includes(marker),'Personal lab does not display other workspace unsent intake');
  r.ok(await button(p,'Request help').count()===0,'Personal lab cannot expose shared workspace intake');
  await pick(p,'Choose Academy workspace',f.personTeam.name);await loaded(p);await navigate(p,'support');const returned=await intake(p);
  r.ok(await body(returned).inputValue()===marker&&await title(returned).inputValue()==='Synthetic workspace specific question','Returning to same account/workspace restores its own memory');
  await assertAckReset(returned,'Returned workspace');await noMarkerStorage(p,r.ok.bind(r),marker);await localNoWrite('Workspace boundary');await c.close();
 });

 await r.scenario('unknown saved pin cannot fall back to a newer edition','intercepted own unknown-pin display copy',async()=>{
  const transform=j=>{preferredCopy(j);if(j.team?.currentUserId===f.a.id){const e=j.state.enrollments.find(e=>e.id===f.firstPrivate.enrollmentId);e.contentRef.versionId='m3-unknown-exact-edition';e.version='m3-unknown-exact-edition';}};
  r.displayFixtures.push('Unknown-pin vector changes only learner-a own original enrollment ref/version in GET display copy; saved server pins remain unchanged.');
  const {page:p,context:c}=await session(f.a,{transform}),d=await intake(p);await title(d).fill('Synthetic unknown edition');await body(d).fill('Preserve the course scope explicitly.');await openOriginal(d);
  await pick(d,'My saved course in this selected cohort','Saved course edition unavailable');
  await d.getByText('This exact selected course edition cannot be confirmed. No other course will replace it.',{exact:true}).waitFor();
  r.ok(await courseCheck(d).count()===0,'Unknown exact edition offers no includable course checkbox');
  await language(d).check();await prepare(d);const value=await body(d).inputValue();
  r.ok(!value.includes(f.firstPrivate.program.title)&&!value.includes(f.secondPrivate.program.title)&&!value.includes(f.globalProgram.title),'Unknown pin preparation substitutes no other course title');
  await pick(d,'Cohort for support','Short review window record circle');
  if(!(await language(d).isVisible()))await expanded(d);
  r.ok(await d.getByRole('combobox',{name:'My saved course in this selected cohort',exact:true}).count()===0,'Another learner cohort offers none of their private enrollment data');
  r.ok(await courseCheck(d).count()===0,'Foreign learner enrollment is not implicitly included');await localNoWrite('Unknown pin and own enrollment boundary');await c.close();
 });

 await r.scenario('owner single content panel maps retired and elapsed editions to exact cohorts','actual owner canonical GET projection',async()=>{
  const {page:p,context:c}=await session(f.owner,{view:'operations',transform:null});const panel=p.locator('section[aria-labelledby="ops-content-title"]');await panel.waitFor();
  r.ok(await panel.count()===1&&await p.locator('#ops-content-title').count()===1,'Operations contains one Content review panel');
  r.ok(await p.locator('section[aria-labelledby="ops-support-title"]').count()===1,'Existing support panel appears once');
  r.ok(await panel.locator('[data-operations-support-id]').count()===0,'Content attention adds no support listing');
  const retired=panel.locator('[data-operations-content-id="'+f.firstPrivate.ref.versionId+'"]'),elapsed=panel.locator('[data-operations-content-id="'+f.secondPrivate.ref.versionId+'"]');await retired.waitFor();await elapsed.waitFor();
  r.ok((await retired.innerText()).includes('Retired publication · new enrollment closed'),'Original retired publication is called retired');
  r.ok((await retired.innerText()).includes('Original private record circle')&&!(await retired.innerText()).includes('Short review window record circle'),'Retired publication maps only its original exact cohort');
  r.ok((await elapsed.innerText()).includes('Publication review date elapsed'),'Newer publication is called elapsed at this observation');
  r.ok((await elapsed.innerText()).includes('Short review window record circle')&&!(await elapsed.innerText()).includes('Original private record circle'),'Elapsed edition maps only its own exact cohort');
  await retired.getByText('Exact publication reference',{exact:true}).click();
  r.ok((await retired.innerText()).includes(f.firstPrivate.ref.scope)&& (await retired.innerText()).includes(f.firstPrivate.ref.programId)&& (await retired.innerText()).includes(f.firstPrivate.ref.versionId),'Expanded publication uses its actual complete saved reference');
  r.ok((await retired.innerText()).includes('SHA256 '+f.firstPrivate.fingerprint),'Expanded publication retains its actual document hash');
  r.ok((await panel.innerText()).includes('Pausing learning and review is a separate current-owner action.'),'Retirement wording keeps pause as a separate permissioned step');
  r.ok(!(await panel.innerText()).includes('PRIVATE_RECORD_'),'Content summary contains no learner evidence');
  const link=button(retired,'Open exact content');await link.focus();await p.keyboard.press('Enter');await p.locator('[data-content-publication-id="'+f.firstPrivate.ref.versionId+'"]').waitFor();
  r.ok(new URL(p.url()).hash==='#teams','Exact publication link navigates to actual existing content destination');await localNoWrite('Owner operations navigation');await c.close();
 });

 await r.scenario('orphan author and reviewer attention offer bounded independent paths','intercepted current owner content GET copies only',async()=>{
  const now=Date.now(),future=new Date(now+14*86400000).toISOString();
  const syntheticIds=['m3-display-orphan-current-review','m3-display-orphan-approved','m3-display-orphan-lost-review'];
  const transform=j=>{
   if(j.team?.currentUserId!==f.owner.id)return;
   const source=j.team.content.drafts[0];assert.ok(source,'Existing retained draft source');
   const authorId=f.b.id,reviewerId=f.contentOwner.id;
   assert.ok(j.team.members.some(m=>m.userId===reviewerId&&m.active&&m.roles.includes('admin')),'Existing current independent owner');
   const make=(id,state,reviewer)=>({...structuredClone(source),id,state,authorId,authorName:'Former synthetic author',reviewerId:reviewer,reviewDueAt:future,document:{...structuredClone(source.document),title:id}});
   j.team.content.drafts.push(make(syntheticIds[0],'in_review',reviewerId),make(syntheticIds[1],'approved',reviewerId),make(syntheticIds[2],'in_review',authorId));
  };
  r.displayFixtures.push('Orphan vector adds three labelled display-only rows copied from an already retained owner draft. Uses existing learner-b former author/current content-owner independent reviewer; no draft, role or reviewer assignment is stored.');
  const {page:p,context:c}=await session(f.owner,{view:'operations',transform}),panel=p.locator('section[aria-labelledby="ops-content-title"]');
  const current=panel.locator('[data-operations-content-id="'+syntheticIds[0]+'"]'),approved=panel.locator('[data-operations-content-id="'+syntheticIds[1]+'"]'),lost=panel.locator('[data-operations-content-id="'+syntheticIds[2]+'"]');await current.waitFor();
  r.ok((await current.innerText()).includes('The assigned independent owner may review the saved draft.'),'Author loss retains current independent review route');
  r.ok((await current.innerText()).includes('author edit authority cannot transfer'),'Orphan guidance does not transfer author edit authority');
  r.ok((await approved.innerText()).includes('may publish the unchanged approved document after server checks'),'Author loss alone does not invent a publication block');
  r.ok((await lost.innerText()).includes('former author cannot recall for fresh review')&&(await lost.innerText()).includes('archive this unpublished draft to preserve history, then start a separate draft'),'Lost reviewer guidance preserves history and requests a separate draft');
  r.ok((await panel.innerText()).includes('3 drafts have a former author'),'Owner panel count includes all three author attention rows');
  r.ok(await panel.locator('[data-operations-support-id]').count()===0,'Orphan content rows do not duplicate support');await localNoWrite('Orphan display guidance');await c.close();
 });

 await r.scenario('facilitator reduction and learner view exclude owner private content panel','intercepted role reduction plus actual learner GET',async()=>{
  const transform=j=>{
   if(j.team?.currentUserId!==f.owner.id)return;
   j.team.roles=['facilitator'];j.team.assigned=[];j.team.summaries=[];
   j.team.content.drafts[0].document.title='M3_FACILITATOR_PRIVATE_AUTHORING_CANARY';
   j.team.cohorts=j.team.cohorts.slice(0,1);j.team.cohorts[0].canHost=true;
  };
  r.displayFixtures.push('Facilitator vector reduces an existing owner own display roles to facilitator and scopes one existing cohort; retained owner-only source canary must remain excluded. This is a UI model fixture, not a server-role change or facilitator authorization proof.');
  const one=await session(f.owner,{view:'operations',transform});await one.page.locator('[data-operations-workspace="'+f.teamId+'"]').waitFor();
  r.ok(await one.page.locator('#ops-content-title').count()===0,'Facilitator view has no owner Content review panel');
  r.ok(!(await one.page.locator('main').innerText()).includes('M3_FACILITATOR_PRIVATE_AUTHORING_CANARY'),'Facilitator content model excludes private authoring data even when present in display fixture');
  r.ok(await one.page.locator('section[aria-labelledby="ops-support-title"]').count()===1,'Facilitator retains one existing scoped support panel');await one.context.close();
  const two=await session(f.a,{view:'operations',transform:null});r.ok(await two.page.locator('#ops-content-title').count()===0,'Learner cannot display owner content attention through route navigation');r.ok(!(await two.page.locator('main').innerText()).includes(f.secondPrivate.program.title),'Learner operations route exposes no other learner edition');await localNoWrite('Content audience boundary');await two.context.close();
 });

 await r.scenario('390px and 200 percent text keep intake usable with keyboard focus and cancel return','local responsive and keyboard UI only',async()=>{
  const {page:p,context:c}=await session(f.a,{viewport:{width:390,height:844}}),d=await intake(p);await title(d).fill('Synthetic phone learning request');await body(d).fill('Fictional details that stay on this device until deliberate submission.');await openOriginal(d);await chooseOriginal(d);await noOverflow(p,r.ok.bind(r),'390px intake');await text200(p);await noOverflow(p,r.ok.bind(r),'390px 200% text intake');
  r.ok(await d.evaluate(node=>{const x=node.getBoundingClientRect();return x.left>=-1&&x.right<=innerWidth+1&&x.top>=-1&&x.bottom<=innerHeight+1;}),'Enlarged dialog remains within phone viewport with scrollable content');
  const detail=disclosure(d);await language(d).focus();await p.keyboard.press('Space');r.ok(await language(d).isChecked(),'Disclosure checkbox works with keyboard Space');
  await button(d,prepareName).focus();await p.keyboard.press('Enter');await frames(p);await p.waitForTimeout(50);r.ok(await body(d).evaluate(n=>n===document.activeElement),'Keyboard preparation returns focus to description');
  for(let n=0;n<18;n++){await p.keyboard.press('Tab');r.ok(await d.evaluate(node=>node.contains(document.activeElement)),'Tab '+(n+1)+' remains inside modal dialog');}
  await button(d,'Cancel').focus();await p.keyboard.press('Shift+Tab');r.ok(await d.evaluate(node=>node.contains(document.activeElement)),'Shift+Tab remains inside modal');
  await p.screenshot({path:path.join(out,'help-mobile-200-percent.png'),fullPage:false});
  await p.keyboard.press('Escape');await d.waitFor({state:'hidden'});r.ok(await button(p,'Request help').evaluate(n=>n===document.activeElement),'Escape restores focus to current Request help button');
  await localNoWrite('Phone keyboard preparation');await c.close();
  const owner=await session(f.owner,{view:'operations',transform:null,viewport:{width:390,height:844}});await text200(owner.page);await owner.page.locator('section[aria-labelledby="ops-content-title"]').waitFor();await noOverflow(owner.page,r.ok.bind(r),'390px 200% text content attention');await owner.page.screenshot({path:path.join(out,'content-mobile-200-percent.png'),fullPage:true});await owner.context.close();
 });

 for(const [key,user,workspace]of existingReads){savedAfter[key]=savedStamp(await getSaved(user,workspace));r.ok(jsonSha(savedAfter[key])===jsonSha(savedBefore[key]),'Read-only suite leaves saved '+key+' state/revision/content/support unchanged');}
 r.ok(r.pageErrors.length===0,'No browser page exceptions');r.ok(r.attemptedWrites.length===0,'Entire suite attempted zero protected writes');r.ok(r.blockedExternal.length===0,'Entire suite attempted zero external page requests');r.pass();
}catch(error){
 for(const [i,c]of openContexts.entries())for(const p of c.pages())await p.screenshot({path:path.join(out,'readonly-failure-'+i+'.png'),fullPage:false}).catch(()=>{});
 r.cases.push({name:'run failure',passed:false,error:String(error)});throw error;
}finally{
 for(const c of openContexts)await c.close().catch(()=>{});await browser.close();
 for(const [key,user,workspace]of existingReads)if(savedBefore[key]&&!savedAfter[key]){try{savedAfter[key]=savedStamp(await getSaved(user,workspace));}catch(error){r.cases.push({name:'final read '+key,passed:false,error:String(error)});}}
 r.finish({browsersClosed:true,focusSnapshots,savedBeforeHashes:Object.fromEntries(Object.entries(savedBefore).map(([k,v])=>[k,jsonSha(v)])),savedAfterHashes:Object.fromEntries(Object.entries(savedAfter).map(([k,v])=>[k,jsonSha(v)]))});
}
