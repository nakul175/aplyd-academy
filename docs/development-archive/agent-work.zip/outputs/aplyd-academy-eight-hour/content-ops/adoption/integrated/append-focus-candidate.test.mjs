import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';

// Execute the exact staged function text in a synthetic DOM/RAF environment.
// These are candidate guard checks, not an application build/browser test.
const text=fs.readFileSync(new URL('./append-focus-replacement.ts.txt',import.meta.url),'utf8');
const code=stripTypeScriptTypes('function createCandidate(ctx:any){const {useRef,useEffect,scope,audience,open,setAckFor,setBody,document,requestAnimationFrame,cancelAnimationFrame}=ctx;'+text+'\nreturn {append,change,boundary:appendBoundary,pending:pendingAppendFocus};}');
const createCandidate=new Function(code+';return createCandidate;')();
function environment(){
 const listeners=new Map(),frames=new Map(),effects=[],cleanups=[];let id=0,focusCalls=0;
 const doc={body:{kind:'body'},activeElement:null,currentDialog:null,currentTarget:null,dialogCount:1,
  getElementById(){return this.currentTarget;},querySelectorAll(){return Array(this.dialogCount).fill(this.currentDialog);},
  addEventListener(type,fn){if(!listeners.has(type))listeners.set(type,new Set());listeners.get(type).add(fn);},
  removeEventListener(type,fn){listeners.get(type)?.delete(fn);},
  dispatch(type,target){for(const fn of [...listeners.get(type)??[]])fn({target});},
 };
 const dialog={kind:'dialog',isConnected:true,state:'open',getAttribute(){return this.state;},querySelector(){return doc.currentTarget;}};
 const target={kind:'description',isConnected:true,dialog,closest(){return this.dialog;},focus(){focusCalls++;doc.activeElement=this;doc.dispatch('focusin',this);}};
 const opener={kind:'prepare',isConnected:true},other={kind:'new-focus',isConnected:true};
 doc.currentDialog=dialog;doc.currentTarget=target;doc.activeElement=opener;
 const ctx={scope:'existing-a/existing-team',audience:'current-own-audience',open:true,document:doc,
  useRef:value=>({current:value}),useEffect:fn=>effects.push(fn),
  setAckFor(){},setBody(){opener.isConnected=false;doc.activeElement=dialog;doc.dispatch('focusin',dialog);},
  requestAnimationFrame:fn=>{const n=++id;frames.set(n,fn);return n;},cancelAnimationFrame:n=>frames.delete(n),
 };
 const model=createCandidate(ctx);for(const effect of effects){const cleanup=effect();if(cleanup)cleanups.push(cleanup);}
 return {doc,dialog,target,opener,other,model,ctx,listeners,focusCalls:()=>focusCalls,
  flush(){for(const [n,fn]of [...frames]){frames.delete(n);fn();}},unmount(){for(const fn of cleanups)fn();},
  listenerCount(){return [...listeners.values()].reduce((n,set)=>n+set.size,0);},
 };
}
function noFocus(label,edit){test(label,()=>{const e=environment();e.model.append('Own prepared text');edit(e);e.flush();assert.equal(e.focusCalls(),0);assert.equal(e.listenerCount(),0);assert.equal(e.model.pending.current,null);});}

test('same live dialog fallback after opener removal focuses current description',()=>{const e=environment();e.model.append('Own prepared text');assert.equal(e.doc.activeElement,e.dialog);e.flush();assert.equal(e.doc.activeElement,e.target);assert.equal(e.focusCalls(),1);assert.equal(e.listenerCount(),0);assert.equal(e.model.pending.current,null);});
test('current description focus remains a permitted destination',()=>{const e=environment();e.model.append('Own prepared text');e.doc.activeElement=e.target;e.flush();assert.equal(e.focusCalls(),1);});
noFocus('another input focus is respected',e=>{e.doc.activeElement=e.other;});
noFocus('new pointer intent cancels even when dialog fallback remains',e=>e.doc.dispatch('pointerdown',e.dialog));
noFocus('new keyboard intent cancels even when dialog fallback remains',e=>e.doc.dispatch('keydown',e.dialog));
noFocus('new input intent cancels',e=>e.doc.dispatch('input',e.target));
noFocus('new focus intent cancels even if focus later returns to container',e=>{e.doc.activeElement=e.other;e.doc.dispatch('focusin',e.other);e.doc.activeElement=e.dialog;});
noFocus('closed dialog does not reclaim focus',e=>{e.dialog.state='closed';});
noFocus('closed intake boundary does not reclaim focus',e=>{e.model.boundary.current.open=false;});
noFocus('account/workspace scope change does not reclaim focus',e=>{e.model.boundary.current.scope='existing-b/existing-team';});
noFocus('current audience change does not reclaim focus',e=>{e.model.boundary.current.audience='reduced-current-audience';});
noFocus('disconnected target does not reclaim focus',e=>{e.target.isConnected=false;});
noFocus('replacement description in same dialog does not reclaim focus',e=>{e.doc.currentTarget={kind:'replacement'};});
noFocus('description moved to another dialog does not reclaim focus',e=>{e.target.dialog={kind:'replacement'};});
noFocus('additional open dialog prevents reclaim',e=>{e.doc.dialogCount=2;});
noFocus('connected opener does not permit arbitrary dialog fallback',e=>{e.opener.isConnected=true;});
noFocus('manual input update cancels pending preparation focus',e=>{e.model.change(()=>{},'Edited text');});
noFocus('unmount cancels pending frame and listeners',e=>{e.unmount();});
test('a second preparation cancels older frame and reclaims only once',()=>{const e=environment();e.model.append('First');e.model.append('Second');e.flush();assert.equal(e.focusCalls(),1);assert.equal(e.listenerCount(),0);assert.equal(e.model.pending.current,null);});
