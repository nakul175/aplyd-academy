# M3 read-only browser acceptance

Completed against root frozen Worker 74111 and copied preview `/private/tmp/academy-m3-preview-jj_n9j8a/dist`: 13 full scenarios / 170 assertions and five focused guard scenarios / 30 assertions passed, for 200 selected browser assertions. The first M3 runs on Worker 34352 confirmed a preparation focus defect after 11 privacy/preservation assertions. Root adopted the guard; the rebuilt actual-root focus proof passed. The 19 synthetic candidate checks remain counted separately. All initial attempts are retained. No app checkout edit, build, server start or restart is part of this harness.

The existing owner `Content review` section is replaced in place. Root integration keeps its existing `content.available` owner guard. The replacement contains no support listing or second dashboard. Its adapter returns null for facilitators and includes no support bodies, learner evidence, learning preferences or facilitator private authoring data.

## Execution boundary

- Existing approved fictional accounts and IDs come from `../../../record-verification/integrated/evidence/fixtures.json`. That file is only read. It is not an authority snapshot: current GET responses supply accepted displays.
- Browser network routing aborts every method other than GET/HEAD and every nonlocal origin. The suite never clicks Submit, Save, Claim, Publish, Retire, Create or any other protected action.
- Preparation changes only the unsent description. Clicking the named prepare button is deliberate local UI typing/navigation work.
- Before and after GET reads compare saved own state, revision, content and support for the six relevant existing account/workspace combinations. No new identity, account, workspace, enrollment, support request, draft or publication is created.
- The helper functions contain no mutation API and make no network call at import time. A stable flag and root Worker session identifier are mandatory when executing, but not for syntax checks.
- Root source/build hashes and fixture file hash are captured. Every browser/context closes in `finally`, including failure paths.

After the root explicitly freezes the adopted build and signals a Worker session, run from the project root with the bundled Node binary:

```sh
ACADEMY_M3_READONLY_STABLE=1 ACADEMY_M3_WORKER=ROOT_SESSION_ID /Users/athena/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node outputs/aplyd-academy-eight-hour/content-ops/adoption/integrated/readonly-browser.mjs
```

The default origin is `http://127.0.0.1:8787`; `ACADEMY_LOCAL_URL` may change it only to loopback HTTP. This harness uses headless installed Google Chrome and the bundled Playwright. It starts no application server.

`ACADEMY_M3_CASES=1,13` selects numbered scenarios for a focused rerun; skipped cases remain explicitly marked and do not count as passed. `focus-browser.mjs` is a separate five-case focused guard suite with its own `focus-browser-result.json`. It checks keyboard preparation after two frames plus 50ms, deliberate new title focus, new keyboard intent, Cancel before the frame, and navigation/remounted-dialog focus. It uses actual local controls/DOM focus events and installs no artificial RAF scheduler or React internal hook.

## Thirteen bounded scenarios

1. Optional help choices start unchecked; explicit generic preparation appends without exposing unchosen preferences, title or evidence. Title/category/cohort survive. Acknowledgement resets and focus returns to description.
2. Explicitly selected own original exact course, language and assistance text are included. A newer edition does not replace the pin. Body changes reset disclosure choices.
3. Exactly 2,000 characters succeed; overflow leaves all original text/title unchanged and explains the limit without truncation.
4. Title, body, category, cohort, each help intent, selected course and edit/undo all require fresh acknowledgement.
5. A fresh accepted audience snapshot resets acknowledgement while preserving own unsent text and chosen cohort.
6. Same-account navigation and denied-read/refresh authority remount preserve scoped memory; reopening requires new acknowledgement. No scratch is written to localStorage/sessionStorage.
7. Another existing account in the same workspace does not receive prior unsent input or cohort choice.
8. Switching between an existing blank shared workspace and its existing personal lab excludes other workspace text; returning restores that same account/workspace memory.
9. An unknown saved pin and another learner's cohort offer no replacement or foreign enrollment details.
10. Actual owner retired/elapsed publications map only their exact cohort, reference and hash. One content section and one support section remain. Keyboard navigation opens the exact existing content destination.
11. Former author/current reviewer, approved unchanged draft and former reviewer examples describe independent review/publication or archive/separate-draft paths without transferring author edit rights.
12. A reduced facilitator display excludes owner private authoring data and content panel; actual learner navigation excludes the owner view.
13. At 390px and CSS-root 200% text, the intake and content attention fit horizontally. Dialog bounds, keyboard check/prepare, Tab/Shift+Tab containment and Escape focus return are checked.

## Explicit display-only fixtures

Only local GET response copies change for these vectors; the server is untouched:

- Existing learner-a's own preference copy requests Hindi/ask/capture-response, permitting check of explicit selection wording. This is not evidence that those preferences were stored.
- Audience check changes the current selected cohort status to paused in learner-a's own returned display. It does not pause a stored cohort or grant authority.
- Missing-pin check changes only learner-a's original enrollment pin in its own returned display. It does not corrupt a saved enrollment.
- Former-author examples append three labelled rows copied from an existing retained owner draft, using existing account IDs. These are rendered model fixtures, not stored drafts or assignments.
- Facilitator check reduces the current owner display role and scopes one existing cohort. A private authoring canary remains in the local copy to prove it is not rendered. This is not actual facilitator login or authorization testing.

The actual owner publication/cohort reference and hash check uses current unaltered GET. The actual account/workspace privacy checks use existing unaltered identities and current acceptance boundaries.

## Evidence and limits

Execution writes `readonly-browser-result.json` with scenario kinds, assertions, method/path request log, attempted-write/external-request counts, source/build hashes, saved-state hashes and closure confirmation. Phone screenshots are `help-mobile-200-percent.png` and `content-mobile-200-percent.png`. Failure screenshots remain beside the report.

`consolidated-result.json` binds the two successful reports, source/dist/copied-preview hashes, six saved-fixture comparisons and closure confirmation. No protected write or external page request was attempted, and no page exception occurred. The phone screenshots were visually reviewed; the long content image also has read-only inspection crops to preserve readable 390px text in the image viewer. These crops are diagnostic evidence, not app edits.

Do not call these assertions independent field-user cases. The suite does not claim hosted authentication, manual VoiceOver, actual browser zoom certification, staffed service, provider AI, external notification, sector approval, accommodation approval or retention after browser close/reload. Read-only execution deliberately does not test protected submit transport or stored support-request creation.
