# M3 support preparation focus finding

The adopted preparation preserves current title/category/cohort and appends its text correctly. Preparing changes `currentBody`, so `OwnLearningHelpDisclosure` remounts its keyed body. This removes the clicked prepare button. Radix FocusScope moves focus to the same live `DialogContent` DIV; the current append guard permits only body/opener/description and declines that dialog fallback.

The failure persists after two animation frames plus 50ms. Captured active element is `DIV`, id `radix-_r_4_`, role `dialog`, exactly the current intake dialog. `#support-body` remains connected and in that exact dialog. The keyboard user receives no reliable move to the newly appended description.

Attempt 01 is a harness-only portal selector issue. Attempts 02/03 and the 50ms confirmation demonstrate the product focus issue. They passed 11 preparation/privacy/preservation assertions before the focus check stopped the suite. No writes, external page requests or page exceptions occurred. In settled confirmations, all six existing account/workspace saved-state/revision/content/support hashes match before and after; source and dist hashes also match. All browsers were closed.

`append-focus-replacement.ts.txt` is an outside-checkout candidate. It admits the current dialog fallback only when the captured opener was removed, keeps the exact description/dialog identity, checks current scope/audience/open state, refuses additional/replacement dialogs and cancels on new pointer/key/input/focus intent. Listeners and pending animation frames are cleaned on input edits, scope/open changes and unmount. Root owns review, adoption, typecheck/build and a new stable signal.

Once adopted and stable, first rerun scenario 1. Then run the unexecuted scenarios and mobile keyboard preparation. Additional focused checks should click prepare and synchronously focus the title before the frame, close before the frame, and replace the account/workspace before the frame; the old description must not reclaim focus. None of these actions submit or save support requests.
