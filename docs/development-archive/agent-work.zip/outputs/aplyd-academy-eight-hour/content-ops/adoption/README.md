# M3 content operations and own learning-help adoption candidate

Staged outside the checkout. Root owns source adoption, compilation, a stable preview and any runtime checks. This workstream executed only isolated pure tests; it started no build, server, browser, API, provider or external message after the M2 guidance checks closed.

## What changes

The existing owner **Content review** panel is replaced in place. Existing review, support, session and cohort snapshot panels remain. The tested 19-case readiness model supplies exact publication/cohort mapping, retired/elapsed/unknown publication attention, and truthful current author/reviewer continuity instructions. A small adapter returns content attention only; it adds no second support dashboard or staff preference count. Publication references/hashes can be read in a bounded disclosure, and buttons navigate through existing operation destinations/focus fences. They do not publish, claim, retire, pause or modify authority.

The optional disclosure sits inside the ordinary requester **Intake**. It uses the current authenticated learner's accepted `state.learningAccess` via the existing `readAccessPreferences`. It never reads staff preference state or takes preferences from an operations projection. All inclusion choices and optional course selection start empty. A course must be explicitly chosen among the requester's own nonwithdrawn enrollments in the currently selected support cohort; both enrollment and cohort must retain the same exact resolved reference. Workspace-only, missing, unknown, withdrawn or changed references yield no course and no fallback.

**Add chosen details** appends only the current unsent description. It preserves the existing title, category and cohort; it does not fill a generated title or silently move a learning request to Accessibility. The ordinary category choice and audience explanation still apply. The 2,000-character limit is checked before writing to in-memory input; overflow leaves all entered text and fields unchanged, without truncation. It grants no approved translation, helper access or accommodation.

Intake subject/body/category/cohort use the existing account/workspace-scoped `useWorkspaceDraft` memory policy. Closing/reopening or a permission-refresh remount retains unsent text in the same scope; none of it is automatically saved or posted. Audience acknowledgement stays local, starts false, resets on open/close/context/audience changes, and is cleared synchronously by every input/disclosure edit—even if the learner later restores the old text. Its in-memory equality key also fences a render after a context change. No acknowledgement key or preference selection is persisted or sent. Removed cohort selection is retained with a clear instruction; it is not silently retargeted.

The normal protected `support-open` command and its audience acknowledgement remain the final separate submit action. The existing HTML bounds and server category/cohort/permission validation remain. Successful submission clears only the acknowledged intake subject/body as before. Unknown/lost response keeps the learner's unsent inputs under the existing command handling. The guarded append focus callback targets the already-connected own description only; it cannot focus a replacement account/workspace dialog.

## Root file mapping

| Staged file | Destination |
| --- | --- |
| `academy-content-readiness.ts` | `lib/academy-content-readiness.ts` |
| `academy-content-readiness-adoption.mjs` | `lib/academy-content-readiness-adoption.mjs` |
| `academy-content-readiness-adoption.d.mts` | `lib/academy-content-readiness-adoption.d.mts` |
| `OperationsContentAttention.tsx` | `app/academy-content-readiness.tsx` |
| `OwnLearningHelpDisclosure.tsx` | `app/academy-learning-help-disclosure.tsx` |
| `existing-root-integration.patch` | Reviewed patch for existing `app/academy-operations.tsx` and `app/academy-support.tsx` |

The patch replaces only the existing content section and ordinary Intake, plus their imports. Full review copies are `academy-operations.tsx.candidate` and `academy-support.tsx.candidate`; `Intake-replacement.tsx.txt` isolates the latter function. The original base 19-case module is copied unchanged from the prior workstream. The adapter's `.mjs` imports this leaf `.ts`, which the bundled Node runtime strips for pure checks and the app bundler resolves on root adoption.

## Validation and limits

`tests/content-readiness.test.mjs` preserves the 19 original cases. `tests/adoption.test.mjs` adds content-only adapter/privacy checks, append preservation/overflow/exact 2,000-character boundary, explicit own-course/no-fallback/pin/cohort checks, malformed resolver refusal, and the acknowledgement context equality fence. `candidate-evidence.json` records results and staged/root hashes.

These are isolated candidate model cases. TSX compilation and actual-root/browser/API behavior are unexecuted in this M3 candidate; root must review and compile the adopted source. No field-user UAT, manual screen-reader assessment, operational staffing or sector approval is claimed. The only earlier stopped candidate test used a mistakenly oversized test fixture; it was corrected to test a valid current body that overflows after append. No product source was changed.

## Focused integrated checks after a new stable signal and authorization

1. Owner sees one Content review panel. A retired publication maps only cohorts pinned to that exact reference; another edition with the same program does not join the list. Exact content/cohort buttons open the existing specific row/editor using current navigation focus fencing. No command is sent by these buttons.
2. Remove author/reviewer owner authority. Verify the retained draft shows the correct independent-review/publication/archive path without transferring authorship. A future review date is not described as a response deadline. Elapsed client observation and accepted server content-enrollment state remain distinct.
3. Facilitator/assessor/removed member has no owner content panel, raw protected source or preference counts. Existing support/review/session/cohort panels remain single and use their original authority.
4. Open ordinary Intake, type a general title/body, pick category/cohort and acknowledge audience. Edit each input, change a disclosure choice, close/reopen, refresh permissions, or change account/workspace: acknowledgement must become false; permitted unsent text remains scoped and is never copied to another account/workspace.
5. All help choices start unchecked. Prepare with none/language/help/course separately. Only deliberately chosen details enter the description; title/category/cohort remain exact. Selecting a course is required separately, in the current cohort. Unknown/foreign/withdrawn/changed edition has no fallback and no evidence/answer key in the description.
6. A description near 2,000 characters rejects append and remains byte-for-byte unchanged. Exactly 2,000 characters is accepted. Successful append returns focus to the description when its own dialog is still connected, with a fresh audience acknowledgement required.
7. At 390px with 200% text, the existing modal scrolls, checkbox names match visible labels, details/buttons wrap, keyboard focus remains inside the ordinary dialog, and closing it restores its existing opener. No nested dialog is introduced.
8. Only explicit **Submit help request** posts `support-open`; its acknowledged content is the user's final visible description. Lost acknowledgement retains inputs. Existing independent handler and queue/body privacy contracts remain unchanged; no external message or provider request occurs.
