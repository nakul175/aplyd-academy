# Eight-hour sprint documentation candidate

**Snapshot:** 6 October 2026 · development/academy-eight-hour-20261006 · baseline HEAD `daf0fb393862d2c2f62ce91f33f633629cfdca13`. Exact observation time and file hashes are in [source-manifest.json](source-manifest.json).

This pack describes the root checkout as read during integration. It stays outside the checkout until the release owner reconciles it with the final commit/build. It does not supersede archived v0.1 documents or imply that the original reference architecture/API/schema was implemented wholesale.

| Artifact | Purpose |
|---|---|
| [FSD delta](fsd-delta.md) | Observable learner behavior, current limits and adoption boundaries |
| [HLD delta](hld-delta.md) | Actual runtime, data flow and trust boundaries |
| [LLD delta](lld-delta.md) | Current algorithms, CAS/receipt rules, offline protocol and migration behavior |
| [API and command register](api-and-commands.json) | Six actual method/path contracts; command payloads and acceptance guards |
| [Data dictionary](data-dictionary.tsv) | Seven D1 tables/32 columns plus new JSON, wire and local shapes;107 rows |
| [Test matrix](test-matrix.tsv) | Concrete expected results, existing evidence and unexecuted release vectors |
| [Evidence register](evidence-register.json) | Evidence provenance and current-source hash comparisons |
| [Source manifest](source-manifest.json) | Read-time hashes, baseline migration preservation and archive identity |

## Status language

- **Implemented source:** code is present and wired in the checkout; no runtime claim follows from presence.
- **Existing actual local proof:** a persisted local API/browser/pure/probe result exists for its stated source and fixture scope.
- **Reported root proof:** root sprint log reports a result; this pack does not invent missing test transcripts.
- **Candidate-only proof:** isolated candidate was tested; root adoption/integrated runtime is a separate question.
- **Not run:** acceptance vector is specified but not executed for the final integrated build.

Do not add counts from these levels into one passing-suite total. Source changes after a result require relevant regression. Local fixtures do not prove hosted authentication, production migration, recognition, external transport or human assistive-technology usability.

## Current boundary

Present in root source: fresh private snapshot export/local inspection; own language/help preferences and learner-declared read-back; context-bound response acceptance; canonical personal offline read; sealed local text drafts and explicit reconnect/save; additive directory projection and exact aggregate RETURNING checks. Root reports migration0005 applied successfully to the isolated/local app DB (seven commands). Current integrated build and stable browser/regression are running or pending; production migration/publication remain unexecuted.

Record-status and ecosystem-readiness panels are separately tested candidates outside the checkout. Live AI awaits explicit credential choice; reviewed translations, recognized external issuer and first live partner API documentation have not been supplied. None is represented as working live capability here.

The release owner must record final source/commit, exact build/test evidence, main merge and private publication outcome before promoting this pack to final as-built status.
