// Root-run isolated compilation only; not executed by the preparing agent.
import {resolve,dirname} from 'node:path';
import {mkdirSync} from 'node:fs';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),app=resolve(process.env.ACADEMY_APP_PATH??'work/aplyd-academy');
const require=createRequire(app+'/package.json'),esbuild=require('esbuild');
const out=resolve(process.env.ACADEMY_ACCEPTANCE_QA_OUT??here+'/runtime');mkdirSync(out,{recursive:true});
await esbuild.build({entryPoints:[here+'/academy-acceptance.candidate.ts'],bundle:true,platform:'node',format:'esm',outfile:out+'/academy-acceptance.mjs',plugins:[{name:'actual-checkout-dependencies',setup(build){build.onResolve({filter:/^\.\/academy-response$/},()=>({path:app+'/app/academy-response.ts'}));build.onResolve({filter:/^\.\.\/lib\/academy-curriculum$/},()=>({path:app+'/lib/academy-curriculum.ts'}));}}]});
console.log(out+'/academy-acceptance.mjs');
