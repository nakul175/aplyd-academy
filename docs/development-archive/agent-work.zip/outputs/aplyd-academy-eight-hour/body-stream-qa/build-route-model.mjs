import {createRequire} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {app,output} from './qa-paths.mjs';
const require=createRequire(app+'/package.json'),esbuild=require('esbuild');
const host=`
export const metrics={authCalls:0,sql:[],reads:0,allCalls:0,batches:0,runs:0};
let identity,config;
const canary='PRIVATE_DB_FAILURE_CANARY';
export function resetHost(options={}){identity=Object.hasOwn(options,'identity')?options.identity:{userId:'qa-body-readonly',email:'body-readonly@academy.test',fullName:'Synthetic readonly learner'};config=options;Object.assign(metrics,{authCalls:0,sql:[],reads:0,allCalls:0,batches:0,runs:0});env.DB=database;}
const database={prepare(sql){metrics.sql.push({sql,args:[]});const index=metrics.sql.length-1;const statement={bind(...args){metrics.sql[index].args=args;return statement;},async first(){metrics.reads++;if(config.fault)throw new Error(canary);return config.row??null;},async all(){metrics.allCalls++;if(config.fault)throw new Error(canary);return {results:[]};},async run(){metrics.runs++;throw new Error('Mock refuses all SQL writes');}};return statement;},async batch(){metrics.batches++;throw new Error('Mock refuses all SQL batches');}};
export const env={DB:database};
export async function getChatGPTUser(){metrics.authCalls++;return identity;}
resetHost();
`;
const entry=output+'/actual-route-entry.ts';
writeFileSync(entry,`export {GET as personalGET,POST as personalPOST} from ${JSON.stringify(app+'/app/api/academy/route.ts')};export {GET as sharedGET,POST as sharedPOST} from ${JSON.stringify(app+'/app/api/teams/route.ts')};export {POST as recordPOST} from ${JSON.stringify(app+'/app/api/academy/records/check/route.ts')};export {env,metrics,resetHost} from 'body-qa-host';`);
await esbuild.build({entryPoints:[entry],bundle:true,platform:'node',format:'esm',outfile:output+'/actual-routes.mjs',tsconfig:app+'/tsconfig.json',plugins:[{name:'explicit-in-memory-host',setup(build){build.onResolve({filter:/^(cloudflare:workers|body-qa-host)$|chatgpt-auth$/},()=>({path:'body-qa-host',namespace:'body-qa-host'}));build.onLoad({filter:/.*/,namespace:'body-qa-host'},()=>({contents:host,loader:'ts'}));}}]});
const files=['lib/academy-request-body.ts','app/api/academy/route.ts','app/api/teams/route.ts','app/api/academy/records/check/route.ts','lib/academy-engine.ts','lib/academy-record-service.ts','lib/academy-teams.ts'];
writeFileSync(output+'/source-evidence.json',JSON.stringify({at:new Date().toISOString(),files:files.map(file=>({file,sha256:createHash('sha256').update(readFileSync(app+'/'+file)).digest('hex')})),bundleSha256:createHash('sha256').update(readFileSync(output+'/actual-routes.mjs')).digest('hex'),limits:['Actual root route/domain code bundled read-only. Only Cloudflare host and authentication are explicit in-memory stubs. No application build, server, fetch, provider, SQL execution or real writes.']},null,2));
console.log('Bundled actual root routes with explicit in-memory auth/D1 stubs.');
