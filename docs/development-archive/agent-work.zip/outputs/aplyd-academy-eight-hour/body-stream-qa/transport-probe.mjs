import assert from 'node:assert/strict';
import http from 'node:http';
import {writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {output} from './qa-paths.mjs';
assert.equal(process.env.ACADEMY_BODY_M3_WORKER_READY,'1');
const base=process.env.ACADEMY_LOCAL_URL??'http://127.0.0.1:8787',url=new URL(base);assert.ok(['127.0.0.1','localhost','[::1]'].includes(url.hostname));assert.equal(url.protocol,'http:');assert.equal(url.port,'8787');
function category(text){try{JSON.parse(text);return 'json';}catch{}return /Workers runtime canceled|code had hung|never generate a response/.test(text)?'worker-request-cancelled-as-hung':/^upstream|unavailable|temporarily/i.test(text)?'availability-text':'other-non-json';}
function call(agent,{method='GET',body,path='/api/academy',signed=false,close=false}={}){const bytes=body===undefined?undefined:Buffer.isBuffer(body)?body:Buffer.from(body);assert.ok(bytes===undefined||bytes.toString('utf8')==='{}'||bytes.length===400001||/^\s+$/.test(bytes.toString('utf8')));const headers={...(bytes?{'Content-Type':'application/json','Content-Length':String(bytes.length)}:{}),...(close?{'Connection':'close'}:{}),...(signed?{'oai-authenticated-user-id':'qa-readonly-body-probe','oai-authenticated-user-email':'readonly-body-probe@academy.test'}:{})};assert.ok(!signed||method==='GET');return new Promise((resolve,reject)=>{const request=http.request(base+path,{method,agent,headers},response=>{const parts=[];response.on('data',chunk=>parts.push(chunk));response.on('error',reject);response.on('end',()=>{const text=Buffer.concat(parts).toString('utf8');let value;try{value=JSON.parse(text);}catch{}resolve({method,path,bodyBytes:bytes?.length??0,signed,status:response.statusCode,contentType:response.headers['content-type']??null,connection:response.headers.connection??null,reusedSocket:request.reusedSocket,localPort:request.socket?.localPort??null,responseBytes:Buffer.byteLength(text),responseSha256:createHash('sha256').update(text).digest('hex'),category:category(text),jsonKeys:value&&typeof value==='object'?Object.keys(value):null});});});request.setTimeout(15000,()=>request.destroy(new Error('Local readonly probe timeout')));request.on('error',reject);request.end(bytes);});}
const tests=[
 {name:'raw overflow then reused POST',first:Buffer.alloc(400001,0xff),next:{method:'POST',body:'{}'}},
 {name:'raw overflow then fresh POST',first:Buffer.alloc(400001,0xff),fresh:true,next:{method:'POST',body:'{}'}},
 {name:'raw overflow then reused authless GET',first:Buffer.alloc(400001,0xff),next:{}},
 {name:'raw overflow then reused signed readonly GET',first:Buffer.alloc(400001,0xff),next:{signed:true}},
 {name:'character overflow then reused POST',first:' '.repeat(100001),next:{method:'POST',body:'{}'}},
 {name:'ordinary empty object repeated POST',first:'{}',next:{method:'POST',body:'{}'}},
];
const results=[];
function evidence(){writeFileSync(output+'/transport-probe-evidence.json',JSON.stringify({at:new Date().toISOString(),results,limits:['Explicit built-in HTTP one-socket local transport diagnosis; no write command/actionId/authenticated POST. Raw response details never recorded. Signed request only readonlyGET for nonexistent fictional subject, no row creation. Not a passing native32 acceptance claim.']},null,2));}
try{for(const t of tests){let agent=new http.Agent({keepAlive:true,maxSockets:1});const result={name:t.name,phase:'overflow-or-baseline'};results.push(result);try{result.first=await call(agent,{method:'POST',body:t.first,close:t.fresh});result.phase='followup';evidence();if(t.fresh){agent.destroy();agent=new http.Agent({keepAlive:true,maxSockets:1});}result.next=await call(agent,t.next);result.phase='complete';}catch(error){result.error=error.message;throw error;}finally{agent.destroy();evidence();}}}finally{evidence();}
console.log(JSON.stringify(results));
