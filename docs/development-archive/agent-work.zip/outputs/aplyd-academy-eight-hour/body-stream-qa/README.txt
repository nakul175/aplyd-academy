Actual-root bounded request reading acceptance

Pure mocked host acceptance (no network/real writes):
1. node build-route-model.mjs
2. node route-body.test.mjs
Actual adopted handlers/domain modules are compiled read-only; only Cloudflare DB
and authentication are explicit test stubs. All SQL mutations/batches throw;
fetch is disabled. Evidence includes current source and generated bundle hashes.
Personal legal-but-incomplete envelope preserves RuleError422; shared400.

Native read-only local acceptance is STAGED, NOT RUN until root signals stable M3:
ACADEMY_BODY_M3_WORKER_READY=1 node native-readonly.mjs
This has no fixture creation/auth headers/actionId/command. Body/status cases
must stop before valid mutation. Only loopback HTTP8787 is allowed. Stop on any
automatic approval rejection; do not reroute gated full mutating template tests.
Optional ACADEMY_BODY_READONLY_DB=/absolute/path/to/existing.sqlite enables
Python mode=ro counts/content hashes for existing qa-* rows before/after.
No SQL mutation/migration/copy, no original sources, no hosted/provider call.

Portable adoption: copy repository-tests/* under tests/body-stream-qa/.
App inferred relative to that folder, cwd or ACADEMY_APP_PATH.
Generated bundle/fixture/evidence goes to .sites-runtime/body-stream-qa by default
when in checkout tests/. Override ACADEMY_BODY_QA_OUTPUT only for isolated work.
The native test cannot reproduce an actual server stream read fault predictably;
44 actual-root mocked route groups plus 29 helper groups cover that path.
