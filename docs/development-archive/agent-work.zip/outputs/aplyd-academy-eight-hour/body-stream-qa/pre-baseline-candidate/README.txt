Saved size-policy candidate routes before selected original Request.text reader comparison. Baseline routes retain fixed-category log hardening only. No published main or DB changes.
