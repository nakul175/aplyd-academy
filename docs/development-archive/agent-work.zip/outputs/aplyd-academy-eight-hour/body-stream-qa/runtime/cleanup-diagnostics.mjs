var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// work/aplyd-academy/lib/academy-request-body.ts
var academy_request_body_exports = {};
__export(academy_request_body_exports, {
  ACADEMY_COMMAND_BODY_LIMITS: () => ACADEMY_COMMAND_BODY_LIMITS,
  ACADEMY_RECORD_CHECK_BODY_LIMITS: () => ACADEMY_RECORD_CHECK_BODY_LIMITS,
  AcademyRequestBodyError: () => AcademyRequestBodyError,
  readAcademyRequestText: () => readAcademyRequestText
});
var ACADEMY_COMMAND_BODY_LIMITS = Object.freeze({ maxCodeUnits: 1e5, maxStreamBytes: 4e5, tooLargeMessage: "This response is too large." });
var ACADEMY_RECORD_CHECK_BODY_LIMITS = Object.freeze({ maxCodeUnits: 2e3, maxStreamBytes: 8e3, maxDecodedBytes: 4e3, tooLargeMessage: "This record-check request is too large." });
var AcademyRequestBodyError = class extends Error {
  constructor(kind, tooLargeMessage = "This request is too large.") {
    const over = ["stream-limit", "character-limit", "decoded-byte-limit"].includes(kind);
    super(over ? tooLargeMessage : "The request could not be read. Send it again only after checking your connection.");
    this.name = "AcademyRequestBodyError";
    this.status = over ? 413 : 400;
    this.kind = kind;
  }
};
function readChunk(reader, signal) {
  if (!signal) return reader.read();
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (result, error) => {
      if (settled) return;
      settled = true;
      try {
        signal.removeEventListener("abort", onAbort);
      } catch {
      }
      if (error) reject(error);
      else resolve(result);
    };
    const onAbort = () => finish(void 0, new AcademyRequestBodyError("aborted"));
    try {
      signal.addEventListener("abort", onAbort, { once: true });
    } catch {
      finish(void 0, new AcademyRequestBodyError("read-failed"));
      return;
    }
    if (signal.aborted) {
      onAbort();
      return;
    }
    let pending;
    try {
      pending = reader.read();
    } catch {
      finish(void 0, new AcademyRequestBodyError(signal.aborted ? "aborted" : "read-failed"));
      return;
    }
    pending.then((result) => finish(result), () => finish(void 0, new AcademyRequestBodyError(signal.aborted ? "aborted" : "read-failed")));
  });
}
async function readAcademyRequestText(request, limits) {
  if (!limits || !Number.isSafeInteger(limits.maxCodeUnits) || limits.maxCodeUnits < 0 || !Number.isSafeInteger(limits.maxStreamBytes) || limits.maxStreamBytes < 0 || limits.maxDecodedBytes !== void 0 && (!Number.isSafeInteger(limits.maxDecodedBytes) || limits.maxDecodedBytes < 0) || typeof limits.tooLargeMessage !== "string" || !limits.tooLargeMessage.trim()) throw new AcademyRequestBodyError("invalid-limits");
  const signal = request.signal;
  if (!request.body) {
    if (signal?.aborted) throw new AcademyRequestBodyError("aborted");
    return "";
  }
  let reader;
  try {
    reader = request.body.getReader();
  } catch {
    throw new AcademyRequestBodyError("read-failed");
  }
  let bytes = 0, units = 0, decodedBytes = 0;
  const parts = [], decoder = new TextDecoder("utf-8"), encoder = limits.maxDecodedBytes === void 0 ? null : new TextEncoder();
  let completed = false;
  const stopForAbort = () => {
    throw new AcademyRequestBodyError("aborted");
  };
  const add = (part) => {
    units += part.length;
    if (units > limits.maxCodeUnits) throw new AcademyRequestBodyError("character-limit", limits.tooLargeMessage);
    if (encoder) {
      decodedBytes += encoder.encode(part).byteLength;
      if (decodedBytes > limits.maxDecodedBytes) throw new AcademyRequestBodyError("decoded-byte-limit", limits.tooLargeMessage);
    }
    if (part) parts.push(part);
  };
  try {
    if (signal?.aborted) stopForAbort();
    while (true) {
      if (signal?.aborted) stopForAbort();
      let result;
      try {
        result = await readChunk(reader, signal);
      } catch (error) {
        if (error instanceof AcademyRequestBodyError) throw error;
        throw new AcademyRequestBodyError(signal?.aborted ? "aborted" : "read-failed");
      }
      if (signal?.aborted) stopForAbort();
      if (result.done) break;
      if (!(result.value instanceof Uint8Array)) throw new AcademyRequestBodyError("read-failed");
      bytes += result.value.byteLength;
      if (bytes > limits.maxStreamBytes) throw new AcademyRequestBodyError("stream-limit", limits.tooLargeMessage);
      add(decoder.decode(result.value, { stream: true }));
    }
    add(decoder.decode());
    if (signal?.aborted) stopForAbort();
    completed = true;
    return parts.join("");
  } catch (error) {
    if (error instanceof AcademyRequestBodyError) throw error;
    throw new AcademyRequestBodyError(signal?.aborted ? "aborted" : "read-failed");
  } finally {
    if (!completed) {
      try {
        void reader.cancel("Academy request stopped").catch(() => {
        });
      } catch {
      }
    }
    try {
      reader.releaseLock();
    } catch {
    }
  }
}

// outputs/aplyd-academy-eight-hour/body-stream-qa/runtime/cleanup-diagnosis/bounded-cancellation.ts
var bounded_cancellation_exports = {};
__export(bounded_cancellation_exports, {
  ACADEMY_COMMAND_BODY_LIMITS: () => ACADEMY_COMMAND_BODY_LIMITS2,
  ACADEMY_RECORD_CHECK_BODY_LIMITS: () => ACADEMY_RECORD_CHECK_BODY_LIMITS2,
  AcademyRequestBodyError: () => AcademyRequestBodyError2,
  readAcademyRequestText: () => readAcademyRequestText2
});
var ACADEMY_COMMAND_BODY_LIMITS2 = Object.freeze({ maxCodeUnits: 1e5, maxStreamBytes: 4e5, tooLargeMessage: "This response is too large." });
var ACADEMY_RECORD_CHECK_BODY_LIMITS2 = Object.freeze({ maxCodeUnits: 2e3, maxStreamBytes: 8e3, maxDecodedBytes: 4e3, tooLargeMessage: "This record-check request is too large." });
var AcademyRequestBodyError2 = class extends Error {
  status;
  kind;
  constructor(kind, tooLargeMessage = "This request is too large.") {
    const over = ["stream-limit", "character-limit", "decoded-byte-limit"].includes(kind);
    super(over ? tooLargeMessage : "The request could not be read. Send it again only after checking your connection.");
    this.name = "AcademyRequestBodyError";
    this.status = over ? 413 : 400;
    this.kind = kind;
  }
};
function readChunk2(reader, signal) {
  if (!signal) return reader.read();
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (result, error) => {
      if (settled) return;
      settled = true;
      try {
        signal.removeEventListener("abort", onAbort);
      } catch {
      }
      if (error) reject(error);
      else resolve(result);
    };
    const onAbort = () => finish(void 0, new AcademyRequestBodyError2("aborted"));
    try {
      signal.addEventListener("abort", onAbort, { once: true });
    } catch {
      finish(void 0, new AcademyRequestBodyError2("read-failed"));
      return;
    }
    if (signal.aborted) {
      onAbort();
      return;
    }
    let pending;
    try {
      pending = reader.read();
    } catch {
      finish(void 0, new AcademyRequestBodyError2(signal.aborted ? "aborted" : "read-failed"));
      return;
    }
    pending.then((result) => finish(result), () => finish(void 0, new AcademyRequestBodyError2(signal.aborted ? "aborted" : "read-failed")));
  });
}
async function readAcademyRequestText2(request, limits) {
  if (!limits || !Number.isSafeInteger(limits.maxCodeUnits) || limits.maxCodeUnits < 0 || !Number.isSafeInteger(limits.maxStreamBytes) || limits.maxStreamBytes < 0 || limits.maxDecodedBytes !== void 0 && (!Number.isSafeInteger(limits.maxDecodedBytes) || limits.maxDecodedBytes < 0) || typeof limits.tooLargeMessage !== "string" || !limits.tooLargeMessage.trim()) throw new AcademyRequestBodyError2("invalid-limits");
  const signal = request.signal;
  if (!request.body) {
    if (signal?.aborted) throw new AcademyRequestBodyError2("aborted");
    return "";
  }
  let reader;
  try {
    reader = request.body.getReader();
  } catch {
    throw new AcademyRequestBodyError2("read-failed");
  }
  let bytes = 0, units = 0, decodedBytes = 0;
  const parts = [], decoder = new TextDecoder("utf-8"), encoder = limits.maxDecodedBytes === void 0 ? null : new TextEncoder();
  let completed = false;
  const stopForAbort = () => {
    throw new AcademyRequestBodyError2("aborted");
  };
  const add = (part) => {
    units += part.length;
    if (units > limits.maxCodeUnits) throw new AcademyRequestBodyError2("character-limit", limits.tooLargeMessage);
    if (encoder) {
      decodedBytes += encoder.encode(part).byteLength;
      if (decodedBytes > limits.maxDecodedBytes) throw new AcademyRequestBodyError2("decoded-byte-limit", limits.tooLargeMessage);
    }
    if (part) parts.push(part);
  };
  try {
    if (signal?.aborted) stopForAbort();
    while (true) {
      if (signal?.aborted) stopForAbort();
      let result;
      try {
        result = await readChunk2(reader, signal);
      } catch (error) {
        if (error instanceof AcademyRequestBodyError2) throw error;
        throw new AcademyRequestBodyError2(signal?.aborted ? "aborted" : "read-failed");
      }
      if (signal?.aborted) stopForAbort();
      if (result.done) break;
      if (!(result.value instanceof Uint8Array)) throw new AcademyRequestBodyError2("read-failed");
      bytes += result.value.byteLength;
      if (bytes > limits.maxStreamBytes) throw new AcademyRequestBodyError2("stream-limit", limits.tooLargeMessage);
      add(decoder.decode(result.value, { stream: true }));
    }
    add(decoder.decode());
    if (signal?.aborted) stopForAbort();
    completed = true;
    return parts.join("");
  } catch (error) {
    if (error instanceof AcademyRequestBodyError2) throw error;
    throw new AcademyRequestBodyError2(signal?.aborted ? "aborted" : "read-failed");
  } finally {
    if (!completed) {
      let cleanupTimer;
      try {
        const cancellation = reader.cancel("Academy request stopped").catch(() => {
        });
        await Promise.race([cancellation, new Promise((resolve) => {
          cleanupTimer = setTimeout(resolve, 100);
        })]);
      } catch {
      } finally {
        if (cleanupTimer !== void 0) clearTimeout(cleanupTimer);
      }
    }
    try {
      reader.releaseLock();
    } catch {
    }
  }
}

// outputs/aplyd-academy-eight-hour/body-stream-qa/runtime/cleanup-diagnosis/release-only-size.ts
var release_only_size_exports = {};
__export(release_only_size_exports, {
  ACADEMY_COMMAND_BODY_LIMITS: () => ACADEMY_COMMAND_BODY_LIMITS3,
  ACADEMY_RECORD_CHECK_BODY_LIMITS: () => ACADEMY_RECORD_CHECK_BODY_LIMITS3,
  AcademyRequestBodyError: () => AcademyRequestBodyError3,
  readAcademyRequestText: () => readAcademyRequestText3
});
var ACADEMY_COMMAND_BODY_LIMITS3 = Object.freeze({ maxCodeUnits: 1e5, maxStreamBytes: 4e5, tooLargeMessage: "This response is too large." });
var ACADEMY_RECORD_CHECK_BODY_LIMITS3 = Object.freeze({ maxCodeUnits: 2e3, maxStreamBytes: 8e3, maxDecodedBytes: 4e3, tooLargeMessage: "This record-check request is too large." });
var AcademyRequestBodyError3 = class extends Error {
  status;
  kind;
  constructor(kind, tooLargeMessage = "This request is too large.") {
    const over = ["stream-limit", "character-limit", "decoded-byte-limit"].includes(kind);
    super(over ? tooLargeMessage : "The request could not be read. Send it again only after checking your connection.");
    this.name = "AcademyRequestBodyError";
    this.status = over ? 413 : 400;
    this.kind = kind;
  }
};
function readChunk3(reader, signal) {
  if (!signal) return reader.read();
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (result, error) => {
      if (settled) return;
      settled = true;
      try {
        signal.removeEventListener("abort", onAbort);
      } catch {
      }
      if (error) reject(error);
      else resolve(result);
    };
    const onAbort = () => finish(void 0, new AcademyRequestBodyError3("aborted"));
    try {
      signal.addEventListener("abort", onAbort, { once: true });
    } catch {
      finish(void 0, new AcademyRequestBodyError3("read-failed"));
      return;
    }
    if (signal.aborted) {
      onAbort();
      return;
    }
    let pending;
    try {
      pending = reader.read();
    } catch {
      finish(void 0, new AcademyRequestBodyError3(signal.aborted ? "aborted" : "read-failed"));
      return;
    }
    pending.then((result) => finish(result), () => finish(void 0, new AcademyRequestBodyError3(signal.aborted ? "aborted" : "read-failed")));
  });
}
async function readAcademyRequestText3(request, limits) {
  if (!limits || !Number.isSafeInteger(limits.maxCodeUnits) || limits.maxCodeUnits < 0 || !Number.isSafeInteger(limits.maxStreamBytes) || limits.maxStreamBytes < 0 || limits.maxDecodedBytes !== void 0 && (!Number.isSafeInteger(limits.maxDecodedBytes) || limits.maxDecodedBytes < 0) || typeof limits.tooLargeMessage !== "string" || !limits.tooLargeMessage.trim()) throw new AcademyRequestBodyError3("invalid-limits");
  const signal = request.signal;
  if (!request.body) {
    if (signal?.aborted) throw new AcademyRequestBodyError3("aborted");
    return "";
  }
  let reader;
  try {
    reader = request.body.getReader();
  } catch {
    throw new AcademyRequestBodyError3("read-failed");
  }
  let bytes = 0, units = 0, decodedBytes = 0;
  const parts = [], decoder = new TextDecoder("utf-8"), encoder = limits.maxDecodedBytes === void 0 ? null : new TextEncoder();
  let completed = false, failure;
  const stopForAbort = () => {
    throw new AcademyRequestBodyError3("aborted");
  };
  const add = (part) => {
    units += part.length;
    if (units > limits.maxCodeUnits) throw new AcademyRequestBodyError3("character-limit", limits.tooLargeMessage);
    if (encoder) {
      decodedBytes += encoder.encode(part).byteLength;
      if (decodedBytes > limits.maxDecodedBytes) throw new AcademyRequestBodyError3("decoded-byte-limit", limits.tooLargeMessage);
    }
    if (part) parts.push(part);
  };
  try {
    if (signal?.aborted) stopForAbort();
    while (true) {
      if (signal?.aborted) stopForAbort();
      let result;
      try {
        result = await readChunk3(reader, signal);
      } catch (error) {
        if (error instanceof AcademyRequestBodyError3) throw error;
        throw new AcademyRequestBodyError3(signal?.aborted ? "aborted" : "read-failed");
      }
      if (signal?.aborted) stopForAbort();
      if (result.done) break;
      if (!(result.value instanceof Uint8Array)) throw new AcademyRequestBodyError3("read-failed");
      bytes += result.value.byteLength;
      if (bytes > limits.maxStreamBytes) throw new AcademyRequestBodyError3("stream-limit", limits.tooLargeMessage);
      add(decoder.decode(result.value, { stream: true }));
    }
    add(decoder.decode());
    if (signal?.aborted) stopForAbort();
    completed = true;
    return parts.join("");
  } catch (error) {
    failure = error instanceof AcademyRequestBodyError3 ? error : new AcademyRequestBodyError3(signal?.aborted ? "aborted" : "read-failed");
    throw failure;
  } finally {
    if (!completed && failure?.status !== 413) {
      try {
        void reader.cancel("Academy request stopped").catch(() => {
        });
      } catch {
      }
    }
    try {
      reader.releaseLock();
    } catch {
    }
  }
}
export {
  bounded_cancellation_exports as bounded,
  academy_request_body_exports as current,
  release_only_size_exports as releaseSizeOnly
};
