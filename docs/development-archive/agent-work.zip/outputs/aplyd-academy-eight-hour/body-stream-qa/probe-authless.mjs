import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {output} from './qa-paths.mjs';
assert.equal(process.env.ACADEMY_BODY_M3_WORKER_READY,'1');
const base=process.env.ACADEMY_LOCAL_URL??'http://127.0.0.1:8787',url=new URL(base);
assert.ok(['127.0.0.1','localhost','[::1]'].includes(url.hostname));assert.equal(url.protocol,'http:');assert.equal(url.port,'8787');
const response=await fetch(base+'/api/academy',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',redirect:'manual',signal:AbortSignal.timeout(15000)}),text=await response.text();
let value;try{value=JSON.parse(text);}catch{}
const evidence={at:new Date().toISOString(),path:'/api/academy',method:'POST',bodyUtf8Bytes:2,authenticated:false,hasActionId:false,hasCommand:false,status:response.status,contentType:response.headers.get('content-type'),location:response.headers.get('location'),bodyBytes:new TextEncoder().encode(text).length,bodySha256:createHash('sha256').update(text).digest('hex'),jsonKeys:value&&typeof value==='object'?Object.keys(value):null,limits:['One fresh incapable {} request only. No authentication/command/actionId or saved data. Raw response not recorded.']};
writeFileSync(output+'/authless-empty-probe.json',JSON.stringify(evidence,null,2));console.log(JSON.stringify(evidence));
assert.equal(response.status,401);assert.deepEqual(Object.keys(value??{}),['error']);
