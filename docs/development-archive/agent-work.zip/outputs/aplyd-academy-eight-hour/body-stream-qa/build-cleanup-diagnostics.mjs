import {createRequire} from 'node:module';import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';import {createHash} from 'node:crypto';import {execFileSync} from 'node:child_process';import {app,output} from './qa-paths.mjs';
const esbuild=createRequire(app+'/package.json')('esbuild'),source=readFileSync(app+'/lib/academy-request-body.ts','utf8'),dir=output+'/cleanup-diagnosis';mkdirSync(dir,{recursive:true});
const cancellation=`   // Initiate cancellation without waiting on a failed or stalled transport hook.
   // No private bytes, exception or AbortSignal.reason are passed as its reason.
   try{void reader.cancel('Academy request stopped').catch(()=>{});}catch{}`;
if(source.split(cancellation).length!==2)throw new Error('Expected current narrow cleanup block exactly once.');
const bounded=source.replace(cancellation,`   // Await ordinary cancellation; a stalled hook gets a bounded soft cleanup wait.
   // Public errors and cancellation reasons contain no request or exception details.
   let cleanupTimer:ReturnType<typeof setTimeout>|undefined;
   try{
    const cancellation=reader.cancel('Academy request stopped').catch(()=>{});
    await Promise.race([cancellation,new Promise<void>(resolve=>{cleanupTimer=setTimeout(resolve,100);})]);
   }catch{}
   finally{if(cleanupTimer!==undefined)clearTimeout(cleanupTimer);}`);
let release=source.replace('let completed=false;','let completed=false,failure:AcademyRequestBodyError|undefined;');
const catcher=` }catch(error){
  if(error instanceof AcademyRequestBodyError)throw error;
  throw new AcademyRequestBodyError(signal?.aborted?'aborted':'read-failed');
 }finally{`;
if(release.split(catcher).length!==2)throw new Error('Expected current catch block exactly once.');
release=release.replace(catcher,` }catch(error){
  failure=error instanceof AcademyRequestBodyError?error:new AcademyRequestBodyError(signal?.aborted?'aborted':'read-failed');
  throw failure;
 }finally{`).replace('  if(!completed){','  if(!completed&&failure?.status!==413){');
writeFileSync(dir+'/bounded-cancellation.ts',bounded);writeFileSync(dir+'/release-only-size.ts',release);
for(const [name,text] of [['bounded-cancellation',bounded],['release-only-size',release]]){try{execFileSync('diff',['-u','--label','a/lib/academy-request-body.ts','--label','b/lib/academy-request-body.ts',app+'/lib/academy-request-body.ts',dir+'/'+name+'.ts']);}catch(error){if(error.status!==1)throw error;writeFileSync(dir+'/'+name+'.patch',error.stdout.toString());}}
writeFileSync(dir+'/entry.ts',`export * as current from ${JSON.stringify(app+'/lib/academy-request-body.ts')};export * as bounded from './bounded-cancellation';export * as releaseSizeOnly from './release-only-size';`);
await esbuild.build({entryPoints:[dir+'/entry.ts'],bundle:true,platform:'node',format:'esm',outfile:output+'/cleanup-diagnostics.mjs'});
writeFileSync(dir+'/source-evidence.json',JSON.stringify({at:new Date().toISOString(),originalSha256:createHash('sha256').update(source).digest('hex'),variants:[['bounded-cancellation',bounded],['release-only-size',release]].map(([name,text])=>({name,sha256:createHash('sha256').update(text).digest('hex')})),limitations:['Diagnostic-only actual-root helper copies; no checkout change, app build, HTTP, provider, DB or protected logic. Size/schema/constants unchanged. No proof either variant fixes native transport until root selected rebuild+acceptance.100ms is scheduler-based soft cleanup bound, not a hardware timeout.']},null,2));console.log('Bundled two narrow cleanup diagnosis variants outside checkout.');
