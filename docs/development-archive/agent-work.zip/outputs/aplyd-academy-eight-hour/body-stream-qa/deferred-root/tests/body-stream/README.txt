Root adoption: tests/body-stream/build-body-model.mjs and request-body.test.mjs. Copy helper to lib/academy-request-body.ts and review small routes.patch first. Generated model/source hashes/test evidence stay in .sites-runtime/body-stream-qa; no absolute hardcoded paths.
node tests/body-stream/build-body-model.mjs
node --test tests/body-stream/request-body.test.mjs
These pure in-memory tests need no Worker, network, provider or SQL access. Actual API415/400/413 acceptance remains separately gated.
