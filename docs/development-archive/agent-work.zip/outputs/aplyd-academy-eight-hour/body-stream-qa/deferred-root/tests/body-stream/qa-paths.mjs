import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {existsSync,mkdirSync} from 'node:fs';
const here=dirname(fileURLToPath(import.meta.url)),nearby=resolve(here,'../..');
export const app=resolve(process.env.ACADEMY_APP_PATH??(existsSync(nearby+'/lib/academy-request-body.ts')?nearby:existsSync('lib/academy-request-body.ts')?'.':'work/aplyd-academy'));
export const output=resolve(process.env.ACADEMY_BODY_QA_OUTPUT??(here.includes('/tests/')?app+'/.sites-runtime/body-stream-qa':here+'/runtime'));
mkdirSync(output,{recursive:true});
export const runtimeModule=file=>pathToFileURL(output+'/'+file).href;
