/** Bounded UTF-8 body reading only. JSON, identity, authority and CAS stay at callers. */
export type AcademyBodyLimits=Readonly<{maxCodeUnits:number;maxStreamBytes:number;maxDecodedBytes?:number;tooLargeMessage:string}>;
export const ACADEMY_COMMAND_BODY_LIMITS:AcademyBodyLimits=Object.freeze({maxCodeUnits:100_000,maxStreamBytes:400_000,tooLargeMessage:'This response is too large.'});
export const ACADEMY_RECORD_CHECK_BODY_LIMITS:AcademyBodyLimits=Object.freeze({maxCodeUnits:2_000,maxStreamBytes:8_000,maxDecodedBytes:4_000,tooLargeMessage:'This record-check request is too large.'});
export type AcademyBodyFailure='invalid-limits'|'stream-limit'|'character-limit'|'decoded-byte-limit'|'read-failed'|'aborted';
export class AcademyRequestBodyError extends Error{
 readonly status:400|413;
 readonly kind:AcademyBodyFailure;
 constructor(kind:AcademyBodyFailure,tooLargeMessage='This request is too large.'){
  const over=['stream-limit','character-limit','decoded-byte-limit'].includes(kind);
  super(over?tooLargeMessage:'The request could not be read. Send it again only after checking your connection.');
  this.name='AcademyRequestBodyError';this.status=over?413:400;this.kind=kind;
 }
}
type RequestBody=Pick<Request,'body'> & {signal?:AbortSignal};

/** Only the current read owns an abort listener; completed chunks retain none. */
function readChunk(reader:ReadableStreamDefaultReader<Uint8Array>,signal?:AbortSignal):Promise<ReadableStreamReadResult<Uint8Array>>{
 if(!signal)return reader.read();
 return new Promise((resolve,reject)=>{
  let settled=false;
  const finish=(result?:ReadableStreamReadResult<Uint8Array>,error?:AcademyRequestBodyError)=>{
   if(settled)return;settled=true;try{signal.removeEventListener('abort',onAbort);}catch{}
   if(error)reject(error);else resolve(result!);
  };
  const onAbort=()=>finish(undefined,new AcademyRequestBodyError('aborted'));
  try{signal.addEventListener('abort',onAbort,{once:true});}catch{finish(undefined,new AcademyRequestBodyError('read-failed'));return;}
  if(signal.aborted){onAbort();return;}
  let pending:Promise<ReadableStreamReadResult<Uint8Array>>;
  try{pending=reader.read();}catch{finish(undefined,new AcademyRequestBodyError(signal.aborted?'aborted':'read-failed'));return;}
  pending.then(result=>finish(result),()=>finish(undefined,new AcademyRequestBodyError(signal.aborted?'aborted':'read-failed')));
 });
}
/** Match Request.text(): UTF-8 replacement decoding, including one leading BOM. */
export async function readAcademyRequestText(request:RequestBody,limits:AcademyBodyLimits):Promise<string>{
 if(!limits||!Number.isSafeInteger(limits.maxCodeUnits)||limits.maxCodeUnits<0||!Number.isSafeInteger(limits.maxStreamBytes)||limits.maxStreamBytes<0||(limits.maxDecodedBytes!==undefined&&(!Number.isSafeInteger(limits.maxDecodedBytes)||limits.maxDecodedBytes<0))||typeof limits.tooLargeMessage!=='string'||!limits.tooLargeMessage.trim())throw new AcademyRequestBodyError('invalid-limits');
 const signal=request.signal;
 if(!request.body){if(signal?.aborted)throw new AcademyRequestBodyError('aborted');return '';}
 let reader:ReadableStreamDefaultReader<Uint8Array>;
 try{reader=request.body.getReader();}catch{throw new AcademyRequestBodyError('read-failed');}
 let bytes=0,units=0,decodedBytes=0;const parts:string[]=[],decoder=new TextDecoder('utf-8'),encoder=limits.maxDecodedBytes===undefined?null:new TextEncoder();
 let completed=false;
 const stopForAbort=()=>{throw new AcademyRequestBodyError('aborted');};
 const add=(part:string)=>{
  units+=part.length;if(units>limits.maxCodeUnits)throw new AcademyRequestBodyError('character-limit',limits.tooLargeMessage);
  if(encoder){decodedBytes+=encoder.encode(part).byteLength;if(decodedBytes>limits.maxDecodedBytes!)throw new AcademyRequestBodyError('decoded-byte-limit',limits.tooLargeMessage);}
  if(part)parts.push(part);
 };
 try{
  if(signal?.aborted)stopForAbort();
  while(true){
   if(signal?.aborted)stopForAbort();
   let result:ReadableStreamReadResult<Uint8Array>;
   try{result=await readChunk(reader,signal);}catch(error){if(error instanceof AcademyRequestBodyError)throw error;throw new AcademyRequestBodyError(signal?.aborted?'aborted':'read-failed');}
   if(signal?.aborted)stopForAbort();
   if(result.done)break;
   if(!(result.value instanceof Uint8Array))throw new AcademyRequestBodyError('read-failed');
   bytes+=result.value.byteLength;if(bytes>limits.maxStreamBytes)throw new AcademyRequestBodyError('stream-limit',limits.tooLargeMessage);
   add(decoder.decode(result.value,{stream:true}));
  }
  add(decoder.decode());if(signal?.aborted)stopForAbort();completed=true;return parts.join('');
 }catch(error){
  if(error instanceof AcademyRequestBodyError)throw error;
  throw new AcademyRequestBodyError(signal?.aborted?'aborted':'read-failed');
 }finally{
  if(!completed){
   // Initiate cancellation without waiting on a failed or stalled transport hook.
   // No private bytes, exception or AbortSignal.reason are passed as its reason.
   try{void reader.cancel('Academy request stopped').catch(()=>{});}catch{}
  }
  try{reader.releaseLock();}catch{}
 }
}
