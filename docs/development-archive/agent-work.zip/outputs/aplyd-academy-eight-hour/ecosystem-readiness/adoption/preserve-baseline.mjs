import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const here="/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/outputs/aplyd-academy-eight-hour/ecosystem-readiness/adoption",path=here+'/app/academy-ecosystems.tsx';let s=readFileSync(path,'utf8');
s=s.replace("import {derivePartnerInspection} from '@/lib/academy-partner-readiness';\nimport {PartnerReadiness} from './academy-partner-readiness';\n","");
const clock=" const [clock,setClock]=useState(()=>new Date().toISOString());useEffect(()=>{const tick=()=>setClock(new Date().toISOString()),timer=setInterval(tick,30000);document.addEventListener('visibilitychange',tick);return()=>{clearInterval(timer);document.removeEventListener('visibilitychange',tick)}},[]);";
const read=" let grants:TestGrant[]=[],savedChoiceError=false;try{grants=readTestGrants(state.ecosystemGrants)}catch{savedChoiceError=true}let receipts:ReturnReceipt[]=[],savedReceiptError=false;try{receipts=readTestReceipts(state.ecosystemReceipts,grants,clock)}catch{savedReceiptError=true}";
s=s.replace(" const {state,team,cmd,busy,go,resolvePinned,activeWorkspace}=useAcademy();\n"+clock+"\n"+read," const {state,team,cmd,busy,go,resolvePinned}=useAcademy();"+read.trim().replace('readTestReceipts(state.ecosystemReceipts,grants,clock)','readTestReceipts(state.ecosystemReceipts,grants)')+"\n"+clock);
s=s.replace("<PartnerReadiness inspection={derivePartnerInspection({workspace:activeWorkspace,state,now:clock},a.id)} onOpenReferences={()=>go('library')}/>","");
const expected=JSON.parse(readFileSync(here+'/runtime-candidate/compilation-evidence.json','utf8')).rootSourcesBefore['app/academy-ecosystems.tsx'];
if(createHash('sha256').update(s).digest('hex')!==expected)throw new Error('Reconstructed baseline does not exactly match reviewed original source');
writeFileSync(here+'/app/academy-ecosystems.before.tsx',s);
let deliver=readFileSync(here+'/deliver.mjs','utf8').replace("f==='app/academy-ecosystems.tsx'?app+'/'+f:'/dev/null'","f==='app/academy-ecosystems.tsx'?dst+'/app/academy-ecosystems.before.tsx':'/dev/null'").replace("readFileSync(app+'/app/academy-ecosystems.tsx')","readFileSync(dst+'/app/academy-ecosystems.before.tsx')");writeFileSync(here+'/deliver.mjs',deliver);
console.log('Preserved exact reviewed baseline for integration diff, independent of root adoption.');

