import {writeFileSync,readFileSync} from 'node:fs';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
const dst="/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/outputs/aplyd-academy-eight-hour/ecosystem-readiness/adoption",app="/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/work/aplyd-academy",files=['lib/academy-partner-readiness.ts','app/academy-partner-readiness.tsx','app/academy-partner-readiness.module.css','app/academy-ecosystems.tsx','tests/compile-partner-readiness-tests.mjs','tests/partner-readiness.test.mjs'];let diff='';
for(const f of files){try{diff+=execFileSync('/usr/bin/diff',['-u','--label','a/'+f,'--label','b/'+f,f==='app/academy-ecosystems.tsx'?dst+'/app/academy-ecosystems.before.tsx':'/dev/null',dst+'/'+f],{encoding:'utf8'})}catch(e){if(e.status!==1)throw e;diff+=e.stdout}}
writeFileSync(dst+'/review.diff',diff);
writeFileSync(dst+'/adoption-contract.txt',[
'APLYD M3 — generic read-only discussion inspector; no live partner contract design, recipient, transport or AI provider.',
'Adopt exactly these six checkout paths:',
...files,
'Model/UI/CSS copied from existing ecosystem-readiness candidate. Existing adapter integration is limited to imports, activeWorkspace context, clock moved before receipts, reader clock supplied, and one child per adapter.',
'Current accepted shell state + exact activeWorkspace + existing informational clock feed a fresh derive call on each adapter render. No memoized historical choice or saved derived model.',
'Shared current view returns before adapter inspection; model shared scope also returns before reading supplied private state. Health retains no pathway, choice/test controls, supported summary fields or mapping.',
'Existing grant/save/local-test/legacy controls retain server authority. No inspector value can enable a write. All authorizesDelivery/authorizesLocalTest flags remain false.',
'readTestReceipts(state.ecosystemReceipts,grants,clock) now prevents future receipts from being rendered as valid by the existing listing. It retains plain unavailable presentation. Withdraw controls remain independent and outside disabled receipt/test fieldsets.',
'Generic discussion brief is generated solely from adapter constants and fixed unresolved questions. It never receives state, identity, enrollment, grant, receipt, progress, status, date or expiry values.',
'Download is a local Blob only. Reference action navigates to existing library without opening/downloading a reference automatically.',
'No database, stored state, migration, API, provider, clinical mapping, identity grant, partner connection or outgoing call.',
'Candidate strict model/UI/connections TypeScript and pure compilation pass. Existing30 tests plus future-clock reader regression31 groups pass.',
'Portable compiler defaults to ACTUAL adopted root files after copying into checkout tests. Candidate mode is explicit via ACADEMY_READINESS_CANDIDATE_ROOT. ACADEMY_READINESS_QA_OUT writes pure evidence outside checkout when needed.',
'Root should compile actual adoption and run the31 pure groups, build/restart its Worker, then send a NEW stable signal before outside browser checks.',
'Prepared browser-readonly.mjs blocks all page requests except same-origin loopback GET. It uses existing approved fictional record identities. Grant/receipt variants are in-memory intercepted display responses only, never written or persisted.',
'Browser scenarios cover exact nonpersonal briefs, selected scopes, unsaved form, expiry/withdrawal/pause/unknown/future/bad receipt/capacity, independent withdrawal availability, workspace/account/malformed-read masking, governance navigation,390/768/1440 widths,200% text and keyboard.',
'No browser/API/server/build executed by this agent for M3 yet. Full mutating fixture tests remain gated by pending explicit user permission.',
'Do not rerun stage.mjs; it is an intermediate generator. review.diff and these six delivered files are the adoption result.'
].join('\n')+'\n');
writeFileSync(dst+'/prepared-evidence.json',JSON.stringify({at:new Date().toISOString(),candidateCompiled:true,strictTypecheck:true,pureGroups:31,sourceUnchanged:true,actualAdoptedCompilerPrepared:true,browserSubsetPrepared:true,browserExecuted:false,networkCalls:0,checkoutMutations:0,files:files.map(f=>({path:f,sha256:createHash('sha256').update(readFileSync(dst+'/'+f)).digest('hex')})),actualConnectionsBeforeSha256:createHash('sha256').update(readFileSync(dst+'/app/academy-ecosystems.before.tsx')).digest('hex'),limits:['Pure explicit candidate preparation only; actual root adoption/Worker/browser/hosted proof pending root integration and new stable signal.','Existing dataset and immutable curriculum untouched; no provider/partner calls or live permission.']},null,2)+'\n');
console.log('Exact six-file adoption diff and prepared-evidence contract written.');

