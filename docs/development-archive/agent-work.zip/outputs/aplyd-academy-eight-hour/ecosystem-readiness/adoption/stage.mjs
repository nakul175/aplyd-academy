import {mkdirSync,readFileSync,writeFileSync,copyFileSync} from 'node:fs';import {resolve,dirname} from 'node:path';
const app="/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/work/aplyd-academy",source="/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/outputs/aplyd-academy-eight-hour/ecosystem-readiness",dst=source+'/adoption';
for(const d of ['lib','app','tests','runtime-candidate'])mkdirSync(dst+'/'+d,{recursive:true});
for(const [a,b]of [['academy-partner-readiness.ts','lib/academy-partner-readiness.ts'],['academy-partner-readiness.tsx','app/academy-partner-readiness.tsx'],['academy-partner-readiness.module.css','app/academy-partner-readiness.module.css']])copyFileSync(source+'/'+a,dst+'/'+b);
let s=readFileSync(app+'/app/academy-ecosystems.tsx','utf8');
s=s.replace("import {useAcademy,useWorkspaceDraft}","import {derivePartnerInspection} from '@/lib/academy-partner-readiness';\nimport {PartnerReadiness} from './academy-partner-readiness';\nimport {useAcademy,useWorkspaceDraft}");
const clock=" const [clock,setClock]=useState(()=>new Date().toISOString());useEffect(()=>{const tick=()=>setClock(new Date().toISOString()),timer=setInterval(tick,30000);document.addEventListener('visibilitychange',tick);return()=>{clearInterval(timer);document.removeEventListener('visibilitychange',tick)}},[]);";
const previous=" const {state,team,cmd,busy,go,resolvePinned}=useAcademy();let grants:TestGrant[]=[],savedChoiceError=false;try{grants=readTestGrants(state.ecosystemGrants)}catch{savedChoiceError=true}let receipts:ReturnReceipt[]=[],savedReceiptError=false;try{receipts=readTestReceipts(state.ecosystemReceipts,grants)}catch{savedReceiptError=true}\n"+clock;
if(!s.includes(previous))throw new Error('Actual clock/read ordering changed; review current source before patch');
s=s.replace(previous," const {state,team,cmd,busy,go,resolvePinned,activeWorkspace}=useAcademy();\n"+clock+"\n let grants:TestGrant[]=[],savedChoiceError=false;try{grants=readTestGrants(state.ecosystemGrants)}catch{savedChoiceError=true}let receipts:ReturnReceipt[]=[],savedReceiptError=false;try{receipts=readTestReceipts(state.ecosystemReceipts,grants,clock)}catch{savedReceiptError=true}");
const close=" </>}</section>})}</div>";
if(!s.includes(close))throw new Error('Actual adapter card boundary changed');
s=s.replace(close," </>}<PartnerReadiness inspection={derivePartnerInspection({workspace:activeWorkspace,state,now:clock},a.id)} onOpenReferences={()=>go('library')}/></section>})}</div>");
writeFileSync(dst+'/app/academy-ecosystems.tsx',s);
let test=readFileSync(source+'/readiness.test.mjs','utf8');
test=test.replace("import {writeFileSync}","import {writeFileSync,mkdirSync}")
.replace("const runtime=new URL(process.env.ACADEMY_READINESS_RUNTIME??'./runtime/readiness.mjs',import.meta.url);","const runtime=new URL(process.env.ACADEMY_READINESS_RUNTIME??'../.sites-runtime/partner-readiness-qa/readiness.mjs',import.meta.url);")
.replace("CONTENT_VERSION,ONBOARDING_QUESTIONS}","CONTENT_VERSION,ONBOARDING_QUESTIONS,readTestGrants,readTestReceipts}")
.replace("new URL('./runtime/test-evidence.json',import.meta.url)","new URL('./test-evidence.json',runtime)");
test=test.replace("process.on('beforeExit',", "run('Existing receipt reader rejects future-created receipts when passed the current informational clock',()=>{let s=fixture();s=command(s,{type:'ecosystem-test',grantId:s.ecosystemGrants[0].id});const future=structuredClone(s);future.ecosystemReceipts[0].createdAt=later;future.ecosystemReceipts[0].payload.occurred_at=later;const grants=readTestGrants(future.ecosystemGrants);assert.equal(readTestReceipts(future.ecosystemReceipts,grants).length,1);assert.throws(()=>readTestReceipts(future.ecosystemReceipts,grants,now));assert.equal(readTestReceipts(future.ecosystemReceipts,grants,later).length,1);assert.equal(view(future).history.state,'unavailable');assert.equal(view(future).summary,null);});\nprocess.on('beforeExit',");
writeFileSync(dst+'/tests/partner-readiness.test.mjs',test);
console.log('Three candidate files, minimal actual-root integration and 31-group portable test source staged outside checkout.');

