// Isolated candidate compilation. No app build, server or storage writes.
import {resolve,dirname} from 'node:path';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url));
const app=resolve(process.env.ACADEMY_APP_PATH??'work/aplyd-academy');
const require=createRequire(app+'/package.json'),esbuild=require('esbuild'),ts=require('typescript');
const out=resolve(process.env.ACADEMY_READINESS_QA_OUT??here+'/runtime');mkdirSync(out,{recursive:true});
const model=here+'/academy-partner-readiness.ts',ui=here+'/academy-partner-readiness.tsx';
const mapping={'./academy-ecosystems':app+'/lib/academy-ecosystems.ts','./academy-curriculum':app+'/lib/academy-curriculum.ts','../lib/academy-partner-readiness':model};
const plugin={name:'actual-checkout-dependencies',setup(build){build.onResolve({filter:/academy-(ecosystems|curriculum|partner-readiness)$/},args=>mapping[args.path]?{path:mapping[args.path]}:undefined)}};
writeFileSync(out+'/entry.ts',`export * from ${JSON.stringify(model)};export {applyCommand,freshWorkspace} from ${JSON.stringify(app+'/lib/academy-engine.ts')};export {programs,CONTENT_VERSION,createCurriculumRegistry,curriculumRegistry} from ${JSON.stringify(app+'/lib/academy-curriculum.ts')};`);
await esbuild.build({entryPoints:[out+'/entry.ts'],bundle:true,platform:'node',format:'esm',outfile:out+'/readiness.mjs',plugins:[plugin]});
await esbuild.build({entryPoints:[ui],bundle:true,platform:'browser',format:'esm',outfile:out+'/readiness-ui.mjs',external:['react','react/*'],plugins:[plugin]});
writeFileSync(out+'/css.d.ts','declare module "*.module.css" { const classes: Record<string,string>; export default classes; }');
const options={noEmit:true,strict:true,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,moduleResolution:ts.ModuleResolutionKind.Bundler,jsx:ts.JsxEmit.ReactJSX,resolveJsonModule:true,esModuleInterop:true,skipLibCheck:true,typeRoots:[app+'/node_modules/@types'],types:['react','react-dom','node']};
const host=ts.createCompilerHost(options);
host.resolveModuleNames=(names,containing)=>names.map(name=>{
  if(mapping[name])return {resolvedFileName:mapping[name],extension:ts.Extension.Ts};
  return ts.resolveModuleName(name,containing,options,host).resolvedModule
    ??ts.resolveModuleName(name,app+'/app/academy.tsx',options,host).resolvedModule;
});
const program=ts.createProgram([model,ui,out+'/css.d.ts'],options,host);
const diagnostics=ts.getPreEmitDiagnostics(program);
const formatted=ts.formatDiagnosticsWithColorAndContext(diagnostics,{getCurrentDirectory:()=>here,getCanonicalFileName:f=>f,getNewLine:()=>"\n"});
const files=[model,ui,here+'/academy-partner-readiness.module.css',app+'/lib/academy-ecosystems.ts',app+'/lib/academy-curriculum.ts',app+'/lib/academy-engine.ts'];
writeFileSync(out+'/compilation-evidence.json',JSON.stringify({passed:diagnostics.length===0,typeDiagnostics:diagnostics.length,files:files.map(path=>({path,sha256:createHash('sha256').update(readFileSync(path)).digest('hex')})),at:new Date().toISOString(),limits:['Isolated candidate compilation only. No application adoption, Worker build, browser, API or partner transport tested.']},null,2));
if(diagnostics.length){console.error(formatted);process.exitCode=1;}else console.log('Readiness model and UI passed isolated strict typecheck and compilation.');
