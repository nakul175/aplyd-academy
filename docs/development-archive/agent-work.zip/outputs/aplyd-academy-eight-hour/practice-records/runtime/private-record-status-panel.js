"use client";

// outputs/aplyd-academy-eight-hour/practice-records/private-record-status-panel.tsx
import { useEffect, useRef, useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
function PrivateRecordStatusPanel({ scopeKey, target, canCheck, check, exportSnapshot }) {
  const targetKey = JSON.stringify(target), sequence = useRef(0), abort = useRef(null), liveScope = useRef("");
  const currentScope = JSON.stringify([scopeKey, targetKey, canCheck]);
  liveScope.current = currentScope;
  const [saved, setSaved] = useState(null), [pending, setPending] = useState(""), [notice, setNotice] = useState(null);
  useEffect(() => {
    sequence.current++;
    abort.current?.abort();
    abort.current = null;
    setSaved(null);
    setPending("");
    setNotice(null);
    return () => {
      sequence.current++;
      abort.current?.abort();
    };
  }, [currentScope]);
  const visible = saved?.scope === currentScope && canCheck ? saved.result : null, checked = visible?.outcome === "checked" ? visible : null;
  const own = "recordId" in target;
  async function run() {
    if (!canCheck) return;
    const captured = currentScope, token = ++sequence.current;
    abort.current?.abort();
    const controller = new AbortController();
    abort.current = controller;
    setSaved(null);
    setNotice(null);
    setPending(captured);
    try {
      const result = await check(target, controller.signal);
      if (controller.signal.aborted || sequence.current !== token || liveScope.current !== captured) return;
      setSaved({ scope: captured, result });
    } catch {
      if (!controller.signal.aborted && sequence.current === token && liveScope.current === captured) setNotice({ scope: captured, text: "This private check is unavailable. Refresh your learning space and try again." });
    } finally {
      if (sequence.current === token && liveScope.current === captured) setPending("");
    }
  }
  const s = checked?.snapshot;
  return /* @__PURE__ */ jsxs("section", { className: "private-record-status", "aria-label": own ? "Private saved record check" : "Assigned original decision check", children: [
    /* @__PURE__ */ jsx("p", { children: own ? "Check your current saved record and its retained review history." : "Check only the original decision already visible in this currently assigned appeal." }),
    /* @__PURE__ */ jsx("button", { type: "button", disabled: !canCheck || pending === currentScope, onClick: run, children: pending === currentScope ? "Checking saved state\u2026" : own ? "Check current saved status" : "Check assigned original decision" }),
    notice?.scope === currentScope && /* @__PURE__ */ jsx("p", { role: "status", children: notice.text }),
    visible?.outcome === "unavailable" && /* @__PURE__ */ jsx("p", { role: "status", children: visible.message }),
    checked && s && /* @__PURE__ */ jsxs("div", { role: "status", "aria-live": "polite", children: [
      /* @__PURE__ */ jsx("h3", { children: own ? "Current saved status" : "Assigned original decision" }),
      /* @__PURE__ */ jsx("p", { children: /* @__PURE__ */ jsx("strong", { children: s.classification }) }),
      own && /* @__PURE__ */ jsxs("p", { children: [
        /* @__PURE__ */ jsx("strong", { children: s.status === "active" ? "Active" : "Suspended" }),
        s.hasOpenAppeal ? " \xB7 Appeal open" : "",
        s.hasPendingAssessment ? " \xB7 Review pending" : ""
      ] }),
      /* @__PURE__ */ jsxs("p", { children: [
        "Checked at ",
        s.checkedAt,
        " \xB7 saved revision ",
        s.asOfRevision,
        ". Recheck after a new decision."
      ] }),
      /* @__PURE__ */ jsxs("p", { children: [
        "Exact course version: ",
        /* @__PURE__ */ jsx("span", { className: "private-record-reference", children: s.contentRef.versionId })
      ] }),
      own ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("p", { children: [
          "Originally recorded ",
          s.issuedAt
        ] }),
        /* @__PURE__ */ jsxs("p", { children: [
          "First passing review: ",
          s.firstPassingDecision.actorDisplay,
          " \xB7 ",
          s.firstPassingDecision.decidedAt
        ] }),
        /* @__PURE__ */ jsxs("p", { children: [
          "Effective review: ",
          s.effectiveDecision.actorDisplay,
          " \xB7 ",
          s.effectiveDecision.decidedAt,
          " \xB7 ",
          s.effectiveDecision.passed ? "Passed" : "Did not pass"
        ] }),
        /* @__PURE__ */ jsx("p", { children: s.issuerAuthority })
      ] }) : /* @__PURE__ */ jsxs("p", { children: [
        "Original review: ",
        s.decision.actorDisplay,
        " \xB7 ",
        s.decision.decidedAt,
        " \xB7 ",
        s.decision.passed ? "Passed" : "Did not pass"
      ] }),
      /* @__PURE__ */ jsxs("details", { children: [
        /* @__PURE__ */ jsx("summary", { children: "Snapshot checksum and limits" }),
        /* @__PURE__ */ jsx("p", { className: "private-record-reference", children: checked.integrity.checksum }),
        /* @__PURE__ */ jsx("p", { children: checked.integrity.meaning }),
        /* @__PURE__ */ jsx("p", { children: "This private snapshot contains no submitted evidence, drafts, private review notes or public verification link." })
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", onClick: () => {
        if (saved?.scope === liveScope.current && canCheck && checked) exportSnapshot(checked);
      }, children: "Download private status snapshot" })
    ] })
  ] });
}
export {
  PrivateRecordStatusPanel
};
