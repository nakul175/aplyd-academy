'use client';
import {useEffect,useRef,useState} from 'react';
import type {RecordStatusResult} from './academy-record-check';

/** Candidate widget: parent owns authenticated API response validation and identity/scope fencing. */
type Target={recordId:string}|{decisionId:string};
type Props={scopeKey:string;target:Target;canCheck:boolean;check:(target:Target,signal:AbortSignal)=>Promise<RecordStatusResult>;exportSnapshot:(result:Extract<RecordStatusResult,{outcome:'checked'}>)=>void};
export function PrivateRecordStatusPanel({scopeKey,target,canCheck,check,exportSnapshot}:Props){
 const targetKey=JSON.stringify(target),sequence=useRef(0),abort=useRef<AbortController|null>(null),liveScope=useRef('');
 const currentScope=JSON.stringify([scopeKey,targetKey,canCheck]);liveScope.current=currentScope;
 const[saved,setSaved]=useState<{scope:string;result:RecordStatusResult}|null>(null),[pending,setPending]=useState(''),[notice,setNotice]=useState<{scope:string;text:string}|null>(null);
 useEffect(()=>{sequence.current++;abort.current?.abort();abort.current=null;setSaved(null);setPending('');setNotice(null);return()=>{sequence.current++;abort.current?.abort()}},[currentScope]);
 const visible=saved?.scope===currentScope&&canCheck?saved.result:null,checked=visible?.outcome==='checked'?visible:null;
 const own='recordId'in target;
 async function run(){
  if(!canCheck)return;const captured=currentScope,token=++sequence.current;abort.current?.abort();const controller=new AbortController();abort.current=controller;setSaved(null);setNotice(null);setPending(captured);
  try{const result=await check(target,controller.signal);if(controller.signal.aborted||sequence.current!==token||liveScope.current!==captured)return;setSaved({scope:captured,result})}
  catch{if(!controller.signal.aborted&&sequence.current===token&&liveScope.current===captured)setNotice({scope:captured,text:'This private check is unavailable. Refresh your learning space and try again.'})}
  finally{if(sequence.current===token&&liveScope.current===captured)setPending('')}
 }
 const s=checked?.snapshot;
 return <section className="private-record-status" aria-label={own?'Private saved record check':'Assigned original decision check'}>
  <p>{own?'Check your current saved record and its retained review history.':'Check only the original decision already visible in this currently assigned appeal.'}</p>
  <button type="button" disabled={!canCheck||pending===currentScope} onClick={run}>{pending===currentScope?'Checking saved state…':own?'Check current saved status':'Check assigned original decision'}</button>
  {notice?.scope===currentScope&&<p role="status">{notice.text}</p>}
  {visible?.outcome==='unavailable'&&<p role="status">{visible.message}</p>}
  {checked&&s&&<div role="status" aria-live="polite">
   <h3>{own?'Current saved status':'Assigned original decision'}</h3>
   <p><strong>{s.classification}</strong></p>
   {own&&<p><strong>{s.status==='active'?'Active':'Suspended'}</strong>{s.hasOpenAppeal?' · Appeal open':''}{s.hasPendingAssessment?' · Review pending':''}</p>}
   <p>Checked at {s.checkedAt} · saved revision {s.asOfRevision}. Recheck after a new decision.</p>
   <p>Exact course version: <span className="private-record-reference">{s.contentRef.versionId}</span></p>
   {own?<>
    <p>Originally recorded {s.issuedAt}</p>
    <p>First passing review: {s.firstPassingDecision.actorDisplay} · {s.firstPassingDecision.decidedAt}</p>
    <p>Effective review: {s.effectiveDecision.actorDisplay} · {s.effectiveDecision.decidedAt} · {s.effectiveDecision.passed?'Passed':'Did not pass'}</p>
    <p>{s.issuerAuthority}</p>
   </>:<p>Original review: {s.decision.actorDisplay} · {s.decision.decidedAt} · {s.decision.passed?'Passed':'Did not pass'}</p>}
   <details><summary>Snapshot checksum and limits</summary><p className="private-record-reference">{checked.integrity.checksum}</p><p>{checked.integrity.meaning}</p><p>This private snapshot contains no submitted evidence, drafts, private review notes or public verification link.</p></details>
   <button type="button" onClick={()=>{if(saved?.scope===liveScope.current&&canCheck&&checked)exportSnapshot(checked)}}>Download private status snapshot</button>
  </div>}
 </section>;
}
