export * from "/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/outputs/aplyd-academy-eight-hour/inclusive-learning/academy-inclusive-learning.ts";
export {programs,currentRef,curriculumRegistry,createCurriculumRegistry,resolvePinnedContent,LEGACY_SOURCE_SHA256} from "/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/work/aplyd-academy/lib/academy-curriculum.ts";
export {applyCommand,freshWorkspace} from "/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/work/aplyd-academy/lib/academy-engine.ts";
