"""Read-only local SQLite diagnostics for only this suite's synthetic team IDs."""
import json,sqlite3,os,pathlib,datetime
root=pathlib.Path(__file__).resolve().parent
app=pathlib.Path(os.environ.get('ACADEMY_APP_PATH','work/aplyd-academy')).resolve()
evidence=json.loads((root/'api-evidence/integrated-api-result.json').read_text())
assert evidence['passed'] is True
team_ids={r['workspace'] for r in evidence['accepted'] if r['workspace'].startswith('tw-')}
candidates=[p for p in (app/'.wrangler/state/v3/d1/miniflare-D1DatabaseObject').glob('*.sqlite') if p.name!='metadata.sqlite']
assert len(candidates)==1,'Specify the exact root-confirmed local D1 file if more than one exists.'
db=sqlite3.connect(candidates[0].as_uri()+'?mode=ro',uri=True)
db.row_factory=sqlite3.Row
checks=0;rows=[]
try:
  db.execute('PRAGMA query_only=ON')
  for team_id in sorted(team_ids):
    row=db.execute('SELECT data,revision,directory_projected FROM academy_teams WHERE id=?',(team_id,)).fetchone()
    assert row is not None;assert row['directory_projected']==1;checks+=2
    team=json.loads(row['data'])
    expected=sorted({m['userId'] for m in team['members']})
    directory=[r['user_id'] for r in db.execute('SELECT user_id FROM academy_team_directory WHERE team_id=? ORDER BY user_id',(team_id,))]
    assert directory==expected;checks+=1
    audit=list(db.execute('SELECT revision,event_id,request_hash FROM academy_team_audit WHERE team_id=? ORDER BY revision',(team_id,)))
    assert [a['revision'] for a in audit]==list(range(1,row['revision']+1));checks+=1
    assert len({a['event_id'] for a in audit})==len(audit);assert all(a['request_hash'] for a in audit);checks+=2
    histories=list(db.execute('SELECT revision FROM academy_team_history WHERE team_id=?',(team_id,)))
    assert all(any(a['revision']==h['revision'] for a in audit) for h in histories);checks+=1
    tokens=list(db.execute('SELECT token_hash,invite_id FROM academy_invite_tokens WHERE team_id=?',(team_id,)))
    assert {(t['token_hash'],t['invite_id']) for t in tokens}=={(i['tokenHash'],i['id']) for i in team['invites']};checks+=1
    rows.append({'teamId':team_id,'sourceRevision':row['revision'],'memberPairs':len(directory),'auditRows':len(audit),'historyRows':len(histories),'tokenRows':len(tokens),'inactiveMembersRetained':sum(m['active'] is False for m in team['members'])})
finally:
  db.close()
result={'passed':True,'checks':checks,'teams':rows,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'databaseMode':'mode=ro plus query_only','limits':['Read-only exact synthetic-fixture inspection of the actual local D1 backing SQLite after supported API writes.','No SQLite/D1 mutation, production query, migration backfill or orphan/stale-pair fault injection.','Pre-M5 legacy parity and production migration are not demonstrated by this check.']}
(root/'api-evidence/directory-read-only-result.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'passed':True,'checks':checks,'teams':len(rows)}))
