APLYD ACADEMY — CURRENT INTEGRATED LOCAL QA
Root-confirmed stable Worker: 89617 on http://127.0.0.1:8787.
Executed 5 October 2026, with unique synthetic trusted-header accounts and fictional data only.

RESULTS
- Integrated API: 628 checks, 544 actual loopback calls, 507 successful bodies accepted, 12 scenarios.
- Read-only actual local D1 backing SQLite: 16 assertions across two synthetic teams. Canonical membership pairs equal normalized directory rows; projected markers1; all revisions have exactly one audit with request hash; retained invite/token map agrees; archived revisions join audit revisions.
- Actual integrated browser: 14 new envelope/uncertain-write scenarios +9 identity/scratch regressions +8 parser/recovery regressions +12 non-JSON read/cache scenarios. Zero page errors.
- 13 actual source hashes recorded before QA and rechecked unchanged afterward.
- Every process finished. No application source edits, application build, Worker start/stop, direct SQL writes or production calls were performed.

TOP-LEVEL EVIDENCE
integrated-evidence.json — final combined result and limits.
runtime/source-evidence.json — actual source hashes compiled before execution.
api-evidence/integrated-api-result.json — full actual request/check trace and source/module hashes.
api-evidence/directory-read-only-result.json — exact read-only synthetic D1 consistency counts.
browser-evidence/acceptance-browser-result.json — new integrated response/context acceptance scenarios.
identity-evidence/identity-browser-result.json — same-account scratch, subject changes, denied reads, stale directory fencing, acknowledged write plus failed directory.
response-recovery-evidence/response-recovery-result.json — malformed successful/missing identity envelopes, plain errors, stale non-JSON denial, unreadable acknowledged save without retry.
nonjson-read-evidence/nonjson-read-result.json —401/403/404 masking and503 cached-view controls, selected shared/directory/personal reads, screenshots.
api-evidence/first-harness-status-failure.json — preserved initial test-expectation error. Unsupported preference mode intentionally returns format-review409, not422. The test was corrected to exact per-field source statuses, and a fresh fixture passed. This failed run is not counted as acceptance evidence.

COVERAGE DETAILS
Actual create/cohort/invite/accept, private authoring independent review/publication and pinned private enrollment, support metadata/full assigned audience, network host/participant/peer/history, removed own history, current directory visibility.
Own optional learningAccess preferences: strict extra fields, language canonicalization, unsupported mode handling, authentication, CAS races, durable replay/mismatch, other-person and other-workspace isolation, unchanged enrollment state, exclusion from team/directory staff projection.
Structured read-back: exact human method/same pinned language/three true declarations, assisted binding, no helper or approval field, wrong enrollment and actor refusal, immutable submitted declaration+evidence, replay single attempt, staff metadata privacy before assignment. Legacy assisted:true without structured declaration remains readable and is not represented as approved accommodation.
M5-supported mutation behavior: same-revision invite acceptance/member update race, one winning commit, retained removed membership/empty roles, restoration, cross-workspace token collision rollback, real archive boundary at200 hot activity rows, winning archive and durable replay without duplicates.
Client failures: wrong requested workspace; null cohort/enrollment/auxiliary array; malformed or foreign private content snapshot; wrong directory subject/null row/duplicate workspace; wrong-account/wrong-workspace/nonadvancing successful write acknowledgement. Private state is masked; own unacknowledged invitation scratch returns only after deliberate same-account canonical refresh; exactly one POST commits, never an automatic retry or misleading workspace switch.
Plain denied/unreadable reads remove protected caches; valid JSON503 retains the established cached view by design. Late reads cannot overwrite a newer subject/workspace. Fresh identity change clears earlier account scratch.

RERUN FROM WORKSPACE ROOT AFTER A NEW ROOT STABLE SIGNAL
Use the bundled Node executable or an equivalent supported Node runtime.
  node outputs/aplyd-academy-eight-hour/integrated-qa/build-current-acceptance.mjs
  ACADEMY_QA_WORKER=<root-session> node outputs/aplyd-academy-eight-hour/integrated-qa/integrated-api.mjs
  ACADEMY_QA_WORKER=<root-session> node outputs/aplyd-academy-eight-hour/integrated-qa/acceptance-browser.mjs
  ACADEMY_QA_WORKER=<root-session> node outputs/aplyd-academy-eight-hour/integrated-qa/identity-browser-current.mjs
  ACADEMY_QA_WORKER=<root-session> node outputs/aplyd-academy-eight-hour/integrated-qa/response-recovery-current.mjs
  ACADEMY_QA_WORKER=<root-session> node outputs/aplyd-academy-eight-hour/integrated-qa/nonjson-read-current.mjs
  python3 outputs/aplyd-academy-eight-hour/integrated-qa/read-only-directory-check.py
ACADEMY_APP_PATH overrides checkout discovery. The helpers assert a loopback URL. Evidence directories are outside checkout by default. The read-only diagnostic requires exactly one root local D1 SQLite file and uses mode=ro plus query_only; it never creates or mutates a fixture.
Browser suites use real application controls and request interception; no React internals. The identity/recovery scripts are faithful current-source-compatible copies of existing checked-in scripts, with external evidence paths. Read-back dialog/speech/mobile checks are separately owned by accessibility_mobile.

PRECISE LIMITS
- New integration evidence is distinct from the earlier109-check candidate compatibility run on Worker20501. That earlier run did not exercise the integrated shell or M5.
- Parent-reported stable Worker identity, recorded source hashes and actual UI/API execution ground this run; hashes alone are not independent production bundle attestation.
- Basic response acceptance is a bounded render/context guard, not a complete nested domain schema or a replacement for server authorization.
- No pre-M5 legacy-row byte parity, forced old-row corruption, missing/stale projection-pair fault, forced archive PK failure, production SQL migration, hosted dispatcher authentication, real identity-provider login or disaster recovery was demonstrated.
- No outbound invitation, partner transport, provider AI, microphone, translation service or recipient notification.
- Root noted the existing FormError text “last action not saved” may misdescribe a failed read or acknowledged cleanup warning; neutral attention copy is a separate forthcoming source change, not treated as a failed identity boundary here.
