Offline count-column readability polish

Only td renderer style changes from width:5rem to width:1%;white-space:nowrap. No text size, label, numeric count, whitelist, model projection, script/asset policy, UI or print semantic changes.

Actual unchanged model generated valid pure memory recaps containing0,200 and48000 (intended minutes maximum). Current baseline fixed5rem was compared with5ch. Plain5ch wrapped48000 at390px/32px text, so its failed experiment remains preserved in offline-comparison-initial.json. Final5ch/nowrap versus content-sized1%/nowrap comparison passes48 renders (24 per proposed variant) at390/768/1440 screen widths and718px CSS print content width, each with16/32px body text. Every displayed number remains a single line and no page overflows.

Chosen content-sized column gives enlarged-phone label width249.16px for zero plan,233.28px for200 practice rows, and206.83px for max48000 minutes; current fixed column gives153.22px in all cases. Completed stays one word/line rather than splitting. Maximum count48000 fits one line. No HTTP/Worker/source checkout mutation occurred; all browser requests were blocked, none attempted, and browsers closed.

See adoption-manifest.json for exact root-target patch/hash and geometry. Phone top/completed-label images were visually reviewed. Root must adopt/rebuild and regenerate an actual app download for affected acceptance; original18/134 browser proof remains intact. Print checks are CSS media geometry, not paginated paper/PDF proof.
