import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),app=resolve(here,'../../../../../work/aplyd-academy');
const html=readFileSync(here+'/unaffected-html-evidence/recap-2.html','utf8');
assert.ok(!/<script|\b(?:src|href|onload|onclick)\s*=|fetch\(/i.test(html));
const allVariants={original:html,bodyWrap:html.replace('body{max-width:','body{overflow-wrap:anywhere;max-width:'),tableFixed:html.replace('table{border-collapse:','table{table-layout:fixed;border-collapse:'),both:html.replace('body{max-width:','body{overflow-wrap:anywhere;max-width:').replace('table{border-collapse:','table{table-layout:fixed;border-collapse:'),liWrap:html.replace('p,th,td{overflow-wrap:','p,th,td,li{overflow-wrap:')};
const variants=process.env.ACADEMY_HTML_VARIANT?{[process.env.ACADEMY_HTML_VARIANT]:allVariants[process.env.ACADEMY_HTML_VARIANT]}:allVariants;
assert.ok(Object.values(variants).every(value=>typeof value==='string'));
const {chromium,browserOptions}=await import(pathToFileURL(app+'/tests/scoped-workbench-qa/browser-runtime.mjs')),browser=await chromium.launch(browserOptions),metrics=[],requests=[],errors=[];
try{
 for(const [variant,content]of Object.entries(variants)){
  const context=await browser.newContext({viewport:{width:390,height:900},serviceWorkers:'block'});await context.route('**/*',route=>{requests.push(route.request().url());return route.abort('blockedbyclient');});
  const p=await context.newPage();p.on('pageerror',e=>errors.push(e.message));await p.setContent(content,{waitUntil:'domcontentloaded'});await p.addStyleTag({content:'html{font-size:200% !important}'});
  const result=await p.evaluate(()=>({innerWidth,scrollWidth:document.documentElement.scrollWidth,bodyWidth:document.body.getBoundingClientRect().width,bodyScroll:document.body.scrollWidth,tableWidth:document.querySelector('table').getBoundingClientRect().width,offenders:[...document.querySelectorAll('body *')].map(e=>({tag:e.tagName,text:e.textContent.slice(0,80),left:e.getBoundingClientRect().left,right:e.getBoundingClientRect().right,scroll:e.scrollWidth,width:e.getBoundingClientRect().width})).filter(e=>e.right>innerWidth+1||e.left<-1||e.scroll>e.width+2)}));metrics.push({variant,...result});
  await p.screenshot({path:here+'/standalone-'+variant+'-200-percent.png',fullPage:true});await context.close();
 }
 assert.deepEqual(requests,[]);assert.deepEqual(errors,[]);
}finally{await browser.close();writeFileSync(here+'/standalone-layout-probe.json',JSON.stringify({at:new Date().toISOString(),metrics,requests,pageErrors:errors,browsersClosed:true,scope:'Offline downloaded constant/count HTML rendering only. No navigation, request, protected action, source checkout edit or server state modification. Variants are diagnostics and are not shipped acceptance.'},null,2)+'\n');console.log(JSON.stringify(metrics));}
