import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),app=resolve(here,'../../../../../work/aplyd-academy');
assert.equal(process.env.ACADEMY_M4_WEEKLY_STABLE,'1');assert.ok(process.env.ACADEMY_M4_WORKER);
const base='http://127.0.0.1:8787',f=JSON.parse(readFileSync(resolve(here,'../../../record-verification/integrated/evidence/fixtures.json'),'utf8'));
const headers={'Content-Type':'application/json','oai-authenticated-user-id':f.person.id,'oai-authenticated-user-email':f.person.email,'oai-authenticated-user-full-name':encodeURIComponent(f.person.name),'oai-authenticated-user-full-name-encoding':'percent-encoded-utf-8'};
const get=async()=>{const r=await fetch(base+'/api/academy',{method:'GET',headers,redirect:'error'});assert.equal(r.status,200);return r.json();};
const before=await get(),{chromium,browserOptions}=await import(pathToFileURL(app+'/tests/scoped-workbench-qa/browser-runtime.mjs')),browser=await chromium.launch(browserOptions),forbidden=[],errors=[],metrics=[];
try{
 const c=await browser.newContext({extraHTTPHeaders:headers,viewport:{width:390,height:1000},serviceWorkers:'block'});
 await c.route('**/*',async route=>{const r=route.request(),u=new URL(r.url());if(u.origin!==base||!['GET','HEAD'].includes(r.method())){forbidden.push({method:r.method(),path:u.pathname});return route.abort('blockedbyclient');}if(process.env.ACADEMY_PROBE_ATTENTION==='1'&&u.pathname==='/api/academy'&&r.method()==='GET'){const response=await route.fetch({maxRedirects:0}),j=await response.json();assert.equal(j.currentUserId,f.person.id);const at=new Date().toISOString();j.state.learningPlan.tasks=[{id:'m4-display-target-private',kind:'practice',enrollmentId:null,lessonId:null,title:'Display-only private target size',dueDate:null,plannedMinutes:15,note:'',status:'planned',createdAt:at,updatedAt:at,completedAt:null}];return route.fulfill({response,json:j});}return route.continue();});
 const p=await c.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto(base+'/#plan');await p.locator('[data-save-state="loaded"]').waitFor();
 await p.locator('[data-own-weekly-review] summary').click();
 for(const width of [390,768,1440]){
  await p.setViewportSize({width,height:1000});
  for(const zoom of [100,200]){
   const style=zoom===200?await p.addStyleTag({content:'html{font-size:200% !important}'}):null;
   await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   metrics.push(await p.locator('[data-own-weekly-review]').evaluate((e,{width,zoom})=>({width,zoom,overflow:document.documentElement.scrollWidth>innerWidth+1,summaryHeight:e.querySelector('summary').getBoundingClientRect().height,summaryFont:getComputedStyle(e.querySelector('summary')).fontSize,buttonHeights:[...e.querySelectorAll('button')].map(n=>({name:n.textContent,height:n.getBoundingClientRect().height,width:n.getBoundingClientRect().width})),frozenMain:document.getElementById('main').getAttribute('data-operation-scope')}),{width,zoom}));
   if(style)await style.evaluate(e=>e.remove());
  }
 }
 await c.close();assert.deepEqual(await get(),before);assert.deepEqual(forbidden,[]);assert.deepEqual(errors,[]);
}finally{await browser.close();writeFileSync(here+(process.env.ACADEMY_PROBE_ATTENTION==='1'?'/layout-probe-attention.json':'/layout-probe.json'),JSON.stringify({at:new Date().toISOString(),worker:process.env.ACADEMY_M4_WORKER,metrics,forbidden,pageErrors:errors,browsersClosed:true,scope:process.env.ACADEMY_PROBE_ATTENTION==='1'?'GET/HEAD-only existing approved own personal fixture; one own practice row is a labelled in-memory GET display copy only. No state write, download, external origin or protected action.':'GET/HEAD-only existing approved own personal fixture; no display mutation, state write, download, external origin or protected action.'},null,2)+'\n');console.log(JSON.stringify(metrics));}
