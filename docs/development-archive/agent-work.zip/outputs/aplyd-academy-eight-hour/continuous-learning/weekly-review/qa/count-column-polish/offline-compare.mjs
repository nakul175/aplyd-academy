import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url)),app=resolve(here,'../../../../../../work/aplyd-academy');mkdirSync(here,{recursive:true});
const {deriveOwnWeeklyReview,prepareOwnWeeklyRecap,renderOwnWeeklyRecapHtml}=await import(pathToFileURL(app+'/lib/academy-weekly-review.mjs'));
const {learningPlanSummary}=await import(pathToFileURL(app+'/lib/academy-plan.ts'));
const sourceHash=createHash('sha256').update(readFileSync(app+'/lib/academy-weekly-review.mjs')).digest('hex');
const now=new Date().toISOString(),today=now.slice(0,10),made=new Date(Date.now()-120000).toISOString();
function fixture(count,minutes){
 const s={enrollments:[],followups:[],paused:[],learningPlan:{goal:'explore',personalGoal:'LOCAL_GEOMETRY_PRIVATE_GOAL',weeklyMinutes:600,timeZone:'UTC',remindersEnabled:false,tasks:Array.from({length:count},(_,i)=>({id:'memory-'+i,kind:'practice',enrollmentId:null,lessonId:null,title:'LOCAL_GEOMETRY_PRIVATE_TITLE',note:'LOCAL_GEOMETRY_PRIVATE_NOTE',dueDate:today,plannedMinutes:minutes,status:'done',createdAt:made,updatedAt:now,completedAt:now}))}};
 const review=deriveOwnWeeklyReview(learningPlanSummary(s,{now,resolveProgram:()=>undefined}),now);assert.ok(review);return review;
}
const fixtures={zero:fixture(0,5),count200:fixture(200,5),minutes48000:fixture(200,240)};
assert.equal(prepareOwnWeeklyRecap(fixtures.zero).selfReportedPractice,0);assert.equal(prepareOwnWeeklyRecap(fixtures.count200).selfReportedPractice,200);assert.equal(prepareOwnWeeklyRecap(fixtures.minutes48000).planned.minutes,48000);
const allVariants={rem5:html=>html,ch5:html=>html.replace('td{font-weight:700;width:5rem}','td{font-weight:700;width:5ch}'),ch5NoWrap:html=>html.replace('td{font-weight:700;width:5rem}','td{font-weight:700;width:5ch;white-space:nowrap}'),content:html=>html.replace('td{font-weight:700;width:5rem}','td{font-weight:700;width:1%;white-space:nowrap}')};
const variants=process.env.ACADEMY_COLUMN_VARIANTS?Object.fromEntries(process.env.ACADEMY_COLUMN_VARIANTS.split(',').map(n=>[n,allVariants[n]])):allVariants;
assert.ok(Object.values(variants).every(v=>typeof v==='function'));
const {chromium,browserOptions}=await import(pathToFileURL(app+'/tests/scoped-workbench-qa/browser-runtime.mjs')),browser=await chromium.launch(browserOptions),metrics=[],requests=[],errors=[],screenshots=[];let passed=false;
try{
 for(const [fixtureName,review]of Object.entries(fixtures)){
  const original=renderOwnWeeklyRecapHtml(review);assert.ok(original.includes('width:5rem'));assert.ok(!original.includes('LOCAL_GEOMETRY_PRIVATE'));assert.ok(!/<script|\b(?:src|href|onload|onclick)\s*=|fetch\(/i.test(original));
  for(const [variant,transform]of Object.entries(variants)){
   const html=transform(original);writeFileSync(here+'/'+fixtureName+'-'+variant+'.html',html);
   const context=await browser.newContext({viewport:{width:390,height:1200},serviceWorkers:'block'});await context.route('**/*',route=>{requests.push({method:route.request().method(),url:route.request().url()});return route.abort('blockedbyclient');});
   const p=await context.newPage();p.on('pageerror',e=>errors.push(e.message));
   for(const media of ['screen','print'])for(const width of media==='screen'?[390,768,1440]:[718])for(const text of [100,200]){
    await p.setViewportSize({width,height:1200});await p.emulateMedia({media});await p.setContent(html,{waitUntil:'domcontentloaded'});if(text===200)await p.addStyleTag({content:'html{font-size:200% !important}'});
    const geometry=await p.evaluate(()=>{
     const lineRects=(element,start=0,end=element.textContent.length)=>{const r=document.createRange();r.setStart(element.firstChild,start);r.setEnd(element.firstChild,end);return [...r.getClientRects()].map(x=>({left:x.left,right:x.right,width:x.width,height:x.height}));};
     const rows=[...document.querySelectorAll('tr')].map(row=>{const th=row.querySelector('th'),td=row.querySelector('td');return {label:th.textContent,value:td.textContent,labelWidth:th.getBoundingClientRect().width,countWidth:td.getBoundingClientRect().width,countContentWidth:td.clientWidth-parseFloat(getComputedStyle(td).paddingLeft)-parseFloat(getComputedStyle(td).paddingRight),countRects:lineRects(td),labelLines:lineRects(th).length};});
     const completed=document.querySelector('tr:last-child th');return {viewportWidth:innerWidth,documentScrollWidth:document.documentElement.scrollWidth,bodyFont:getComputedStyle(document.body).fontSize,tableWidth:document.querySelector('table').getBoundingClientRect().width,tableHeight:document.querySelector('table').getBoundingClientRect().height,rows,completedWordRects:lineRects(completed,0,'Completed'.length),activeElements:document.querySelectorAll('script,a,img,iframe,form,link').length};
    });
    metrics.push({fixture:fixtureName,variant,media,width,text,...geometry});
    assert.ok(geometry.documentScrollWidth<=width+1,'No horizontal overflow');assert.equal(geometry.bodyFont,text===200?'32px':'16px','Body text remains unchanged');assert.equal(geometry.activeElements,0);
    assert.ok(geometry.rows.every(r=>r.countRects.length===1),'Every count stays on one line');
    if(media==='screen'&&width===390&&text===200&&fixtureName==='minutes48000'){
     const first=here+'/phone-390-200-'+variant+'-top.png';await p.screenshot({path:first,fullPage:false});screenshots.push(first);
     await p.locator('tr:last-child').scrollIntoViewIfNeeded();const last=here+'/phone-390-200-'+variant+'-last-label.png';await p.screenshot({path:last,fullPage:false});screenshots.push(last);
     const table=here+'/phone-390-200-'+variant+'-table.png';await p.locator('table').screenshot({path:table});screenshots.push(table);
    }
    if(media==='screen'&&width===390&&text===100&&variant==='content'){const path=here+'/phone-390-normal-'+fixtureName+'-content.png';await p.screenshot({path,fullPage:false});screenshots.push(path);}
    if(media==='print'&&text===200&&fixtureName==='minutes48000'&&variant==='content'){const path=here+'/print-718-200-count48000-content.png';await p.screenshot({path,fullPage:false});screenshots.push(path);}
   }
   await context.close();
  }
 }
 assert.deepEqual(requests,[]);assert.deepEqual(errors,[]);assert.equal(createHash('sha256').update(readFileSync(app+'/lib/academy-weekly-review.mjs')).digest('hex'),sourceHash);passed=true;
}finally{
 await browser.close();writeFileSync(here+'/offline-comparison.json',JSON.stringify({passed,at:new Date().toISOString(),sourceHash,renderedCases:metrics.length,metrics,requests,pageErrors:errors,browsersClosed:true,screenshots,limits:['Offline in-memory valid planning projections and static HTML only. No Worker, HTTP, stored fixture, protected action or root checkout edit. Every browser request is blocked.','Counts0/200/48000 are geometry fixtures derived through the actual unchanged planning/recap models, not claims about actual learner activity.','Print checks emulate CSS print media at718px A4 content width; no paginated printer/PDF or physical-paper proof.','Current18-scenario/134-assertion actual runtime acceptance remains unchanged. Comparison variants are proposed readability polish only, awaiting root adoption/rebuild and a newly downloaded-file check.']},null,2)+'\n');console.log(JSON.stringify({passed,renderedCases:metrics.length,requests:requests.length,pageErrors:errors.length}));
}
