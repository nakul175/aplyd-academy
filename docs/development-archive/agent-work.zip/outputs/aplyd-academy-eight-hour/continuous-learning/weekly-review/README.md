# Compact own weekly review for the existing Plan

Candidate only, outside the checkout. Twenty-two pure tests pass against an unchanged copy of the actual root planning module. Both TSX candidate files have no syntax diagnostics; this is not a full typecheck or application build. No API/browser/server call or fixture seeding occurred for this kit.

The current Plan combines linked saved actions and self-reported practice into one `completedActivitiesThisWeek` figure. This kit replaces its four-cell weekly stats and explanation with one compact own weekly review. It preserves the existing goal form, next useful step, due notice and full activity list. It adds no second dashboard or planning command.

Default view separates activities dated this week, retained plan items backed by saved course actions this week, and self-reported private practice. It keeps intended minutes/budget labelled as intention and displays blocked/undated open counts. One optional disclosure contains the saved lesson/submission/reflection breakdown, earlier/skipped work, at most six attention rows with real links into the existing activity list, and explicit download buttons.

The review uses `learningPlanSummary` and its existing `taskProgress` projection; it never re-evaluates eligibility or resolves another course version. Completion evidence can remain historical when current access/pin becomes unavailable. New unresolved/paused/withdrawn/inactive/appeal-gated activity keeps the existing blocked reason. The saved plan timezone, not the browser timezone or an unsaved form edit, sets the Monday–Sunday week. Planned dates and completion dates remain independent. Missing/future completion dates are displayed as needing review, not included in weekly completion counts.

Counts describe retained plan items, not unique evidence events, all course activity, assessed competence or job impact. A submission saved with failed assessment still counts only as a saved submission. Private practice remains self-reported. Attention counts may overlap and do not create an additional activity total. Skipped planned items do not contribute intended weekly minutes.

## Root adoption mapping

| Candidate | Root target |
| --- | --- |
| `academy-weekly-review.mjs` | `lib/academy-weekly-review.mjs` |
| `academy-weekly-review.d.mts` | `lib/academy-weekly-review.d.mts` |
| `OwnWeeklyReview.tsx` | `app/academy-weekly-review.tsx` |
| `academy-weekly-review.module.css` | `app/academy-weekly-review.module.css` |
| `existing-plan-integration.patch` | Existing `app/academy-plan.tsx` only |

`academy-plan.tsx.candidate` is the full review copy. The patch adds the import and replaces only the existing combined weekly stats/explanation. `removed-combined-stats.fragment.txt` records precisely what it replaces. Root owns review, adoption, strict typecheck, build, server and publication. Nothing is copied into the checkout by this workstream.

The library module imports the existing `academy-plan.ts`, consistent with the adopted content-readiness adapter style. Its `runtime/academy-plan.ts` test copy is byte-identical to the current root source; source hashes are in `source-manifest.json`. Regenerate these outside-checkout copies if root changes the planning module before adoption. Do not copy `runtime/` into the app.

## Local recap boundary

Both downloads are explicit type-button actions inside the collapsed disclosure. They require an accepted current account/workspace projection, no read error/loading state, and no pending save. Inactive accepted own history can still be reviewed/exported. They do not call a command, save a field, schedule a notification or send anything externally.

The JSON/standalone printable HTML reconstruct a whitelist of week dates, saved timezone, numeric counts and fixed explanations. They exclude personal goals, notes, activity titles, evidence/answers/reflections, contact details, account/workspace/task/enrollment/course identifiers, pins and revision metadata—even if those exist on the input object. Filenames contain only the week dates. HTML has no scripts, links, remote assets or automatic print call. The browser’s ordinary Print command is optional after opening the downloaded file.

The recap is a local count summary, not independently verified proof, a certificate, a passed assessment or a workplace outcome. JSON export format metadata is an artifact schema only; it adds no saved academy state or server API.

## Verification completed

Run pure candidate tests from the project root:

```sh
/Users/athena/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --experimental-transform-types --test outputs/aplyd-academy-eight-hour/continuous-learning/weekly-review/tests/weekly-review.test.mjs
```

Twenty-two cases cover empty plan, distinct intention/evidence/self-report, forged linked-done flags, due/completion boundary differences, saved timezone midnight and DST, exact unknown pin with retained evidence, access/role/pause/appeal blocks, missing/future completion times, overlapping attention, row limits, malformed projections, export whitelist, detached output, invalid counts and script/asset-free printable HTML. All data is in-memory test input; no stored identity or record is seeded.

See the reviewed `qa/reviewed-pure-test.tap` and original `pure-test.tap`, `candidate-syntax.json` and `candidate-evidence.json`. Syntax transpilation does not resolve the application imports or prove runtime accessibility. Root review/typecheck/build and bounded actual browser acceptance remain required before shipping.

## Later bounded browser acceptance

Wait for root’s new stable build/Worker signal. Use only existing approved local accounts and GETs, normal navigation/typing and deliberate local downloads; never click Save plan/Save activity/Mark complete/Skip or other protected commands. Block all non-GET/HEAD requests and external origins.

- Check one weekly review replaces the old combined stats; default details are collapsed and no duplicate plan dashboard exists.
- Compare dates/counts with the current accepted `learningPlanSummary` and saved timezone. Change the unsaved form minute budget/timezone/general goal; recap must continue to use saved values and exclude the goal text.
- Open the attention disclosure and navigate into an existing own activity. Preserve current block reasons and exact unknown pin; no fallback title/version or new learning authority is introduced.
- Download JSON/HTML explicitly. Parse both, confirm only whitelist fields, no private goal/note/title/evidence/contact/identifier marker, no HTML scripts/remote assets, and no network write. Compare saved own state/revision before/after.
- At 390px/CSS-root 200%, check metrics, summary, attention rows and buttons wrap; keyboard activation and ordinary navigation keep focus on valid current elements.
- Accepted account/workspace change or unverified read disables/removes old export. Own inactive history remains readable only after a current accepted own projection. Do not create new accounts/activities to fill test data; use in-memory pure coverage when existing fixtures do not contain a needed condition, unless root explicitly approves a read-display fixture.

No provider AI, third-party message, field-user UAT, hosted authentication, human screen-reader certification or real-job performance claim is part of this kit.

## M4 independent review correction

The initial candidate rejected every task title above100 characters. Actual published lesson/submission titles can be160, and a retained reflection title adds a fixed prefix. The reviewed candidate keeps100 for user-entered private practice and uses a bounded200-character envelope for linked titles. Two new pure cases exercise the unchanged actual planning command for long lesson/submission/reflection titles, then verify readable attention and title-free recap output; oversized inputs remain unavailable. The original model is preserved in `qa/reviewed-initial/`. All22 cases pass.

## Final M4 actual local acceptance

Root adopted the reviewed model and the two subsequent scoped layout corrections, completed strict application typecheck/build and supplied frozen Worker91739. The full actual browser suite passes18 scenarios/134 assertions. It verifies count separation, unsaved preferences, own attention navigation, exact unavailable/paused history, uncertain dates, long linked titles, inactive own history, rejected/mismatched reads, account/workspace changes, malformed projection, all new44px review controls at390/768/1440px and200% text, and a newly downloaded standalone HTML document at390px/200% text.

Zero protected writes, external page requests or page exceptions occurred. Four existing fictional own saved snapshots—including revisions/team projections—are unchanged. Adopted source, root build and frozen runtime hashes remain stable, and the copied entry matches the root build. Every browser is closed. See `qa/final-runtime-evidence/browser-evidence.json` and `qa/final-acceptance-summary.json`.

The original harness enrollment-id mistake, actual touch-target failure and actual offline list-item overflow failure remain preserved separately. Diagnostic style variants were never counted as shipped acceptance. Local display-copy states establish rendering guards, not stored server states, real user identity, field usability or external ecosystem delivery. Pending protected-save coverage remains source-reviewed only while direct fictional fixture approval is pending. Root owns publication and all public release claims.

## Final source acceptance after count-column polish

Root subsequently adopted one renderer-style change: numeric cells use a content-sized column with no number wrapping. Offline valid0/200/48000 count projections passed48 comparative renders, including unchanged16/32px body text at390/768/1440px screen widths and718px CSS print content width. The chosen variant reserves only the width each table’s longest displayed number needs, leaving more width for labels. No Worker or HTTP was used in that comparison; proposed variants remained separate from release proof.

After root’s final strict typecheck/build and675 Node entries passed, the rebuilt frozen Worker97593 passed all18 actual browser scenarios/138 assertions. The newly downloaded phone recap retains32px body text, a270.55px label column, whole-word Completed, single-line counts and no overflow. Zero protected writes, external requests or page exceptions occurred; all four saved fixture snapshots and source/build/frozen-runtime hashes remain unchanged. Every browser/check is closed. Root may stop the Worker and publish.

Latest evidence is `qa/publish-runtime-evidence/browser-evidence.json` and `qa/publish-acceptance-summary.json`; the earlier18/134 report remains preserved in its original folder. Root owns commit/main merge/native publication. Offline print geometry does not establish paginated or physical-paper output.
