import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
const dir="/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/outputs/aplyd-academy-eight-hour/record-verification/integrated/readonly",f=dir+'/browser-readonly.mjs';let s=readFileSync(f,'utf8');
s=s.replace("assert.equal(await p.getByRole('button',{name:'Download my record',exact:true}).count(),1);await ownPanel(p)","await p.getByRole('button',{name:'Download my record',exact:true}).waitFor();assert.equal(await p.getByRole('button',{name:'Download my record',exact:true}).count(),1);await ownPanel(p)");
writeFileSync(f,s);copyFileSync("/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/outputs/aplyd-academy-eight-hour/record-verification/integrated/evidence/read-only-browser/browser-result.json","/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/outputs/aplyd-academy-eight-hour/record-verification/integrated/evidence/read-only-browser/browser-result-first-readiness-failure.json");
console.log('Outside browser readiness assertion corrected and failed-run evidence retained.');

