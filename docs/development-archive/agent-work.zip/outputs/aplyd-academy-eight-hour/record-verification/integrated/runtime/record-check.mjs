// ../../../../work/aplyd-academy/lib/curriculum-versions/0.1-review-draft.json
var review_draft_default = {
  schemaVersion: "1.0",
  contentVersion: "0.1-review-draft",
  product: "Aplyd Academy",
  status: "Review draft: not approved sector training, accredited curriculum, or professional advice",
  language: "en",
  audience: "Adult learners",
  designNotes: [
    "All people, orders, records, documents, policies and AI outputs in this file are fictional teaching fixtures.",
    "Supplied AI drafts allow the whole journey to work without an external AI account or API call.",
    "An approved external AI tool may optionally produce another draft using the synthetic packet only. Learners must not enter real confidential material or credentials.",
    "Quiz feedback supports learning. A quiz score alone must not issue a competency credential.",
    "Practical assessment requires an assigned human reviewer. Rubric weights and critical gates are proposed, published training standards for this draft.",
    "A facilitator may read lesson text and capture an oral response with learner confirmation when an approved accommodation exists. Assistance must be recorded and must not supply the judgment answer."
  ],
  assessmentPolicy: {
    scoreScale: [0, 1, 2, 3, 4],
    weightedScoreFormula: "Sum of criterion weight multiplied by criterion score divided by 4; maximum 100",
    minimumWeightedScore: 70,
    passingRule: "Weighted score is at least 70 AND every declared critical gate is met. A critical failure cannot be averaged away.",
    decisionAuthority: "Assigned independent human assessor; no self-assessment or autonomous AI credential decision",
    feedbackRule: "Record score, evidence reference, critical-gate decision and actionable feedback for each criterion.",
    retryRule: "Retries and deadlines must be published by the offering before enrollment. Do not infer a fixed retry allowance from this seed file.",
    appealRule: "A learner may request a reasoned review under the offering's published appeal policy. The appeal reviewer must be independent of the original decision."
  },
  pathways: [
    {
      id: "farmer-work-records",
      title: "Farm records and better questions with AI",
      ecosystem: "Agri Saha",
      role: "Farmer",
      level: "Foundation to applied",
      summary: "Organize an activity record, check an AI-generated summary, and prepare useful questions for an agricultural expert.",
      promise: "You can turn a simple farm record into a verified summary and explain what still needs expert input.",
      estimatedMinutes: 110,
      prerequisites: ["Understand the example currency amounts with help if needed", "Use a simple form or receive planned facilitator assistance"],
      outcomes: ["Distinguish a duplicate transaction from a separate expense", "Check totals against source records", "Spot unsupported AI claims", "Create a clear expert question brief", "Keep private or commercially sensitive records out of unapproved tools"],
      credentialClaim: "Demonstrated farm-record organization, information checking and expert-question preparation using synthetic training data",
      credentialExclusions: ["No agricultural professional qualification", "No certification to prescribe farm inputs or make agronomic decisions"],
      sourceNotice: "Synthetic farm records supplied within each activity are the only factual source for this exercise.",
      lessons: [
        {
          id: "farm-01",
          title: "Make a useful work record",
          estimatedMinutes: 25,
          objective: "Build a consistent record and verify a duplicate before calculating a total.",
          lessonText: "A useful record separates what happened from what you think it means. Start with a date, activity, transaction reference, amount and unit where needed. A repeated line may be a duplicate, but two similar expenses can also be real. Check the reference or original receipt before removing anything. In this exercise, the source packet explicitly says that T02 was copied twice and represents one transport payment. Keep a note of that correction. Add the verified amounts rather than trusting a total supplied by a tool. AI can help organize a table or explain a calculation, but it cannot know which entry is genuine without evidence. When you use your own records later, keep the master copy in your approved location and choose a tool you are permitted to use. You do not need to upload names, telephone numbers, bank information or exact location details to practise this skill.",
          steps: ["Read the source packet", "Create one row per confirmed transaction", "Record why the extra T02 line was removed", "Calculate the verified total", "Identify one field you would add for future records"],
          exercise: {
            title: "Clean the fictional farm activity record",
            sourcePacket: [
              { sourceId: "T01", date: "2026-10-01", activity: "Recordkeeping support", quantity: 3, unit: "hours", rate: 150, amount: 450, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR" },
              { sourceId: "T03", date: "2026-10-03", activity: "Storage materials", quantity: 1, unit: "lot", rate: 800, amount: 800, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR", sourceNote: "Confirmed copied line; same receipt and payment as T02 above" }
            ],
            suppliedAiDraft: "The four entries total INR 1,550. Each row is a separate expense.",
            optionalAiPrompt: "Organize the supplied fictional transactions into a table. Use the source note to handle duplicates, show the calculation, and list uncertainty. Do not infer farm area, crop performance or missing transactions.",
            learnerTask: "Produce a corrected three-row table, show your total and explain the duplicate correction.",
            expectedEvidence: ["Corrected rows with source references", "450 + 150 + 800 = 1,400", "Note that T02 was removed once because the source confirms a copied payment", "One useful future record field such as receipt reference or unit"],
            assessorReference: "There are three confirmed transactions totaling INR 1,400. The raw four-line total is INR 1,550, but that counts the confirmed T02 copy twice. A learner must not generalize that every repeated amount is a duplicate."
          },
          quiz: [
            { id: "farm-01-q1", question: "What is the verified expense total?", options: ["INR 1,400", "INR 1,550", "INR 1,250", "It must be guessed from the activities"], correctOptionIndex: 0, explanation: "T02 is a confirmed copy of the same payment. The three verified amounts are 450, 150 and 800, which total 1,400." },
            { id: "farm-01-q2", question: "Two entries have the same amount but different receipt references. What should you do?", options: ["Delete the second amount automatically", "Keep both as confirmed without checking", "Check the source records before deciding whether either is duplicated", "Ask AI to choose the genuine one without evidence"], correctOptionIndex: 2, explanation: "Equal amounts are not proof of duplication. The original references and payment evidence decide whether the expenses are separate." },
            { id: "farm-01-q3", question: "Which practice input is suitable for this activity?", options: ["Your bank login details", "The supplied fictional record", "A neighbor's private transaction history", "Any record because AI makes it anonymous"], correctOptionIndex: 1, explanation: "The fictional record provides enough information for practice. Uploading private or secret information is unnecessary and inappropriate." }
          ],
          reflectionPrompt: "Which record field would make it easier for you to check a future total, and why?",
          returnToWorkAction: "Create a blank record template in an approved location. Use it for one permitted task and check entries against the original records before any sharing."
        },
        {
          id: "farm-02",
          title: "Check an AI summary before using it",
          estimatedMinutes: 20,
          objective: "Separate supported observations, missing context and unsupported recommendations.",
          lessonText: "A summary can sound confident while mixing correct statements with invented ones. Check important statements one at a time. Ask what evidence supports each claim. A total can be checked against transaction rows. A cost per acre needs area information. A claim about crop results needs relevant evidence, rather than a guess based on expenses. In this activity, the verified spending record tells you what was recorded; it does not tell you the farm area, complete budget, crop condition or likely yield. Mark these gaps explicitly. When a claim could affect a significant farm decision, prepare a question for an appropriate expert instead of treating an AI draft as a recommendation. A useful summary includes the known total, its limited scope, and the missing information. Verification is part of the work, even when it takes more time than generating the draft.",
          steps: ["Check the total", "Label each claim supported, unsupported or unknown", "Explain what evidence a per-acre figure would need", "Rewrite the summary with limits", "Identify the claim that needs expert input"],
          exercise: {
            title: "Find the unsupported claims",
            sourcePacket: ["Verified transactions: T01 INR 450; T02 INR 150; T03 INR 800.", "Recorded total: INR 1,400.", "Farm area, crop condition, total seasonal budget and crop outcomes are not supplied."],
            suppliedAiDraft: "The recorded expenses are INR 1,400. That is INR 700 per acre. These purchases will increase yield by 30%, so the farmer should immediately repeat them.",
            optionalAiPrompt: "Summarize only the supplied synthetic expense record. For every statement distinguish source-supported facts from missing context. Do not predict yield or recommend actions.",
            learnerTask: "Annotate the draft and create a two- or three-sentence corrected summary.",
            expectedEvidence: ["Total supported by the three transaction rows", "Per-acre claim rejected because area is missing", "Yield and immediate-action claims rejected as unsupported", "Corrected summary describes recorded expenses and missing context", "Expert referral for consequential recommendations"],
            assessorReference: "The packet supports only the INR 1,400 recorded total. It does not establish cost per acre, a 30% yield effect or a decision to repeat the purchases. Accept a cautious summary using equivalent plain language."
          },
          quiz: [
            { id: "farm-02-q1", question: "Which claim is supported by the packet?", options: ["Yield will rise by 30%", "The farm has two acres", "The recorded expenses total INR 1,400", "Repeating the purchases is the right decision"], correctOptionIndex: 2, explanation: "The transaction amounts support the total. Area, yield and action advice are not in the source packet." },
            { id: "farm-02-q2", question: "Why is INR 700 per acre unverified?", options: ["It is too small", "The packet does not give the farm area", "All AI calculations are wrong", "Per-acre costs can never be calculated"], correctOptionIndex: 1, explanation: "A cost per acre requires a relevant area and a defined cost scope. The area is absent, so the figure is unsupported here." },
            { id: "farm-02-q3", question: "What is the appropriate response to the draft's yield recommendation?", options: ["Act immediately because the wording is confident", "Forward it as approved guidance", "Ask AI to make the recommendation stronger", "Mark it unsupported and seek appropriate expert input before a consequential action"], correctOptionIndex: 3, explanation: "The provided record does not support a yield prediction or action. Recognizing the limit and escalating is the responsible response." }
          ],
          reflectionPrompt: "What is one confident-sounding statement you would still need to check?",
          returnToWorkAction: "For your next permitted AI-assisted summary, label important statements as verified, unverified or requiring expert input before using the draft."
        },
        {
          id: "farm-03",
          title: "Prepare a useful expert conversation",
          estimatedMinutes: 30,
          objective: "Turn a checked record into a concise question brief without claiming an unsupported decision.",
          lessonText: "AI is useful when it helps you organize questions, rather than deciding something it cannot support. A good expert brief states the purpose, summarizes verified information, identifies missing context, and asks specific questions. Keep facts separate from assumptions. Do not turn a missing detail into a made-up answer. In this example, you can explain that three recorded expenses total INR 1,400 and that a previous draft invented a yield claim. You can ask what additional records an expert needs and how to check any recommendation. The expert may need information beyond the training packet; share it only through an approved channel and only when relevant. Keep the brief short enough to use during a conversation. Afterward, record what was confirmed, what remains uncertain and who will take the next step. This pathway demonstrates recordkeeping and information judgment, not authority to prescribe farm practices.",
          steps: ["State the conversation's purpose", "Include the checked record total and sources", "List three relevant missing details", "Write three specific expert questions", "Choose an approved way to use the brief"],
          exercise: {
            title: "Build the expert question brief",
            sourcePacket: ["Use the verified three-row record from farm-01.", "The earlier AI draft's per-acre and yield claims were unsupported.", "No farm area, crop condition or complete seasonal expense record is provided."],
            suppliedAiDraft: "Expert brief: Our two-acre farm will gain 30% yield if we repeat the purchases. Please approve this plan.",
            optionalAiPrompt: "Create a short question brief from the supplied fictional packet. Separate verified facts, missing context and questions. Do not invent area, crop condition or outcomes, and do not request approval of an unsupported plan.",
            learnerTask: "Produce a 120\u2013200 word brief or equivalent oral response with verified facts, gaps, questions and next action.",
            expectedEvidence: ["Purpose: seek informed guidance about what information is needed", "Checked INR 1,400 recorded total with transaction references", "Missing area, crop context and record completeness", "Questions about needed information and verification, rather than a demanded action", "Next action stays within recordkeeping and approved expert consultation"],
            assessorReference: "A suitable brief says the record is limited, removes invented area/yield details, asks what further information is needed and how to verify advice, and uses an approved channel. Equivalent plain-language or approved oral evidence is acceptable."
          },
          quiz: [
            { id: "farm-03-q1", question: "Which question best fits the available information?", options: ["Can you confirm the promised 30% increase?", "What additional information do you need to interpret these recorded expenses?", "Which input should everyone buy?", "Can we omit the original records?"], correctOptionIndex: 1, explanation: "The question acknowledges the limited packet and asks an expert for the missing context needed for interpretation." },
            { id: "farm-03-q2", question: "What should the brief do with the invented two-acre detail?", options: ["Keep it because it is convenient", "Describe it as verified", "Remove it and state that area is not supplied", "Replace it with another guess"], correctOptionIndex: 2, explanation: "A missing field should remain a documented gap until appropriate evidence is available." },
            { id: "farm-03-q3", question: "What does this pathway's competency credential demonstrate?", options: ["Authority to prescribe crop inputs", "A professional agricultural qualification", "A guaranteed yield improvement", "Record organization, information checking and expert-question preparation"], correctOptionIndex: 3, explanation: "The credential must describe the assessed capability accurately. It does not create professional authority or guarantee an outcome." }
          ],
          reflectionPrompt: "How would this brief help an expert understand your question without pretending that every detail is known?",
          returnToWorkAction: "Use a blank fact\u2013gap\u2013question template for one permitted work conversation. Record the expert's confirmed guidance separately from your own assumptions."
        }
      ],
      practicalAssessment: {
        id: "farm-practical-01",
        title: "A verified farm record and expert brief",
        scenario: "A facilitator asks you to prepare the fictional T01/T02/T03 record for an expert conversation. The extra T02 row is a confirmed copy. The supplied AI output contains unsupported area and yield statements.",
        submissionPrompts: [
          { id: "task", label: "What are you trying to achieve and for whom?", help: "State the purpose of the record and expert conversation." },
          { id: "record", label: "Your corrected record and calculation", help: "Include source IDs, explain the duplicate treatment and show the INR total." },
          { id: "safe-input", label: "What information is safe to use?", help: "Identify the synthetic packet and information you would exclude from an unapproved tool." },
          { id: "ai-evidence", label: "The draft you reviewed and instructions you used", help: "You may review the supplied draft without opening an AI tool. Describe instructions for a safer draft." },
          { id: "checks", label: "Checks, errors and corrections", help: "Explain the total, area gap, invented yield statement and action recommendation." },
          { id: "final", label: "Final expert question brief", help: "Separate verified facts, missing information and questions." },
          { id: "return", label: "Your return-to-work action and boundary", help: "Describe a safe action such as improving records or using an approved expert channel." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable record or brief", "1": "Major record errors or an unclear brief", "2": "Mostly usable output with a material omission", "3": "Correct three-row record, INR 1,400 total and clear brief", "4": "Correct output with concise source mapping, useful questions and a reusable structure" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts the flawed output without checks", "1": "Checks only one minor detail", "2": "Checks total and duplicate but incompletely explains unsupported claims", "3": "Shows arithmetic and source-based rejection of invented area/yield claims", "4": "Checks all material claims and clearly distinguishes confirmed facts from unknowns" }, criticalGate: "Must not retain the invented yield or immediate-action claim as verified guidance" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual secrets or inappropriate private records", "1": "Cannot identify what should be excluded", "2": "Uses the synthetic packet but gives incomplete handling reasons", "3": "Uses only synthetic evidence and identifies private information to withhold", "4": "Adds an approved-channel plan with minimal necessary sharing" }, criticalGate: "No actual private records, third-party personal information or credentials submitted or proposed for unapproved use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Acts on unsupported consequential advice", "1": "Mentions caution without a usable next step", "2": "Identifies a limit but an unclear expert question", "3": "Asks relevant expert questions and limits the immediate action to permitted work", "4": "Explains escalation, missing context and how confirmed advice will be recorded" }, criticalGate: "Consequential farm decisions are not justified by this expense packet; the brief seeks appropriate expert input" }
        ],
        samplePassingEvidence: "I counted T02 once because the source identifies its duplicate. The total is 450 + 150 + 800 = INR 1,400. No farm area or yield evidence is supplied, so I removed INR 700 per acre and 30% yield improvement. I used fictional data only. My brief asks what context and further records an expert needs. My immediate work action is to maintain a checked record and seek guidance through an approved channel.",
        sampleCriticalFailure: "The learner produces a polished brief but recommends repeating the purchases to obtain a 30% yield improvement without verification. The verification and judgment gates fail regardless of aggregate score.",
        assessorNote: "Do not require advanced agricultural terminology, typing speed or use of a particular AI brand. Assess the record, checks, handling and explanation."
      },
      followUp: { afterDays: 14, question: "Did you use a checked record or expert question brief for a permitted task?", evidenceOptions: ["A structured reflection with no private record contents", "A blank improved template", "Facilitator-confirmed use under an approved process"], successSignal: "The learner can explain one check performed and one limit or question identified", privacyNote: "Do not collect real farm documents by default." }
    },
    {
      id: "msme-customer-operations",
      title: "Customer communication and daily operations with AI",
      ecosystem: "MSME",
      role: "MSME owner or team member",
      level: "Foundation to applied",
      summary: "Draft an accurate customer response, organize a daily work checklist, and measure whether AI assistance actually helped.",
      promise: "You can produce a useful customer draft and operations checklist while checking promises, information use and task quality.",
      estimatedMinutes: 110,
      prerequisites: ["Read a short order policy with help if needed", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Separate customer-relevant facts from internal details", "Avoid invented stock, dispatch and pricing commitments", "Create a source-based action checklist", "Compare time and quality including verification work", "Keep human approval for commitments outside the stated policy"],
      credentialClaim: "Demonstrated customer-draft preparation, operations checklist creation and responsible AI checking using synthetic business records",
      credentialExclusions: ["No financial, tax or legal professional qualification", "No assurance of business results or automated customer commitments"],
      sourceNotice: "The example order policy and records are fictional fixtures, not a recommended business policy.",
      lessons: [
        {
          id: "msme-01",
          title: "Write a customer response you can stand behind",
          estimatedMinutes: 25,
          objective: "Draft an accurate response using permitted facts and withhold irrelevant internal details.",
          lessonText: "A helpful customer response is clear about what is confirmed and what still needs checking. AI can make a message sound polished, but it may invent a discount, a delivery promise or available stock. Start by listing the facts the customer needs. Keep internal costs, private contact information and unrelated customer details out of an unapproved AI prompt. In this fictional policy, an item costs INR 120, delivery is INR 60 and pickup has no delivery fee. Only four units are confirmed in stock, while the customer requests six. That means a six-unit dispatch cannot be promised yet. You can explain the confirmed stock and say the team will check options; do not assume an arrival date. Check every promise in the draft against the supplied policy and records. Treat the final response as a draft for human approval whenever it changes a commitment or exceeds your role.",
          steps: ["Read the request, stock and policy", "Identify customer-relevant facts", "Remove irrelevant internal details from the prompt", "Correct the supplied AI draft", "Mark the check needed before sending"],
          exercise: {
            title: "Respond to a six-unit request",
            sourcePacket: [
              { sourceId: "P1", type: "fictional policy", content: "Unit price INR 120. Delivery fee INR 60 per order. Pickup delivery fee INR 0. Dispatch quantity and date require stock-team confirmation. Exceptions require supervisor approval." },
              { sourceId: "O101", type: "fictional request", content: "Customer C requests six blue units and asks whether all can be delivered on Friday." },
              { sourceId: "S1", type: "fictional stock record", content: "Four blue units are confirmed available. Arrival date for additional units is unknown." },
              { sourceId: "I1", type: "internal fixture", content: "Internal unit cost INR 75; private contact marker [PRIVATE CONTACT]; unrelated account notes. These are not needed for the customer draft." }
            ],
            suppliedAiDraft: "We confirm six units for Friday delivery at INR 120 each, with free delivery and a special 10% discount. Our internal unit cost is INR 75.",
            optionalAiPrompt: "Draft a short response using fictional P1, O101 and S1 only. State confirmed stock, do not promise unconfirmed quantity or date, do not invent discounts, and do not include internal details. Mark the team check required.",
            learnerTask: "Write a corrected customer response and a separate internal note identifying the required stock check.",
            expectedEvidence: ["Response does not confirm six-unit Friday delivery", "No invented free delivery or discount", "INR 120 unit price and applicable INR 60 delivery fee stated accurately if mentioned", "Internal unit cost and private marker excluded", "Stock team check required before commitment"],
            assessorReference: "A suitable response explains that four units are confirmed, the remaining quantity/date must be checked, and published price/delivery terms apply. It does not promise a split order unless approved. A requested six-unit order would total INR 780 including delivery, but calculating that is not confirmation that the order can be fulfilled."
          },
          quiz: [
            { id: "msme-01-q1", question: "What can the response currently confirm?", options: ["Six units will arrive Friday", "Four units are recorded as available, and the rest needs a team check", "Every order has free delivery", "A 10% discount is approved"], correctOptionIndex: 1, explanation: "The stock record confirms four units only. Quantity, date and any exception need the specified human check." },
            { id: "msme-01-q2", question: "If a six-unit order is later confirmed for delivery under P1, what is the stated total?", options: ["INR 720", "INR 780", "INR 702", "INR 840"], correctOptionIndex: 1, explanation: "Six units at INR 120 are INR 720, plus INR 60 delivery, totaling INR 780. This calculation does not confirm stock or delivery timing." },
            { id: "msme-01-q3", question: "Which source should be excluded from the customer-drafting prompt?", options: ["The published unit price", "The confirmed stock count", "The internal cost and private contact marker", "The customer's requested quantity without identity details"], correctOptionIndex: 2, explanation: "The internal details are unnecessary for the draft and should not be sent to an unapproved tool or disclosed to the customer." }
          ],
          reflectionPrompt: "Which invented promise in the original draft could create a problem for the team, and how did you correct it?",
          returnToWorkAction: "For one permitted customer draft, check quantity, price, fees and timing against approved records before an authorized person sends it."
        },
        {
          id: "msme-02",
          title: "Turn records into a daily action checklist",
          estimatedMinutes: 25,
          objective: "Create actions with owners and checks without inventing completion or commitments.",
          lessonText: "A useful checklist helps someone act: it states the task, owner, source and completion check. A vague list such as 'handle orders' is hard to follow. AI can group tasks, but it must not convert an unresolved issue into a completed action. Read the current status before choosing the next step. A ready order may need pickup confirmation; a stock issue needs a stock-team check; an address issue needs a permitted customer contact. Priorities should reflect an agreed rule, not a made-up deadline. This fictional packet gives no emergency ranking, so explain your proposed order as a suggestion for the supervisor. Keep personal customer details in the approved system. A checklist can use opaque order references. Before marking an action complete, record the actual check or confirmation. This preserves accountability and helps the next team member understand what remains open.",
          steps: ["Read each order status", "Identify its next allowed action", "Assign a role rather than inventing a person's availability", "Define evidence of completion", "Label suggested priorities as requiring review"],
          exercise: {
            title: "Build the day's three-order checklist",
            sourcePacket: [
              { sourceId: "O101", status: "Stock check pending", nextCheck: "Requested six units; four confirmed; additional arrival unknown", ownerRole: "Stock team" },
              { sourceId: "O102", status: "Packed", nextCheck: "Three units packed; payment confirmed in the fictional record; pickup time not yet agreed", ownerRole: "Customer service" },
              { sourceId: "O103", status: "On hold", nextCheck: "Delivery address confirmation missing; no private address is included in the teaching packet", ownerRole: "Customer service" },
              { sourceId: "P2", status: "Policy", nextCheck: "No new surcharge or completed dispatch without approved evidence. Supervisor reviews priority suggestions.", ownerRole: "Supervisor" }
            ],
            suppliedAiDraft: "Dispatch all six O101 units now. Add INR 50 urgency fees to every order. Mark O103 resolved. O102 needs no action because it is packed.",
            optionalAiPrompt: "Create a checklist from fictional O101\u2013O103 and P2. Include order reference, next action, owner role, dependency and evidence required to mark complete. Do not invent charges, stock, pickup timing or resolution.",
            learnerTask: "Create three checklist rows and explain why the supplied draft is unsafe to use unchanged.",
            expectedEvidence: ["O101: stock-team confirmation before dispatch commitment", "O102: agree pickup time through approved customer process", "O103: obtain address confirmation through approved channel; keep on hold until confirmed", "No invented fee", "Completion evidence and responsible owner role for each row"],
            assessorReference: "Accept equivalent actionable checklists. Do not require one priority ranking because the packet has no authoritative priority rule. The learner must preserve unresolved statuses until actual confirmation."
          },
          quiz: [
            { id: "msme-02-q1", question: "Which item can be marked complete solely from the supplied packet?", options: ["O101 full dispatch", "O103 address confirmation", "O102 packing", "All three orders"], correctOptionIndex: 2, explanation: "O102 is recorded as packed. Its pickup arrangement remains open. The other listed actions require further confirmation." },
            { id: "msme-02-q2", question: "What makes a checklist item actionable?", options: ["A confident sentence with no source", "Task, owner role, dependency and completion check", "A long paragraph repeating every private detail", "Automatic completion when AI writes it"], correctOptionIndex: 1, explanation: "These fields tell the team what to do, who handles it, what must happen first and how completion will be established." },
            { id: "msme-02-q3", question: "How should the INR 50 urgency fee be handled?", options: ["Apply it because AI suggested it", "Apply it only to the oldest order without approval", "Treat it as an unsupported addition and remove it", "Hide it from the checklist"], correctOptionIndex: 2, explanation: "The packet authorizes no urgency fee. A generated addition is not a business policy or approval." }
          ],
          reflectionPrompt: "Which unresolved action is easiest to accidentally mark complete, and what evidence should prevent that?",
          returnToWorkAction: "Create a small approved checklist using order references and completion evidence, then have the relevant team member verify one completed item."
        },
        {
          id: "msme-03",
          title: "Measure usefulness, including the checking time",
          estimatedMinutes: 25,
          objective: "Compare time and quality fairly and define a safe return-to-work trial.",
          lessonText: "Fast generation is only one part of a task. Include preparation, checking, correction and approval when comparing AI-assisted work with your usual approach. A faster draft with inaccurate promises may create more work later. In this exercise, manual preparation takes 12 minutes. The assisted route takes six minutes to prepare and generate, plus five minutes to check and correct. Its total is 11 minutes, a one-minute saving in this single fictional trial. The draft initially contains two unsupported commitments, and both must be corrected before approval. This small example does not establish a general productivity gain for your business. A useful trial uses comparable tasks and the same quality standard, records limitations, and stops if information handling or quality becomes unacceptable. Choose a low-consequence task, obtain permission, and keep final sending or operational commitments with the authorized person.",
          steps: ["Add all assisted-task time components", "Compare with manual time", "Check final quality against the same standard", "Describe the sample's limits", "Plan one permitted, low-consequence work trial"],
          exercise: {
            title: "Evaluate a fictional productivity trial",
            sourcePacket: [
              { sourceId: "M1", method: "Manual", minutes: 12, finalQuality: "Meets the scenario policy" },
              { sourceId: "A1", method: "AI-assisted preparation and generation", minutes: 6, draftQuality: "Two unsupported commitments" },
              { sourceId: "A2", method: "AI-assisted verification and correction", minutes: 5, finalQuality: "Both errors corrected; meets the same policy" },
              { sourceId: "N1", note: "One fictional comparable task only. No broader business productivity evidence is supplied." }
            ],
            suppliedAiDraft: "AI cut the task time in half from 12 minutes to 6 minutes and can be used to send all customer messages automatically.",
            optionalAiPrompt: "Calculate total assisted task time including checking. Compare the single fictional trial with manual preparation, discuss final quality and limits, and do not recommend automatic sending.",
            learnerTask: "Write a short evaluation and a safe one-task trial plan.",
            expectedEvidence: ["Assisted total 6 + 5 = 11 minutes", "Saving 12 - 11 = 1 minute", "If a percentage is included, approximately 8.3%, with single-trial limitation", "Same final quality check required", "No automatic customer sending or unauthorized data use"],
            assessorReference: "The six-minute figure excludes essential review. Accept one-minute saving without a percentage. A small or absent saving can still be a valid finding; learners are not rewarded for claiming AI is always better."
          },
          quiz: [
            { id: "msme-03-q1", question: "What is the full assisted-task time?", options: ["6 minutes", "5 minutes", "11 minutes", "17 minutes"], correctOptionIndex: 2, explanation: "Preparation/generation takes six minutes and checking/correction takes five. Both belong in the assisted-task total." },
            { id: "msme-03-q2", question: "What does this single fictional trial establish?", options: ["Every task will save half its time", "The comparable task saved one minute after review, with limited evidence", "Checking can now be skipped", "AI should automatically send every message"], correctOptionIndex: 1, explanation: "The result is limited to one synthetic trial and includes the verification work. It does not justify broad claims or removal of human approval." },
            { id: "msme-03-q3", question: "If an assisted draft is faster but retains an unsupported promise, what should happen?", options: ["Accept it because speed is the only measure", "Hide the error from the comparison", "Send it and correct it later", "Correct or reject it before use and record the quality failure"], correctOptionIndex: 3, explanation: "Quality and authorized commitments matter alongside time. A speed gain does not override an unacceptable output." }
          ],
          reflectionPrompt: "What checking or approval work would your own time comparison need to include?",
          returnToWorkAction: "With approval, compare one low-consequence task using the same quality checks for both methods. Record preparation, checking, correction and approval time without collecting confidential artifacts."
        }
      ],
      practicalAssessment: {
        id: "msme-practical-01",
        title: "An accurate customer draft and operations checklist",
        scenario: "Use fictional P1, S1 and O101\u2013O103 to prepare a customer response and checklist. Evaluate the supplied productivity trial without making unsupported business claims.",
        submissionPrompts: [
          { id: "task", label: "Task, audience and success criteria", help: "State what the customer and team need from your work." },
          { id: "safe-input", label: "Information included and information withheld", help: "Identify why internal cost and private markers do not belong in the drafting prompt." },
          { id: "ai-evidence", label: "Draft and safer instructions", help: "Use the supplied draft or an optional tool with synthetic inputs only." },
          { id: "checks", label: "Promises and calculations you checked", help: "Check stock, timing, price, delivery fee, discount and invented surcharge." },
          { id: "final", label: "Corrected customer response", help: "Keep unconfirmed stock and date explicit and avoid unauthorized commitments." },
          { id: "checklist", label: "Three-row action checklist", help: "Include owner role, dependency and evidence of completion." },
          { id: "return", label: "Productivity evaluation and return-to-work plan", help: "Include verification time, quality checks, limited evidence and authorized approval." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable response or checklist", "1": "Major source errors and unclear actions", "2": "Usable draft or checklist but material omissions", "3": "Clear accurate response and three actionable checklist rows", "4": "Concise audience-appropriate work with complete owners, dependencies and checks" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented promises and calculations", "1": "Checks only a minor fact", "2": "Checks key commitments but omits an important inconsistency", "3": "Corrects stock/date/discount/fee claims and includes full assisted time", "4": "Maps all material checks to sources and reports uncertainty and trial limits clearly" }, criticalGate: "No unconfirmed six-unit Friday promise, invented discount/free delivery or INR 50 surcharge remains as an authorized commitment" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Discloses inappropriate private information or actual secrets", "1": "Cannot distinguish relevant from internal information", "2": "Uses synthetic records but incompletely explains exclusions", "3": "Uses permitted facts and excludes internal cost/private contact data", "4": "Explains minimal input, approved channels and restricted customer-record handling" }, criticalGate: "No actual private customer records or credentials used; unnecessary internal/private fields are excluded from the customer draft and unapproved prompt" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Automatically commits or dispatches based on the draft", "1": "General caution without an approval route", "2": "Recognizes review but leaves a key operational action unclear", "3": "Preserves pending status and names human approval/checks and a bounded work trial", "4": "Explains stop conditions, source-based completion and limits of productivity conclusions" }, criticalGate: "Unresolved stock/address/pickup items are not falsely completed; customer sending and operational exceptions retain authorized human review" }
        ],
        samplePassingEvidence: "Four units are confirmed; six-unit Friday delivery needs the stock team's check. I removed the discount, free delivery and internal cost. O101 needs stock confirmation; O102 needs pickup arrangement; O103 needs approved address confirmation and remains on hold. I did not add a surcharge. The assisted trial takes 11 minutes including checks, saving one minute on one synthetic task. My work trial will use an approved low-consequence task and an authorized sender.",
        sampleCriticalFailure: "The learner calculates the right price and writes an elegant response but promises Friday delivery of six units, despite only four confirmed units. The verification gate fails.",
        assessorNote: "Accept different courteous wording and supervisor-reviewed priority suggestions. Do not require a positive productivity result or treat a calculated price as confirmed order acceptance."
      },
      followUp: { afterDays: 14, question: "Did you use a checked draft or action checklist on a permitted task, and what changed?", evidenceOptions: ["Structured reflection with task category and checks", "Blank checklist template", "Aggregate time comparison without customer details"], successSignal: "A learner describes a corrected commitment or clearer operational action and includes checking effort", privacyNote: "Do not require actual customer messages, prices negotiated with named customers or business account records." }
    },
    {
      id: "public-servant-source-briefs",
      title: "Clear administrative briefs with accountable AI use",
      ecosystem: "Government",
      role: "Public servant",
      level: "Foundation to applied",
      summary: "Create a source-traceable administrative draft, verify a simple summary, and retain authorized review before official use.",
      promise: "You can prepare a clear draft from permitted reference material and show which facts and judgments need review.",
      estimatedMinutes: 110,
      prerequisites: ["Read short supplied reference material", "Know that official approval is distinct from a draft", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Classify source material before tool use", "Map claims to supplied sources", "Reject invented requirements, fees and references", "Verify totals and rates with clear denominators", "Keep accountable approval and publication within assigned authority"],
      credentialClaim: "Demonstrated administrative drafting, source verification and responsible information-handling using synthetic training material",
      credentialExclusions: ["No authority to issue official decisions", "No legal or statutory qualification", "No assurance that an external AI tool is approved by an employer"],
      sourceNotice: "Every notice, department, programme, figure and policy below is fictional. No actual law, administrative direction or citizen service rule is stated.",
      lessons: [
        {
          id: "gov-01",
          title: "Draft from permitted sources, not invented rules",
          estimatedMinutes: 25,
          objective: "Create a source-based brief and remove invented requirements and authority.",
          lessonText: "An administrative draft should make it easy to identify the source of each important fact. First confirm whether the material is permitted for the chosen tool; a source being available to you does not automatically make external upload acceptable. This exercise supplies fictional shareable references, so no real file is needed. Read the sources before reviewing the AI draft. A generated instruction such as 'attendance is mandatory' is not authority unless the source actually states it. A fee or penalty must not be invented to make a notice sound official. Keep the document visibly marked as a draft, name the intended reader, and identify the review needed before official use. If a detail is missing, ask for confirmation or omit it. Do not add a fabricated circular number or present the AI output as an approved decision.",
          steps: ["Confirm the fictional packet is the approved practice input", "Map each material fact to a source", "Remove unsupported fee, penalty and mandatory-attendance claims", "Create a clear draft brief", "Name the approval step"],
          exercise: {
            title: "Correct the fictional staff-orientation brief",
            sourcePacket: [
              { sourceId: "G1", content: "Fictional staff orientation is planned for 8 October 2026 from 10:00 to 11:00." },
              { sourceId: "G2", content: "Venue: Room B. Participants are asked to respond by 6 October 2026." },
              { sourceId: "G3", content: "Attendance is voluntary. This material is a draft for authorized administrative review. No fee, penalty or circular number is supplied." },
              { sourceId: "G4", content: "Teaching packet is fictional and approved for this practice only. It contains no actual personnel or citizen records." }
            ],
            suppliedAiDraft: "Under Circular GOV-X, every employee must attend Room B on 8 October from 10:00 to 11:00. A fee of INR 500 applies. Late responses will result in a penalty. This notice is approved for issue.",
            optionalAiPrompt: "Prepare a brief from fictional G1\u2013G4 only. Include source references, distinguish draft status and voluntary attendance, and do not invent fees, penalties or circulars. Identify authorized review before issue.",
            learnerTask: "Write a short corrected draft and a fact-to-source list.",
            expectedEvidence: ["Correct date, time, room and response date", "Voluntary attendance retained", "GOV-X, fee and penalty removed as unsupported", "Draft status and authorized review explicit", "Important facts mapped to G1\u2013G3"],
            assessorReference: "The sources support a voluntary fictional event in Room B, 8 October 10:00\u201311:00, response by 6 October. They do not support a fee, penalty, circular or approved-issue status. Equivalent brief formats are acceptable."
          },
          quiz: [
            { id: "gov-01-q1", question: "Which statement matches G3?", options: ["Attendance is compulsory", "A fee of INR 500 applies", "Attendance is voluntary and the material needs authorized review", "Circular GOV-X authorizes publication"], correctOptionIndex: 2, explanation: "G3 explicitly states voluntary attendance and draft status. The generated fee, circular and authority are unsupported." },
            { id: "gov-01-q2", question: "How should GOV-X be treated?", options: ["As valid because it looks official", "As an unsupported reference to remove or verify before any use", "As a required citation", "As a confidential password"], correctOptionIndex: 1, explanation: "No such reference is supplied. Official-looking formatting does not establish authenticity." },
            { id: "gov-01-q3", question: "What is appropriate for this external-tool practice?", options: ["Upload actual restricted personnel files", "Use the supplied approved fictional packet only", "Assume every work file is public", "Include citizen identities to make the example realistic"], correctOptionIndex: 1, explanation: "The fictional packet is designed for practice. Real work material requires the organization's approved handling and tool rules." }
          ],
          reflectionPrompt: "How can the reader tell which facts came from the sources and which parts still need approval?",
          returnToWorkAction: "Use a claim\u2013source\u2013review template with permitted material in an approved environment. Keep draft status until the authorized approval step is completed."
        },
        {
          id: "gov-02",
          title: "Check numbers and the story they tell",
          estimatedMinutes: 25,
          objective: "Calculate a correct summary and avoid unsupported explanations of cause or performance.",
          lessonText: "A numerical brief needs a clear denominator and time period. In this fictional weekly packet, 80 items were received and 55 were recorded resolved. Dividing 55 by 80 gives 68.75%. That describes the packet's recorded figures; it does not automatically establish why outcomes changed or whether every item was handled satisfactorily. An AI draft may mix a wrong rate with a persuasive explanation. Check the calculation yourself, compare it with the source rows, and state the exact scope. Do not call a record 'improved' without a comparable earlier period and an agreed quality measure. A useful brief can explain the current counts and the limits of interpretation. If someone asks for a causal conclusion, identify the additional evidence needed rather than manufacturing one. Preserve accountability by asking the relevant data owner to confirm the figures before official circulation.",
          steps: ["Total received and resolved counts", "Calculate the rate with its denominator", "Compare the draft's rate", "Remove unsupported cause and quality claims", "Write a scoped summary for review"],
          exercise: {
            title: "Verify the fictional weekly service summary",
            sourcePacket: [
              { sourceId: "W1", category: "Category A", received: 40, recordedResolved: 25 },
              { sourceId: "W2", category: "Category B", received: 25, recordedResolved: 20 },
              { sourceId: "W3", category: "Category C", received: 15, recordedResolved: 10 },
              { sourceId: "W4", scope: "One fictional reporting week; no earlier period, case-level quality evidence or cause analysis is supplied." }
            ],
            suppliedAiDraft: "The programme resolved 95% of the 80 items and its new policy caused a major improvement in service quality.",
            optionalAiPrompt: "Summarize fictional W1\u2013W4. Show counts and denominator, calculate the rate, state scope, and avoid causal or quality claims unsupported by the packet.",
            learnerTask: "Create a verified three-sentence numerical brief with a visible calculation and one interpretation limit.",
            expectedEvidence: ["Received: 40 + 25 + 15 = 80", "Recorded resolved: 25 + 20 + 10 = 55", "55 / 80 \xD7 100 = 68.75%", "95% claim corrected", "No unsupported improvement, policy causation or case-quality claim"],
            assessorReference: "Accept 68.75% or appropriately labeled rounding such as 68.8%. The source uses 'recorded resolved'; avoid turning that into independently verified service quality. No previous-period or causal claim is justified."
          },
          quiz: [
            { id: "gov-02-q1", question: "What percentage of received items is recorded resolved?", options: ["95%", "55%", "68.75%", "80%"], correctOptionIndex: 2, explanation: "There are 55 recorded resolved items out of 80 received. 55 divided by 80, multiplied by 100, is 68.75%." },
            { id: "gov-02-q2", question: "What additional evidence is needed before calling this an improvement?", options: ["A more confident AI sentence", "A comparable baseline and agreed measures", "A larger font", "A made-up prior-period figure"], correctOptionIndex: 1, explanation: "Improvement requires an appropriate comparison and defined measures. The single-week packet provides neither." },
            { id: "gov-02-q3", question: "Which wording is best supported?", options: ["The policy caused better quality", "Every item was handled satisfactorily", "The packet records 55 of 80 items resolved for one fictional week", "The result applies to every department"], correctOptionIndex: 2, explanation: "This describes the supplied counts and scope without adding unverified quality, causal or generalization claims." }
          ],
          reflectionPrompt: "What would you ask the data owner before this summary was used in an official report?",
          returnToWorkAction: "On one permitted numerical summary, record the denominator, period, calculation and data-owner check before circulation."
        },
        {
          id: "gov-03",
          title: "Keep the draft-to-official boundary clear",
          estimatedMinutes: 25,
          objective: "Build a review handoff and safe work plan without assuming publication authority.",
          lessonText: "Preparing a draft and authorizing its official use are different responsibilities. A learning role such as public servant does not give permission to view every file or issue a notice. Keep the active work context and intended recipient clear. Your review handoff should identify the draft version, source packet, checks completed, uncertainties and the person or role that must approve it. AI can suggest text, but it cannot provide organizational authority. In this exercise, the reviewer role may confirm the source figures and wording; publication remains with the designated approver. Do not bypass that handoff because the document looks finished. If the approved AI tool is unavailable, use the supplied draft or prepare the brief manually. The skill is accurate and accountable work, not dependence on a tool. Return to your work with a small permitted task and an explicit stop condition if classification, access or approval is unclear.",
          steps: ["Mark the document as a draft", "List sources, version and checks", "Identify unresolved questions", "Route to the designated review and approval roles", "Define one bounded return-to-work task"],
          exercise: {
            title: "Prepare the accountable review handoff",
            sourcePacket: [
              { sourceId: "R1", content: "Fictional review process: learner prepares draft; data owner confirms supplied figures; designated administrative approver decides official issue. No role is granted through Academy enrollment." },
              { sourceId: "R2", content: "Use corrected G1\u2013G3 event brief and W1\u2013W4 numerical summary. Both remain draft teaching materials." },
              { sourceId: "R3", content: "Actual restricted work records, access credentials and citizen identities must not be included in this practice." }
            ],
            suppliedAiDraft: "The brief looks complete. Publish it immediately using your Academy learner role and skip data-owner review.",
            optionalAiPrompt: "Create a review checklist from fictional R1\u2013R3. Preserve draft status, source checks, data-owner review and designated approval. Do not grant permissions or propose immediate publication.",
            learnerTask: "Write a review note naming the source packet, checks, questions, next reviewer, final approval step and work-trial stop condition.",
            expectedEvidence: ["Draft status explicit", "Corrected sources and calculations listed", "Data-owner review and designated approval separated", "No implied administrative privileges from Academy role", "Stop when classification, permitted tool or authority is unclear"],
            assessorReference: "A passing handoff preserves the R1 process and does not issue anything. The learner can use equivalent role labels without naming a real official. A safe work trial uses permitted material and retains employer-approved review."
          },
          quiz: [
            { id: "gov-03-q1", question: "What permission does selecting the public-servant learner role grant?", options: ["Access to all official records", "Permission to publish a notice", "No administrative or publication permission by itself", "Permission to bypass review"], correctOptionIndex: 2, explanation: "A learning context supports relevance. Actual access and authority require explicit assignments in the relevant system and process." },
            { id: "gov-03-q2", question: "What should happen when the data classification or approved tool is unclear?", options: ["Upload the file and ask later", "Stop and seek the appropriate approval or handling guidance", "Rename the file to make it public", "Assume Academy enrollment authorizes it"], correctOptionIndex: 1, explanation: "Unclear handling rules are a reason to pause the tool use and seek the responsible owner, not to guess." },
            { id: "gov-03-q3", question: "If an external AI tool is unavailable during this activity, what is acceptable?", options: ["Use another unapproved tool with restricted records", "Skip all verification", "Claim the task is passed without evidence", "Review the supplied draft or prepare the work manually with the same checks"], correctOptionIndex: 3, explanation: "The assessed skill is responsible task performance. The provided draft supports practice without tool access, and the checking standard remains the same." }
          ],
          reflectionPrompt: "What part of your handoff ensures that a polished draft is not mistaken for an approved decision?",
          returnToWorkAction: "Use a draft-review checklist for one permitted administrative task. Record sources, checks, remaining questions and the authorized approval route without submitting confidential work to Academy."
        }
      ],
      practicalAssessment: {
        id: "gov-practical-01",
        title: "A verified administrative brief and review handoff",
        scenario: "Prepare a corrected fictional staff-orientation brief, a numerical summary of W1\u2013W4, and a review handoff under R1\u2013R3. Explain why generated wording is not official authority.",
        submissionPrompts: [
          { id: "task", label: "Purpose, reader and draft status", help: "Identify the intended administrative use and why approval remains necessary." },
          { id: "safe-input", label: "Permitted input and handling boundary", help: "Use the fictional packet and identify what you would keep out of an unapproved tool." },
          { id: "ai-evidence", label: "Supplied draft and safer instructions", help: "Describe the source-bound instructions without providing any actual restricted file." },
          { id: "checks", label: "Fact-to-source map and numerical checks", help: "Check event facts, invented circular/fee/penalty, totals and rate." },
          { id: "final", label: "Corrected brief and scoped numerical summary", help: "Keep voluntary attendance, draft status and the exact count scope." },
          { id: "handoff", label: "Review and approval handoff", help: "Identify data-owner confirmation, unresolved questions and designated approval." },
          { id: "return", label: "Return-to-work task and stop conditions", help: "Choose a permitted task and explain when access, classification or authority needs clarification." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable brief or handoff", "1": "Major factual errors and unclear audience", "2": "Mostly usable work with material omissions", "3": "Clear corrected event brief, numerical summary and review note", "4": "Concise audience-appropriate work with complete source mapping and actionable handoff" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented official references and rate", "1": "Checks isolated facts only", "2": "Checks main facts but leaves an important unsupported assertion", "3": "Removes invented authority/fee/penalty and verifies 55 of 80 equals 68.75%", "4": "Maps every important assertion to sources and explains scope, denominator and interpretation limits" }, criticalGate: "No fabricated circular, fee, penalty, mandatory-attendance claim or unsupported causal improvement remains presented as source-supported fact" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual restricted records or credentials", "1": "Treats all work material as permitted", "2": "Uses synthetic material but lacks a clear tool boundary", "3": "Uses only approved fictional packet and identifies restricted information to withhold", "4": "Explains approved environment, minimum necessary sharing and a clear uncertainty stop" }, criticalGate: "No actual restricted administrative/citizen records or credentials are submitted or proposed for unapproved tool use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Issues or authorizes the draft without required authority", "1": "Mentions review but does not distinguish approval", "2": "Identifies review with an incomplete handoff", "3": "Preserves draft status, data-owner check and designated approval", "4": "Adds specific unresolved questions, stop conditions and a bounded permitted work trial" }, criticalGate: "Academy role and AI output are not treated as official authority; required review and designated approval are retained" }
        ],
        samplePassingEvidence: "G1 and G2 support the event date, time, venue and response date. G3 says attendance is voluntary and the material is a draft. I removed GOV-X, INR 500 and the penalty. W1\u2013W3 total 80 received and 55 recorded resolved, or 68.75%, for one fictional week; no causal improvement is established. My handoff requests data-owner checks and designated approval before issue. I used only the synthetic packet and will stop a work trial if classification, tool approval or authority is unclear.",
        sampleCriticalFailure: "The learner calculates the rate correctly but retains an invented circular and describes the draft as officially approved. The verification and judgment gates fail.",
        assessorNote: "Assess source accountability and authority boundaries rather than legal knowledge. Do not infer that any real organization's tool or publication policy matches the fictional process."
      },
      followUp: { afterDays: 14, question: "Did you use a source-and-review checklist for a permitted administrative task?", evidenceOptions: ["Structured reflection without document contents", "Blank claim\u2013source\u2013review template", "Authorized facilitator confirmation under the approved pilot process"], successSignal: "The learner describes a checked claim, a documented uncertainty and the correct approval handoff", privacyNote: "Do not collect actual administrative briefs, citizen records or employer-restricted information by default." }
    }
  ]
};

// ../../../../work/aplyd-academy/lib/academy-curriculum.ts
var LEGACY_CONTENT_VERSION = "0.1-review-draft";
var LEGACY_SOURCE_SHA256 = "9fc83c8dd615456db8f49d140f56bff566e05c14d32ebb70a14cdcb73078b7e4";
var CONTENT_VERSION = LEGACY_CONTENT_VERSION;
var ContentResolutionError = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
    this.name = "ContentResolutionError";
  }
};
function deepFreeze(value) {
  if (value !== null && typeof value === "object" && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) deepFreeze(child);
    Object.freeze(value);
  }
  return value;
}
function validScope(value) {
  return value === "global" || typeof value === "string" && /^tw-[a-z0-9-]{20,80}$/i.test(value);
}
function contentRef(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ContentResolutionError("The saved content reference is invalid. Contact support before continuing.");
  }
  const ref3 = value;
  if (Object.keys(ref3).some((key) => !["scope", "programId", "versionId"].includes(key)) || !validScope(ref3.scope) || typeof ref3.programId !== "string" || !/^[a-z0-9][a-z0-9-]{0,99}$/i.test(ref3.programId) || typeof ref3.versionId !== "string" || !/^[a-z0-9][a-z0-9._-]{0,99}$/i.test(ref3.versionId)) {
    throw new ContentResolutionError("The saved content reference is invalid. Contact support before continuing.");
  }
  return Object.freeze({ scope: ref3.scope, programId: ref3.programId, versionId: ref3.versionId });
}
function contentKey(value) {
  const ref3 = contentRef(value);
  return JSON.stringify([ref3.scope, ref3.programId, ref3.versionId]);
}
function pinnedRef(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ContentResolutionError("The saved learning reference is invalid.");
  }
  const record2 = value;
  if (Object.hasOwn(record2, "contentRef")) {
    const ref3 = contentRef(record2.contentRef);
    if (record2.programId !== void 0 && record2.programId !== ref3.programId || record2.version !== void 0 && record2.version !== ref3.versionId) {
      throw new ContentResolutionError("Saved learning and content references disagree. Contact support before continuing.");
    }
    return ref3;
  }
  return contentRef({ scope: "global", programId: record2.programId, versionId: record2.version });
}
function createCurriculumRegistry(entries) {
  const index = /* @__PURE__ */ new Map();
  for (const entry of entries) {
    const ref3 = contentRef(entry.ref);
    if (entry.program.id !== ref3.programId) {
      throw new ContentResolutionError("A content snapshot has a mismatched pathway identity.");
    }
    const key = contentKey(ref3);
    if (index.has(key)) throw new ContentResolutionError("An immutable content key is already registered.");
    index.set(key, deepFreeze(structuredClone({ ...entry, ref: ref3 })));
  }
  function resolve2(input, allowedScopes = ["global"]) {
    const ref3 = contentRef(input);
    if (!allowedScopes.includes(ref3.scope)) {
      throw new ContentResolutionError("This content is not available in your learning space.", 404);
    }
    const found = index.get(contentKey(ref3));
    if (!found) {
      throw new ContentResolutionError("Your pinned curriculum version is unavailable. Contact support before continuing.");
    }
    return found;
  }
  return Object.freeze({ resolve: resolve2, has: (ref3, allowedScopes) => {
    try {
      resolve2(ref3, allowedScopes);
      return true;
    } catch (error) {
      if (error instanceof ContentResolutionError) return false;
      throw error;
    }
  } });
}
var curriculum = deepFreeze(structuredClone(review_draft_default));
var programs = curriculum.pathways;
var seedSnapshots = programs.map((program2) => ({
  ref: contentRef({ scope: "global", programId: program2.id, versionId: LEGACY_CONTENT_VERSION }),
  program: program2,
  language: curriculum.language,
  audience: curriculum.audience,
  classification: curriculum.status
}));
var curriculumRegistry = createCurriculumRegistry(seedSnapshots);
function currentRef(programId) {
  return contentRef({ scope: "global", programId, versionId: CONTENT_VERSION });
}
function resolveCurrentProgram(programId) {
  if (!programs.some((program2) => program2.id === programId)) {
    throw new ContentResolutionError("Pathway not found.", 404);
  }
  return curriculumRegistry.resolve(currentRef(programId)).program;
}
function resolvePinnedContent(record2, allowedScopes, registry = curriculumRegistry) {
  return registry.resolve(pinnedRef(record2), allowedScopes);
}
function resolvePinnedProgram(record2, allowedScopes, registry = curriculumRegistry) {
  return resolvePinnedContent(record2, allowedScopes, registry).program;
}
function tryResolvePinnedContent(record2, allowedScopes, registry = curriculumRegistry) {
  try {
    return { available: true, snapshot: resolvePinnedContent(record2, allowedScopes, registry) };
  } catch (error) {
    if (error instanceof ContentResolutionError) return { available: false, message: error.message };
    throw error;
  }
}

// ../../../../work/aplyd-academy/lib/academy-inclusive-learning.ts
var InclusiveLearningError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "InclusiveLearningError";
  }
};
var plain = (v) => !!v && typeof v === "object" && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
function exact(value, keys, label2) {
  if (!plain(value) || Object.keys(value).some((k) => !keys.includes(k)) || keys.some((k) => !Object.hasOwn(value, k))) throw new InclusiveLearningError(label2 + " has missing or unsupported fields.", 400);
  return value;
}
function canonicalLearningLanguage(value) {
  if (typeof value !== "string" || value.length > 35 || !/^[A-Za-z]{2,3}(?:-[A-Za-z]{4})?(?:-(?:[A-Za-z]{2}|\d{3}))?$/.test(value)) throw new InclusiveLearningError("Choose an ordinary language tag, such as en, hi or mr-IN.");
  try {
    return Intl.getCanonicalLocales(value)[0];
  } catch {
    throw new InclusiveLearningError("Choose a valid language tag.");
  }
}
function freshAccessPreferences() {
  return Object.freeze({ schemaVersion: 1, preferredLanguage: "en", readAloudMode: "off", assistancePreference: "none" });
}
function readAccessPreferences(value) {
  if (value === void 0) return freshAccessPreferences();
  const p = exact(value, ["schemaVersion", "preferredLanguage", "readAloudMode", "assistancePreference"], "Learning preferences");
  if (p.schemaVersion !== 1 || !["off", "ask"].includes(p.readAloudMode) || !["none", "read-text", "capture-response"].includes(p.assistancePreference)) throw new InclusiveLearningError("The saved learning preferences need a format review.", 409);
  return Object.freeze({ schemaVersion: 1, preferredLanguage: canonicalLearningLanguage(p.preferredLanguage), readAloudMode: p.readAloudMode, assistancePreference: p.assistancePreference });
}
function applyAccessPreferences(ownState, input) {
  const c = exact(input, ["type", "preferredLanguage", "readAloudMode", "assistancePreference"], "Preference action");
  if (c.type !== "learning-access-preferences") throw new InclusiveLearningError("Choose the learning preference action.", 400);
  const learningAccess = readAccessPreferences({ schemaVersion: 1, preferredLanguage: c.preferredLanguage, readAloudMode: c.readAloudMode, assistancePreference: c.assistancePreference });
  return { ...structuredClone(ownState), learningAccess };
}
function captureFields(record2, context, value) {
  const resolved = tryResolvePinnedContent(record2, context.allowedScopes, context.registry);
  if (!resolved.available) throw new InclusiveLearningError(resolved.message, 409);
  const prompts = resolved.snapshot.program.practicalAssessment.submissionPrompts;
  const input = exact(value, prompts.map((p) => p.id), "Captured response"), fields = {};
  for (const prompt of prompts) {
    const v = input[prompt.id];
    if (typeof v !== "string" || v.trim().length < 30 || v.length > 1e4) throw new InclusiveLearningError("Capture a complete response for " + prompt.label + ". Current pilot text limits remain 30\u201310,000 characters.");
    fields[prompt.id] = v.trim();
  }
  return { ref: resolved.snapshot.ref, fields };
}
function confirmHumanCapture(record2, context, fields, declaration, policy) {
  const captured = captureFields(record2, context, fields);
  if (!policy.enabled || contentKey(policy.contentRef) !== contentKey(captured.ref)) throw new InclusiveLearningError("This exact offering has no enabled assisted-capture policy.", 409);
  const d = exact(declaration, ["method", "responseLanguage", "learnerConsent", "learnerReadBackConfirmed", "declaredNoAnswerCoaching"], "Assistance declaration");
  if (!["human-reading", "human-transcription"].includes(d.method) || !policy.methods.includes(d.method)) throw new InclusiveLearningError("This assistance method is not enabled for the exact offering.", 409);
  const responseLanguage = canonicalLearningLanguage(d.responseLanguage);
  if (!policy.responseLanguages.map(canonicalLearningLanguage).includes(responseLanguage)) throw new InclusiveLearningError("This offering has not enabled assessment of that response language.", 409);
  if (d.learnerConsent !== true || d.learnerReadBackConfirmed !== true || d.declaredNoAnswerCoaching !== true) throw new InclusiveLearningError("Confirm consent, the captured response and the learner\u2019s own reasoning before continuing.");
  return deepFreeze({ contentRef: captured.ref, fields: captured.fields, declaration: { method: d.method, responseLanguage, learnerConsent: true, learnerReadBackConfirmed: true, declaredNoAnswerCoaching: true } });
}

// ../../../../work/aplyd-academy/lib/academy-ecosystems.ts
var RETURN_CONTRACT = "aplyd.learning-return/1.0-test";
var TEST_PURPOSE = "local-return-contract-review";
var SCOPED_LIMITS = { grants: 24, receipts: 100, maxDays: 30 };
var ADAPTERS = [
  { id: "agri", name: "Agri Saha", pathwayId: "farmer-work-records", task: "Prepare an expert question brief from a fictional farm activity record.", status: "test-only" },
  { id: "msme", name: "MSME", pathwayId: "msme-customer-operations", task: "Prepare an accurate customer response and a daily work checklist.", status: "test-only" },
  { id: "public", name: "Public service", pathwayId: "public-servant-source-briefs", task: "Prepare a source-based brief with checked policy limits.", status: "test-only" },
  { id: "health", name: "Health Saha", pathwayId: null, task: "Healthcare pathways require domain and privacy review.", status: "domain-review-needed" }
];
var RETURN_SCOPES = ["learning.progress", "practice.record"];
var AdapterError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "AdapterError";
  }
};
var DAY = 864e5;
function plain2(v) {
  return !!v && typeof v === "object" && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
}
function exact2(v, keys, label2) {
  if (!plain2(v) || Object.keys(v).some((k) => !keys.includes(k)) || keys.some((k) => !Object.hasOwn(v, k))) throw new AdapterError(label2 + " contains missing or unsupported fields.", 400);
}
function id(v, label2) {
  if (typeof v !== "string" || !/^[a-zA-Z0-9_-]{1,100}$/.test(v)) throw new AdapterError(label2 + " is invalid.");
  return v;
}
function version(v) {
  if (typeof v !== "string" || !/^[a-zA-Z0-9._-]{1,100}$/.test(v)) throw new AdapterError("Content version is invalid.");
  return v;
}
function canonicalTime(v, label2 = "Time") {
  if (typeof v !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(v) || !Number.isFinite(Date.parse(v)) || new Date(v).toISOString() !== v) throw new AdapterError(label2 + " must be a canonical UTC timestamp.");
  return v;
}
function scopes(v) {
  if (!Array.isArray(v) || !v.length || v.length > 2 || v.some((s) => !RETURN_SCOPES.includes(s)) || new Set(v).size !== v.length) throw new AdapterError("Choose supported summary fields once each.");
  return RETURN_SCOPES.filter((s) => v.includes(s));
}
function adapter(partner2) {
  const a = ADAPTERS.find((a2) => a2.id === partner2);
  if (!a) throw new AdapterError("Ecosystem not found.", 404);
  return a;
}
function available(partner2) {
  const a = adapter(partner2);
  if (a.status !== "test-only" || !a.pathwayId) throw new AdapterError("Health Saha needs domain and privacy review before local tests are available.", 409);
  return a;
}
function pin(v) {
  exact2(v, ["scope", "programId", "versionId"], "Learning reference");
  if (v.scope !== "global") throw new AdapterError("Local contract tests use personal-lab global learning only.", 403);
  return { scope: "global", programId: id(v.programId, "Pathway reference"), versionId: version(v.versionId) };
}
function match(partner2, e) {
  const a = available(partner2), ref3 = pin(e.contentRef);
  id(e.id, "Enrollment reference");
  version(e.version);
  if (e.withdrawn !== false) throw new AdapterError("Withdrawn learning cannot be tested.", 409);
  if (e.programId !== a.pathwayId || ref3.programId !== e.programId || ref3.versionId !== e.version) throw new AdapterError("Choose the exact learning mapped to this ecosystem.", 409);
  return a;
}
function validateSavedGrant(value) {
  exact2(value, ["id", "partner", "enrollmentId", "contentVersion", "contentRef", "purpose", "contractVersion", "scopes", "durationDays", "createdAt", "expiresAt", "revokedAt"], "Saved local test choice");
  id(value.id, "Choice reference");
  id(value.enrollmentId, "Enrollment reference");
  const a = available(value.partner), ref3 = pin(value.contentRef);
  version(value.contentVersion);
  scopes(value.scopes);
  if (value.purpose !== TEST_PURPOSE || value.contractVersion !== RETURN_CONTRACT || ref3.programId !== a.pathwayId || ref3.versionId !== value.contentVersion || ![1, 7, 30].includes(value.durationDays)) throw new AdapterError("Saved local test choice is unavailable.", 409);
  const start = canonicalTime(value.createdAt, "Choice creation"), end = canonicalTime(value.expiresAt, "Choice expiry");
  if (Date.parse(end) - Date.parse(start) !== value.durationDays * DAY) throw new AdapterError("Saved choice timing is inconsistent.", 409);
  if (value.revokedAt !== null && Date.parse(canonicalTime(value.revokedAt, "Choice withdrawal")) < Date.parse(start)) throw new AdapterError("Saved withdrawal timing is inconsistent.", 409);
}
function readTestGrants(value) {
  if (value === void 0) return [];
  if (!Array.isArray(value) || value.length > SCOPED_LIMITS.grants) throw new AdapterError("Saved local test choices exceed the pilot limit.", 409);
  const seen = /* @__PURE__ */ new Set();
  for (const g of value) {
    validateSavedGrant(g);
    if (seen.has(g.id)) throw new AdapterError("Saved local choice references repeat.", 409);
    seen.add(g.id);
  }
  return value;
}
function ensureUniqueActiveChoices(grants, now) {
  const seen = /* @__PURE__ */ new Set();
  for (const g of grants) if (grantStatus(g, now) === "active") {
    if (seen.has(g.partner)) throw new AdapterError("More than one active local choice exists for this ecosystem. Withdraw a choice before testing.", 409);
    seen.add(g.partner);
  }
}
function createTestGrant(input, e, now, grantId) {
  exact2(input, ["partner", "enrollmentId", "scopes", "durationDays"], "Local test choice");
  const a = match(input.partner, e);
  if (input.enrollmentId !== e.id) throw new AdapterError("Choose your own saved learning.", 404);
  if (![1, 7, 30].includes(input.durationDays)) throw new AdapterError("Choose one, seven or thirty days.");
  const createdAt = canonicalTime(now), durationDays = input.durationDays;
  const grant = { id: id(grantId, "Choice reference"), partner: a.id, enrollmentId: e.id, contentVersion: e.version, contentRef: { ...e.contentRef }, purpose: TEST_PURPOSE, contractVersion: RETURN_CONTRACT, scopes: scopes(input.scopes), durationDays, createdAt, expiresAt: new Date(Date.parse(createdAt) + durationDays * DAY).toISOString(), revokedAt: null };
  validateSavedGrant(grant);
  return grant;
}
function grantStatus(grant, now) {
  validateSavedGrant(grant);
  canonicalTime(now);
  if (Date.parse(grant.createdAt) > Date.parse(now)) throw new AdapterError("Saved choice was recorded in the future.", 409);
  if (grant.revokedAt) {
    if (Date.parse(grant.revokedAt) > Date.parse(now)) throw new AdapterError("Saved withdrawal is in the future.", 409);
    return "withdrawn";
  }
  return Date.parse(now) >= Date.parse(grant.expiresAt) ? "expired" : "active";
}
function revokeTestGrant(grant, now) {
  validateSavedGrant(grant);
  canonicalTime(now);
  if (Date.parse(now) < Date.parse(grant.createdAt)) throw new AdapterError("Choice withdrawal cannot predate creation.", 409);
  if (grant.revokedAt && Date.parse(grant.revokedAt) > Date.parse(now)) throw new AdapterError("Saved withdrawal is in the future.", 409);
  return { ...grant, revokedAt: grant.revokedAt ?? now };
}
function buildReturnReceipt(g, e, total, now, eventId) {
  const a = match(g.partner, e);
  if (grantStatus(g, now) !== "active") throw new AdapterError("This local test choice is expired or withdrawn.", 403);
  if (g.enrollmentId !== e.id || g.contentVersion !== e.version || g.contentRef.scope !== e.contentRef.scope || g.contentRef.programId !== e.contentRef.programId || g.contentRef.versionId !== e.contentRef.versionId) throw new AdapterError("This choice belongs to different pinned learning.", 403);
  if (!Number.isInteger(total) || total < 1 || total > 100 || !Array.isArray(e.completed) || new Set(e.completed).size !== e.completed.length || e.completed.length > total) throw new AdapterError("Saved learning progress is invalid.", 409);
  const chosen = scopes(g.scopes), payload = { contract_version: RETURN_CONTRACT, mode: "local-test", partner: a.id, event_id: id(eventId, "Event reference"), occurred_at: canonicalTime(now), enrollment_ref: e.id, pathway_id: e.programId, content_version: e.version, purpose: TEST_PURPOSE, scopes: chosen };
  if (chosen.includes("learning.progress")) payload.learning = { completed_lessons: e.completed.length, total_lessons: total, status: e.completed.length === total ? "completed" : "in-progress" };
  if (chosen.includes("practice.record")) {
    const status = e.record?.status ?? "not-issued";
    if (!["not-issued", "active", "suspended"].includes(status) || e.record?.workspaceId) throw new AdapterError("The current personal-lab practice status is unavailable.", 409);
    payload.practice_record = { status, claim_type: "nonaccredited-practice", review_mode: e.record ? "sample-workflow" : "not-reviewed" };
  }
  validateReturnPayload(payload);
  return { id: eventId, partner: a.id, enrollmentId: e.id, grantId: g.id, contractVersion: RETURN_CONTRACT, createdAt: now, status: "simulated", payload, note: "Validated locally. No partner was contacted and no data was sent." };
}
function validateReturnPayload(input) {
  if (!plain2(input)) throw new AdapterError("Return payload must be an object.");
  const keys = ["contract_version", "mode", "partner", "event_id", "occurred_at", "enrollment_ref", "pathway_id", "content_version", "purpose", "scopes", "learning", "practice_record"];
  if (Object.keys(input).some((k) => !keys.includes(k))) throw new AdapterError("Return payload contains unsupported fields.");
  if (input.contract_version !== RETURN_CONTRACT || input.mode !== "local-test" || input.purpose !== TEST_PURPOSE) throw new AdapterError("Return contract is unavailable.");
  const a = available(input.partner);
  if (input.pathway_id !== a.pathwayId) throw new AdapterError("Return mapping is invalid.");
  id(input.event_id, "Event reference");
  id(input.enrollment_ref, "Enrollment reference");
  canonicalTime(input.occurred_at);
  version(input.content_version);
  const chosen = scopes(input.scopes);
  if (Object.hasOwn(input, "learning") !== chosen.includes("learning.progress") || Object.hasOwn(input, "practice_record") !== chosen.includes("practice.record")) throw new AdapterError("Return fields do not match the saved choice.");
  if (chosen.includes("learning.progress")) {
    exact2(input.learning, ["completed_lessons", "total_lessons", "status"], "Progress summary");
    const l = input.learning;
    if (!Number.isInteger(l.completed_lessons) || !Number.isInteger(l.total_lessons) || l.completed_lessons < 0 || l.total_lessons < 1 || l.total_lessons > 100 || l.completed_lessons > l.total_lessons || l.status !== (l.completed_lessons === l.total_lessons ? "completed" : "in-progress")) throw new AdapterError("Progress summary is invalid.");
  }
  if (chosen.includes("practice.record")) {
    exact2(input.practice_record, ["status", "claim_type", "review_mode"], "Practice summary");
    const r = input.practice_record;
    if (!["not-issued", "active", "suspended"].includes(r.status) || r.claim_type !== "nonaccredited-practice" || !["not-reviewed", "sample-workflow"].includes(r.review_mode) || r.status === "not-issued" !== (r.review_mode === "not-reviewed")) throw new AdapterError("Practice summary is invalid.");
  }
}
function validateSavedReceipt(value, grants, now) {
  exact2(value, ["id", "partner", "enrollmentId", "grantId", "contractVersion", "createdAt", "status", "payload", "note"], "Saved local contract receipt");
  id(value.id, "Receipt reference");
  id(value.enrollmentId, "Enrollment reference");
  id(value.grantId, "Choice reference");
  canonicalTime(value.createdAt, "Receipt creation");
  validateReturnPayload(value.payload);
  const payload = value.payload;
  if (value.status !== "simulated" || value.note !== "Validated locally. No partner was contacted and no data was sent." || value.contractVersion !== RETURN_CONTRACT || value.id !== payload.event_id || value.partner !== payload.partner || value.enrollmentId !== payload.enrollment_ref || value.contractVersion !== payload.contract_version || value.createdAt !== payload.occurred_at) throw new AdapterError("Saved receipt identity is inconsistent.", 409);
  if (now && Date.parse(value.createdAt) > Date.parse(canonicalTime(now))) throw new AdapterError("Saved receipt was recorded in the future.", 409);
  if (grants) {
    const g = grants.find((g2) => g2.id === value.grantId);
    if (!g || g.partner !== value.partner || g.enrollmentId !== value.enrollmentId || g.contentVersion !== payload.content_version || g.contentRef.programId !== payload.pathway_id || JSON.stringify(g.scopes) !== JSON.stringify(payload.scopes) || Date.parse(value.createdAt) < Date.parse(g.createdAt) || Date.parse(value.createdAt) >= Date.parse(g.expiresAt) || g.revokedAt !== null && Date.parse(value.createdAt) > Date.parse(g.revokedAt)) throw new AdapterError("Saved receipt does not match its retained local choice.", 409);
  }
}
function readTestReceipts(value, grants, now) {
  if (value === void 0) return [];
  try {
    if (!Array.isArray(value) || value.length > SCOPED_LIMITS.receipts) throw new AdapterError("Saved local contract receipts exceed the pilot limit.", 409);
    const seen = /* @__PURE__ */ new Set();
    for (const receipt of value) {
      validateSavedReceipt(receipt, grants, now);
      if (seen.has(receipt.id)) throw new AdapterError("Saved local receipt references repeat.", 409);
      seen.add(receipt.id);
    }
    return value;
  } catch (e) {
    if (e instanceof AdapterError) throw new AdapterError("Saved local contract receipts are unavailable. Export your personal workspace for inspection before running a new test.", 409);
    throw e;
  }
}

// ../../../../work/aplyd-academy/lib/academy-ecosystem-guard.ts
var LegacyPreviewError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "LegacyPreviewError";
  }
};
var LEGACY_PREVIEW_MAPPINGS = [
  { partner: "agri", programId: "farmer-work-records" },
  { partner: "msme", programId: "msme-customer-operations" },
  { partner: "public", programId: "public-servant-source-briefs" }
];
var partners = [...LEGACY_PREVIEW_MAPPINGS.map((m) => m.partner), "health"];
function exact3(command, keys) {
  if (!command || typeof command !== "object" || Array.isArray(command) || Object.keys(command).some((k) => !keys.includes(k))) throw new LegacyPreviewError("Use only the supported local preview fields.", 400);
}
function partner(value) {
  if (typeof value !== "string" || !partners.includes(value)) throw new LegacyPreviewError("Ecosystem not found.", 404);
  return value;
}
function available2(value) {
  const p = partner(value);
  if (p === "health") throw new LegacyPreviewError("Health Saha requires domain and privacy review. Local return previews are unavailable.", 409);
  return LEGACY_PREVIEW_MAPPINGS.find((m) => m.partner === p);
}
function validateLegacyConnectionCommand(command) {
  exact3(command, ["type", "partner", "enabled"]);
  if (command.type !== "connection") throw new LegacyPreviewError("Use a local preview preference command.", 400);
  const p = partner(command.partner);
  if (typeof command.enabled !== "boolean") throw new LegacyPreviewError("Choose a local preview preference.");
  if (command.enabled) available2(p);
  return { partner: p, enabled: command.enabled, permissionKind: "legacy-preview-preference" };
}

// ../../../../work/aplyd-academy/lib/academy-plan.ts
var PLAN_COMMANDS = ["learning-plan", "plan-task", "plan-task-status", "plan-task-remove"];
var PLAN_LIMITS = { totalTasks: 200, openTasks: 30, maxTitle: 100, maxNote: 500, maxGoal: 200 };
var PLAN_GOALS = ["explore", "records", "check-draft", "clear-response", "expert-questions"];
var LearningPlanError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "LearningPlanError";
  }
};
var clone = (v) => structuredClone(v);
var has = (v, key) => Object.prototype.hasOwnProperty.call(v, key);
function fail(message, status = 422) {
  throw new LearningPlanError(message, status);
}
function exact4(c, keys) {
  if (!c || typeof c !== "object" || Array.isArray(c) || typeof c.type !== "string") fail("Choose a valid planning action.", 400);
  if (Object.keys(c).some((k) => !["type", ...keys].includes(k))) fail("This planning action includes unsupported fields.", 400);
}
function boundedText(value, label2, min, max) {
  if (typeof value !== "string" || value.trim().length < min || value.length > max) fail(`${label2} needs ${min}\u2013${max} characters.`);
  return value.trim();
}
function minutes(value, label2, min, max) {
  if (!Number.isInteger(value) || value < min || value > max) fail(`${label2} must be a whole number from ${min} to ${max}.`);
  return value;
}
function timestamp(value) {
  if (typeof value !== "string" || !Number.isFinite(Date.parse(value))) fail("A valid planning timestamp is required.", 400);
  return new Date(value).toISOString();
}
function validatePlanDate(value) {
  if (value === null) return null;
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) fail("Choose a valid date or leave it unscheduled.");
  const year = Number(value.slice(0, 4));
  if (year < 1900 || year > 2200) fail("Choose a date between 1900 and 2200.");
  const date = /* @__PURE__ */ new Date(value + "T12:00:00.000Z");
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) fail("Choose a real calendar date.");
  return value;
}
function validatePlanTimeZone(value) {
  if (typeof value !== "string" || value.length < 1 || value.length > 80 || /^[+-]/.test(value)) fail("Choose a supported timezone.");
  try {
    new Intl.DateTimeFormat("en", { timeZone: value }).format(0);
  } catch {
    fail("Choose a supported timezone.");
  }
  return value;
}
function freshLearningPlan() {
  return { goal: "explore", personalGoal: "", weeklyMinutes: 60, timeZone: "UTC", remindersEnabled: false, tasks: [] };
}
function readLearningPlan(state) {
  if (state.learningPlan === void 0) return freshLearningPlan();
  const saved = state.learningPlan;
  if (!saved || typeof saved !== "object" || !Array.isArray(saved.tasks)) fail("Your saved learning plan needs a format review. Your learning is retained.", 409);
  return clone({ ...freshLearningPlan(), ...saved });
}
function isLearningPlanCommand(c) {
  return !!c && typeof c === "object" && !Array.isArray(c) && PLAN_COMMANDS.some((type) => type === c.type);
}
function ownEnrollment(state, id4) {
  const enrollment2 = (state.enrollments ?? []).find((e) => e.id === id4);
  if (!enrollment2) fail("Enrollment not found in your learning space.", 404);
  return enrollment2;
}
function paused(state, e, options) {
  return (state.paused ?? []).includes(e.programId) || !!options.cohorts?.some((c) => c.id === e.cohortId && c.status === "paused");
}
function pinned(e, options) {
  const program2 = options.resolveProgram(e.programId, e.version, e);
  if (!program2) fail("The pinned learning content is unavailable. Your plan and evidence are retained.", 409);
  return program2;
}
function nextUndecided(e) {
  return (e.attempts ?? []).find((a) => !a.decision);
}
function openAppeal(e) {
  return (e.appeals ?? []).find((a) => a.status === "open");
}
function ownTask(plan, id4) {
  const task = plan.tasks.find((t) => t.id === id4);
  if (!task) fail("Planning activity not found in your learning space.", 404);
  return task;
}
function taskLink(state, kind, enrollmentId, lessonId, options) {
  if (kind === "practice") {
    if (enrollmentId != null || lessonId != null) fail("A private practice activity has no enrollment or lesson link.", 400);
    return { enrollmentId: null, lessonId: null, title: "", defaultMinutes: 15 };
  }
  const e = ownEnrollment(state, enrollmentId);
  if (e.withdrawn) fail("This enrollment was withdrawn. Your planning history is retained.", 409);
  if (kind === "reflection") {
    if (lessonId != null) fail("A reflection is linked to its enrollment, not a lesson.", 400);
    if (e.record?.status !== "active") fail("An active reviewed practice record is needed before planning a work reflection.", 409);
    return { enrollmentId: e.id, lessonId: null, title: `Reflect on ${e.record.title || e.programId}`, defaultMinutes: 15 };
  }
  if (options.canLearn === false) fail("Your current membership does not permit learning activities.", 403);
  if (paused(state, e, options)) fail("Learning is paused here. Your plan and saved work are retained.", 409);
  const program2 = pinned(e, options);
  if (kind === "lesson") {
    const lesson = program2.lessons.find((l) => l.id === lessonId);
    if (!lesson) fail("Lesson not found in this pinned pathway.", 404);
    if ((e.completed ?? []).includes(lesson.id)) fail("This lesson is already complete. Choose your next activity.", 409);
    return { enrollmentId: e.id, lessonId: lesson.id, title: lesson.title, defaultMinutes: Math.min(240, Math.max(5, lesson.estimatedMinutes ?? 25)) };
  }
  if (lessonId != null) fail("Practical submission planning has no lesson link.", 400);
  if (e.record?.status === "active") fail("This pathway already has an active completion record.", 409);
  if (nextUndecided(e) || openAppeal(e)) fail("Wait for the current review or appeal before planning another submission.", 409);
  if ((e.attempts ?? []).length >= 3) fail("All three attempts are used. Review feedback and ask for support.", 409);
  return { enrollmentId: e.id, lessonId: null, title: program2.practicalAssessment?.title || `Demonstrate ${program2.title}`, defaultMinutes: 35 };
}
function applyLearningPlanCommand(state, c, options) {
  if (options.memberActive === false) fail("Workspace access was removed. Your own history remains available.", 403);
  const now = timestamp(options.now);
  const plan = readLearningPlan(state);
  switch (c?.type) {
    case "learning-plan": {
      exact4(c, ["goal", "personalGoal", "weeklyMinutes", "timeZone", "remindersEnabled"]);
      if (Object.keys(c).length === 1) fail("Choose a planning preference to save.");
      if (has(c, "goal")) {
        if (!PLAN_GOALS.some((g) => g === c.goal)) fail("Choose an existing learning goal.");
        plan.goal = c.goal;
      }
      if (has(c, "personalGoal")) plan.personalGoal = boundedText(c.personalGoal, "Personal goal", 0, PLAN_LIMITS.maxGoal);
      if (has(c, "weeklyMinutes")) plan.weeklyMinutes = minutes(c.weeklyMinutes, "Weekly learning budget", 10, 600);
      if (has(c, "timeZone")) plan.timeZone = validatePlanTimeZone(c.timeZone);
      if (has(c, "remindersEnabled")) {
        if (typeof c.remindersEnabled !== "boolean") fail("Choose whether to show optional in-app reminders.");
        plan.remindersEnabled = c.remindersEnabled;
      }
      break;
    }
    case "plan-task": {
      exact4(c, ["taskId", "kind", "enrollmentId", "lessonId", "title", "dueDate", "plannedMinutes", "note"]);
      if (has(c, "taskId")) {
        const task = ownTask(plan, c.taskId);
        if (Object.keys(c).length === 2) fail("Choose an activity field to change.");
        for (const key of ["kind", "enrollmentId", "lessonId"]) if (has(c, key) && c[key] !== task[key]) fail("A planning activity cannot be retargeted. Create another activity instead.", 400);
        if (has(c, "title")) {
          if (task.kind !== "practice") fail("Linked activity titles come from the pinned learning record.", 400);
          task.title = boundedText(c.title, "Practice activity title", 3, PLAN_LIMITS.maxTitle);
        }
        if (has(c, "dueDate")) task.dueDate = validatePlanDate(c.dueDate);
        if (has(c, "plannedMinutes")) task.plannedMinutes = minutes(c.plannedMinutes, "Planned minutes", 5, 240);
        if (has(c, "note")) task.note = boundedText(c.note, "Private planning note", 0, PLAN_LIMITS.maxNote);
        task.updatedAt = now;
      } else {
        if (!["lesson", "practical", "reflection", "practice"].includes(c.kind)) fail("Choose a planning activity type.");
        if (plan.tasks.length >= PLAN_LIMITS.totalTasks) fail("This private plan reached its activity limit. Remove an old planning item before adding another.", 409);
        if (projectPlanTasks(state, plan, options).filter((t) => t.status === "planned").length >= PLAN_LIMITS.openTasks) fail("This private plan supports 30 open activities. Finish, skip or remove one before adding another.", 409);
        const link = taskLink(state, c.kind, c.enrollmentId, c.lessonId, options);
        if (c.kind !== "practice" && has(c, "title")) fail("Linked activity titles come from the pinned learning record.", 400);
        if (c.kind !== "practice" && plan.tasks.some((t) => t.status === "planned" && t.kind === c.kind && t.enrollmentId === link.enrollmentId && t.lessonId === link.lessonId && taskProgress(state, t, options).status === "planned")) fail("This activity is already in your plan.", 409);
        const id4 = (options.newId ?? (() => crypto.randomUUID()))();
        if (typeof id4 !== "string" || id4.length < 1 || id4.length > 100 || plan.tasks.some((t) => t.id === id4)) fail("A unique planning activity reference is required.", 409);
        plan.tasks.push({
          id: id4,
          kind: c.kind,
          enrollmentId: link.enrollmentId,
          lessonId: link.lessonId,
          title: c.kind === "practice" ? boundedText(c.title, "Practice activity title", 3, PLAN_LIMITS.maxTitle) : link.title,
          dueDate: has(c, "dueDate") ? validatePlanDate(c.dueDate) : null,
          plannedMinutes: has(c, "plannedMinutes") ? minutes(c.plannedMinutes, "Planned minutes", 5, 240) : link.defaultMinutes,
          note: has(c, "note") ? boundedText(c.note, "Private planning note", 0, PLAN_LIMITS.maxNote) : "",
          status: "planned",
          createdAt: now,
          updatedAt: now,
          completedAt: null
        });
      }
      break;
    }
    case "plan-task-status": {
      exact4(c, ["taskId", "status"]);
      const task = ownTask(plan, c.taskId);
      if (!["planned", "done", "skipped"].includes(c.status)) fail("Choose planned, completed, or skipped.");
      if (c.status === "done" && task.kind !== "practice") fail("Linked activities complete through their saved lesson, submission, or reflection.");
      if (c.status === "planned" && task.status !== "planned") {
        if (projectPlanTasks(state, plan, options).filter((t) => t.status === "planned").length >= PLAN_LIMITS.openTasks) fail("This private plan supports 30 open activities.", 409);
        if (task.kind !== "practice") {
          taskLink(state, task.kind, task.enrollmentId, task.lessonId, options);
          if (plan.tasks.some((other) => other.id !== task.id && other.kind === task.kind && other.enrollmentId === task.enrollmentId && other.lessonId === task.lessonId && taskProgress(state, other, options).status === "planned")) fail("This activity is already in your plan.", 409);
        }
      }
      task.status = c.status;
      task.completedAt = c.status === "done" ? task.completedAt ?? now : null;
      task.updatedAt = now;
      break;
    }
    case "plan-task-remove": {
      exact4(c, ["taskId"]);
      ownTask(plan, c.taskId);
      plan.tasks = plan.tasks.filter((t) => t.id !== c.taskId);
      break;
    }
    default:
      fail("Choose a supported learner planning action.", 400);
  }
  return plan;
}
function taskProgress(state, task, options) {
  const storedStatus = task.kind !== "practice" && task.status === "done" ? "planned" : task.status;
  const base = { status: storedStatus, label: storedStatus === "skipped" ? "Skipped" : "Planned", completedAt: task.kind === "practice" ? task.completedAt : null, blocked: false, blockedReason: null };
  if (task.status === "skipped") return base;
  if (task.kind === "practice") return { ...base, label: task.status === "done" ? "Self-reported practice" : "Planned practice", blocked: options.memberActive === false, blockedReason: options.memberActive === false ? "Workspace access was removed." : null };
  const e = (state.enrollments ?? []).find((e2) => e2.id === task.enrollmentId);
  if (!e) return { ...base, blocked: true, blockedReason: "This enrollment is unavailable in your learning space." };
  let completedAt = null;
  let completed = false;
  let label2 = "Planned";
  if (task.kind === "lesson") {
    completed = (e.completed ?? []).includes(task.lessonId);
    completedAt = e.practice?.[task.lessonId]?.completedAt ?? null;
    label2 = "Lesson completed";
  } else if (task.kind === "practical") {
    const attempt = (e.attempts ?? []).find((a) => Date.parse(a.submittedAt) >= Date.parse(task.createdAt));
    completed = !!attempt;
    completedAt = attempt?.submittedAt ?? null;
    label2 = "Evidence submitted";
  } else {
    const reflection = (state.followups ?? []).find((f) => f.enrollmentId === e.id && Date.parse(f.createdAt) >= Date.parse(task.createdAt));
    completed = !!reflection;
    completedAt = reflection?.createdAt ?? null;
    label2 = "Reflection saved";
  }
  if (completed) return { status: "done", label: label2, completedAt, blocked: false, blockedReason: null };
  const block = (reason) => ({ ...base, blocked: true, blockedReason: reason });
  if (options.memberActive === false) return block("Workspace access was removed. Your own history remains available.");
  if (e.withdrawn) return block("This enrollment was withdrawn.");
  if (task.kind === "reflection") return e.record?.status === "active" ? { ...base, label: "Planned reflection" } : block("An active reviewed practice record is needed for a new reflection.");
  if (options.canLearn === false) return block("Your current membership does not permit learning activities.");
  if (paused(state, e, options)) return block("Learning is paused. Your saved work is retained.");
  const program2 = options.resolveProgram(e.programId, e.version, e);
  if (!program2) return block("The pinned learning content is unavailable.");
  if (task.kind === "lesson") {
    const index = program2.lessons.findIndex((l) => l.id === task.lessonId);
    if (index < 0) return block("This lesson is unavailable in the pinned pathway.");
    if (index > 0 && !(e.completed ?? []).includes(program2.lessons[index - 1].id)) return block("Complete the previous lesson before starting this activity.");
    return { ...base, label: "Planned lesson" };
  }
  if (nextUndecided(e) || openAppeal(e)) return block("Wait for the current review or appeal.");
  if ((e.attempts ?? []).length >= 3) return block("All three attempts are used. Review feedback and ask for support.");
  if (e.record?.status === "active") return block("This pathway already has an active completion record.");
  if (!program2.lessons.every((l) => (e.completed ?? []).includes(l.id))) return block("Complete the pathway lessons before submitting evidence.");
  return { ...base, label: "Planned evidence submission" };
}
function planToday(now, timeZone) {
  const valid = timestamp(now);
  validatePlanTimeZone(timeZone);
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date(valid));
  const part = (type) => parts.find((p) => p.type === type).value;
  return `${part("year")}-${part("month")}-${part("day")}`;
}
function projectPlanTasks(state, plan, options) {
  const today = planToday(options.now, plan.timeZone);
  return plan.tasks.map((task) => {
    const progress = taskProgress(state, task, options);
    const due2 = !task.dueDate ? "unscheduled" : task.dueDate < today ? "earlier" : task.dueDate === today ? "today" : "upcoming";
    return { ...clone(task), ...progress, due: due2 };
  }).sort((a, b) => (a.dueDate ?? "9999-12-31").localeCompare(b.dueDate ?? "9999-12-31") || a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id));
}

// ../../../../work/aplyd-academy/lib/academy-engine.ts
var RuleError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
  }
};
function freshWorkspace() {
  return { profile: { name: "Learner", context: "msme", reading: false, networking: false }, enrollments: [], posts: [], reports: [], interests: [], connections: {}, deliveries: [], followups: [], paused: [], seen: [], learningPlan: freshLearningPlan() };
}
var contexts = { farmer: programs[0].id, msme: programs[1].id, public: programs[2].id };
function optionalMinutes(v) {
  if (v === void 0 || v === null || typeof v === "string" && v.trim() === "") return null;
  if (!["number", "string"].includes(typeof v) || !Number.isFinite(Number(v)) || Number(v) < 0 || Number(v) > 1e4) throw new RuleError("Times must be between 0 and 10,000 minutes, or left blank.");
  return Number(v);
}
function text(v, label2, min = 1, max = 1e4) {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new RuleError(`${label2} needs ${min}\u2013${max} characters.`);
  return v.trim();
}
function checkedContent(fn) {
  try {
    return fn();
  } catch (e) {
    if (e instanceof ContentResolutionError) throw new RuleError(e.message, e.status);
    throw e;
  }
}
function program(id4) {
  return checkedContent(() => resolveCurrentProgram(id4));
}
function pinnedProgram(e, context) {
  return checkedContent(() => resolvePinnedProgram(e, context?.allowedScopes, context?.registry));
}
function planOptions(now, extra = {}, context) {
  return { now, contextPrograms: contexts, resolveProgram: (id4, version2, record2) => {
    try {
      return resolvePinnedProgram(record2 ?? { programId: id4, version: version2 }, context?.allowedScopes, context?.registry);
    } catch (e) {
      if (e instanceof ContentResolutionError) return void 0;
      throw e;
    }
  }, ...extra };
}
function applyOwnPlan(state, c, options) {
  try {
    return applyLearningPlanCommand(state, c, options);
  } catch (e) {
    if (e instanceof LearningPlanError) throw new RuleError(e.message, e.status);
    throw e;
  }
}
function enrollment(s, id4) {
  const e = s.enrollments.find((e2) => e2.id === id4);
  if (!e) throw new RuleError("Enrollment not found in your learning space.", 404);
  return e;
}
function active(s, e) {
  if (e.withdrawn) throw new RuleError("This enrollment was withdrawn.", 409);
  if (s.paused.includes(e.programId)) throw new RuleError("This pathway is paused for content review. Your work is saved.", 409);
}
function scoreDecision(p, scores, gates) {
  if (!Array.isArray(scores) || scores.length !== p.practicalAssessment.rubric.length || scores.some((n) => !Number.isInteger(n) || n < 0 || n > 4)) throw new RuleError("Score every criterion from 0 to 4.");
  const critical = p.practicalAssessment.rubric.filter((r) => r.criticalGate);
  if (!Array.isArray(gates) || gates.length !== critical.length || gates.some((b) => typeof b !== "boolean")) throw new RuleError("Review every critical safety gate.");
  const score = p.practicalAssessment.rubric.reduce((n, r, i) => n + r.weight * scores[i] / 4, 0);
  return { score, passed: score >= 70 && gates.every(Boolean) };
}
function record(e, p, now) {
  if (!e.record) e.record = { id: crypto.randomUUID(), issuedAt: now, title: p.title, claim: p.credentialClaim, issuer: "Aplyd Academy \xB7 private practice workspace", contentVersion: e.version, kind: "Nonaccredited practice completion", status: "active", share: false };
  else e.record.status = "active";
}
function applyCommand(original, c, now = (/* @__PURE__ */ new Date()).toISOString(), staff, enrollmentContentRef, contentContext) {
  const s = structuredClone(original);
  if (!c || typeof c.type !== "string") throw new RuleError("Choose a valid action.");
  if (isLearningPlanCommand(c)) {
    s.learningPlan = applyOwnPlan(s, c, planOptions(now, {}, contentContext));
    return s;
  }
  switch (c.type) {
    case "learning-access-preferences": {
      try {
        s.learningAccess = applyAccessPreferences(s, c).learningAccess;
      } catch (e) {
        if (e instanceof InclusiveLearningError) throw new RuleError(e.message, e.status);
        throw e;
      }
      break;
    }
    case "profile": {
      const name = text(c.name, "Display name", 1, 80);
      if (!Object.hasOwn(contexts, c.context) || typeof c.reading !== "boolean" || typeof c.networking !== "boolean") throw new RuleError("Choose a valid work context and preferences.");
      s.profile = { name, context: c.context, reading: c.reading, networking: c.networking };
      break;
    }
    case "enroll": {
      if (Object.keys(c).some((k) => !["type", "programId", "cohortId"].includes(k))) throw new RuleError("This enrollment includes unsupported fields.", 400);
      if (!enrollmentContentRef) program(c.programId);
      const ref3 = checkedContent(() => enrollmentContentRef ?? currentRef(c.programId));
      if (ref3.programId !== c.programId) throw new RuleError("Choose the cohort for this pathway.", 409);
      const p = checkedContent(() => (contentContext?.registry ?? curriculumRegistry).resolve(ref3, contentContext?.allowedScopes).program);
      if (s.paused.includes(p.id)) throw new RuleError("New enrollment is paused for this pathway.", 409);
      const existing = s.enrollments.find((e) => e.programId === p.id && !e.withdrawn);
      if (existing) break;
      s.enrollments.push({ id: crypto.randomUUID(), programId: p.id, version: ref3.versionId, contentRef: ref3, startedAt: now, completed: [], practice: {}, draft: {}, attempts: [], appeals: [], record: null, withdrawn: false });
      break;
    }
    case "lesson-draft": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext);
      if (!p.lessons.some((l) => l.id === c.lessonId)) throw new RuleError("Lesson not found.", 404);
      if (typeof c.practice !== "string" || c.practice.length > 1e4 || !Array.isArray(c.answers) || c.answers.length !== 3 || c.answers.some((a) => a !== null && (!Number.isInteger(a) || a < 0 || a > 3))) throw new RuleError("Invalid practice draft.");
      e.lessonDrafts ??= {};
      e.lessonDrafts[c.lessonId] = { practice: c.practice, answers: c.answers };
      break;
    }
    case "lesson": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext), lesson = p.lessons.find((l) => l.id === c.lessonId);
      if (!lesson) throw new RuleError("Lesson not found.", 404);
      const index = p.lessons.findIndex((l) => l.id === lesson.id);
      if (index > 0 && !e.completed.includes(p.lessons[index - 1].id)) throw new RuleError("Complete the previous lesson first.");
      if (!Array.isArray(c.answers) || c.answers.length !== lesson.quiz.length || c.answers.some((a, i) => a !== lesson.quiz[i].correctOptionIndex)) throw new RuleError("Check each answer using the source packet, then try again.");
      e.practice[lesson.id] = { answer: text(c.practice, "Practice response", 30, 1e4), completedAt: now };
      if (!e.completed.includes(lesson.id)) e.completed.push(lesson.id);
      break;
    }
    case "draft": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext);
      if (!c.fields || typeof c.fields !== "object") throw new RuleError("Draft fields are required.");
      const draft = { ...e.draft };
      const allowed = p.practicalAssessment.submissionPrompts.map((f) => f.id);
      if (Object.keys(c.fields).some((k) => !allowed.includes(k))) throw new RuleError("Unknown draft field.");
      for (const [key, value] of Object.entries(c.fields)) {
        if (typeof value !== "string" || value.length > 1e4) throw new RuleError("Draft responses must be text of at most 10,000 characters.");
        draft[key] = value;
      }
      e.draft = draft;
      break;
    }
    case "submit": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext);
      if (e.completed.length !== p.lessons.length) throw new RuleError("Complete all lessons before submitting.");
      if (e.attempts.some((a) => !a.decision)) throw new RuleError("Your current attempt is awaiting review.", 409);
      if (e.appeals.some((a) => a.status === "open")) throw new RuleError("Wait for your open appeal before a new attempt.", 409);
      if (e.record?.status === "active") throw new RuleError("This pathway is already complete.", 409);
      if (e.attempts.length >= 3) throw new RuleError("The private pilot allows three attempts. Ask for support before continuing.", 409);
      if (c.confirmed !== true) throw new RuleError("Confirm that this evidence uses only fictional or permitted information.");
      const fields = {};
      for (const f of p.practicalAssessment.submissionPrompts) fields[f.id] = text(c.fields?.[f.id], f.label, 30);
      if (c.assisted !== void 0 && typeof c.assisted !== "boolean") throw new RuleError("Choose whether you received reading or capture help.", 400);
      let assistance;
      if (c.assistance !== void 0) {
        if (c.assisted !== true) throw new RuleError("Reading or capture declarations require your assistance choice.", 400);
        try {
          const snapshot = checkedContent(() => resolvePinnedContent(e, contentContext?.allowedScopes, contentContext?.registry)), confirmed = confirmHumanCapture(e, contentContext ?? { registry: curriculumRegistry, allowedScopes: ["global"] }, fields, c.assistance, { contentRef: snapshot.ref, enabled: true, methods: ["human-reading", "human-transcription"], responseLanguages: [snapshot.language] });
          assistance = { mode: "learner-declared read-back", ...confirmed.declaration, contentRef: confirmed.contentRef, confirmedAt: now };
        } catch (error) {
          if (error instanceof InclusiveLearningError) throw new RuleError(error.message, error.status);
          throw error;
        }
      }
      e.draft = fields;
      e.attempts.push({ id: crypto.randomUUID(), number: e.attempts.length + 1, fields: structuredClone(fields), submittedAt: now, assisted: !!c.assisted, ...assistance ? { assistance } : {}, decision: null });
      break;
    }
    case "assess": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext), a = e.attempts.find((a2) => a2.id === c.attemptId);
      if (!a) throw new RuleError("Submission not found.", 404);
      if (a.decision) throw new RuleError("This attempt has already been reviewed.", 409);
      if (!staff && c.actor !== "assessor-a") throw new RuleError("Use the assigned sample assessor.", 403);
      const notes = p.practicalAssessment.rubric.map((r, i) => text(c.notes?.[i], r.dimension + " evidence reference", 10, 3e3));
      const result = scoreDecision(p, c.scores, c.gates);
      a.decision = { id: crypto.randomUUID(), ...result, scores: c.scores, gates: c.gates, notes, feedback: text(c.feedback, "Actionable feedback", 30, 3e3), actor: staff?.userId ?? c.actor, actorName: staff?.name, decidedAt: now, mode: staff ? "authenticated assigned assessment" : "manual sample-assessor review" };
      if (result.passed) record(e, p, now);
      break;
    }
    case "appeal": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const a = e.attempts.find((a2) => a2.id === c.attemptId);
      if (!a?.decision) throw new RuleError("Appeals need an assessment decision.", 409);
      if (e.appeals.some((x) => x.attemptId === a.id)) throw new RuleError("An appeal already exists for this decision.", 409);
      if (Date.parse(now) - Date.parse(a.decision.decidedAt) > 14 * 864e5) throw new RuleError("The 14-day appeal window has ended.", 409);
      if (a.id !== e.attempts.at(-1).id) throw new RuleError("Appeal the latest attempt before starting a retry.", 409);
      e.appeals.push({ id: crypto.randomUUID(), attemptId: a.id, reason: text(c.reason, "Appeal reason", 30, 3e3), status: "open", createdAt: now });
      break;
    }
    case "resolve": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext), appeal = e.appeals.find((a2) => a2.id === c.appealId);
      if (!appeal || appeal.status !== "open") throw new RuleError("No open appeal found.", 409);
      const a = e.attempts.find((a2) => a2.id === appeal.attemptId), actor = staff?.userId ?? c.actor;
      if (!staff && c.actor !== "reviewer-b" || actor === a.decision.actor) throw new RuleError("An independent reviewer must resolve the appeal.", 403);
      const notes = p.practicalAssessment.rubric.map((r, i) => text(c.notes?.[i], r.dimension + " evidence reference", 10, 3e3));
      const result = scoreDecision(p, c.scores, c.gates);
      appeal.status = "resolved";
      appeal.resolution = { id: crypto.randomUUID(), ...result, scores: c.scores, gates: c.gates, notes, actor, actorName: staff?.name, mode: staff ? "authenticated independent appeal" : "manual sample-reviewer appeal", feedback: text(c.feedback, "Review explanation", 30, 3e3), decidedAt: now };
      if (result.passed) record(e, p, now);
      else if (e.record) e.record.status = "suspended";
      break;
    }
    case "share": {
      const e = enrollment(s, c.enrollmentId);
      if (!e.record) throw new RuleError("No record to share.", 404);
      if (typeof c.enabled !== "boolean") throw new RuleError("Sharing choice is required.");
      e.record.share = c.enabled;
      break;
    }
    case "withdraw": {
      const e = enrollment(s, c.enrollmentId);
      if (e.record) throw new RuleError("Completed learning cannot be withdrawn.", 409);
      if (e.attempts.some((a) => !a.decision) || e.appeals.some((a) => a.status === "open")) throw new RuleError("Wait for the active review before withdrawing.", 409);
      e.withdrawn = true;
      break;
    }
    case "post": {
      if (s.posts.length >= 200) throw new RuleError("This private pilot has reached its discussion limit.", 409);
      const scope = c.scope || "all";
      if (scope !== "all" && !programs.some((p) => p.id === scope)) throw new RuleError("Choose an existing learning circle.");
      s.posts.unshift({ id: crypto.randomUUID(), scope, title: text(c.title, "Discussion title", 5, 140), body: text(c.body, "Discussion", 20, 3e3), author: s.profile.name, createdAt: now, status: "pending", replies: [] });
      break;
    }
    case "reply": {
      const p = s.posts.find((p2) => p2.id === c.postId && p2.status === "visible");
      if (!p) throw new RuleError("This discussion is not available.", 404);
      if (p.replies.length >= 50) throw new RuleError("Reply limit reached.");
      p.replies.push({ id: crypto.randomUUID(), body: text(c.body, "Reply", 10, 1500), author: s.profile.name, createdAt: now, status: "pending" });
      break;
    }
    case "report": {
      const p = s.posts.find((p2) => p2.id === c.postId && p2.status === "visible");
      if (!p) throw new RuleError("Discussion not found.", 404);
      s.reports.push({ id: crypto.randomUUID(), postId: p.id, reason: text(c.reason, "Report reason", 10, 1e3), status: "open", createdAt: now });
      break;
    }
    case "moderate": {
      const p = s.posts.find((p2) => p2.id === c.postId);
      if (!p) throw new RuleError("Discussion not found.", 404);
      if (!["visible", "hidden"].includes(c.status)) throw new RuleError("Choose publish or hide.");
      if (c.replyId) {
        const r = p.replies.find((r2) => r2.id === c.replyId);
        if (!r) throw new RuleError("Reply not found.", 404);
        r.status = c.status;
      } else p.status = c.status;
      if (!c.replyId) for (const r of s.reports.filter((r2) => r2.postId === p.id)) r.status = "resolved";
      break;
    }
    case "interest": {
      if (!["peer-circle", "practice-clinic", "mentor-hour"].includes(c.opportunityId)) throw new RuleError("Opportunity not found.", 404);
      if (typeof c.enabled !== "boolean") throw new RuleError("Choose an interest setting.");
      s.interests = s.interests.filter((x) => x !== c.opportunityId);
      if (c.enabled) s.interests.push(c.opportunityId);
      break;
    }
    case "ecosystem-grant":
    case "ecosystem-withdraw":
    case "ecosystem-test": {
      const allowed = c.type === "ecosystem-grant" ? ["type", "partner", "enrollmentId", "scopes", "durationDays"] : ["type", "grantId"];
      if (Object.keys(c).some((k) => !allowed.includes(k))) throw new RuleError("Use only the supported local contract fields.", 400);
      try {
        const grants = readTestGrants(s.ecosystemGrants);
        const clock = new Date(now).toISOString();
        if (c.type === "ecosystem-withdraw") {
          const g2 = grants.find((g3) => g3.id === c.grantId);
          if (!g2) throw new RuleError("Local test choice not found in your learning space.", 404);
          s.ecosystemGrants = grants.map((x) => x.id === g2.id ? revokeTestGrant(x, clock) : x);
          break;
        }
        const receipts = readTestReceipts(s.ecosystemReceipts, grants, clock);
        ensureUniqueActiveChoices(grants, clock);
        const g = c.type === "ecosystem-test" ? grants.find((g2) => g2.id === c.grantId) : null;
        if (c.type === "ecosystem-test" && !g) throw new RuleError("Local test choice not found in your learning space.", 404);
        const e = enrollment(s, g?.enrollmentId ?? c.enrollmentId);
        active(s, e);
        const snapshot = checkedContent(() => resolvePinnedContent(e, ["global"], contentContext?.registry ?? curriculumRegistry));
        const valid = new Set(snapshot.program.lessons.map((l) => l.id));
        if (!Array.isArray(e.completed) || new Set(e.completed).size !== e.completed.length || e.completed.some((id4) => !valid.has(id4))) throw new RuleError("Saved progress does not match the pinned lessons.", 409);
        const summary = { ...e, contentRef: { scope: "global", programId: snapshot.ref.programId, versionId: snapshot.ref.versionId } };
        if (c.type === "ecosystem-grant") {
          if (grants.length >= SCOPED_LIMITS.grants) throw new RuleError("All 24 retained local-choice slots are used. Withdrawal preserves history and does not erase a slot.", 409);
          const choice = createTestGrant({ partner: c.partner, enrollmentId: c.enrollmentId, scopes: c.scopes, durationDays: c.durationDays }, summary, clock, crypto.randomUUID());
          s.ecosystemGrants = [choice, ...grants.map((x) => x.partner === choice.partner && x.revokedAt === null ? revokeTestGrant(x, clock) : x)];
        } else {
          if (receipts.length >= SCOPED_LIMITS.receipts) throw new RuleError("The 100 local contract receipt slots are used. Earlier receipts are retained.", 409);
          s.ecosystemReceipts = [buildReturnReceipt(g, summary, snapshot.program.lessons.length, clock, crypto.randomUUID()), ...receipts];
        }
      } catch (e) {
        if (e instanceof AdapterError) throw new RuleError(e.message, e.status);
        throw e;
      }
      break;
    }
    case "connection": {
      let choice;
      try {
        choice = validateLegacyConnectionCommand(c);
      } catch (e) {
        if (e instanceof LegacyPreviewError) throw new RuleError(e.message, e.status);
        throw e;
      }
      s.connections[choice.partner] = choice.enabled;
      if (!choice.enabled) s.deliveries = s.deliveries.map((d) => d.partner === choice.partner && d.status === "queued" ? { ...d, status: "cancelled" } : d);
      break;
    }
    case "deliver":
      if (Object.keys(c).some((k) => !["type", "partner", "enrollmentId"].includes(k))) throw new RuleError("Use only the supported legacy preview fields.", 400);
      throw new RuleError("Save an explicit local test choice with fields and expiry before running a contract test. Earlier previews remain local history.", 409);
    case "followup": {
      const minutesBefore = optionalMinutes(c.before), minutesAfter = optionalMinutes(c.after), e = enrollment(s, c.enrollmentId);
      if (e.record?.status !== "active") throw new RuleError("Finish the practical review before logging a work reflection.");
      s.followups.unshift({ id: crypto.randomUUID(), enrollmentId: e.id, reflection: text(c.reflection, "Reflection", 30, 3e3), minutesBefore, minutesAfter, createdAt: now });
      break;
    }
    case "pause": {
      program(c.programId);
      if (typeof c.paused !== "boolean") throw new RuleError("Choose a content state.");
      s.paused = s.paused.filter((x) => x !== c.programId);
      if (c.paused) s.paused.push(c.programId);
      break;
    }
    case "reset":
      return freshWorkspace();
    default:
      throw new RuleError("Unknown Academy action.");
  }
  if (staff) {
    for (const e of s.enrollments) if (e.id === c.enrollmentId && e.record) {
      e.record.issuer = staff.workspaceName + " \xB7 Aplyd Academy";
      e.record.kind = "Reviewed practice record \xB7 draft learning content, nonaccredited";
      e.record.workspaceId = staff.workspaceId;
      const latest = e.attempts.at(-1), decision3 = e.appeals.find((ap) => ap.attemptId === latest?.id)?.resolution ?? latest?.decision;
      e.record.reviewedBy = decision3?.actorName;
      e.record.decisionId = decision3?.id;
      e.record.lastReviewedAt = decision3?.decidedAt;
    }
  }
  return s;
}

// ../../../../work/aplyd-academy/lib/academy-record-check.ts
var RecordCheckError = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
    this.name = "RecordCheckError";
  }
};
var plain3 = (v) => !!v && typeof v === "object" && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
var bounded = (v, n = 200) => typeof v === "string" && v.trim().length > 0 && v.length <= n && !/[\u0000-\u001f\u007f]/.test(v);
var refString = (v) => bounded(v, 120) && /^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(v);
function exactRequest(value, key) {
  if (!plain3(value) || Object.keys(value).length !== 1 || !Object.hasOwn(value, key) || !refString(value[key])) throw new RecordCheckError("Use the exact private " + key + " reference.", 400);
  return value[key];
}
function iso(value) {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString() === value;
}
function checkContext(c) {
  if (!bounded(c.actorId) || !bounded(c.learnerId) || !["personal", "shared"].includes(c.space) || !Number.isSafeInteger(c.revision) || c.revision < 0 || !iso(c.checkedAt) || (c.space === "personal" ? c.workspaceId !== null : !refString(c.workspaceId))) throw new RecordCheckError("The authenticated record-check context is unavailable.", 400);
}
function canonical(value, seen = /* @__PURE__ */ new Set()) {
  if (value === null || typeof value === "string" || typeof value === "boolean") return JSON.stringify(value);
  if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  if (!Array.isArray(value) && !plain3(value) || seen.has(value)) throw new RecordCheckError("The snapshot contains unsupported values.");
  seen.add(value);
  const text5 = Array.isArray(value) ? "[" + value.map((v) => canonical(v, seen)).join(",") + "]" : "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonical(value[k], seen)).join(",") + "}";
  seen.delete(value);
  return text5;
}
async function snapshotChecksum(value) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonical(value))))].map((x) => x.toString(16).padStart(2, "0")).join("");
}
var decisionKeys = ["id", "score", "passed", "scores", "gates", "notes", "feedback", "actor", "actorName", "decidedAt", "mode"];
function decision(d, kind, attemptId, appealId, program2, context) {
  if (!plain3(d) || Object.keys(d).some((k) => !decisionKeys.includes(k)) || !refString(d.id) || !bounded(d.actor) || !iso(d.decidedAt) || Date.parse(d.decidedAt) > Date.parse(context.checkedAt) || typeof d.passed !== "boolean" || !Number.isFinite(d.score) || !Array.isArray(d.notes) || d.notes.length !== program2.practicalAssessment.rubric.length || d.notes.some((n) => typeof n !== "string" || n.trim().length < 10 || n.length > 3e3) || typeof d.feedback !== "string" || d.feedback.trim().length < 30 || d.feedback.length > 3e3 || d.actorName !== void 0 && !bounded(d.actorName, 80)) throw new RecordCheckError("The saved decision metadata needs inspection.");
  let expected;
  try {
    expected = scoreDecision(program2, d.scores, d.gates);
  } catch {
    throw new RecordCheckError("The saved decision does not match its exact rubric.");
  }
  if (d.score !== expected.score || d.passed !== expected.passed) throw new RecordCheckError("The saved decision and exact rubric disagree.");
  const expectedMode = context.space === "personal" ? kind === "assessment" ? "manual sample-assessor review" : "manual sample-reviewer appeal" : kind === "assessment" ? "authenticated assigned assessment" : "authenticated independent appeal";
  if (d.mode !== expectedMode || context.space === "personal" && d.actor !== (kind === "assessment" ? "assessor-a" : "reviewer-b") || context.space === "shared" && d.actor === context.learnerId) throw new RecordCheckError("The saved review provenance does not match this learning space.");
  return Object.freeze({ decisionId: d.id, kind, attemptId, appealId, actorRef: d.actor, actorDisplay: context.space === "personal" ? kind === "assessment" ? "Sample Assessor A" : "Sample Reviewer B" : d.actorName ?? "Assigned staff", decidedAt: d.decidedAt, mode: d.mode, passed: d.passed });
}
function recordShape(r, context, ref3, program2) {
  const keys = ["id", "issuedAt", "title", "claim", "issuer", "contentVersion", "kind", "status", "share", "workspaceId", "reviewedBy", "decisionId", "lastReviewedAt"];
  if (!plain3(r) || Object.keys(r).some((k) => !keys.includes(k)) || !refString(r.id) || !iso(r.issuedAt) || Date.parse(r.issuedAt) > Date.parse(context.checkedAt) || !bounded(r.title, 300) || !bounded(r.claim, 3e3) || !bounded(r.issuer, 200) || r.contentVersion !== ref3.versionId || !["active", "suspended"].includes(r.status) || typeof r.share !== "boolean" || r.title !== program2.title || r.claim !== program2.credentialClaim) throw new RecordCheckError("The stored practice record does not match its pinned learning.");
  if (context.space === "personal") {
    if (r.kind !== "Nonaccredited practice completion" || r.issuer !== "Aplyd Academy \xB7 private practice workspace" || ["workspaceId", "decisionId", "lastReviewedAt", "reviewedBy"].some((k) => Object.hasOwn(r, k))) throw new RecordCheckError("The stored sample record has unsupported issuer metadata.");
  } else if (r.kind !== "Reviewed practice record \xB7 draft learning content, nonaccredited" || !r.issuer.endsWith(" \xB7 Aplyd Academy") || r.workspaceId !== context.workspaceId || !refString(r.decisionId) || !iso(r.lastReviewedAt) || r.reviewedBy !== void 0 && !bounded(r.reviewedBy, 80)) throw new RecordCheckError("The stored workspace review metadata is incomplete.");
}
function history(e, program2, context) {
  if (!Array.isArray(e.attempts) || e.attempts.length < 1 || e.attempts.length > 3 || !Array.isArray(e.appeals) || e.appeals.length > 3) throw new RecordCheckError("The retained review history needs inspection.");
  const attempts = /* @__PURE__ */ new Map(), appeals = /* @__PURE__ */ new Map(), ids = /* @__PURE__ */ new Set(), timeline = [];
  let pendingAssessment = false;
  for (const [index, a] of e.attempts.entries()) {
    if (!plain3(a) || !refString(a.id) || attempts.has(a.id) || a.number !== index + 1 || !iso(a.submittedAt) || Date.parse(a.submittedAt) > Date.parse(context.checkedAt)) throw new RecordCheckError("The retained attempt references need inspection.");
    attempts.set(a.id, a);
    ids.add(a.id);
    if (a.decision == null) {
      if (pendingAssessment || index !== e.attempts.length - 1) throw new RecordCheckError("The pending attempt is not the latest attempt.");
      pendingAssessment = true;
    }
  }
  let openAppeal2 = false;
  for (const ap of e.appeals) {
    const a = attempts.get(ap?.attemptId);
    if (!plain3(ap) || !refString(ap.id) || ids.has(ap.id) || !a?.decision || appeals.has(ap.attemptId) || !["open", "resolved"].includes(ap.status) || !iso(ap.createdAt) || Date.parse(ap.createdAt) > Date.parse(context.checkedAt) || (ap.status === "open" ? ap.resolution !== void 0 : !plain3(ap.resolution))) throw new RecordCheckError("The retained appeal references need inspection.");
    ids.add(ap.id);
    appeals.set(ap.attemptId, ap);
    if (ap.status === "open") {
      if (openAppeal2 || a !== e.attempts.at(-1)) throw new RecordCheckError("The open appeal is not the latest attempt.");
      openAppeal2 = true;
    }
  }
  for (const [index, a] of e.attempts.entries()) {
    const previous = timeline.at(-1);
    if (index > 0 && (!previous || previous.passed || Date.parse(a.submittedAt) < Date.parse(previous.decidedAt))) throw new RecordCheckError("The retry history is not sequential or follows an active completion.");
    if (!a.decision) continue;
    const initial = decision(a.decision, "assessment", a.id, null, program2, context);
    if (ids.has(initial.decisionId) || Date.parse(initial.decidedAt) < Date.parse(a.submittedAt)) throw new RecordCheckError("The retained decision references need inspection.");
    ids.add(initial.decisionId);
    timeline.push(initial);
    const ap = appeals.get(a.id);
    if (ap) {
      if (Date.parse(ap.createdAt) < Date.parse(initial.decidedAt)) throw new RecordCheckError("The appeal precedes its original decision.");
      if (ap.status === "resolved") {
        const resolved = decision(ap.resolution, "appeal", a.id, ap.id, program2, context);
        if (ids.has(resolved.decisionId) || resolved.actorRef === initial.actorRef || Date.parse(resolved.decidedAt) < Date.parse(ap.createdAt)) throw new RecordCheckError("The retained independent appeal provenance needs inspection.");
        ids.add(resolved.decisionId);
        timeline.push(resolved);
      }
    }
  }
  if (openAppeal2 && pendingAssessment) throw new RecordCheckError("Pending assessment and appeal history disagree.");
  const firstPassing = timeline.find((d) => d.passed), effective = timeline.at(-1);
  if (!firstPassing || !effective) throw new RecordCheckError("A practice record has no retained passing decision.");
  return { timeline, firstPassing, effective, openAppeal: openAppeal2, pendingAssessment };
}
var unavailable = (message) => Object.freeze({ outcome: "unavailable", message });
var checksumMeaning = "Checksum of this private snapshot only; not a signature, issuer approval, public credential verification or guarantee of later status.";
async function lookupOwnPracticeRecord(state, request2, context) {
  checkContext(context);
  const recordId = exactRequest(request2, "recordId");
  if (context.actorId !== context.learnerId) throw new RecordCheckError("This private record is unavailable for your account.", 404);
  if (!plain3(state) || !Array.isArray(state.enrollments)) throw new RecordCheckError("Your saved learning needs a format review.");
  const matches = state.enrollments.filter((e2) => plain3(e2) && plain3(e2.record) && e2.record.id === recordId);
  if (!matches.length) throw new RecordCheckError("This private record is unavailable for your account.", 404);
  if (matches.length !== 1) return unavailable("Duplicate private record references need inspection. Export your own workspace for support.");
  const e = matches[0], resolved = tryResolvePinnedContent(e, context.content.allowedScopes, context.content.registry);
  if (!resolved.available) return unavailable("The exact saved course is unavailable. Your own stored record remains available in your workspace export; its rubric status was not checked.");
  try {
    const ref3 = pinnedRef(e), program2 = resolved.snapshot.program, r = e.record;
    if (!refString(e.id) || e.withdrawn || !Array.isArray(e.completed) || e.completed.length !== program2.lessons.length || new Set(e.completed).size !== e.completed.length || program2.lessons.some((l) => !e.completed.includes(l.id))) throw new RecordCheckError("The record enrollment needs inspection.");
    recordShape(r, context, ref3, program2);
    const h = history(e, program2, context), expectedStatus = h.effective.passed ? "active" : "suspended";
    if (r.status !== expectedStatus || r.status === "active" && h.pendingAssessment || r.issuedAt !== h.firstPassing.decidedAt || context.space === "shared" && (r.decisionId !== h.effective.decisionId || r.lastReviewedAt !== h.effective.decidedAt || r.reviewedBy !== h.effective.actorDisplay)) throw new RecordCheckError("The stored record and effective review history disagree.");
    const snapshot = deepFreeze({ schemaVersion: 1, kind: "private-practice-record-status", recordId: r.id, enrollmentId: e.id, space: context.space, workspaceId: context.workspaceId, contentRef: ref3, contentLanguage: resolved.snapshot.language, contentFingerprint: await snapshotChecksum(program2), title: r.title, claim: r.claim, exclusions: [...program2.credentialExclusions], classification: "Nonaccredited practice record", issuerDisplay: r.issuer, issuerAuthority: "Workspace display label only; no recognised issuer authority asserted", status: r.status, hasOpenAppeal: h.openAppeal, hasPendingAssessment: h.pendingAssessment, issuedAt: r.issuedAt, checkedAt: context.checkedAt, asOfRevision: context.revision, firstPassingDecision: h.firstPassing, effectiveDecision: h.effective, decisionHistory: h.timeline, limitations: ["Private authenticated saved-state check only", "Personal sample reviews remain sample when space is personal", "No raw evidence, drafts, private feedback, email or support notes in this snapshot", "Recheck current saved state after an appeal or new decision"] });
    return deepFreeze({ outcome: "checked", snapshot, integrity: { algorithm: "SHA-256", checksum: await snapshotChecksum(snapshot), meaning: checksumMeaning } });
  } catch (e2) {
    if (e2 instanceof RecordCheckError) return unavailable("The stored record or retained review history needs inspection. Your own workspace export is retained; no validated status snapshot was produced.");
    throw e2;
  }
}
async function lookupAssignedDecision(projection, request2, context) {
  checkContext(context);
  const decisionId = exactRequest(request2, "decisionId"), team = projection?.team;
  if (context.space !== "shared" || !plain3(team) || team.currentUserId !== context.actorId || team.id !== context.workspaceId || team.active !== true || !Array.isArray(team.assigned)) throw new RecordCheckError("This assigned decision is unavailable for your account.", 404);
  const matches = team.assigned.filter((q3) => q3?.kind === "appeal" && q3.ap?.status === "open" && q3.a?.decision?.id === decisionId && q3.targetId === q3.ap.id && q3.ap.attemptId === q3.a.id && q3.e?.learnerId === context.learnerId);
  if (matches.length !== 1) throw new RecordCheckError("This assigned decision is unavailable for your account.", 404);
  const q2 = matches[0], resolved = tryResolvePinnedContent(q2.e, context.content.allowedScopes, context.content.registry);
  if (!resolved.available) return unavailable("The exact assigned course is unavailable; its decision rubric was not checked.");
  try {
    if (!refString(q2.e.id) || !refString(q2.a.id) || !refString(q2.ap.id) || !Number.isInteger(q2.a.number) || q2.a.number < 1 || q2.a.number > 3 || !iso(q2.a.submittedAt) || !iso(q2.ap.createdAt) || Date.parse(q2.ap.createdAt) > Date.parse(context.checkedAt) || q2.ap.resolution !== void 0) throw new RecordCheckError("The assigned appeal references need inspection.");
    const original = decision(q2.a.decision, "assessment", q2.a.id, null, resolved.snapshot.program, context);
    if (original.actorRef === context.actorId || context.actorId === context.learnerId || (/* @__PURE__ */ new Set([q2.a.id, q2.ap.id, original.decisionId])).size !== 3 || Date.parse(original.decidedAt) < Date.parse(q2.a.submittedAt) || Date.parse(q2.ap.createdAt) < Date.parse(original.decidedAt)) throw new RecordCheckError("The assigned appeal is not independent or its timeline disagrees.");
    const snapshot = deepFreeze({ schemaVersion: 1, kind: "private-assigned-original-decision", workspaceId: context.workspaceId, enrollmentId: q2.e.id, contentRef: pinnedRef(q2.e), contentFingerprint: await snapshotChecksum(resolved.snapshot.program), classification: "Nonaccredited practice decision", decision: original, openAssignedAppealId: q2.ap.id, checkedAt: context.checkedAt, asOfRevision: context.revision, limitations: ["Only the original decision already present in the current assigned appeal is checked", "No current practice-record status or other learner history is disclosed", "No raw evidence, notes, feedback, email or public bearer URL", "Current assignment/role must be rechecked by the API on each request"] });
    return deepFreeze({ outcome: "checked", snapshot, integrity: { algorithm: "SHA-256", checksum: await snapshotChecksum(snapshot), meaning: checksumMeaning } });
  } catch (e) {
    if (e instanceof RecordCheckError) return unavailable("The assigned decision metadata needs inspection; no validated snapshot was produced.");
    throw e;
  }
}

// ../../../../work/aplyd-academy/lib/academy-authoring.ts
var AUTHORING_CLASSIFICATION = "Private workspace practice draft \xB7 nonaccredited";
var AUTHORING_LIMITS = { activeDrafts: 4, publications: 8, totalDrafts: 24, documentBytes: 65536, contentBytes: 65e4 };
var CLAIM = "Demonstrated the published synthetic practice exercise through checked work, careful information handling and human review";
var EXCLUSIONS = ["Nonaccredited private practice record", "No medical, legal, financial, agricultural or other professional qualification", "No authority to make consequential professional decisions"];
var NOTICE = "All sources, people, work records and AI drafts in this pathway are fictional teaching fixtures. Submit no actual private work records or credentials.";
var AuthoringError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
  }
};
var savedName = (value) => String(value || "Workspace owner").slice(0, 80);
var activeDraft = (d) => !["published", "archived"].includes(d.state);
var copy = (value) => structuredClone(value);
function freshAuthoring() {
  return { drafts: [], publications: [] };
}
var CONTENT_COMMANDS = ["content-copy", "content-save", "content-submit", "content-recall", "content-review", "content-publish", "content-retire", "content-archive"];
function isContentCommand(c) {
  return !!c && CONTENT_COMMANDS.includes(c.type);
}
function member(host, user) {
  const m = host.members.find((m2) => m2.userId === user.userId);
  if (!m || !m.active) throw new AuthoringError("This workspace is unavailable for your current account.", 404);
  return m;
}
function owner(host, user) {
  const m = member(host, user);
  if (!m.roles.includes("admin")) throw new AuthoringError("A current workspace owner permission is required.", 403);
  return m;
}
function exact5(c, allowed) {
  if (!c || typeof c !== "object" || Array.isArray(c) || Object.keys(c).some((k) => !["type", ...allowed].includes(k))) throw new AuthoringError("This content action has unsupported fields.", 400);
}
function text2(v, label2, min, max) {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new AuthoringError(`${label2} needs ${min}\u2013${max} characters.`);
  return v.trim();
}
function scopedRef(host, ref3) {
  try {
    const x = contentRef(ref3);
    if (x.scope !== "global" && x.scope !== host.id) throw new AuthoringError("Content from another workspace is unavailable.", 404);
    return x;
  } catch (e) {
    if (e instanceof AuthoringError) throw e;
    throw new AuthoringError(e.message, e.status ?? 409);
  }
}
function workspaceRegistry(host) {
  return createCurriculumRegistry([...programs.map((program2) => curriculumRegistry.resolve({ scope: "global", programId: program2.id, versionId: LEGACY_CONTENT_VERSION })), ...(host.content?.publications ?? []).map((p) => p.snapshot)]);
}
function resolve(host, ref3) {
  try {
    return workspaceRegistry(host).resolve(scopedRef(host, ref3), ["global", host.id]);
  } catch (e) {
    if (e instanceof AuthoringError) throw e;
    throw new AuthoringError(e.message, e.status ?? 409);
  }
}
function template(host, draft) {
  const doc = copy(resolve(host, draft.baseRef).program);
  doc.id = draft.programId;
  doc.estimatedMinutes = Math.max(doc.estimatedMinutes, doc.lessons.reduce((sum, l) => sum + l.estimatedMinutes, 0));
  doc.credentialClaim = CLAIM;
  doc.credentialExclusions = copy(EXCLUSIONS);
  doc.sourceNotice = NOTICE;
  doc.lessons.forEach((lesson) => {
    const seen = /* @__PURE__ */ new Set();
    lesson.exercise.sourcePacket = lesson.exercise.sourcePacket.map((row, index) => {
      const item = typeof row === "string" ? { sourceId: lesson.id + "-source-" + (index + 1), content: row } : row;
      const id4 = item.sourceId.trim();
      if (draft.baseRef.scope === "global" && seen.has(id4) && typeof item.sourceNote === "string" && /confirmed copied line/i.test(item.sourceNote)) item.duplicateOf = id4;
      seen.add(id4);
      return item;
    });
  });
  return doc;
}
function plain4(v) {
  if (!v || typeof v !== "object" || Array.isArray(v)) return false;
  const p = Object.getPrototypeOf(v);
  return p === Object.prototype || p === null;
}
function canonicalJson(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(canonicalJson).join(",") + "]";
  return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonicalJson(value[k])).join(",") + "}";
}
async function documentHash(document) {
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalJson(document))))).map((x) => x.toString(16).padStart(2, "0")).join("");
}
function validateDocument(document, expected) {
  const issues = [], issue = (path, kind, message) => issues.push({ path, kind, message });
  const locked = /* @__PURE__ */ new Set(["id", "ecosystem", "role", "level", "credentialClaim", "credentialExclusions", "sourceNotice", "followUp"]);
  function walk(v, t, path) {
    if (path.endsWith(".sourcePacket")) {
      if (!Array.isArray(v) || v.length < 1 || v.length > 20) {
        issue(path, "shape", "Provide 1\u201320 fictional source records.");
        return;
      }
      v.forEach((row, i) => {
        if (!plain4(row) || Object.keys(row).length < 2 || Object.keys(row).length > 15) {
          issue(path + "." + i, "shape", "A source record needs a reference and bounded plain facts.");
          return;
        }
        if (typeof row.sourceId !== "string" || row.sourceId.trim().length < 1 || row.sourceId.length > 80) issue(path + "." + i + ".sourceId", "shape", "Provide a source reference of 1\u201380 characters.");
        for (const [key, value] of Object.entries(row)) {
          if (key.length > 60 || ["__proto__", "constructor", "prototype"].includes(key)) {
            issue(path + "." + i, "shape", "This source field name is unsupported.");
            continue;
          }
          if (typeof value === "string") {
            if (value.length > 2e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value)) issue(path + "." + i + "." + key, "limit", "Keep source facts within 2,000 characters using ordinary text.");
          } else if (typeof value === "number") {
            if (!Number.isFinite(value) || Math.abs(value) > 1e12) issue(path + "." + i + "." + key, "shape", "Use a finite bounded number.");
          } else if (value !== null && typeof value !== "boolean") issue(path + "." + i + "." + key, "shape", "Source facts must be plain text, numbers or simple flags.");
        }
      });
      return;
    }
    if (Array.isArray(t)) {
      if (!Array.isArray(v)) {
        issue(path, "shape", "This field must be a list.");
        return;
      }
      const fixed = /\.(lessons|quiz|options|submissionPrompts|rubric)$/.test(path);
      if (fixed && v.length !== t.length || !fixed && (v.length < 1 || v.length > 20)) {
        issue(path, "shape", fixed ? `This pilot keeps exactly ${t.length} entries here.` : "Provide 1\u201320 entries.");
        return;
      }
      v.forEach((child, i) => walk(child, fixed ? t[i] : t[0], path + "." + i));
      return;
    }
    if (t === null) {
      if (v !== null) issue(path, "locked", "This pilot preserves the original critical-gate structure.");
      return;
    }
    if (typeof t === "object") {
      if (!plain4(v)) {
        issue(path, "shape", "Provide a plain content object.");
        return;
      }
      if (Object.keys(v).some((k) => !Object.hasOwn(t, k)) || Object.keys(t).some((k) => !Object.hasOwn(v, k))) {
        issue(path, "shape", "Content fields are missing or unsupported.");
        return;
      }
      for (const key of Object.keys(t)) {
        if (path === "program" && locked.has(key) || key === "id") {
          if (canonicalJson(v[key]) !== canonicalJson(t[key])) issue(path + "." + key, "locked", "Published identity, classification and supported structure are fixed for this pilot.");
        } else walk(v[key], t[key], path + "." + key);
      }
      return;
    }
    if (typeof v !== typeof t) {
      issue(path, "shape", "This field has an unsupported value type.");
      return;
    }
    if (typeof v === "string" && (v.length > 12e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v))) issue(path, "limit", "Use ordinary text within the field limit.");
    if (typeof v === "number" && !Number.isFinite(v)) issue(path, "shape", "Use a finite number.");
  }
  walk(document, expected, "program");
  try {
    if (new TextEncoder().encode(JSON.stringify(document)).length > AUTHORING_LIMITS.documentBytes) issue("program", "limit", "This pathway exceeds the 64 KiB pilot document limit.");
  } catch {
    issue("program", "shape", "Content must be serializable text and facts.");
  }
  if (issues.some((x) => ["shape", "locked", "limit"].includes(x.kind))) return issues;
  function required(value, path, min = 10, max = 2e3) {
    if (typeof value !== "string" || value.trim().length < min) issue(path, "required", `Add at least ${min} characters.`);
    else if (value.length > max) issue(path, "limit", `Keep this field within ${max} characters.`);
  }
  function minutes2(value, path) {
    if (!Number.isInteger(value) || value < 5 || value > 720) issue(path, "consistency", "Use whole minutes between 5 and 720.");
  }
  required(document.title, "program.title", 3, 160);
  required(document.summary, "program.summary", 20, 2e3);
  required(document.promise, "program.promise", 20, 1e3);
  minutes2(document.estimatedMinutes, "program.estimatedMinutes");
  for (const key of ["prerequisites", "outcomes"]) document[key].forEach((v, i) => required(v, "program." + key + "." + i, 10, 500));
  if (document.estimatedMinutes < document.lessons.reduce((sum, l) => sum + l.estimatedMinutes, 0)) issue("program.estimatedMinutes", "consistency", "Total learning time must include all lesson estimates.");
  for (const [i, l] of document.lessons.entries()) {
    const base = "program.lessons." + i;
    required(l.title, base + ".title", 3, 160);
    required(l.objective, base + ".objective", 20, 1e3);
    required(l.lessonText, base + ".lessonText", 100, 12e3);
    minutes2(l.estimatedMinutes, base + ".estimatedMinutes");
    l.steps.forEach((v, j) => required(v, base + ".steps." + j, 5, 500));
    required(l.reflectionPrompt, base + ".reflectionPrompt", 15, 1e3);
    required(l.returnToWorkAction, base + ".returnToWorkAction", 30, 2e3);
    const ex = l.exercise;
    const sourceIds = /* @__PURE__ */ new Set();
    for (const [j, row] of ex.sourcePacket.entries()) {
      const id4 = row.sourceId.trim();
      if (sourceIds.has(id4) && !(row.duplicateOf === id4 && typeof row.sourceNote === "string" && row.sourceNote.trim().length >= 10)) issue(base + ".exercise.sourcePacket." + j + ".sourceId", "consistency", "Give distinct sources separate references, or explicitly mark and explain a teaching duplicate.");
      if (Object.hasOwn(row, "duplicateOf") && (!sourceIds.has(id4) || row.duplicateOf !== id4)) issue(base + ".exercise.sourcePacket." + j + ".duplicateOf", "consistency", "A teaching duplicate must identify an earlier same-reference source.");
      sourceIds.add(id4);
      if (!Object.entries(row).some(([key, value]) => !["sourceId", "duplicateOf", "sourceNote", "type"].includes(key) && value !== null && (typeof value !== "string" || value.trim().length > 0))) issue(base + ".exercise.sourcePacket." + j, "required", "Add at least one meaningful fictional source fact.");
      if (Object.hasOwn(row, "content") && typeof row.content === "string" && !row.content.trim()) issue(base + ".exercise.sourcePacket." + j + ".content", "required", "Add the fictional source text.");
    }
    for (const key of ["title", "suppliedAiDraft", "optionalAiPrompt", "learnerTask", "assessorReference"]) required(ex[key], base + ".exercise." + key, key === "title" ? 3 : 30, key === "title" ? 160 : 4e3);
    ex.expectedEvidence.forEach((v, j) => required(v, base + ".exercise.expectedEvidence." + j, 10, 700));
    for (const [j, q2] of l.quiz.entries()) {
      required(q2.question, base + ".quiz." + j + ".question", 10, 1e3);
      required(q2.explanation, base + ".quiz." + j + ".explanation", 20, 2e3);
      q2.options.forEach((v, k) => required(v, base + ".quiz." + j + ".options." + k, 1, 500));
      if (new Set(q2.options.map((option) => option.trim())).size !== q2.options.length) issue(base + ".quiz." + j + ".options", "consistency", "Use four distinct answer options.");
      if (!Number.isInteger(q2.correctOptionIndex) || q2.correctOptionIndex < 0 || q2.correctOptionIndex > 3) issue(base + ".quiz." + j + ".correctOptionIndex", "consistency", "Choose one of the four answer options.");
    }
  }
  const a = document.practicalAssessment;
  required(a.title, "program.practicalAssessment.title", 3, 160);
  required(a.scenario, "program.practicalAssessment.scenario", 30, 5e3);
  for (const [i, p] of a.submissionPrompts.entries()) {
    required(p.label, "program.practicalAssessment.submissionPrompts." + i + ".label", 3, 160);
    required(p.help, "program.practicalAssessment.submissionPrompts." + i + ".help", 10, 1e3);
  }
  for (const [i, r] of a.rubric.entries()) {
    const b = "program.practicalAssessment.rubric." + i;
    required(r.dimension, b + ".dimension", 3, 160);
    if (!Number.isInteger(r.weight) || r.weight < 1 || r.weight > 97) issue(b + ".weight", "consistency", "Use a positive whole weight, keeping the total at 100.");
    for (const level of ["0", "1", "2", "3", "4"]) required(r.anchors[level], b + ".anchors." + level, 10, 1e3);
    if (r.criticalGate !== null) required(r.criticalGate, b + ".criticalGate", 30, 2e3);
  }
  if (a.rubric.reduce((n, r) => n + r.weight, 0) !== 100) issue("program.practicalAssessment.rubric", "consistency", "Criterion weights must total exactly 100.");
  for (const key of ["samplePassingEvidence", "sampleCriticalFailure", "assessorNote"]) required(a[key], "program.practicalAssessment." + key, 30, 5e3);
  return issues;
}
function findDraft(host, id4, revision2) {
  const d = host.content?.drafts.find((d2) => d2.id === id4);
  if (!d) throw new AuthoringError("Content draft not found in this workspace.", 404);
  if (!Number.isInteger(revision2) || revision2 !== d.revision) throw new AuthoringError("This content draft changed. Reload its latest revision before saving.", 409);
  return d;
}
function byAuthor(d, user) {
  if (d.authorId !== user.userId) throw new AuthoringError("Only this draft author may edit or submit it.", 403);
}
function due(value, now) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value) || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString() !== value || Date.parse(value) <= Date.parse(now) || Date.parse(value) > Date.parse(now) + 730 * 864e5) throw new AuthoringError("Choose a future content review date within two years.");
  return value;
}
function bump(d, actor, action, now, note) {
  d.revision++;
  d.updatedAt = now;
  d.history.push({ id: crypto.randomUUID(), actor: actor.userId, actorName: savedName(actor.name), action, at: now, ...note ? { note } : {} });
  if (d.history.length > (action === "archived private practice draft" ? 101 : 100)) throw new AuthoringError("This draft reached its pilot history limit. Copy its latest publication or seek support.", 409);
}
var complete = (issues) => {
  if (issues.length) throw new AuthoringError("Resolve the content preview issues before requesting review or publishing.");
};
async function applyWorkspaceContentCommand(original, user, c, now = (/* @__PURE__ */ new Date()).toISOString()) {
  if (!isContentCommand(c)) throw new AuthoringError("Unknown content action.", 400);
  if (!Number.isFinite(Date.parse(now))) throw new AuthoringError("A trusted action time is required.", 400);
  now = new Date(now).toISOString();
  if (now.length !== 24) throw new AuthoringError("A four-digit-year action time is required.", 400);
  const t = copy(original), actor = owner(t, user);
  t.content ??= freshAuthoring();
  switch (c.type) {
    case "content-copy": {
      exact5(c, ["sourceRef"]);
      if (t.content.drafts.filter(activeDraft).length >= AUTHORING_LIMITS.activeDrafts) throw new AuthoringError("This pilot supports four active content drafts per workspace.", 409);
      if (t.content.drafts.length >= AUTHORING_LIMITS.totalDrafts) throw new AuthoringError("This pilot retains up to 24 source drafts including archived history.", 409);
      const source2 = scopedRef(t, c.sourceRef), resolved = resolve(t, source2), programId = source2.scope === t.id ? source2.programId : "path-" + crypto.randomUUID(), id4 = "cd-" + crypto.randomUUID();
      const draft = { id: id4, programId, baseRef: source2, authorId: user.userId, authorName: savedName(actor.name), state: "draft", revision: 1, documentRevision: 1, document: {}, createdAt: now, updatedAt: now, history: [{ id: crypto.randomUUID(), actor: user.userId, actorName: savedName(actor.name), action: "copied", at: now }] };
      draft.document = template(t, draft);
      t.content.drafts.push(draft);
      break;
    }
    case "content-save": {
      exact5(c, ["draftId", "revision", "document"]);
      const d = findDraft(t, c.draftId, c.revision);
      byAuthor(d, user);
      if (d.state !== "draft") throw new AuthoringError("Recall the draft before editing reviewed content.", 409);
      const issues = validateDocument(c.document, template(t, d));
      if (issues.some((x) => ["shape", "locked", "limit"].includes(x.kind))) throw new AuthoringError("Keep the supported content structure, classification and text limits.");
      d.document = copy(c.document);
      d.documentRevision++;
      delete d.approval;
      bump(d, actor, "saved", now);
      break;
    }
    case "content-submit": {
      exact5(c, ["draftId", "revision", "reviewerId", "reviewDueAt"]);
      const d = findDraft(t, c.draftId, c.revision);
      byAuthor(d, user);
      if (d.state !== "draft") throw new AuthoringError("Only an editable draft can request review.", 409);
      complete(validateDocument(d.document, template(t, d)));
      const reviewer = t.members.find((m) => m.userId === c.reviewerId && m.active && m.roles.includes("admin"));
      if (!reviewer || reviewer.userId === d.authorId) throw new AuthoringError("Choose another active workspace owner for independent content review.", 403);
      d.reviewerId = reviewer.userId;
      d.reviewDueAt = due(c.reviewDueAt, now);
      d.state = "in_review";
      delete d.approval;
      bump(d, actor, "submitted for independent review", now);
      break;
    }
    case "content-recall": {
      exact5(c, ["draftId", "revision", "reason"]);
      const d = findDraft(t, c.draftId, c.revision);
      byAuthor(d, user);
      if (!["in_review", "approved"].includes(d.state)) throw new AuthoringError("Only unpublished reviewed content may be recalled.", 409);
      const reason = text2(c.reason, "Reason for recall", 10, 1e3);
      d.state = "draft";
      delete d.approval;
      bump(d, actor, "recalled for editing", now, reason);
      break;
    }
    case "content-review": {
      exact5(c, ["draftId", "revision", "decision", "note", "checks"]);
      const d = findDraft(t, c.draftId, c.revision);
      if (d.state !== "in_review") throw new AuthoringError("This draft is not awaiting review.", 409);
      if (d.reviewerId !== user.userId || d.authorId === user.userId) throw new AuthoringError("Only the assigned independent owner may review this content.", 403);
      if (!["approve", "changes"].includes(c.decision)) throw new AuthoringError("Choose approval or request changes.");
      const note = text2(c.note, "Content review note", 30, 2e3);
      if (c.decision === "changes") {
        d.state = "draft";
        delete d.approval;
        bump(d, actor, "changes requested", now, note);
        break;
      }
      const keys = ["sources", "answers", "rubric", "safety", "accessibility"];
      if (!plain4(c.checks) || Object.keys(c.checks).some((k) => !keys.includes(k)) || keys.some((k) => c.checks[k] !== true)) throw new AuthoringError("Record every required content review check before approval.");
      complete(validateDocument(d.document, template(t, d)));
      due(d.reviewDueAt, now);
      d.approval = { reviewerId: user.userId, reviewerName: savedName(actor.name), documentRevision: d.documentRevision, documentHash: await documentHash(d.document), reviewedAt: now, note, checks: copy(c.checks) };
      d.state = "approved";
      bump(d, actor, "approved private practice draft", now, note);
      break;
    }
    case "content-publish": {
      exact5(c, ["draftId", "revision"]);
      const d = findDraft(t, c.draftId, c.revision);
      if (d.state !== "approved" || !d.approval) throw new AuthoringError("Publish only content approved by an independent owner.", 409);
      const reviewer = t.members.find((m) => m.userId === d.approval.reviewerId && m.active && m.roles.includes("admin"));
      if (!reviewer || reviewer.userId === d.authorId) throw new AuthoringError("Independent reviewer permission changed. Request a current content review.", 403);
      complete(validateDocument(d.document, template(t, d)));
      due(d.reviewDueAt, now);
      const hash = await documentHash(d.document);
      if (d.approval.documentRevision !== d.documentRevision || hash !== d.approval.documentHash) throw new AuthoringError("The document differs from the independently approved revision.", 409);
      if (t.content.publications.length >= AUTHORING_LIMITS.publications) throw new AuthoringError("This pilot supports eight immutable workspace publications.", 409);
      const ref3 = contentRef({ scope: t.id, programId: d.programId, versionId: "cp-" + crypto.randomUUID() });
      t.content.publications.push({ id: ref3.versionId, snapshot: { ref: ref3, program: copy(d.document), language: "en", audience: "Adult learners", classification: AUTHORING_CLASSIFICATION, policy: { minimumWeightedScore: 70, scoreMaximum: 4, criticalGates: "all", maxAttempts: 3, appealDays: 14, lessonCount: 3, questionsPerLesson: 3, optionsPerQuestion: 4, submissionFieldCount: 7, evidenceMinCharacters: 30, evidenceMaxCharacters: 1e4 } }, documentHash: hash, authorId: d.authorId, authorName: d.authorName, reviewerId: d.approval.reviewerId, reviewerName: d.approval.reviewerName, reviewedAt: d.approval.reviewedAt, publishedBy: user.userId, publishedByName: savedName(actor.name), publishedAt: now, reviewDueAt: d.reviewDueAt, availability: "available" });
      d.state = "published";
      d.publishedRef = ref3;
      bump(d, actor, "published immutable private practice draft", now);
      break;
    }
    case "content-archive": {
      exact5(c, ["draftId", "revision", "reason"]);
      const d = findDraft(t, c.draftId, c.revision);
      if (!activeDraft(d)) throw new AuthoringError("Only an unpublished active draft can be archived.", 409);
      const reason = text2(c.reason, "Reason for archiving", 10, 1e3);
      d.state = "archived";
      bump(d, actor, "archived private practice draft", now, reason);
      break;
    }
    case "content-retire": {
      exact5(c, ["publicationId", "reason"]);
      const p = t.content.publications.find((p2) => p2.id === c.publicationId);
      if (!p) throw new AuthoringError("Publication not found in this workspace.", 404);
      if (p.availability === "retired") throw new AuthoringError("This publication is already closed to new enrollment.", 409);
      const reason = text2(c.reason, "Reason for closing new enrollment", 10, 1e3);
      p.availability = "retired";
      p.retirement = { reason, actor: user.userId, actorName: savedName(actor.name), at: now };
      break;
    }
  }
  const oldEffective = utf8JsonBytes(original.content ?? freshAuthoring()) + authoringClosureReserve(original), newEffective = utf8JsonBytes(t.content) + authoringClosureReserve(t);
  if (newEffective > oldEffective && newEffective > AUTHORING_LIMITS.contentBytes) throw new AuthoringError("This workspace must retain room to archive drafts and close publications. Keep your edits and seek support before adding more content.", 413);
  return t;
}
function requireAvailablePublication(host, refValue, now = (/* @__PURE__ */ new Date()).toISOString()) {
  const ref3 = scopedRef(host, refValue);
  if (ref3.scope === "global") return resolve(host, ref3);
  const p = host.content?.publications.find((p2) => p2.snapshot.ref.programId === ref3.programId && p2.snapshot.ref.versionId === ref3.versionId);
  if (!p || p.availability !== "available") throw new AuthoringError("This private pathway is closed to new cohort offerings and enrollment.", 409);
  if (!Number.isFinite(Date.parse(now))) throw new AuthoringError("A trusted action time is required.", 400);
  if (Date.parse(p.reviewDueAt) <= Date.parse(now)) throw new AuthoringError("Content review is due before new enrollment.", 409);
  return copy(p.snapshot);
}
function projectWorkspaceContent(host, user, neededRefs) {
  const m = host.members.find((m2) => m2.userId === user.userId);
  if (!m) throw new AuthoringError("Workspace not found.", 404);
  const admin = m.active && m.roles.includes("admin"), content = host.content ?? freshAuthoring();
  const keys = new Set(neededRefs.map((ref3) => contentKey(scopedRef(host, ref3))));
  const versions = content.publications.filter((p) => admin || keys.has(contentKey(p.snapshot.ref))).map((p) => copy(p.snapshot));
  return { versions, ...admin ? { drafts: copy(content.drafts), publications: content.publications.map((p) => ({ id: p.id, ref: p.snapshot.ref, title: p.snapshot.program.title, availability: p.availability, classification: p.snapshot.classification, authorName: p.authorName, reviewerName: p.reviewerName, publishedAt: p.publishedAt, reviewDueAt: p.reviewDueAt, documentHash: p.documentHash, retirement: p.retirement })) } : {} };
}
var utf8JsonBytes = (value) => new TextEncoder().encode(JSON.stringify(value)).length;
var WORST_REASON = String.fromCharCode(0).repeat(1e3);
var WORST_NAME = String.fromCharCode(0).repeat(80);
var CLOCK = "2000-01-01T00:00:00.000Z";
function largestSavedActorId(host) {
  let actor = "";
  for (const m of host.members) {
    if (utf8JsonBytes(m.userId) > utf8JsonBytes(actor)) actor = m.userId;
  }
  return actor;
}
function retirementGrowth(publication, actorId) {
  if (publication.availability !== "available") return 0;
  return Math.max(0, utf8JsonBytes({ ...publication, availability: "retired", retirement: { reason: WORST_REASON, actor: actorId, actorName: WORST_NAME, at: CLOCK } }) - utf8JsonBytes(publication));
}
function archiveGrowth(draft, actorId) {
  if (!activeDraft(draft)) return 0;
  return Math.max(0, utf8JsonBytes({ ...draft, state: "archived", revision: draft.revision + 1, updatedAt: CLOCK, history: [...draft.history, { id: "0".repeat(36), actor: actorId, actorName: WORST_NAME, action: "archived private practice draft", at: CLOCK, note: WORST_REASON }] }) - utf8JsonBytes(draft));
}
function authoringRetirementReserve(host) {
  const actor = largestSavedActorId(host);
  return (host.content?.publications ?? []).reduce((sum, p) => sum + retirementGrowth(p, actor), 0);
}
function authoringClosureReserve(host) {
  const actor = largestSavedActorId(host);
  return authoringRetirementReserve(host) + (host.content?.drafts ?? []).reduce((sum, d) => sum + archiveGrowth(d, actor), 0);
}

// ../../../../work/aplyd-academy/lib/academy-job-templates.ts
var JOB_TEMPLATE_VERSION = "1.0-owner-review-draft";
var ref = (resourceId, sections) => ({ resourceId, sections, limit: "Teaching reference only. This adaptation needs owner and independent content review; no institutional or domain authority is established." });
var C1 = ref("government-trainer-handbook", "Procurement, governance and sunset: \xA7\xA74.6, 4.8, 4.15");
var C2 = ref("development-trainer-handbook", "Funder conditions and funded exit: \xA74.11");
var C3 = ref("oversight-participant-handbook", "FIT, subgroup evidence and governance: \xA7\xA73.1\u20133.4");
var C4 = ref("emerging-leaders-participant-handbook", "Defensible governed work and capstone reasoning: \xA7\xA71, 3, 5.6");
var C5 = ref("frontline-trainer-handbook", "Spot/Override/Flag, consent and institution-specific OPEN items: \xA7\xA74, 6.7, 8");
var q = (question, options, correctOptionIndex, explanation) => ({ question, options, correctOptionIndex, explanation });
var source = (sourceId, content) => ({ sourceId, type: "fictional teaching fixture", content });
var TRAINING_BOUNDARY = source("TRAINING-BOUNDARY", "Fictional practice rule: use only supplied records, identify a named reviewer with a usable channel and backup, and keep consequential actions outside this exercise. Before any real frontline adaptation, confirm the institution\u2019s responsibility, written override permission and reporting protection. Teaching references and Academy roles cannot confirm these institution-specific items.");
var JOB_TEMPLATES = [
  {
    id: "farmer-expert-brief",
    title: "A checked farm record and an expert question",
    audience: "Farmer",
    baseProgramId: "farmer-work-records",
    summary: "Check a fictional expense record, remove invented claims, and prepare a concise question for an approved agricultural expert channel.",
    promise: "Prepare a reusable source-linked record and question brief while keeping consequential farm advice outside this synthetic exercise.",
    checkedFacts: "FARM-R1 records INR 300 and FARM-R2 records INR 200. FARM-R2-COPY explicitly repeats the same FARM-R2 payment. Count it once: the verified total is INR 500.",
    calculation: "300 + 200 = INR 500; the confirmed copied payment is excluded once.",
    missingContext: "No farm area, soil condition, water availability, diagnosis, input dose, yield result or expert recommendation is supplied.",
    unsupportedClaim: "a per-acre cost, yield improvement, diagnosis or instruction to repeat a purchase",
    flawedDraft: "The expenses total INR 700. This proves a 25% yield improvement; repeat these inputs immediately and report a cost per acre.",
    correctedOutput: "Draft expert question: the verified expense total is INR 500 after counting the confirmed FARM-R2 copy once. No area or yield evidence is provided. Which additional records and approved observations would an expert need before advising on a consequential farm decision?",
    handoff: "FARM-ROUTE names fictional expert desk lead Nila, using the training question sheet; fictional coordinator Dev is the backup. Record missing context rather than inventing it.",
    permittedAction: "Improve the fictional record and seek an expert question review. No product, treatment, sowing, irrigation or spending decision is authorized by Academy or this packet.",
    recordSources: [TRAINING_BOUNDARY, source("FARM-R1", "Fictional payment reference R1: INR 300 for a recorded work expense."), source("FARM-R2", "Fictional payment reference R2: INR 200 for another recorded work expense."), source("FARM-R2-COPY", "Confirmed copied row of payment R2, not a separate payment; count the original R2 once."), source("FARM-ROUTE", "Training procedure: prepare a checked record for expert desk lead Nila via the fictional training question sheet. Coordinator Dev is backup. No farm recommendation or production authority is granted.")],
    factQuestion: q("What total is supported after checking the confirmed copied payment?", ["INR 500", "INR 700", "INR 300", "An estimated per-acre figure"], 0, "R1 is INR 300 and R2 is INR 200. The copy is the same R2 payment; 300 + 200 is INR 500, with no area denominator."),
    claimQuestion: q("Which statement must be removed from the supplied draft?", ["The record needs expert review", "Repeat the inputs for a 25% yield improvement", "R2 is a confirmed copied row", "The packet supplies no area"], 1, "The packet records expenses, not crop response or an expert recommendation. The claimed yield improvement and repeat-purchase action are unsupported."),
    trialQuestion: q("What can this checked record establish about crop improvement?", ["A guaranteed gain", "A causal gain if the output reads well", "No crop-improvement conclusion from this expense packet", "A diagnosis of the field"], 2, "There is no crop outcome, field context, comparison or expert judgment. A useful checked record does not establish an agricultural result."),
    references: [C1, C4, C5]
  },
  {
    id: "msme-customer-commitments",
    title: "A customer draft with promises you can support",
    audience: "MSME owner or team member",
    baseProgramId: "msme-customer-operations",
    summary: "Use fictional price, stock and workflow sources to prepare a checked customer reply, an action checklist and a limited productivity observation.",
    promise: "Separate a requested commitment from a confirmed fact, protect unnecessary internal details and retain the designated human review before sending.",
    checkedFacts: "SHOP-P1 states INR 100 per unit and INR 40 delivery if delivery is approved. SHOP-S1 confirms two units; the customer requests three. The third unit and delivery date remain unconfirmed.",
    calculation: "If three units and delivery are later approved: 3 \xD7 INR 100 + INR 40 = INR 340. The calculation does not confirm availability or timing.",
    missingContext: "There is no third-unit confirmation, delivery date, approved discount, delivery waiver or authorization to send the reply.",
    unsupportedClaim: "a three-unit same-day commitment, approved discount or free delivery",
    flawedDraft: "Your three units will arrive today with a 10% discount and free delivery. The system has approved the order; no team review is needed.",
    correctedOutput: "Draft customer reply: two units are recorded as available. We need a stock-team check for the third unit and a dispatch-team check for timing. The conditional three-unit delivered total is INR 340 under SHOP-P1. No discount or waiver is approved. This remains an unsent draft.",
    handoff: "SHOP-ROUTE names fictional stock lead Ria for availability and dispatch lead Om for date; desk owner Tara approves customer sending. The training review sheet is the channel; Tara is the backup for an unanswered stock/date check.",
    permittedAction: "Prepare an unsent draft and checklist with owner role, dependency and confirming source. Real customer sending and exceptions require the actual organization\u2019s approved route.",
    recordSources: [TRAINING_BOUNDARY, source("SHOP-P1", "Fictional published terms: unit price INR 100. Delivery fee INR 40 if delivery is approved. No discount or waiver is authorized."), source("SHOP-S1", "Fictional stock record: two units confirmed. Request is for three units; third unit and date await human checks."), source("SHOP-TRIAL", "One fictional task took 12 minutes manually; drafting took 5 minutes and verification took 4 minutes. No sales, revenue or wider quality result was measured."), source("SHOP-ROUTE", "Training review sheet: Ria checks stock, Om checks dispatch timing, and Tara approves customer sending and is backup. These fictional named roles grant no real authority.")],
    factQuestion: q("What is the conditional delivered total if all three units and delivery are approved?", ["INR 300", "INR 340", "INR 306", "INR 240"], 1, "Three units at INR 100 total INR 300; the stated delivery fee adds INR 40. INR 340 is conditional, not a confirmation of stock or date."),
    claimQuestion: q("What can the draft currently promise about quantity and timing?", ["Three units today", "A discount if a chatbot says so", "Only two recorded units; the third unit and date need checks", "Free delivery for all orders"], 2, "SHOP-S1 confirms two units only. SHOP-P1 contains no discount or waiver, and SHOP-ROUTE retains named checks and approval."),
    trialQuestion: q("What does the one-task productivity observation support?", ["Three minutes saved on one fictional task including verification", "Seven minutes saved because checks do not count", "Guaranteed revenue growth", "A proven gain for all customers"], 0, "Assisted time is 5 + 4 = 9 minutes compared with 12 manually, a three-minute difference on one task. This does not establish a wider productivity or business effect."),
    references: [C1, C2, C4, C5]
  },
  {
    id: "public-source-brief",
    title: "A source brief that keeps authority clear",
    audience: "Public servant",
    baseProgramId: "public-servant-source-briefs",
    summary: "Prepare a fictional service-update brief with checked figures, source traceability, explicit uncertainty and a designated approval handoff.",
    promise: "Produce usable draft work without inventing rules, causal improvements or official approval, and identify the evidence and authority still needed.",
    checkedFacts: "DESK-W1 states 50 requests received and 35 recorded resolved in one fictional week. DESK-G1 says the service update is a draft and participation in the demonstration is voluntary.",
    calculation: "35 \xF7 50 \xD7 100 = 70% recorded resolved in that fictional week, not a causal improvement or a subgroup result.",
    missingContext: "No earlier comparison, subgroup breakdown, causal evaluation, binding circular, mandatory attendance instruction or official approval is supplied.",
    unsupportedClaim: "a mandatory instruction, invented circular, causal improvement or official approval",
    flawedDraft: "Under binding circular GOV-NEW, every person must attend. AI improved resolution by 70% and the update is officially approved for issue.",
    correctedOutput: "Draft service brief: DESK-W1 records 35 of 50 requests resolved, or 70%, for one fictional week. This is an observation, not an improvement claim. DESK-G1 makes the demonstration voluntary and the update a draft. No binding circular or official approval is evidenced.",
    handoff: "DESK-ROUTE names fictional data steward Asha to check figures and designated approver Ishan to decide whether to issue. The training handoff sheet is the channel; coordinator Leela is backup. Missing subgroup and comparison evidence remain open questions.",
    permittedAction: "Prepare the draft and handoff only. Academy roles and AI text grant no official or legal authority; real issue requires the institution\u2019s designated approval.",
    recordSources: [TRAINING_BOUNDARY, source("DESK-W1", "One fictional week: 50 requests received, 35 recorded resolved. No prior comparison or subgroup breakdown is supplied."), source("DESK-G1", "Fictional demonstration participation is voluntary. The service update is a draft, not an approved circular."), source("DESK-ROUTE", "Training handoff sheet: Asha checks figures; Ishan is designated issue approver; Leela is backup. These fictional roles grant no official authority.")],
    factQuestion: q("What does 35 recorded resolutions out of 50 received requests equal?", ["35%", "50%", "70%", "A 70% causal improvement"], 2, "35 divided by 50 is 0.7, or 70% recorded resolved for the supplied week. No baseline or causal design is supplied."),
    claimQuestion: q("Which part of the draft is unsupported?", ["The update remains a draft", "The demonstration is voluntary", "The source counts 50 received requests", "An invented binding circular and official approval"], 3, "DESK-G1 states voluntary participation and draft status. No binding circular or official approval appears in any fictional source."),
    trialQuestion: q("Which missing evidence matters before a wider success claim?", ["Comparison and subgroup evidence with defined measures", "A more confident heading", "The Academy owner role", "A larger font for the same figure"], 0, "A one-week aggregate does not show causal improvement or who was missed. The reference governance principles call for meaningful field and subgroup evidence."),
    references: [C1, C2, C3, C4]
  },
  {
    id: "frontline-spot-override-flag",
    title: "Spot, check the permitted route, and flag",
    audience: "Public-service frontline desk \xB7 fictional nonclinical practice",
    baseProgramId: "public-servant-source-briefs",
    summary: "Practise checking a fictional appointment flag against source records, recording a bounded human-review action and escalating a repeating problem.",
    promise: "Make the source conflict and named escalation route visible while keeping production override permission and frontline protections subject to institutional confirmation.",
    checkedFacts: "FRONT-A1 confirms a fictional demonstration appointment under reference DEMO-7. FRONT-F1 wrongly labels it missing. FRONT-P1 records two similar missing-label cases for review, without diagnosing their cause.",
    calculation: "Two similar recorded flags warrant a pattern question; they do not establish a failure rate, affected population or cause.",
    missingContext: "No production system access, entitlement decision, clinical facts, real override authorization or institutional protection is supplied. The required institutional OPEN items remain unconfirmed.",
    unsupportedClaim: "a final rejection, medical judgment, production override permission or confirmed protection from a training role",
    flawedDraft: "The computer says missing, so reject DEMO-7 without review. An Academy owner may override any real system, and every institution guarantees protection for doing so.",
    correctedOutput: "Fictional review note: FRONT-F1 says missing; FRONT-A1 records DEMO-7. I will hold the automated rejection and request the permitted training review route, with the conflict and source references recorded. I will flag the two similar cases without claiming a cause or granting myself real override authority.",
    handoff: "FRONT-ROUTE names fictional shift lead Mira via the training incident sheet, with coordinator Kiran as backup. State urgency and the effect of waiting. Confirm the actual institution\u2019s written responsibility, override permission and reporting protection before any production adaptation.",
    permittedAction: "In this training case, prepare a human-review request and pattern note. In real work follow the approved local route; if permission or protection is unclear, raise that gap to a named responsible person rather than inventing it.",
    recordSources: [TRAINING_BOUNDARY, source("FRONT-A1", "Fictional demonstration appointment reference DEMO-7 is recorded as present. No real person, entitlement, health assessment or financial decision is represented."), source("FRONT-F1", "Supplied fictional tool output incorrectly labels DEMO-7 missing. It is a suggestion that needs source checking, not final decision authority."), source("FRONT-P1", "Training log records two similar missing-label cases. Cause, population rate and subgroup distribution are unknown."), source("FRONT-ROUTE", "Fictional training procedure permits holding this simulated rejection for human review. Mira is lead via the training incident sheet; Kiran is backup. Production responsibility, written override permission and protection from retaliation are unconfirmed OPEN items.")],
    factQuestion: q("Which source conflict is a reason to pause and check?", ["The tool says missing while FRONT-A1 records DEMO-7", "The tool has a confident tone alone proving truth", "The Academy course grants system access", "A training participant becomes an approver"], 0, "The appointment record and the suggested flag conflict. The appropriate training action is a bounded human review with the source conflict recorded."),
    claimQuestion: q("What does the fictional training procedure permit?", ["Override every real service system", "Hold this simulated rejection for human review", "Issue a clinical judgment", "Treat reporting protection as confirmed everywhere"], 1, "FRONT-ROUTE permits a training review request only. Actual responsibility, override permission and reporting protections must be confirmed with the institution."),
    trialQuestion: q("What can two similar recorded flags establish?", ["A proven bias cause", "A population failure rate", "A pattern question needing investigation, without a cause claim", "Permission to publish client records"], 2, "Two cases justify asking about a repeating pattern. They do not provide population denominators, subgroup distribution or a causal investigation."),
    references: [C3, C4, C5]
  }
];
var JobTemplateError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "JobTemplateError";
  }
};
function jobTemplate(id4) {
  const found = JOB_TEMPLATES.find((t) => t.id === id4);
  if (!found) throw new JobTemplateError("Choose an available job-practice starting point.", 404);
  return structuredClone(found);
}
function jobTemplateSourceRef(id4) {
  const t = jobTemplate(id4);
  return { scope: "global", programId: t.baseProgramId, versionId: LEGACY_CONTENT_VERSION };
}
function tailorJobTemplateDocument(newCopiedDocument, id4) {
  const t = jobTemplate(id4), d = structuredClone(newCopiedDocument);
  if (d.lessons.length !== 3 || d.lessons.some((l) => l.quiz.length !== 3 || l.quiz.some((q2) => q2.options.length !== 4))) throw new JobTemplateError("The starting content structure changed. Review the template against its exact seed version.", 409);
  d.title = t.title;
  d.summary = t.summary;
  d.promise = t.promise;
  d.estimatedMinutes = 110;
  d.prerequisites = ["Use only the supplied fictional records; bring no real private information.", "Basic reading or learner-declared reading help; no provider account is required."];
  d.outcomes = ["Link each material statement to a supplied source and mark missing context.", "Correct the supplied draft without inventing authority or wider success.", "Prepare a named human handoff with a permitted next step and stop boundary."];
  const phaseTitles = ["Check the record before trusting the draft", "Correct a claim and explain the limits", "Prepare the handoff and escalation"];
  const tasks = [`Show the verified facts and calculation: ${t.calculation} Separate these from missing context.`, `Correct the supplied draft. Remove ${t.unsupportedClaim}; show the source basis for every retained commitment.`, `Prepare a short handoff. ${t.handoff} State the permitted action, backup, missing authority and reason to stop.`];
  const phaseQuestions = [t.factQuestion, t.claimQuestion, t.trialQuestion];
  for (const [index, l] of d.lessons.entries()) {
    l.title = phaseTitles[index];
    l.objective = tasks[index];
    l.estimatedMinutes = [35, 35, 40][index];
    l.lessonText = `This fictional practice content starts as an owner-authored draft and must receive independent content review before publication. ${t.checkedFacts}

Check: ${t.calculation}

Unknown: ${t.missingContext}

A polished AI draft is not a source or a permission. Compare its material claims with the source packet and keep unsupported statements out of the final work. ${t.permittedAction}

${t.handoff}

The library offers governance teaching principles; it does not approve this adaptation or grant your institution's permissions. Practise this lesson using only the supplied fictional packet.`;
    l.steps = ["Read each source reference and distinguish facts from an instruction or suggestion.", "Check the calculation or source conflict and list what cannot be concluded.", "Write the corrected draft or handoff; retain the human review and permission boundary."];
    l.reflectionPrompt = "Which unsupported claim was easiest to believe, and which source or named human route changes your next step?";
    l.returnToWorkAction = t.permittedAction + " Prepare a fictional review card before considering a low-consequence permitted work trial.";
    l.exercise = {
      ...l.exercise,
      title: phaseTitles[index] + " \xB7 fictional task",
      sourcePacket: structuredClone(t.recordSources),
      suppliedAiDraft: t.flawedDraft,
      optionalAiPrompt: "Optional drafting instruction only: use these fictional source facts, name their references, mark unknowns, make no unsupported commitment, and keep human approval. You can complete the exercise by reviewing the supplied draft; no AI account or provider call is needed.",
      learnerTask: tasks[index],
      expectedEvidence: ["Checked source references and explicit unknowns.", "A corrected statement, calculation or source-conflict explanation.", "A named fictional reviewer, backup and permitted next action."],
      assessorReference: `Check against the packet, not against a model's confidence. ${t.checkedFacts} ${t.calculation} ${t.missingContext} ${t.correctedOutput} ${t.handoff}`
    };
    const general = index === 0 ? [q("Which input is suitable for this practice?", ["An actual client file", "Only the supplied fictional packet", "Bank credentials", "A colleague\u2019s private notes"], 1, "The supplied fictional records are enough. Private client files, credentials and third-party notes are unnecessary and must not be supplied."), q("What should happen to missing context?", ["Ask a model to invent it", "Omit the fact that it is missing", "Name the gap and seek the designated human check", "Treat confidence as evidence"], 2, `The source cannot establish the missing facts. ${t.missingContext} Name the gap rather than turn a guess into a claim.`)] : index === 1 ? [q("What makes a corrected claim defensible?", ["Fluent wording", "A source reference and explicit limits", "A larger productivity promise", "The Academy owner role"], 1, "A corrected claim must map to permitted source facts and disclose unresolved context. Fluency, promises and training roles supply no evidence or authority."), q("When is a real action authorized by this exercise?", ["As soon as a draft sounds confident", "When a learner finishes the quiz", "The exercise grants no real authority; follow the approved institutional route", "When the app displays a green tag"], 2, `This is synthetic practice. ${t.permittedAction} Completion and interface indicators do not grant consequential decision authority.`)] : [q("What must a usable escalation handoff contain?", ["Only the word supervisor", "A named reviewer, usable channel, backup and source conflict", "Every real client record", "A claim that protection is guaranteed"], 1, `${t.handoff} A generic role name and an untested promise are not enough; keep sharing minimal and source-based.`), q("What must be confirmed before adapting frontline override or reporting rights to real work?", ["That the fictional learner passed", "That AI is always right", "The institution\u2019s responsibility, written override permission and reporting protection", "Nothing because a library handbook grants permission"], 2, "C5 Trainer OPEN items are institution-specific confirmations. Teaching references, Academy roles and fictional procedures cannot establish them.")];
    const questions = [phaseQuestions[index], ...general];
    l.quiz = l.quiz.map((existing, i) => ({ ...existing, ...structuredClone(questions[i]), options: [...questions[i].options] }));
  }
  const a = d.practicalAssessment;
  a.title = t.title + " \xB7 practical demonstration";
  a.scenario = `Using only the three lesson packets, prepare one checked work product, a corrected draft, and a named fictional human handoff. ${t.checkedFacts} ${t.missingContext} The supplied AI draft intentionally includes unsupported statements. This is private nonaccredited practice, not approval for real work.`;
  const labels = { task: "Purpose, audience and safe boundary", record: "Checked record and calculation", "safe-input": "Fictional input and information withheld", "ai-evidence": "Supplied draft and safer instructions", checks: "Sources, unsupported claims and corrections", final: "Corrected draft or human-review brief", checklist: "Named actions, dependencies and checks", handoff: "Named reviewer, channel and backup", return: "Permitted next step and escalation" };
  const promptHelp = {
    task: `State the fictional audience, intended work product and safe action boundary. ${t.summary}`,
    record: `Show the checked record with source IDs and calculation. ${t.checkedFacts} ${t.calculation}`,
    "safe-input": "Name which fictional source records you used and why. State the real private information, credentials and unnecessary third-party records you withheld; bring none of them into this exercise.",
    "ai-evidence": `Identify an unsupported claim in the supplied draft and write a safer source-bound instruction. The supplied draft says: ${t.flawedDraft}`,
    checks: `Map each retained claim to a source ID, show your checks and explain missing context. ${t.calculation} ${t.missingContext}`,
    final: `Write your own corrected work product with source mapping and explicit limits. Reference outcome: ${t.correctedOutput}`,
    checklist: `List actions, dependencies, named owners and the confirming source for each. ${t.handoff}`,
    handoff: `Prepare a concise handoff naming the reviewer, usable channel, backup and the issue that needs a decision. ${t.handoff}`,
    return: `Name the permitted next step and stopping boundary, with escalation if it remains unclear. ${t.permittedAction} ${t.handoff}`
  };
  for (const prompt of a.submissionPrompts) {
    prompt.label = labels[prompt.id] ?? "Source-linked practice explanation";
    prompt.help = promptHelp[prompt.id] ?? "Use fictional source references and explain your own reasoning, unknowns and human review boundary.";
  }
  const dimensions = ["Checked work product", "Source verification", "Careful information handling", "Human judgment and escalation"];
  for (const [i, r] of a.rubric.entries()) {
    r.dimension = dimensions[i] ?? r.dimension;
    const evidence = [t.correctedOutput, `${t.calculation} ${t.missingContext}`, "Only the fictional packet is used; real personal records, secrets and unnecessary details are withheld.", `${t.handoff} ${t.permittedAction}`][i];
    r.anchors = { "0": "No relevant evidence, or a material unsafe claim remains.", "1": "Partial work with important source or boundary errors.", "2": "Mostly usable work with one material missing check or handoff.", "3": "A complete checked explanation meeting the stated requirement: " + evidence, "4": "Meets the requirement and adds concise source mapping, explicit unknowns and a reusable permitted review route: " + evidence };
    if (r.criticalGate !== null) r.criticalGate = i === 1 ? "Do not present " + t.unsupportedClaim + " as a verified fact or authorized recommendation." : i === 2 ? "No actual private records, credentials or unnecessary third-party information are submitted or proposed for an unapproved tool." : "The learner retains designated human review and does not infer professional, official or production override authority from Academy or the fictional packet.";
  }
  a.samplePassingEvidence = `I used only the fictional packet. ${t.checkedFacts} ${t.calculation} I removed the unsupported claims and named these gaps: ${t.missingContext} My corrected output is: ${t.correctedOutput} My handoff is: ${t.handoff} ${t.permittedAction}`;
  a.sampleCriticalFailure = `A polished response still retains ${t.unsupportedClaim} or claims that an Academy role authorizes a real consequential action. The relevant critical gate fails regardless of aggregate score.`;
  a.assessorNote = "Assess the source-linked work, stated limits, minimal information and human handoff, not typing speed, use of an AI brand or agreement with unsupported claims. This owner adaptation still needs independent source/answer/rubric/safety/accessibility review; it establishes no domain or recognized issuer approval.";
  return d;
}

// ../../../../work/aplyd-academy/lib/academy-job-template-create.ts
async function applyJobPracticeTemplate(original, user, input, now = (/* @__PURE__ */ new Date()).toISOString()) {
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.getPrototypeOf(input) !== Object.prototype || Object.keys(input).some((k) => !["type", "templateId"].includes(k)) || !Object.hasOwn(input, "templateId") || input.type !== "content-job-template") throw new JobTemplateError("Use only an available job-practice starting point.", 400);
  const id4 = input.templateId, t = jobTemplate(id4), sourceRef = jobTemplateSourceRef(id4);
  const beforeIds = new Set((original.content?.drafts ?? []).map((d2) => d2.id));
  const copied = await applyWorkspaceContentCommand(original, user, { type: "content-copy", sourceRef }, now);
  const created = copied.content.drafts.filter((d2) => !beforeIds.has(d2.id));
  if (created.length !== 1) throw new JobTemplateError("The new draft could not be identified. Refresh before creating another.", 409);
  const d = created[0], document = tailorJobTemplateDocument(d.document, id4), issues = validateDocument(document, d.document);
  if (issues.length) throw new JobTemplateError("This starting point needs content maintenance before it can create a draft.", 409);
  const next = await applyWorkspaceContentCommand(copied, user, { type: "content-save", draftId: d.id, revision: d.revision, document }, now);
  const saved = next.content.drafts.find((x) => x.id === d.id);
  const origin = { kind: "owner-job-practice-template", templateId: t.id, templateVersion: JOB_TEMPLATE_VERSION, sourceRef: { ...sourceRef }, governanceReferences: structuredClone(t.references), createdAt: saved.createdAt, adaptationStatus: "independent-review-required" };
  Object.assign(saved, { templateOrigin: origin });
  const oldEffective = utf8JsonBytes(original.content ?? freshAuthoring()) + authoringClosureReserve(original);
  const newEffective = utf8JsonBytes(next.content) + authoringClosureReserve(next);
  if (newEffective > oldEffective && newEffective > AUTHORING_LIMITS.contentBytes) throw new JobTemplateError("This workspace must retain room to archive drafts and close publications. Keep your edits and seek support before adding more content.", 413);
  return next;
}

// ../../../../work/aplyd-academy/lib/academy-support.ts
var SupportRuleError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "SupportRuleError";
  }
};
var SUPPORT_CATEGORIES = ["access", "learning", "technical", "content", "accessibility", "privacy"];
var MAX_SUPPORT_BYTES = 25e4;
var MAX_REQUESTS = 100;
var MAX_OPEN = 5;
var MAX_MESSAGES = 20;
var MAX_EVENTS = 100;
var MAX_RESOLUTIONS = 20;
var snapshotName = (name) => String(name || "Academy member").slice(0, 80);
var commands = /* @__PURE__ */ new Set(["support-open", "support-claim", "support-reply", "support-resolve", "support-reopen", "support-withdraw"]);
var exact6 = (c, keys) => {
  if (Object.keys(c).some((k) => !["type", ...keys].includes(k))) throw new SupportRuleError("This support request includes unsupported fields.", 400);
};
function text3(v, label2, min, max) {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new SupportRuleError(`${label2} needs ${min}\u2013${max} characters.`);
  return v.trim();
}
function member2(t, userId, active2 = true) {
  const m = t.members.find((m2) => m2.userId === userId);
  if (!m) throw new SupportRuleError("Workspace support is unavailable for this account.", 404);
  if (active2 && !m.active) throw new SupportRuleError("Workspace access is no longer active. Your past requests remain available to read.", 403);
  return m;
}
var owner2 = (m) => m.active && m.roles.includes("admin");
function eligibleSupportHandler(t, m, r) {
  return !!m && m.active && m.userId !== r.requesterId && (owner2(m) || m.roles.includes("facilitator") && ["learning", "content"].includes(r.category) && r.cohortId !== null && t.cohorts.some((c) => c.id === r.cohortId) && m.scopes.includes(r.cohortId));
}
function handler(t, r) {
  const m = t.members.find((m2) => m2.userId === r.assignedTo);
  return eligibleSupportHandler(t, m, r) ? m : null;
}
function reconcileSupportAssignments(t) {
  let released = 0;
  for (const r of t.support ?? []) {
    if (r.assignedTo && !handler(t, r)) {
      r.assignedTo = null;
      released++;
    }
  }
  return released;
}
function canQueue(t, m, r) {
  return m.active && (owner2(m) || m.roles.includes("facilitator") && ["learning", "content"].includes(r.category) && r.cohortId !== null && t.cohorts.some((c) => c.id === r.cohortId) && m.scopes.includes(r.cohortId));
}
function request(t, c, m) {
  if (typeof c.requestId !== "string") throw new SupportRuleError("Choose a support request.", 400);
  const r = t.support?.find((r2) => r2.id === c.requestId);
  if (!r || r.requesterId !== m.userId && !canQueue(t, m, r) && handler(t, r)?.userId !== m.userId) throw new SupportRuleError("Support request not found for this account.", 404);
  return r;
}
function intakeCohort(t, m, id4) {
  if (id4 === null) return null;
  if (typeof id4 !== "string") throw new SupportRuleError("Choose a current cohort or workspace access.", 400);
  const c = t.cohorts.find((c2) => c2.id === id4);
  if (!c) throw new SupportRuleError("Current workspace cohort not found.", 404);
  if (!owner2(m) && !m.roles.includes("learner") && !(m.scopes.includes(id4) && m.roles.some((r) => ["facilitator", "assessor", "reviewer", "moderator"].includes(r)))) throw new SupportRuleError("This cohort is outside your current request scope.", 403);
  return c.id;
}
function appendMessage(r, m, kind, body, now) {
  if (r.messages.length >= MAX_MESSAGES) throw new SupportRuleError("This pilot request reached its 20-message limit. Keep your input and ask the workspace owner for support.", 409);
  r.messages.push({ id: crypto.randomUUID(), actorId: m.userId, actorName: snapshotName(m.name), authorKind: kind, body, createdAt: now });
}
function event(r, m, type, now, extra = {}) {
  if (r.events.length >= MAX_EVENTS && type !== "withdrawn") throw new SupportRuleError("This pilot request reached its lifecycle history limit.", 409);
  r.events.push({ id: crypto.randomUUID(), type, actorId: m.userId, actorName: snapshotName(m.name), createdAt: now, ...extra });
}
function mustOpen(r) {
  if (r.status !== "open") throw new SupportRuleError("Only open requests allow this action.", 409);
}
function assertOwn(r, m) {
  if (r.requesterId !== m.userId) throw new SupportRuleError("Only the requester can do this.", 403);
}
function assertHandler(t, r, m) {
  if (handler(t, r)?.userId !== m.userId) throw new SupportRuleError("Only the currently assigned eligible handler can do this.", 403);
}
function applySupportCommand(t, actorId, c, now) {
  if (!c || typeof c !== "object" || !commands.has(c.type)) return false;
  if (typeof now !== "string" || !Number.isFinite(Date.parse(now))) throw new SupportRuleError("A valid support timestamp is required.", 400);
  now = new Date(now).toISOString();
  if (now.length !== 24) throw new SupportRuleError("A four-digit-year support timestamp is required.", 400);
  const actor = member2(t, actorId), next = { members: t.members, cohorts: t.cohorts, support: structuredClone(t.support ?? []) }, cases = next.support;
  switch (c.type) {
    case "support-open": {
      exact6(c, ["category", "cohortId", "subject", "body", "audienceAcknowledged"]);
      if (c.audienceAcknowledged !== true) throw new SupportRuleError("Acknowledge who can see the request before submitting.");
      if (!SUPPORT_CATEGORIES.includes(c.category)) throw new SupportRuleError("Choose an existing support category.");
      const cohortId = intakeCohort(next, actor, c.cohortId), subject3 = text3(c.subject, "Request title", 5, 160), body = text3(c.body, "Request description", 10, 2e3);
      if (cases.length >= MAX_REQUESTS) throw new SupportRuleError("This pilot workspace reached its 100-request limit. Keep your input and ask the workspace owner for support.", 409);
      if (cases.filter((r2) => r2.requesterId === actorId && r2.status === "open").length >= MAX_OPEN) throw new SupportRuleError("You already have five open requests. Continue an existing request before opening another.", 409);
      const r = { id: crypto.randomUUID(), requesterId: actorId, requesterName: snapshotName(actor.name), category: c.category, cohortId, subject: subject3, status: "open", createdAt: now, updatedAt: now, assignedTo: null, messages: [], resolution: null, resolutions: [], events: [] };
      appendMessage(r, actor, "requester", body, now);
      event(r, actor, "opened", now);
      cases.push(r);
      break;
    }
    case "support-claim": {
      exact6(c, ["requestId"]);
      const r = request(next, c, actor);
      mustOpen(r);
      if (!eligibleSupportHandler(next, actor, r)) throw new SupportRuleError("A current eligible staff member independent of the requester must handle this request.", 403);
      if (handler(next, r)) throw new SupportRuleError("This request already has a current eligible handler.", 409);
      const prior = next.members.find((m) => m.userId === r.assignedTo);
      event(r, actor, "claimed", now, { previousHandlerId: r.assignedTo, previousHandlerName: prior ? snapshotName(prior.name) : null, handlerId: actorId, handlerName: snapshotName(actor.name) });
      r.assignedTo = actorId;
      r.updatedAt = now;
      break;
    }
    case "support-reply": {
      exact6(c, ["requestId", "body"]);
      const r = request(next, c, actor);
      mustOpen(r);
      const kind = r.requesterId === actorId ? "requester" : "handler";
      if (kind === "handler") assertHandler(next, r, actor);
      appendMessage(r, actor, kind, text3(c.body, "Reply", 10, 2e3), now);
      r.updatedAt = now;
      break;
    }
    case "support-resolve": {
      exact6(c, ["requestId", "resolution"]);
      const r = request(next, c, actor);
      mustOpen(r);
      assertHandler(next, r, actor);
      if (r.resolutions.length >= MAX_RESOLUTIONS) throw new SupportRuleError("This pilot request reached its resolution history limit.", 409);
      const resolution = { id: crypto.randomUUID(), actorId, actorName: snapshotName(actor.name), body: text3(c.resolution, "Resolution", 20, 2e3), resolvedAt: now };
      r.resolutions.push(resolution);
      r.resolution = structuredClone(resolution);
      event(r, actor, "resolved", now);
      r.status = "resolved";
      r.updatedAt = now;
      break;
    }
    case "support-reopen": {
      exact6(c, ["requestId", "body"]);
      const r = request(next, c, actor);
      assertOwn(r, actor);
      if (r.status !== "resolved") throw new SupportRuleError("Only a resolved request can be reopened. Withdrawn requests stay read only.", 409);
      if (cases.filter((x) => x.requesterId === actorId && x.status === "open").length >= MAX_OPEN) throw new SupportRuleError("You already have five open requests. Continue an existing request first.", 409);
      appendMessage(r, actor, "requester", text3(c.body, "Reason for reopening", 10, 2e3), now);
      event(r, actor, "reopened", now);
      r.resolution = null;
      r.status = "open";
      r.updatedAt = now;
      break;
    }
    case "support-withdraw": {
      exact6(c, ["requestId"]);
      const r = request(next, c, actor);
      assertOwn(r, actor);
      mustOpen(r);
      event(r, actor, "withdrawn", now);
      r.status = "withdrawn";
      r.updatedAt = now;
      break;
    }
  }
  const bytes = new TextEncoder().encode(JSON.stringify(cases)).length;
  if (bytes + supportClosureReserve(next) > MAX_SUPPORT_BYTES) throw new SupportRuleError("This pilot workspace reached its support storage limit. Keep your input and ask the workspace owner for support.", 413);
  t.support = cases;
  return true;
}
function fullThread(t, r) {
  const effective = handler(t, r), { requesterId, assignedTo, ...safe } = structuredClone(r);
  return { ...safe, handlerName: effective?.name ?? null, messages: safe.messages.map(({ actorId, ...m }) => m), resolution: safe.resolution ? (({ actorId, ...v }) => v)(safe.resolution) : null, resolutions: safe.resolutions.map(({ actorId, ...v }) => v), events: safe.events.map(({ actorId, handlerId, previousHandlerId, ...e }) => e) };
}
function projectSupport(t, actorId) {
  const m = member2(t, actorId, false), cases = t.support ?? [], mine = cases.filter((r) => r.requesterId === actorId).map((r) => fullThread(t, r));
  if (!m.active) return { mine, queue: [], assigned: [] };
  const queue = cases.filter((r) => canQueue(t, m, r)).map((r) => {
    const effective = handler(t, r);
    return { id: r.id, category: r.category, cohortId: r.cohortId, cohortTitle: r.cohortId ? t.cohorts.find((c) => c.id === r.cohortId)?.title ?? "Former cohort" : null, subject: r.subject, requesterName: r.requesterName, createdAt: r.createdAt, updatedAt: r.updatedAt, status: r.status, handlerName: effective?.name ?? null, canClaim: r.status === "open" && !effective && eligibleSupportHandler(t, m, r), eligibleHandlerAvailable: t.members.some((x) => eligibleSupportHandler(t, x, r)) };
  });
  const assigned = cases.filter((r) => handler(t, r)?.userId === actorId).map((r) => fullThread(t, r));
  return { mine, queue, assigned };
}
function supportClosureReserve(t) {
  const bytes = (v) => new TextEncoder().encode(JSON.stringify(v)).length;
  return (t.support ?? []).filter((r) => r.status === "open").reduce((total, r) => {
    const final = { id: "0".repeat(36), type: "withdrawn", actorId: r.requesterId, actorName: "\0".repeat(80), createdAt: "2000-01-01T00:00:00.000Z" };
    return total + bytes(final) + (r.events.length ? 1 : 0) + 5 + Math.max(0, 24 - r.updatedAt.length);
  }, 0);
}

// ../../../../work/aplyd-academy/lib/academy-network.ts
var NETWORK_FOCUS = ["Checking AI drafts", "Work records", "Customer operations", "Source-based briefs", "Careful information handling"];
var text4 = (v, label2, min, max) => {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new RuleError(`${label2} needs ${min}\u2013${max} characters.`);
  return v.trim();
};
var exact7 = (c, keys) => {
  if (Object.keys(c).some((k) => !["type", ...keys].includes(k))) throw new RuleError("This request includes unsupported fields.", 400);
};
var network = (t) => t.network ?? { profiles: [], sessions: [] };
var canHost = (m, cid) => m.active && (m.roles.includes("admin") || m.roles.includes("facilitator") && m.scopes.includes(cid));
var eligible = (t, id4, cid, access) => {
  const m = t.members.find((x) => x.userId === id4);
  return !!m && access(t, m, cid);
};
var currentSeats = (t, s, access) => s.registrations.filter((r) => r.status === "going" && eligible(t, r.userId, s.cohortId, access));
function reconcileNetworkAccess(t, now, access) {
  if (!t.network) return;
  for (const p of t.network.profiles) {
    const remaining = p.cohortIds.filter((id4) => eligible(t, p.userId, id4, access));
    if (remaining.length !== p.cohortIds.length) {
      p.cohortIds = remaining;
      p.updatedAt = now;
      if (!remaining.length) {
        p.enabled = false;
        p.accessRevokedAt = now;
      }
    }
  }
  for (const session2 of t.network.sessions) if (Date.parse(session2.startsAt) > Date.parse(now)) {
    for (const r of session2.registrations) if (r.status === "going" && !eligible(t, r.userId, session2.cohortId, access)) Object.assign(r, { status: "cancelled", cancelledAt: now, updatedAt: now, cancellationReason: "Cohort access ended. Reserve again after access returns." });
  }
}
function session(t, m, id4, access) {
  const s = network(t).sessions.find((s2) => s2.id === id4);
  if (!s || !access(t, m, s.cohortId)) throw new RuleError("Session not found for your cohort.", 404);
  return s;
}
function hosted(s, m) {
  if (s.hostId !== m.userId || !canHost(m, s.cohortId)) throw new RuleError("Only the current scoped session host can do this.", 403);
}
function time(v, label2) {
  if (typeof v !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/.test(v) || !Number.isFinite(Date.parse(v)) || new Date(v).toISOString() !== v.replace(/:([0-9]{2})Z$/, ":$1.000Z")) throw new RuleError(`${label2} needs a valid UTC date and time.`);
  return Date.parse(v);
}
function applyNetworkCommand(t, m, c, now, access) {
  t.network ??= { profiles: [], sessions: [] };
  const n = t.network;
  switch (c.type) {
    case "network-profile": {
      exact7(c, ["enabled", "bio", "focus", "cohortIds"]);
      if (typeof c.enabled !== "boolean") throw new RuleError("Choose a directory sharing setting.");
      let p = n.profiles.find((p2) => p2.userId === m.userId);
      if (!c.enabled) {
        if (p) {
          p.enabled = false;
          p.updatedAt = now;
        }
        break;
      }
      if (!Array.isArray(c.cohortIds) || !c.cohortIds.length || c.cohortIds.length > 5 || new Set(c.cohortIds).size !== c.cohortIds.length || c.cohortIds.some((id4) => !t.cohorts.some((x) => x.id === id4) || !access(t, m, id4))) throw new RuleError("Choose up to five cohorts you can currently access.", 403);
      if (!NETWORK_FOCUS.includes(c.focus)) throw new RuleError("Choose a learning focus.");
      const bio = text4(c.bio, "Profile introduction", 10, 300);
      if (!p) {
        p = { id: crypto.randomUUID(), userId: m.userId };
        n.profiles.push(p);
      }
      Object.assign(p, { enabled: true, bio, focus: c.focus, cohortIds: c.cohortIds, consentVersion: "cohort-directory-1", consentedAt: now, updatedAt: now });
      break;
    }
    case "session-create": {
      exact7(c, ["cohortId", "title", "description", "startsAt", "endsAt", "capacity", "instructions"]);
      const co = t.cohorts.find((x) => x.id === c.cohortId);
      if (!co || !access(t, m, co.id)) throw new RuleError("Cohort not found.", 404);
      if (!canHost(m, co.id)) throw new RuleError("A workspace owner or scoped facilitator must host sessions.", 403);
      if (co.status === "paused") throw new RuleError("This cohort is paused.", 409);
      if (n.sessions.length >= 100) throw new RuleError("This pilot supports 100 sessions per workspace.", 409);
      const start = time(c.startsAt, "Start"), end = time(c.endsAt, "End"), clock = Date.parse(now);
      if (start <= clock || start > clock + 180 * 864e5 || end <= start || end - start > 180 * 6e4) throw new RuleError("Schedule a future session within 180 days, lasting up to three hours.");
      if (!Number.isInteger(c.capacity) || c.capacity < 1 || c.capacity > 100) throw new RuleError("Set a session capacity between 1 and 100.");
      n.sessions.push({ id: crypto.randomUUID(), cohortId: co.id, hostId: m.userId, title: text4(c.title, "Session title", 5, 120), description: text4(c.description, "Session purpose", 20, 1e3), instructions: text4(c.instructions, "Joining instructions", 10, 2e3), startsAt: new Date(start).toISOString(), endsAt: new Date(end).toISOString(), capacity: c.capacity, status: "scheduled", createdAt: now, registrations: [], attendance: [] });
      break;
    }
    case "session-rsvp": {
      exact7(c, ["sessionId", "going"]);
      if (typeof c.going !== "boolean") throw new RuleError("Choose an attendance preference.");
      const s = session(t, m, c.sessionId, access);
      let r = s.registrations.find((r2) => r2.userId === m.userId);
      if (!c.going) {
        if (r && r.status === "going") {
          r.status = "cancelled";
          r.cancelledAt = now;
          r.updatedAt = now;
        }
        break;
      }
      if (s.status !== "scheduled" || Date.parse(s.startsAt) <= Date.parse(now)) throw new RuleError("This session is no longer accepting places.", 409);
      if (t.cohorts.find((x) => x.id === s.cohortId)?.status === "paused") throw new RuleError("This cohort is paused.", 409);
      if (!eligible(t, s.hostId, s.cohortId, access) || !canHost(t.members.find((x) => x.userId === s.hostId), s.cohortId)) throw new RuleError("The host no longer has access. Ask the workspace owner to arrange another session.", 409);
      if (r?.status === "going") break;
      if (currentSeats(t, s, access).length >= s.capacity) throw new RuleError("This session is full. Choose another session or check again after a cancellation.", 409);
      if (!r) {
        r = { id: crypto.randomUUID(), userId: m.userId, createdAt: now };
        s.registrations.push(r);
      }
      Object.assign(r, { status: "going", confirmedAt: now, cancelledAt: null, updatedAt: now });
      break;
    }
    case "session-cancel": {
      exact7(c, ["sessionId", "reason"]);
      const s = session(t, m, c.sessionId, access);
      if (!(m.roles.includes("admin") && m.active)) hosted(s, m);
      if (s.status === "cancelled" || Date.parse(s.endsAt) <= Date.parse(now)) throw new RuleError("This session is cancelled or has ended.", 409);
      s.status = "cancelled";
      s.cancellation = { reason: text4(c.reason, "Cancellation reason", 10, 1e3), actor: m.userId, actorName: m.name, createdAt: now };
      break;
    }
    case "session-attendance": {
      exact7(c, ["sessionId", "registrationId", "status", "reason"]);
      const s = session(t, m, c.sessionId, access);
      hosted(s, m);
      if (s.status !== "scheduled") throw new RuleError("Cancelled sessions cannot record attendance.", 409);
      const clock = Date.parse(now);
      if (clock < Date.parse(s.startsAt) || clock > Date.parse(s.endsAt) + 7 * 864e5) throw new RuleError("Record attendance from the start until seven days after the session.");
      const r = s.registrations.find((r2) => r2.id === c.registrationId && Date.parse(r2.confirmedAt ?? r2.createdAt) <= Date.parse(s.startsAt) && (!r2.cancelledAt || Date.parse(r2.cancelledAt) > Date.parse(s.startsAt)));
      if (!r || !eligible(t, r.userId, s.cohortId, access)) throw new RuleError("Eligible registration at the session start not found.", 404);
      if (!["attended", "absent"].includes(c.status)) throw new RuleError("Choose attended or absent.");
      if (s.attendance.length >= 300) throw new RuleError("This session reached its attendance history limit.", 409);
      s.attendance.push({ id: crypto.randomUUID(), registrationId: r.id, status: c.status, reason: text4(c.reason, "Attendance basis", 10, 500), actor: m.userId, actorName: m.name, createdAt: now });
      break;
    }
    default:
      return false;
  }
  return true;
}
function projectNetwork(t, m, access) {
  const n = network(t), self = n.profiles.find((p) => p.userId === m.userId), myProfile = self ? { enabled: self.enabled, bio: self.bio, focus: self.focus, cohortIds: self.cohortIds ?? [], consentedAt: self.consentedAt } : null;
  const history2 = n.sessions.flatMap((session2) => {
    const r = session2.registrations.find((x) => x.userId === m.userId);
    return r ? [{ id: session2.id, title: session2.title, cohortTitle: t.cohorts.find((x) => x.id === session2.cohortId)?.title, startsAt: session2.startsAt, endsAt: session2.endsAt, status: session2.status, myRsvp: r.status, cancellationReason: session2.cancellation?.reason ?? r.cancellationReason ?? null, attendance: session2.attendance.filter((a) => a.registrationId === r.id).map((a) => ({ id: a.id, status: a.status, reason: a.reason, actorName: a.actorName, createdAt: a.createdAt })) }] : [];
  });
  if (!m.active) return { myProfile, history: history2, directory: [], sessions: [] };
  const directory = n.profiles.filter((p) => p.enabled && p.cohortIds.some((id4) => access(t, m, id4) && eligible(t, p.userId, id4, access))).map((p) => ({ id: p.id, name: t.members.find((x) => x.userId === p.userId)?.name, bio: p.bio, focus: p.focus, cohortIds: p.cohortIds.filter((id4) => access(t, m, id4) && eligible(t, p.userId, id4, access)), isMe: p.userId === m.userId }));
  const sessions = n.sessions.filter((s) => access(t, m, s.cohortId)).map((s) => {
    const own = s.registrations.find((r) => r.userId === m.userId), host = s.hostId === m.userId && canHost(m, s.cohortId), seats2 = currentSeats(t, s, access), roster = s.registrations.filter((r) => eligible(t, r.userId, s.cohortId, access) && (r.status === "going" || r.cancelledAt && Date.parse(r.cancelledAt) > Date.parse(s.startsAt) && Date.parse(r.confirmedAt ?? r.createdAt) <= Date.parse(s.startsAt))), validHost = eligible(t, s.hostId, s.cohortId, access) && canHost(t.members.find((x) => x.userId === s.hostId), s.cohortId);
    const current = (rid) => {
      const a = s.attendance.filter((a2) => a2.registrationId === rid).at(-1);
      if (!a) return null;
      const { actor, ...safe } = a;
      return safe;
    };
    return { id: s.id, cohortId: s.cohortId, title: s.title, description: s.description, startsAt: s.startsAt, endsAt: s.endsAt, capacity: s.capacity, occupied: seats2.length, status: s.status, hostName: t.members.find((x) => x.userId === s.hostId)?.name, hostAvailable: validHost, isHost: host, canCancel: host || m.roles.includes("admin"), myRsvp: own?.status ?? "none", myAttendance: own ? current(own.id) : null, ...s.cancellation ? { cancellation: { reason: s.cancellation.reason, createdAt: s.cancellation.createdAt } } : {}, ...s.status === "scheduled" && validHost && (host || own?.status === "going") ? { instructions: s.instructions } : {}, ...host ? { registrations: roster.map((r) => ({ id: r.id, name: t.members.find((x) => x.userId === r.userId)?.name, attendance: current(r.id) ?? null })), attendanceHistory: s.attendance.map(({ actor, ...a }) => a) } : {} };
  });
  return { myProfile, history: history2, directory, sessions };
}

// ../../../../work/aplyd-academy/lib/academy-teams.ts
var TEAM_ROLES = ["admin", "learner", "facilitator", "assessor", "reviewer", "moderator"];
var copy2 = (x) => structuredClone(x);
var label = (u) => u.fullName || "Academy member";
function txt(v, name, min = 1, max = 200) {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new RuleError(`${name} needs ${min}\u2013${max} characters.`);
  return v.trim();
}
var normalizeEmail = (v) => v.trim().toLowerCase();
function email(v) {
  const x = txt(v, "Recipient email", 3, 254);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x)) throw new RuleError("Enter a valid account email.");
  return normalizeEmail(x);
}
function member3(t, userId, active2 = true) {
  const m = t.members.find((m2) => m2.userId === userId);
  if (!m) throw new RuleError("Workspace not found for your account.", 404);
  if (active2 && !m.active) throw new RuleError("Your workspace access has been removed. Your own learning history remains readable.", 403);
  return m;
}
function requireRole(m, role, cohortId) {
  if (!m.roles.includes(role) || cohortId && !m.scopes.includes(cohortId)) throw new RuleError("Your current membership does not permit this action.", 403);
}
function roles(v) {
  if (!Array.isArray(v) || !v.length || v.length > TEAM_ROLES.length || new Set(v).size !== v.length || v.some((r) => !TEAM_ROLES.includes(r))) throw new RuleError("Choose existing workspace roles.");
  return v;
}
function scopes2(t, v) {
  if (!Array.isArray(v) || new Set(v).size !== v.length || v.some((id4) => !t.cohorts.some((c) => c.id === id4))) throw new RuleError("Choose existing cohorts for staff access.");
  return v;
}
function exact8(c, keys) {
  if (Object.keys(c).some((k) => !["type", ...keys].includes(k))) throw new RuleError("This request includes unsupported fields.", 400);
}
function cohort(t, id4) {
  const c = t.cohorts.find((c2) => c2.id === id4);
  if (!c) throw new RuleError("Cohort not found.", 404);
  return c;
}
function learner(t, u) {
  let l = t.learners.find((l2) => l2.userId === u.userId);
  if (!l) {
    const state = freshWorkspace();
    state.profile.name = label(u);
    state.profile.context = t.context;
    l = { userId: u.userId, state };
    t.learners.push(l);
  }
  return l;
}
function target(t, userId, enrollmentId) {
  const l = t.learners.find((l2) => l2.userId === userId), e = l?.state.enrollments.find((e2) => e2.id === enrollmentId);
  if (!l || !e) throw new RuleError("Enrollment not found in this workspace.", 404);
  return { l, e, c: cohort(t, e.cohortId) };
}
function boardAccess(t, m, cid) {
  return m.active && (m.roles.includes("admin") || m.scopes.includes(cid) && m.roles.some((r) => ["facilitator", "assessor", "reviewer", "moderator"].includes(r)) || m.roles.includes("learner") && t.learners.find((l) => l.userId === m.userId)?.state.enrollments.some((e) => e.cohortId === cid && !e.withdrawn));
}
function seats(t, cid) {
  return t.learners.reduce((n, l) => n + l.state.enrollments.filter((e) => e.cohortId === cid && !e.withdrawn).length, 0);
}
function pending(t) {
  return t.learners.flatMap((l) => l.state.enrollments.flatMap((e) => [
    ...e.attempts.filter((a) => !a.decision && !e.withdrawn).map((a) => ({ kind: "assessment", targetId: a.id, enrollmentId: e.id, learnerId: l.userId, cohortId: e.cohortId, programId: e.programId, number: a.number, createdAt: a.submittedAt })),
    ...e.appeals.filter((ap) => ap.status === "open" && !e.withdrawn).map((ap) => ({ kind: "appeal", targetId: ap.id, enrollmentId: e.id, learnerId: l.userId, cohortId: e.cohortId, programId: e.programId, createdAt: ap.createdAt, originalActor: e.attempts.find((a) => a.id === ap.attemptId)?.decision?.actor }))
  ]));
}
function eligible2(t, m, q2) {
  return m?.active && m.userId !== q2.learnerId && m.userId !== q2.originalActor && m.roles.includes(q2.kind === "appeal" ? "reviewer" : "assessor") && m.scopes.includes(q2.cohortId);
}
function createTeam(u, c, id4, now = (/* @__PURE__ */ new Date()).toISOString()) {
  exact8(c, ["name", "purpose", "context"]);
  if (!Object.hasOwn(contexts, c.context)) throw new RuleError("Choose a work context.");
  return { id: id4, name: txt(c.name, "Workspace name", 3, 80), purpose: txt(c.purpose, "Workspace purpose", 10, 500), context: c.context, createdAt: now, createdBy: u.userId, members: [{ userId: u.userId, email: normalizeEmail(u.email), name: label(u), roles: ["admin", "learner"], scopes: [], active: true, joinedAt: now }], invites: [], cohorts: [], learners: [], assignments: [], posts: [], reports: [], moderation: [], activity: [] };
}
function invitation(t, hash, u, now = (/* @__PURE__ */ new Date()).toISOString()) {
  const i = t.invites.find((i2) => i2.tokenHash === hash);
  if (!i || i.email !== normalizeEmail(u.email)) throw new RuleError("This invitation is unavailable for your signed-in account.", 404);
  if (i.status === "accepted" && i.acceptedBy === u.userId) {
    member3(t, u.userId);
    return i;
  }
  if (!t.members.some((m2) => m2.userId === i.createdBy && m2.active && m2.roles.includes("admin"))) throw new RuleError("This invitation issuer no longer has workspace authority. Ask a current owner for a new link.", 409);
  if (i.status !== "active" || Date.parse(i.expiresAt) <= Date.parse(now)) throw new RuleError("This invitation expired or was revoked. Ask the workspace owner for a new link.", 409);
  const m = t.members.find((m2) => m2.userId === u.userId);
  if (m && !m.active) throw new RuleError("An invitation cannot restore removed access. Ask a workspace owner to restore your membership.", 403);
  return i;
}
function finishAccess(t, now) {
  reconcileNetworkAccess(t, now, boardAccess);
  reconcileSupportAssignments(t);
  return t;
}
function applyTeamCommand(original, u, c, now = (/* @__PURE__ */ new Date()).toISOString()) {
  const t = copy2(original);
  if (!c || typeof c.type !== "string") throw new RuleError("Choose a valid workspace action.", 400);
  if (c.type === "accept") {
    exact8(c, ["tokenHash"]);
    const i = invitation(t, c.tokenHash, u, now);
    if (i.status === "accepted") return finishAccess(t, now);
    if (t.members.length >= 100 && !t.members.some((m2) => m2.userId === u.userId)) throw new RuleError("This pilot workspace supports up to 100 members.", 409);
    if (!t.members.some((m2) => m2.userId === u.userId)) t.members.push({ userId: u.userId, email: normalizeEmail(u.email), name: label(u), roles: i.roles, scopes: i.scopes, active: true, joinedAt: now });
    i.status = "accepted";
    i.acceptedBy = u.userId;
    i.acceptedAt = now;
    return finishAccess(t, now);
  }
  const m = member3(t, u.userId);
  if (isContentCommand(c) || c.type === "content-job-template") {
    const operation = c.type === "content-job-template" ? applyJobPracticeTemplate(t, u, c, now) : applyWorkspaceContentCommand(t, u, c, now);
    return operation.then((next) => {
      finishAccess(next, now);
      next.activity ??= [];
      if (!["content-retire", "content-archive"].includes(c.type)) {
        const createdDraft = c.type === "content-job-template" ? next.content?.drafts.find((d) => !t.content?.drafts.some((previous) => previous.id === d.id)) : void 0;
        next.activity.push({ id: crypto.randomUUID(), actor: u.userId, actorName: String(m.name || "Workspace owner").slice(0, 80), action: c.type, createdAt: new Date(now).toISOString(), detail: c.type === "content-job-template" ? { draftId: createdDraft?.id, templateId: c.templateId } : { draftId: c.draftId, publicationId: c.publicationId } });
      }
      return next;
    }).catch((error) => {
      if (error instanceof AuthoringError || error instanceof JobTemplateError) throw new RuleError(error.message, error.status);
      throw error;
    });
  }
  let registryContext;
  const contentContext = () => registryContext ??= { registry: workspaceRegistry(t), allowedScopes: ["global", t.id] };
  if (isLearningPlanCommand(c)) {
    const l = learner(t, u);
    l.state.learningPlan = applyOwnPlan(l.state, c, planOptions(now, { memberActive: m.active, canLearn: m.roles.includes("learner"), cohorts: t.cohorts }, contentContext()));
    return finishAccess(t, now);
  }
  if (applyNetworkCommand(t, m, c, now, boardAccess)) return finishAccess(t, now);
  try {
    if (applySupportCommand(t, u.userId, c, now)) return finishAccess(t, now);
  } catch (e) {
    if (e instanceof SupportRuleError) throw new RuleError(e.message, e.status);
    throw e;
  }
  switch (c.type) {
    case "invite": {
      requireRole(m, "admin");
      exact8(c, ["email", "roles", "scopes", "tokenHash"]);
      if (t.invites.length >= 200) throw new RuleError("Invitation limit reached for this pilot.", 409);
      const recipient = email(c.email), r = roles(c.roles), s = scopes2(t, c.scopes);
      if (t.members.some((m2) => m2.active && m2.email === recipient)) throw new RuleError("This account is already a member. Use membership settings to change its roles.", 409);
      if (t.invites.some((i) => i.email === recipient && i.status === "active" && Date.parse(i.expiresAt) > Date.parse(now))) throw new RuleError("An active invitation already exists. Revoke it before creating a replacement.", 409);
      if (typeof c.tokenHash !== "string" || !/^[a-f0-9]{64}$/.test(c.tokenHash)) throw new RuleError("A secure invitation token is required.");
      if (t.invites.some((i) => i.tokenHash === c.tokenHash)) throw new RuleError("This invitation token was already used. Generate a new link.", 409);
      t.invites.push({ id: crypto.randomUUID(), email: recipient, roles: r, scopes: s, tokenHash: c.tokenHash, status: "active", createdBy: u.userId, createdAt: now, expiresAt: new Date(Date.parse(now) + 7 * 864e5).toISOString() });
      break;
    }
    case "revoke-invite": {
      requireRole(m, "admin");
      exact8(c, ["inviteId"]);
      const i = t.invites.find((i2) => i2.id === c.inviteId);
      if (!i) throw new RuleError("Invitation not found.", 404);
      if (i.status !== "active") throw new RuleError("This invitation is no longer active.", 409);
      i.status = "revoked";
      break;
    }
    case "member": {
      requireRole(m, "admin");
      exact8(c, ["userId", "roles", "scopes", "active"]);
      const target2 = member3(t, c.userId, false), r = roles(c.roles), s = scopes2(t, c.scopes);
      if (typeof c.active !== "boolean") throw new RuleError("Choose an access state.");
      if (target2.active && target2.roles.includes("admin") && (!c.active || !r.includes("admin")) && t.members.filter((x) => x.active && x.roles.includes("admin")).length === 1) throw new RuleError("Keep at least one active workspace owner.", 409);
      Object.assign(target2, { roles: r, scopes: s, active: c.active });
      if (!target2.active || !target2.roles.includes("admin")) for (const i of t.invites.filter((i2) => i2.createdBy === target2.userId && i2.status === "active")) i.status = "revoked";
      t.assignments = t.assignments.filter((a) => {
        const q2 = pending(t).find((q3) => q3.targetId === a.targetId && q3.kind === a.kind);
        return !q2 || eligible2(t, t.members.find((x) => x.userId === a.staffId), q2);
      });
      break;
    }
    case "cohort-create": {
      requireRole(m, "admin");
      exact8(c, ["title", "programId", "capacity", "contentRef"]);
      let ref3, snapshot;
      try {
        ref3 = c.contentRef ?? currentRef(c.programId);
        if (ref3.programId !== c.programId) throw new RuleError("Choose the matching publication reference.", 409);
        snapshot = requireAvailablePublication(t, ref3, now);
      } catch (e) {
        if (e instanceof AuthoringError || e instanceof ContentResolutionError) throw new RuleError(e.message, e.status);
        throw e;
      }
      const p = snapshot.program;
      if (!Number.isInteger(c.capacity) || c.capacity < 1 || c.capacity > 100) throw new RuleError("Set a capacity between 1 and 100.");
      if (t.cohorts.length >= 20) throw new RuleError("This pilot supports 20 cohorts per workspace.", 409);
      t.cohorts.push({ id: crypto.randomUUID(), title: txt(c.title, "Cohort name", 3, 100), programId: p.id, version: ref3.versionId, contentRef: ref3, capacity: c.capacity, status: "open", createdAt: now });
      break;
    }
    case "cohort-status": {
      requireRole(m, "admin");
      exact8(c, ["cohortId", "status"]);
      const x = cohort(t, c.cohortId);
      if (!["open", "paused", "closed"].includes(c.status)) throw new RuleError("Choose an existing cohort state.");
      x.status = c.status;
      break;
    }
    case "assign": {
      requireRole(m, "admin");
      exact8(c, ["kind", "targetId", "staffId"]);
      const q2 = pending(t).find((q3) => q3.kind === c.kind && q3.targetId === c.targetId);
      if (!q2) throw new RuleError("Pending review not found.", 404);
      const staff = member3(t, c.staffId);
      if (!eligible2(t, staff, q2)) throw new RuleError("Assign a scoped staff member who is independent of the learner and original assessor.", 403);
      t.assignments = t.assignments.filter((a) => !(a.kind === q2.kind && a.targetId === q2.targetId));
      t.assignments.push({ id: crypto.randomUUID(), kind: q2.kind, targetId: q2.targetId, staffId: staff.userId, assignedBy: u.userId, assignedAt: now });
      break;
    }
    case "assess":
    case "resolve": {
      exact8(c, ["enrollmentId", "learnerId", "attemptId", "appealId", "scores", "gates", "notes", "feedback"]);
      const { l, e, c: co } = target(t, c.learnerId, c.enrollmentId), kind = c.type === "resolve" ? "appeal" : "assessment", targetId = c.type === "resolve" ? c.appealId : c.attemptId, q2 = pending(t).find((q3) => q3.kind === kind && q3.targetId === targetId && q3.enrollmentId === e.id && q3.learnerId === l.userId);
      if (u.userId === l.userId) throw new RuleError("A learner cannot assess or resolve their own evidence.", 403);
      if (c.type === "resolve" && e.attempts.find((a) => a.id === e.appeals.find((ap) => ap.id === c.appealId)?.attemptId)?.decision?.actor === u.userId) throw new RuleError("The original assessor cannot resolve this appeal.", 403);
      if (!q2 || !t.assignments.some((a) => a.kind === kind && a.targetId === targetId && a.staffId === u.userId)) throw new RuleError("This review is not assigned to your account.", 404);
      if (!eligible2(t, m, q2)) throw new RuleError("Your current scoped role does not permit this review.", 403);
      if (co.status === "paused") throw new RuleError("This cohort is paused for content review.", 409);
      l.state = applyCommand(l.state, c, now, { userId: u.userId, name: m.name, workspaceId: t.id, workspaceName: t.name }, void 0, contentContext());
      break;
    }
    case "post": {
      exact8(c, ["cohortId", "title", "body"]);
      const co = cohort(t, c.cohortId);
      if (!boardAccess(t, m, co.id)) throw new RuleError("This cohort discussion is unavailable.", 404);
      if (co.status === "paused") throw new RuleError("This cohort is paused.", 409);
      if (t.posts.length >= 500) throw new RuleError("Pilot discussion limit reached.", 409);
      t.posts.unshift({ id: crypto.randomUUID(), scope: co.programId, cohortId: co.id, title: txt(c.title, "Title", 5, 140), body: txt(c.body, "Discussion", 20, 3e3), author: m.name, authorId: u.userId, status: "pending", createdAt: now, replies: [] });
      break;
    }
    case "reply":
    case "report":
    case "moderate": {
      const p = t.posts.find((p2) => p2.id === c.postId);
      if (!p || !boardAccess(t, m, p.cohortId)) throw new RuleError("Discussion not found.", 404);
      if (c.type === "moderate") {
        exact8(c, ["postId", "replyId", "status", "reason"]);
        requireRole(m, "moderator", p.cohortId);
        if (!["visible", "hidden"].includes(c.status)) throw new RuleError("Choose publish or hide.");
        const reason = txt(c.reason, "Moderation reason", 10, 1e3), previousStatus = c.replyId ? p.replies.find((r) => r.id === c.replyId)?.status : p.status;
        t.moderation ??= [];
        t.moderation.push({ id: crypto.randomUUID(), postId: p.id, replyId: c.replyId || null, cohortId: p.cohortId, actor: u.userId, actorName: m.name, reason, previousStatus, status: c.status, createdAt: now });
        if (c.replyId) {
          const r = p.replies.find((r2) => r2.id === c.replyId);
          if (!r) throw new RuleError("Reply not found.", 404);
          r.status = c.status;
        } else {
          p.status = c.status;
          for (const r of t.reports.filter((r2) => r2.postId === p.id)) r.status = "resolved";
        }
        break;
      }
      if (p.status !== "visible") throw new RuleError("This discussion is not available.", 404);
      if (c.type === "reply") {
        exact8(c, ["postId", "body"]);
        if (cohort(t, p.cohortId).status === "paused") throw new RuleError("This cohort is paused.", 409);
        if (p.replies.length >= 50) throw new RuleError("Reply limit reached.");
        p.replies.push({ id: crypto.randomUUID(), body: txt(c.body, "Reply", 10, 1500), author: m.name, authorId: u.userId, status: "pending", createdAt: now });
      } else {
        exact8(c, ["postId", "reason"]);
        if (t.reports.some((r) => r.postId === p.id && r.reporterId === u.userId && r.status === "open")) throw new RuleError("Your report is already awaiting review.", 409);
        t.reports.push({ id: crypto.randomUUID(), postId: p.id, reporterId: u.userId, reason: txt(c.reason, "Report reason", 10, 1e3), status: "open", createdAt: now });
      }
      break;
    }
    case "enroll": {
      exact8(c, ["programId", "cohortId"]);
      requireRole(m, "learner");
      const co = cohort(t, c.cohortId);
      if (co.programId !== c.programId) throw new RuleError("Choose the cohort for this pathway.");
      let ref3;
      try {
        resolvePinnedContent(co, contentContext().allowedScopes, contentContext().registry);
        ref3 = pinnedRef(co);
      } catch (e2) {
        if (e2 instanceof ContentResolutionError) throw new RuleError(e2.message, e2.status);
        throw e2;
      }
      const l = learner(t, u), existing = l.state.enrollments.find((e2) => e2.programId === co.programId && !e2.withdrawn);
      if (existing) {
        if (existing.cohortId !== co.id) throw new RuleError("Finish or withdraw the existing enrollment before joining another cohort for this pathway.", 409);
        break;
      }
      try {
        requireAvailablePublication(t, ref3, now);
      } catch (e2) {
        if (e2 instanceof AuthoringError || e2 instanceof ContentResolutionError) throw new RuleError(e2.message, e2.status);
        throw e2;
      }
      if (co.status !== "open") throw new RuleError("This cohort is not open for enrollment.", 409);
      if (seats(t, co.id) >= co.capacity) throw new RuleError("This cohort just filled. Choose another offering or ask the owner for support.", 409);
      l.state = applyCommand(l.state, c, now, void 0, ref3, contentContext());
      const e = l.state.enrollments.at(-1);
      e.cohortId = co.id;
      e.claimPolicy = "Draft content \xB7 authenticated assigned review \xB7 nonaccredited";
      break;
    }
    case "learning-access-preferences":
    case "profile":
    case "lesson-draft":
    case "lesson":
    case "draft":
    case "submit":
    case "appeal":
    case "share":
    case "withdraw":
    case "followup":
    case "interest": {
      if (Object.hasOwn(c, "learnerId") || Object.hasOwn(c, "actor")) throw new RuleError("Use only your own learning actions.", 400);
      const l = learner(t, u);
      if (c.enrollmentId) {
        const { c: co } = target(t, u.userId, c.enrollmentId);
        if (co.status === "paused" && !["appeal", "share", "withdraw", "followup"].includes(c.type)) throw new RuleError("This cohort is paused. Your saved work is retained.", 409);
      }
      if (["lesson-draft", "lesson", "draft", "submit"].includes(c.type)) requireRole(m, "learner");
      l.state = applyCommand(l.state, c, now, void 0, void 0, contentContext());
      if (c.type === "profile") m.name = l.state.profile.name;
      break;
    }
    default:
      throw new RuleError("This action belongs in your personal practice lab or is unavailable in shared workspaces.", 400);
  }
  finishAccess(t, now);
  if (["invite", "revoke-invite", "member", "cohort-create", "cohort-status", "assign"].includes(c.type)) {
    t.activity ??= [];
    t.activity.push({ id: crypto.randomUUID(), actor: u.userId, actorName: m.name, action: c.type, createdAt: now, detail: c.type === "invite" ? { inviteId: t.invites.at(-1).id, roles: c.roles, scopes: c.scopes } : c.type === "member" ? { userId: c.userId, roles: c.roles, scopes: c.scopes, active: c.active } : c.type === "assign" ? { kind: c.kind, targetId: c.targetId, staffId: c.staffId } : c.type === "revoke-invite" ? { inviteId: c.inviteId } : c.type === "cohort-status" ? { cohortId: c.cohortId, status: c.status } : { cohortId: t.cohorts.at(-1).id } });
  }
  return t;
}
function projectTeam(t, u) {
  const m = member3(t, u.userId, false), own = t.learners.find((l) => l.userId === u.userId), state = copy2(own?.state ?? freshWorkspace());
  if (!own) {
    state.profile.name = label(u);
    state.profile.context = t.context;
  }
  const admin = m.active && m.roles.includes("admin"), qs = pending(t);
  state.paused = t.cohorts.filter((c) => c.status === "paused" && state.enrollments.some((e) => e.cohortId === c.id)).map((c) => c.programId);
  const visibleCohorts = t.cohorts.filter((c) => m.active ? m.roles.includes("learner") || boardAccess(t, m, c.id) : state.enrollments.some((e) => e.cohortId === c.id));
  const isMod = (cid) => m.active && m.roles.includes("moderator") && m.scopes.includes(cid);
  state.posts = m.active ? t.posts.filter((p) => boardAccess(t, m, p.cohortId) && (p.status === "visible" || p.authorId === u.userId || isMod(p.cohortId))).map((p) => {
    const x = copy2(p);
    delete x.authorId;
    x.replies = x.replies.filter((r) => r.status === "visible" || r.authorId === u.userId || isMod(p.cohortId)).map((r) => {
      const z = copy2(r);
      delete z.authorId;
      return z;
    });
    return x;
  }) : [];
  state.reports = m.active ? t.reports.filter((r) => {
    const p = t.posts.find((p2) => p2.id === r.postId);
    return p && isMod(p.cohortId);
  }).map((r) => ({ id: r.id, postId: r.postId, reason: r.reason, status: r.status, createdAt: r.createdAt })) : [];
  const assigned = qs.filter((q2) => eligible2(t, m, q2) && t.assignments.some((a) => a.kind === q2.kind && a.targetId === q2.targetId && a.staffId === u.userId)).map((q2) => {
    const { e } = target(t, q2.learnerId, q2.enrollmentId), ap = q2.kind === "appeal" ? e.appeals.find((ap2) => ap2.id === q2.targetId) : void 0, a = e.attempts.find((a2) => a2.id === (ap?.attemptId ?? q2.targetId));
    return { ...q2, learnerName: t.members.find((m2) => m2.userId === q2.learnerId)?.name, e: { id: e.id, learnerId: q2.learnerId, programId: e.programId, version: e.version, ...e.contentRef ? { contentRef: copy2(e.contentRef) } : {}, cohortId: e.cohortId }, a: copy2(a), ...ap ? { ap: copy2(ap) } : {} };
  });
  const summaries = t.learners.flatMap((l) => l.state.enrollments.filter((e) => admin || m.active && m.roles.includes("facilitator") && m.scopes.includes(e.cohortId)).map((e) => ({ learnerId: l.userId, learnerName: t.members.find((m2) => m2.userId === l.userId)?.name, cohortId: e.cohortId, programId: e.programId, completedLessons: e.completed.length, practiceRecordStatus: e.record?.status ?? null, hasOpenAppeal: !e.withdrawn && e.appeals.some((ap) => ap.status === "open"), hasPendingAssessment: !e.withdrawn && e.attempts.some((a) => !a.decision), status: e.withdrawn ? "Withdrawn" : e.record?.status === "active" ? "Practice completed" : e.appeals.some((ap) => ap.status === "open") ? "Appeal pending" : e.attempts.some((a) => !a.decision) ? "Review pending" : "Learning" })));
  const result = { state, team: { currentUserId: u.userId, id: t.id, name: t.name, purpose: t.purpose, context: t.context, roles: m.active ? m.roles : [], active: m.active, support: projectSupport(t, u.userId), network: projectNetwork(t, m, boardAccess), cohorts: visibleCohorts.map((c) => ({ ...c, ...cohortContentAvailability(t, c), occupied: seats(t, c.id), boardAccess: boardAccess(t, m, c.id), canModerate: isMod(c.id), canHost: m.active && (admin || m.roles.includes("facilitator") && m.scopes.includes(c.id)) })), moderationHistory: (t.moderation ?? []).filter((x) => isMod(x.cohortId)), ...admin ? { activity: t.activity ?? [], members: t.members.map((m2) => ({ ...m2 })), invites: t.invites.map(({ tokenHash, ...i }) => i), pending: qs.map((q2) => ({ ...q2, learnerName: t.members.find((m2) => m2.userId === q2.learnerId)?.name, assignedTo: t.assignments.find((a) => a.kind === q2.kind && a.targetId === q2.targetId)?.staffId, eligibleStaff: t.members.filter((m2) => eligible2(t, m2, q2)).map((m2) => ({ userId: m2.userId, name: m2.name })) })) } : {}, assigned, summaries } };
  const neededRefs = [];
  for (const record2 of [...result.state.enrollments, ...result.team.cohorts, ...result.team.assigned.map((q2) => q2.e)]) {
    try {
      const ref3 = pinnedRef(record2);
      if (ref3.scope === "global" || ref3.scope === t.id) neededRefs.push(ref3);
    } catch (e) {
      if (!(e instanceof ContentResolutionError)) throw e;
    }
  }
  const content = projectWorkspaceContent(t, u, neededRefs);
  return { ...result, contentVersions: content.versions, team: { ...result.team, ...admin ? { content: { drafts: content.drafts, publications: content.publications } } : {} } };
}
function cohortContentAvailability(t, c) {
  try {
    requireAvailablePublication(t, pinnedRef(c));
    return { contentOpen: true, contentNotice: null };
  } catch (e) {
    if (e instanceof AuthoringError || e instanceof ContentResolutionError) return { contentOpen: false, contentNotice: e.message };
    throw e;
  }
}

// ../../../../work/aplyd-academy/lib/academy-record-service.ts
var plain5 = (v) => !!v && typeof v === "object" && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
var id2 = (v) => typeof v === "string" && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,119}$/.test(v);
var subject = (v) => typeof v === "string" && v.trim() === v && v.length > 0 && v.length <= 300 && !/[\u0000-\u001f\u007f]/.test(v);
var revision = (v) => Number.isSafeInteger(v) && Number(v) >= 0;
var canonicalTime2 = (v) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(v) && Number.isFinite(Date.parse(v)) && new Date(v).toISOString() === v;
function parseRecordCheckRequest(value) {
  if (!plain5(value) || Object.keys(value).some((k) => !["workspaceId", "sourceRevision", "recordId", "decisionId"].includes(k)) || !Object.hasOwn(value, "workspaceId") || !Object.hasOwn(value, "sourceRevision") || !revision(value.sourceRevision) || value.workspaceId !== null && (typeof value.workspaceId !== "string" || !/^tw-[a-z0-9-]{20,80}$/i.test(value.workspaceId)) || Object.hasOwn(value, "recordId") === Object.hasOwn(value, "decisionId")) throw new RecordCheckError("Choose an exact private record and current saved revision.", 400);
  const own = Object.hasOwn(value, "recordId"), reference = value[own ? "recordId" : "decisionId"];
  if (!id2(reference) || !own && value.workspaceId === null) throw new RecordCheckError("Choose an exact private record or currently assigned shared appeal.", 400);
  return Object.freeze({ workspaceId: value.workspaceId, sourceRevision: value.sourceRevision, target: Object.freeze({ kind: own ? "record" : "decision", id: reference }) });
}
function assertRecordRevision(actual, expected) {
  if (!revision(actual)) throw new RecordCheckError("The saved learning revision is temporarily unavailable.", 503);
  if (actual !== expected) throw new RecordCheckError("Your learning space changed. Refresh before checking this record.", 409);
}
async function checkSavedPracticeRecord(input) {
  const { user, request: request2, row, checkedAt } = input;
  if (!subject(user.userId) || !canonicalTime2(checkedAt)) throw new RecordCheckError("The authenticated record check is temporarily unavailable.", 503);
  let result;
  if (request2.workspaceId === null) {
    assertRecordRevision(row?.revision ?? 0, request2.sourceRevision);
    if (request2.target.kind !== "record") throw new RecordCheckError("This assigned decision is unavailable for your account.", 404);
    const state = row ? JSON.parse(row.data) : freshWorkspace();
    result = await lookupOwnPracticeRecord(state, { recordId: request2.target.id }, { actorId: user.userId, learnerId: user.userId, space: "personal", workspaceId: null, revision: request2.sourceRevision, checkedAt, content: { registry: curriculumRegistry, allowedScopes: ["global"] } });
  } else {
    if (!row) throw new RecordCheckError("This private learning space is unavailable for your account.", 404);
    const team = JSON.parse(row.data);
    if (!plain5(team) || team.id !== request2.workspaceId) throw new RecordCheckError("The saved learning space needs inspection.", 503);
    const projection = projectTeam(team, user);
    assertRecordRevision(row.revision, request2.sourceRevision);
    const content = { registry: workspaceRegistry(team), allowedScopes: ["global", team.id] };
    const context = { actorId: user.userId, learnerId: user.userId, space: "shared", workspaceId: team.id, revision: request2.sourceRevision, checkedAt, content };
    if (request2.target.kind === "record") result = await lookupOwnPracticeRecord(projection.state, { recordId: request2.target.id }, context);
    else {
      const matches = projection.team.assigned.filter((q2) => q2.kind === "appeal" && q2.ap?.status === "open" && q2.a?.decision?.id === request2.target.id);
      if (matches.length !== 1 || !subject(matches[0].e?.learnerId)) throw new RecordCheckError("This assigned decision is unavailable for your account.", 404);
      result = await lookupAssignedDecision(projection, { decisionId: request2.target.id }, { ...context, learnerId: matches[0].e.learnerId });
    }
  }
  return deepFreeze({ format: "aplyd-academy-private-record-check", formatVersion: 1, currentUserId: user.userId, workspaceId: request2.workspaceId, sourceRevision: request2.sourceRevision, checkedAt, target: request2.target, result });
}

// ../../../../work/aplyd-academy/lib/academy-record-response.ts
var RecordResponseError = class extends Error {
  constructor() {
    super("The private record-check response could not be verified. Refresh saved progress before checking again.");
    this.name = "RecordResponseError";
  }
};
var reject = () => {
  throw new RecordResponseError();
};
var plain6 = (v) => !!v && typeof v === "object" && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
var exact9 = (v, keys) => plain6(v) && Object.keys(v).length === keys.length && keys.every((k) => Object.hasOwn(v, k));
var bounded2 = (v, max = 300) => typeof v === "string" && v.trim() === v && v.length > 0 && v.length <= max && !/[\u0000-\u001f\u007f]/.test(v);
var id3 = (v) => bounded2(v, 120) && /^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(v);
var hex = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v);
var iso2 = (v) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(v) && Number.isFinite(Date.parse(v)) && new Date(v).toISOString() === v;
var rev = (v) => Number.isSafeInteger(v) && Number(v) >= 0;
var words = (v, maxCount, maxLength) => Array.isArray(v) && v.length <= maxCount && v.every((x) => bounded2(x, maxLength));
var ownLimits = ["Private authenticated saved-state check only", "Personal sample reviews remain sample when space is personal", "No raw evidence, drafts, private feedback, email or support notes in this snapshot", "Recheck current saved state after an appeal or new decision"];
var assignedLimits = ["Only the original decision already present in the current assigned appeal is checked", "No current practice-record status or other learner history is disclosed", "No raw evidence, notes, feedback, email or public bearer URL", "Current assignment/role must be rechecked by the API on each request"];
var equivalent = (a, b) => JSON.stringify(a) === JSON.stringify(b);
var sameDecision = (a, b) => ["decisionId", "kind", "attemptId", "appealId", "actorRef", "actorDisplay", "decidedAt", "mode", "passed"].every((k) => a[k] === b[k]);
function ref2(value, expected) {
  let actual;
  try {
    actual = contentRef(value);
  } catch {
    return reject();
  }
  if (actual.scope !== "global" && actual.scope !== expected.workspaceId || contentKey(actual) !== contentKey(expected.target.contentRef)) return reject();
  return actual;
}
function decision2(value, expected, checkedAt) {
  if (!exact9(value, ["decisionId", "kind", "attemptId", "appealId", "actorRef", "actorDisplay", "decidedAt", "mode", "passed"]) || !id3(value.decisionId) || !["assessment", "appeal"].includes(value.kind) || !id3(value.attemptId) || (value.kind === "assessment" ? value.appealId !== null : !id3(value.appealId)) || !bounded2(value.actorRef) || !bounded2(value.actorDisplay, 80) || !iso2(value.decidedAt) || Date.parse(value.decidedAt) > Date.parse(checkedAt) || typeof value.passed !== "boolean") return reject();
  const personal = expected.workspaceId === null;
  const expectedMode = personal ? value.kind === "assessment" ? "manual sample-assessor review" : "manual sample-reviewer appeal" : value.kind === "assessment" ? "authenticated assigned assessment" : "authenticated independent appeal";
  if (value.mode !== expectedMode) return reject();
  if (personal && (value.actorRef !== (value.kind === "assessment" ? "assessor-a" : "reviewer-b") || value.actorDisplay !== (value.kind === "assessment" ? "Sample Assessor A" : "Sample Reviewer B"))) return reject();
  if (!personal && (value.actorRef === expected.accountId || expected.target.kind === "decision" && value.actorRef === expected.target.learnerId)) return reject();
  return value;
}
function ownSnapshot(value, e, checkedAt) {
  const keys = ["schemaVersion", "kind", "recordId", "enrollmentId", "space", "workspaceId", "contentRef", "contentLanguage", "contentFingerprint", "title", "claim", "exclusions", "classification", "issuerDisplay", "issuerAuthority", "status", "hasOpenAppeal", "hasPendingAssessment", "issuedAt", "checkedAt", "asOfRevision", "firstPassingDecision", "effectiveDecision", "decisionHistory", "limitations"];
  if (!exact9(value, keys) || e.target.kind !== "record" || value.schemaVersion !== 1 || value.kind !== "private-practice-record-status" || value.recordId !== e.target.id || value.enrollmentId !== e.target.enrollmentId || value.workspaceId !== e.workspaceId || value.space !== (e.workspaceId === null ? "personal" : "shared") || !bounded2(value.contentLanguage, 50) || value.contentFingerprint !== e.target.contentFingerprint || !bounded2(value.title, 300) || !bounded2(value.claim, 3e3) || !words(value.exclusions, 30, 1e3) || value.classification !== "Nonaccredited practice record" || !bounded2(value.issuerDisplay, 200) || value.issuerAuthority !== "Workspace display label only; no recognised issuer authority asserted" || !["active", "suspended"].includes(value.status) || typeof value.hasOpenAppeal !== "boolean" || typeof value.hasPendingAssessment !== "boolean" || value.hasOpenAppeal && value.hasPendingAssessment || value.status === "active" && value.hasPendingAssessment || !iso2(value.issuedAt) || value.checkedAt !== checkedAt || value.asOfRevision !== e.sourceRevision || !Array.isArray(value.decisionHistory) || value.decisionHistory.length < 1 || value.decisionHistory.length > 6 || !equivalent(value.limitations, ownLimits)) return reject();
  ref2(value.contentRef, e);
  const decisions = value.decisionHistory.map((d) => decision2(d, e, checkedAt));
  const unique = new Set(decisions.map((d) => d.decisionId));
  if (unique.size !== decisions.length) return reject();
  for (let i = 1; i < decisions.length; i++) if (Date.parse(decisions[i].decidedAt) < Date.parse(decisions[i - 1].decidedAt)) return reject();
  const first = decisions.find((d) => d.passed), last = decisions.at(-1);
  const firstDeclared = decision2(value.firstPassingDecision, e, checkedAt), effectiveDeclared = decision2(value.effectiveDecision, e, checkedAt);
  if (!first || !sameDecision(first, firstDeclared) || !sameDecision(last, effectiveDeclared) || value.issuedAt !== first.decidedAt || value.status !== (last.passed ? "active" : "suspended")) return reject();
  for (const d of decisions) {
    if (d.kind === "appeal") {
      const original = decisions.find((x) => x.kind === "assessment" && x.attemptId === d.attemptId);
      if (!original || original.actorRef === d.actorRef || Date.parse(d.decidedAt) < Date.parse(original.decidedAt)) return reject();
    }
  }
  return value;
}
function assignedSnapshot(value, e, checkedAt) {
  if (!exact9(value, ["schemaVersion", "kind", "workspaceId", "enrollmentId", "contentRef", "contentFingerprint", "classification", "decision", "openAssignedAppealId", "checkedAt", "asOfRevision", "limitations"]) || e.target.kind !== "decision" || e.workspaceId === null || value.schemaVersion !== 1 || value.kind !== "private-assigned-original-decision" || value.workspaceId !== e.workspaceId || value.enrollmentId !== e.target.enrollmentId || value.openAssignedAppealId !== e.target.appealId || value.contentFingerprint !== e.target.contentFingerprint || value.classification !== "Nonaccredited practice decision" || value.checkedAt !== checkedAt || value.asOfRevision !== e.sourceRevision || !equivalent(value.limitations, assignedLimits)) return reject();
  ref2(value.contentRef, e);
  const original = decision2(value.decision, e, checkedAt);
  if (original.kind !== "assessment" || original.decisionId !== e.target.id) return reject();
  return value;
}
async function acceptRecordCheckEnvelope(value, expected) {
  if (!bounded2(expected.accountId) || !rev(expected.sourceRevision) || !id3(expected.target.id) || !id3(expected.target.enrollmentId) || !hex(expected.target.contentFingerprint) || expected.workspaceId !== null && !/^tw-[a-z0-9-]{20,80}$/i.test(expected.workspaceId) || expected.target.kind === "decision" && (!id3(expected.target.appealId) || !bounded2(expected.target.learnerId) || expected.workspaceId === null)) return reject();
  if (!exact9(value, ["format", "formatVersion", "currentUserId", "workspaceId", "sourceRevision", "checkedAt", "target", "result"]) || value.format !== "aplyd-academy-private-record-check" || value.formatVersion !== 1 || value.currentUserId !== expected.accountId || value.workspaceId !== expected.workspaceId || value.sourceRevision !== expected.sourceRevision || !iso2(value.checkedAt) || !exact9(value.target, ["kind", "id"]) || value.target.kind !== expected.target.kind || value.target.id !== expected.target.id || !plain6(value.result)) return reject();
  try {
    contentRef(expected.target.contentRef);
  } catch {
    return reject();
  }
  const result = value.result;
  if (result.outcome === "unavailable") {
    if (!exact9(result, ["outcome", "message"]) || !bounded2(result.message, 1e3)) return reject();
  } else {
    if (!exact9(result, ["outcome", "snapshot", "integrity"]) || result.outcome !== "checked" || !exact9(result.integrity, ["algorithm", "checksum", "meaning"]) || result.integrity.algorithm !== "SHA-256" || !hex(result.integrity.checksum) || result.integrity.meaning !== checksumMeaning) return reject();
    const snapshot = expected.target.kind === "record" ? ownSnapshot(result.snapshot, expected, value.checkedAt) : assignedSnapshot(result.snapshot, expected, value.checkedAt);
    if (await snapshotChecksum(snapshot) !== result.integrity.checksum) return reject();
  }
  return deepFreeze(structuredClone(value));
}

// ../../../../work/aplyd-academy/app/academy-record-client.ts
var RecordClientError = class extends Error {
  constructor(message, status, unverified = false, stale = false) {
    super(message);
    this.status = status;
    this.unverified = unverified;
    this.stale = stale;
    this.name = "RecordClientError";
  }
};
var subject2 = (v) => typeof v === "string" && v.trim() === v && v.length > 0 && v.length <= 300 && !/[\u0000-\u001f\u007f]/.test(v);
var plain7 = (v) => !!v && typeof v === "object" && !Array.isArray(v);
var stamp = (c) => JSON.stringify([c.accountId, c.workspace, c.authorityEpoch, c.sourceRevision, c.readGeneration, c.mounted, c.loading, c.saving]);
function createPrivateRecordChecker(options) {
  return async (target2, signal) => {
    const captured = options.getContext(), scope = stamp(captured);
    const current = () => !signal.aborted && stamp(options.getContext()) === scope;
    const requireCurrent = () => {
      if (!current()) throw new RecordClientError("This private check was cancelled because the learning space changed.", 409, false, true);
    };
    requireCurrent();
    if (!captured.mounted || !subject2(captured.accountId) || captured.loading || captured.saving || !Number.isSafeInteger(captured.sourceRevision) || captured.sourceRevision < 0) throw new RecordClientError("Refresh saved progress before checking your private record.", 409);
    if (!plain7(target2) || Object.keys(target2).length !== 1 || Object.hasOwn(target2, "recordId") === Object.hasOwn(target2, "decisionId")) throw new RecordClientError("Choose an exact private record or current assigned appeal.", 400);
    const workspaceId = captured.workspace === "lab" ? null : captured.workspace, own = Object.hasOwn(target2, "recordId"), id4 = own ? target2.recordId : target2.decisionId;
    let enrollment2, appeal;
    if (own) {
      const matches = captured.state?.enrollments?.filter((e) => e?.record?.id === id4);
      if (!Array.isArray(matches) || matches.length !== 1) throw new RecordClientError("This record is unavailable in your own saved learning.", 404);
      enrollment2 = matches[0];
    } else {
      if (workspaceId === null || captured.team?.active !== true || captured.team?.id !== workspaceId || captured.team?.currentUserId !== captured.accountId) throw new RecordClientError("This original decision is not in a current assigned appeal.", 404);
      const matches = captured.team.assigned?.filter((q2) => q2?.kind === "appeal" && q2.ap?.status === "open" && q2.a?.decision?.id === id4 && q2.targetId === q2.ap?.id);
      if (!Array.isArray(matches) || matches.length !== 1) throw new RecordClientError("This original decision is not in a current assigned appeal.", 404);
      enrollment2 = matches[0].e;
      appeal = matches[0].ap;
    }
    const pinned2 = tryResolvePinnedContent(enrollment2, captured.content.allowedScopes, captured.content.registry);
    if (!pinned2.available) throw new RecordClientError("The exact saved course is unavailable. Keep your own record export for support.", 409);
    const fingerprint = await snapshotChecksum(pinned2.snapshot.program);
    requireCurrent();
    const expectation = { accountId: captured.accountId, workspaceId, sourceRevision: captured.sourceRevision, target: own ? { kind: "record", id: id4, enrollmentId: enrollment2.id, contentRef: pinnedRef(enrollment2), contentFingerprint: fingerprint } : { kind: "decision", id: id4, enrollmentId: enrollment2.id, contentRef: pinnedRef(enrollment2), contentFingerprint: fingerprint, appealId: appeal.id, learnerId: enrollment2.learnerId } };
    const response = await (options.transport ?? fetch)("/api/academy/records/check", { method: "POST", credentials: "same-origin", cache: "no-store", signal, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ workspaceId, sourceRevision: captured.sourceRevision, [own ? "recordId" : "decisionId"]: id4 }) });
    requireCurrent();
    let data;
    try {
      data = await response.json();
    } catch {
      requireCurrent();
      const unverified = response.ok || [401, 403, 404].includes(response.status);
      if (unverified) options.onUnverifiedAccess(response.status);
      throw new RecordClientError("The private record-check response could not be read. Refresh saved progress before checking again.", response.status, unverified);
    }
    requireCurrent();
    if (!response.ok) {
      const message = plain7(data) && typeof data.error === "string" && data.error.length <= 1e3 ? data.error : "This private record check is unavailable. Refresh saved progress and try again.";
      const unverified = [401, 403, 404].includes(response.status);
      if (unverified) options.onUnverifiedAccess(response.status);
      if (response.status === 409) options.onRefreshRequired(message);
      throw new RecordClientError(message, response.status, unverified);
    }
    try {
      const accepted = await acceptRecordCheckEnvelope(data, expectation);
      requireCurrent();
      return accepted.result;
    } catch (error) {
      requireCurrent();
      if (error instanceof RecordResponseError) {
        options.onUnverifiedAccess(response.status);
        throw new RecordClientError(error.message, response.status, true);
      }
      throw error;
    }
  };
}
export {
  LEGACY_SOURCE_SHA256,
  RecordCheckError,
  RecordClientError,
  RecordResponseError,
  acceptRecordCheckEnvelope,
  applyCommand,
  applyTeamCommand,
  assertRecordRevision,
  checkSavedPracticeRecord,
  checksumMeaning,
  createCurriculumRegistry,
  createPrivateRecordChecker,
  createTeam,
  currentRef,
  curriculumRegistry,
  freshWorkspace,
  lookupAssignedDecision,
  lookupOwnPracticeRecord,
  parseRecordCheckRequest,
  programs,
  projectTeam,
  requireAvailablePublication,
  resolvePinnedContent,
  snapshotChecksum,
  workspaceRegistry
};
