import assert from 'node:assert/strict';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
export const here=dirname(fileURLToPath(import.meta.url));
export const app=resolve(process.env.ACADEMY_APP_PATH??here+'/../../../../work/aplyd-academy');
process.env.ACADEMY_APP_PATH=app;
export const out=resolve(process.env.ACADEMY_RECORD_QA_OUT??here+'/evidence');
mkdirSync(out,{recursive:true});
export const local=await import(pathToFileURL(app+'/tests/local-qa.mjs'));
export const {base,headers,identity,current,action,post,get,success,curriculum,nonce}=local;
export const sourceFiles=['lib/academy-record-check.ts','lib/academy-record-service.ts','lib/academy-record-response.ts','app/academy-record-client.ts','app/academy-record-status.tsx','app/api/academy/records/check/route.ts','app/academy.tsx','app/academy-settings.tsx','app/academy-studio.tsx','app/academy-context.tsx','app/globals.css','lib/academy-curriculum.ts','lib/academy-engine.ts','lib/academy-teams.ts','lib/academy-authoring.ts','lib/curriculum.json','lib/curriculum-versions/0.1-review-draft.json'];
export const sourceHashes=()=>Object.fromEntries(sourceFiles.map(f=>[f,createHash('sha256').update(readFileSync(app+'/'+f)).digest('hex')]));
export function requireStable(){assert.ok(process.env.ACADEMY_QA_WORKER,'Set ACADEMY_QA_WORKER only after root confirms the CURRENT integrated Worker is stable.');}
export function save(name,value){writeFileSync(out+'/'+name,JSON.stringify(value,null,2)+'\n');}
export function canonical(value){if(value===null||typeof value!=='object')return JSON.stringify(value);return Array.isArray(value)?'['+value.map(canonical).join(',')+']':'{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}';}
export const checksum=value=>createHash('sha256').update(canonical(value)).digest('hex');
export const fields=program=>Object.fromEntries(program.practicalAssessment.submissionPrompts.map(f=>[f.id,'PRIVATE_RECORD_EVIDENCE fictional exact source checks and a permitted human approval route.']));
export const review=(program,passed=true)=>({scores:program.practicalAssessment.rubric.map(()=>4),gates:program.practicalAssessment.rubric.filter(r=>r.criticalGate).map((_,i)=>passed||i!==0),notes:program.practicalAssessment.rubric.map(()=> 'PRIVATE_RECORD_NOTES checked exact evidence and source references.'),feedback:'PRIVATE_RECORD_FEEDBACK fictional actionable reasoning against source and safety checks.'});
export const personalCurrent=user=>get(user,'/api/academy');
export async function personalAction(user,command){const x=success(await personalCurrent(user));const r=await fetch(base+'/api/academy',{method:'POST',headers:headers(user),body:JSON.stringify({revision:x.revision,actionId:crypto.randomUUID(),command})});return success({status:r.status,...await r.json()});}
export async function join(owner,id,user,roles,scopes=[]){const token=crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-','');success(await action(owner,id,{type:'invite',email:user.email,roles,scopes,token}));const preview=success(await get(user,'/api/teams?invite='+token));return success(await post(user,id,{type:'accept',token},preview.revision));}
export async function personalRecord(user,program=curriculum.pathways[1]){let x=await personalAction(user,{type:'enroll',programId:program.id}),e=x.state.enrollments.at(-1);for(const l of program.lessons)x=await personalAction(user,{type:'lesson',enrollmentId:e.id,lessonId:l.id,practice:'PRIVATE_RECORD_PRACTICE fictional exact source mapping and a human check.',answers:l.quiz.map(q=>q.correctOptionIndex)});x=await personalAction(user,{type:'submit',enrollmentId:e.id,confirmed:true,fields:fields(program)});e=x.state.enrollments.find(v=>v.id===e.id);return personalAction(user,{type:'assess',enrollmentId:e.id,attemptId:e.attempts.at(-1).id,actor:'assessor-a',...review(program)});}
export async function sharedRecord(owner,user,id,program,enrollmentId){let x=success(await current(user,id)),e=x.state.enrollments.find(v=>v.id===enrollmentId)||x.state.enrollments.find(v=>v.programId===program.id);for(const l of program.lessons)x=success(await action(user,id,{type:'lesson',enrollmentId:e.id,lessonId:l.id,practice:'PRIVATE_RECORD_SHARED_PRACTICE fictional exact checks and bounded human judgment.',answers:l.quiz.map(q=>q.correctOptionIndex)}));x=success(await action(user,id,{type:'submit',enrollmentId:e.id,confirmed:true,fields:fields(program)}));e=x.state.enrollments.find(v=>v.id===e.id);success(await action(owner,id,{type:'assign',kind:'assessment',targetId:e.attempts.at(-1).id,staffId:owner.id}));success(await action(owner,id,{type:'assess',learnerId:user.id,enrollmentId:e.id,attemptId:e.attempts.at(-1).id,...review(program)}));return success(await current(user,id));}
