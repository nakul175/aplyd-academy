import {readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url));
const app=resolve(process.env.ACADEMY_APP_PATH??resolve(here,'../../../work/aplyd-academy'));
const out=resolve(here,'runtime');mkdirSync(out,{recursive:true});
const esbuild=await import(pathToFileURL(resolve(app,'node_modules/esbuild/lib/main.js')));
const aliases={'@academy/curriculum':resolve(app,'lib/academy-curriculum.ts'),'@academy/engine':resolve(app,'lib/academy-engine.ts'),'@academy/teams':resolve(app,'lib/academy-teams.ts'),'@academy/authoring':resolve(app,'lib/academy-authoring.ts'),
 '@/lib/academy-engine':resolve(app,'lib/academy-engine.ts'),'@/lib/academy-record-check':resolve(here,'academy-record-check.ts'),'@/lib/academy-record-service':resolve(here,'academy-record-service.ts')};
const walk=dir=>readdirSync(resolve(app,dir),{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(dir+'/'+e.name):/\.(ts|json)$/.test(e.name)?[dir+'/'+e.name]:[]);
const sourceFiles=[...walk('lib').sort(),'app/chatgpt-auth.ts','cloudflare-env.d.ts'];
const candidateFiles=['academy-record-check.ts','academy-record-service.ts','academy-record-response.ts','academy-record-client.ts','route.ts','private-record-status-panel.tsx'];
const digest=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
const before=Object.fromEntries(sourceFiles.map(file=>[file,digest(resolve(app,file))]));
const entry=resolve(out,'entry.ts');
writeFileSync(entry,`export * from ${JSON.stringify(resolve(here,'academy-record-check.ts'))};\nexport * from ${JSON.stringify(resolve(here,'academy-record-service.ts'))};\nexport * from ${JSON.stringify(resolve(here,'academy-record-response.ts'))};\nexport * from ${JSON.stringify(resolve(here,'academy-record-client.ts'))};\nexport {programs,currentRef,curriculumRegistry,createCurriculumRegistry,resolvePinnedContent,LEGACY_SOURCE_SHA256} from ${JSON.stringify(aliases['@academy/curriculum'])};\nexport {applyCommand,freshWorkspace} from ${JSON.stringify(aliases['@academy/engine'])};\nexport {createTeam,applyTeamCommand,projectTeam} from ${JSON.stringify(aliases['@academy/teams'])};\nexport {workspaceRegistry,requireAvailablePublication} from ${JSON.stringify(aliases['@academy/authoring'])};\n`);
const plugin={name:'actual-root-candidate-source',setup(build){build.onResolve({filter:/^@academy\/|^@\/lib\/academy-/},args=>aliases[args.path]?{path:aliases[args.path]}:undefined)}};
await esbuild.build({entryPoints:[entry],outfile:resolve(out,'record-check.mjs'),bundle:true,platform:'node',format:'esm',target:'es2022',plugins:[plugin]});
const mock=resolve(out,'route-mock.ts');
writeFileSync(mock,`export const env:{DB:any}={DB:null};\nlet identity:any=null;\nexport function setIdentity(value:any){identity=value;}\nexport async function getChatGPTUser(){return identity;}\n`);
writeFileSync(resolve(out,'route-entry.ts'),`export {POST} from ${JSON.stringify(resolve(here,'route.ts'))};\nexport {env,setIdentity} from ${JSON.stringify(mock)};\n`);
await esbuild.build({entryPoints:[resolve(out,'route-entry.ts')],outfile:resolve(out,'record-route.mjs'),bundle:true,platform:'node',format:'esm',target:'es2022',plugins:[plugin,{name:'pure-route-host-mocks',setup(build){build.onResolve({filter:/^cloudflare:workers$|chatgpt-auth$/},()=>({path:mock}))}}]});
await esbuild.build({entryPoints:[resolve(here,'private-record-status-panel.tsx')],outfile:resolve(out,'private-record-status-panel.js'),bundle:true,platform:'browser',format:'esm',target:'es2022',jsx:'automatic',external:['react','react/jsx-runtime']});
const after=Object.fromEntries(sourceFiles.map(file=>[file,digest(resolve(app,file))]));
if(JSON.stringify(before)!==JSON.stringify(after))throw new Error('Actual root sources changed while compiling; repeat for current manifest.');
const archiveHash='9fc83c8dd615456db8f49d140f56bff566e05c14d32ebb70a14cdcb73078b7e4';
if(before['lib/curriculum-versions/0.1-review-draft.json']!==archiveHash||before['lib/curriculum.json']!==archiveHash)throw new Error('Immutable global 0.1 archive changed.');
const candidates=Object.fromEntries(candidateFiles.map(file=>[file,digest(resolve(here,file))]));
writeFileSync(resolve(out,'source-manifest.json'),JSON.stringify({at:new Date().toISOString(),app,scope:'Isolated candidate with ACTUAL current root pure modules. Route host bindings are pure mocks. No live API/DB/browser/hosted proof.',rootSources:before,candidates,unchangedAfterCompilation:true,archiveHash},null,2));
const paths={...Object.fromEntries(Object.entries(aliases).map(([k,v])=>[k,[v]])),react:[resolve(app,'node_modules/@types/react/index.d.ts')],'react/jsx-runtime':[resolve(app,'node_modules/@types/react/jsx-runtime.d.ts')]};
writeFileSync(resolve(out,'tsconfig.json'),JSON.stringify({compilerOptions:{strict:true,noEmit:true,target:'ES2022',module:'ESNext',moduleResolution:'Bundler',jsx:'react-jsx',lib:['ES2023','DOM'],resolveJsonModule:true,esModuleInterop:true,skipLibCheck:true,baseUrl:here,paths},files:candidateFiles.filter(f=>f!=='route.ts').map(f=>resolve(here,f))},null,2));
// The candidate route is outside app/api. Only its relative auth import is rewritten
// for type checking, to the ACTUAL current host auth module and worker declarations.
const typedRoute=resolve(out,'route-type-overlay.ts');
writeFileSync(typedRoute,readFileSync(resolve(here,'route.ts'),'utf8').replace("from '../../../../chatgpt-auth'",`from ${JSON.stringify(resolve(app,'app/chatgpt-auth').replaceAll('\\\\','/'))}`));
writeFileSync(resolve(out,'route-tsconfig.json'),JSON.stringify({compilerOptions:{strict:true,noEmit:true,target:'ES2022',module:'ESNext',moduleResolution:'Bundler',jsx:'react-jsx',lib:['ES2023','DOM'],resolveJsonModule:true,esModuleInterop:true,skipLibCheck:true,baseUrl:here,paths,types:['node','@cloudflare/workers-types'],typeRoots:[resolve(app,'node_modules/@types'),resolve(app,'node_modules')]},files:[typedRoute,resolve(app,'cloudflare-env.d.ts')]},null,2));
console.log('Record service, response guard, UI and pure host-mock route compiled; current-source manifest saved.');
