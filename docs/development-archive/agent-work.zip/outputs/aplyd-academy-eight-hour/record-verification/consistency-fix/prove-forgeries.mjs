import {writeFileSync} from 'node:fs';
import {forgeryVectors} from './runtime/tests/record-consistency.test.mjs';
import {acceptRecordCheckEnvelope as current} from '../integrated/runtime/record-check.mjs';
import {acceptRecordCheckEnvelope as staged} from './runtime/record-check.mjs';
const vectors=await forgeryVectors(),results=[];
for(const v of vectors){let baselineAccepted=false,stagedRejected=false;try{await current(v.envelope,v.expected);baselineAccepted=true}catch{}try{await staged(v.envelope,v.expected)}catch{stagedRejected=true}results.push({vector:v.name,baselineAccepted,stagedRejected})}
writeFileSync('./runtime/forgery-evidence.json',JSON.stringify({at:new Date().toISOString(),scope:'Pure actual baseline versus staged two-file fix; rehashed internally consistent malicious successful responses, no server or network',vectors:results,baselineAccepted:results.filter(x=>x.baselineAccepted).length,stagedRejected:results.filter(x=>x.stagedRejected).length},null,2)+'\n');
if(results.some(x=>!x.baselineAccepted||!x.stagedRejected))throw new Error('Unexpected regression vector proof');
console.log('Confirmed '+results.length+' baseline accepted forgeries; staged rejects all.');

