import {writeFileSync,readFileSync} from 'node:fs';import {execFileSync} from 'node:child_process';
const dst="/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/outputs/aplyd-academy-eight-hour/record-verification/consistency-fix",app="/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/work/aplyd-academy",files=['lib/academy-record-response.ts','app/academy-record-client.ts','tests/record-fixtures.mjs','tests/record-consistency.test.mjs','tests/record-consistency-client.test.mjs'];let diff='';
for(const file of files){try{diff+=execFileSync('/usr/bin/diff',['-u','--label','a/'+file,'--label','b/'+file,file.includes('consistency')?'/dev/null':app+'/'+file,dst+'/'+file],{encoding:'utf8'})}catch(e){if(e.status!==1)throw e;diff+=e.stdout}}
writeFileSync(dst+'/review.diff',diff);
writeFileSync(dst+'/adoption-contract.txt',[
'Adopt exactly the five paths listed below; other lib files are copied actual dependencies for outside-only TypeScript checking and MUST NOT be copied into checkout.',
...files,
'No route, service, model, database shape, content snapshot, migration, publication, authority or audience change.',
'Response expectation now requires a trusted deriveExpectedResult callback; runtime callers without it fail closed.',
'Client detaches only exact own enrollment or already accepted current assigned-open original queue and copies allowed scopes before await.',
'Expected thin result derives from existing lookup functions using canonical response checkedAt and captured account/workspace/revision/content registry.',
'Validator first detaches response before awaits; strict shape/digest checks still apply; complete canonical result must agree with independent captured projection.',
'Agreement includes pinned language/title/claim/exclusions, stored issuer display, initial/effective/full review metadata, issuance, active/suspended and pending flags.',
'No raw evidence/notes/feedback is added to export. A checksum remains integrity only and server authorization is still required.',
'Existing account/workspace/authority/read generation/mounted/loading/saving/signal fences remain before and after awaited verification.',
'Pure proof: 98 groups including 11 new consistency/lifetime groups passed; strict TypeScript passed. 14 internally consistent rehashed baseline forgeries accepted; staged rejects all.',
'Actual API baseline remains the approved M2 run (230 assertions, 9 scenarios, 20 read-only status checks); this staged fix is not current browser/Worker or hosted proof.',
'Root must adopt/rebuild and rerun targeted pure/client/browser checks before publication. Use separate prepared read-only browser suite pending stable signal.',
'Do not rerun stage.mjs; it is a one-time intermediate generator. bundle.mjs uses delivered final source copies.'
].join('\n')+'\n');
console.log('Separate adoption diff and exact five-file contract written.');
