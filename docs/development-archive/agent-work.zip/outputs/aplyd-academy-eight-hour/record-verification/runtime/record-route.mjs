// runtime/route-mock.ts
var env = { DB: null };
var identity = null;
function setIdentity(value) {
  identity = value;
}
async function getChatGPTUser() {
  return identity;
}

// ../../../work/aplyd-academy/lib/curriculum-versions/0.1-review-draft.json
var review_draft_default = {
  schemaVersion: "1.0",
  contentVersion: "0.1-review-draft",
  product: "Aplyd Academy",
  status: "Review draft: not approved sector training, accredited curriculum, or professional advice",
  language: "en",
  audience: "Adult learners",
  designNotes: [
    "All people, orders, records, documents, policies and AI outputs in this file are fictional teaching fixtures.",
    "Supplied AI drafts allow the whole journey to work without an external AI account or API call.",
    "An approved external AI tool may optionally produce another draft using the synthetic packet only. Learners must not enter real confidential material or credentials.",
    "Quiz feedback supports learning. A quiz score alone must not issue a competency credential.",
    "Practical assessment requires an assigned human reviewer. Rubric weights and critical gates are proposed, published training standards for this draft.",
    "A facilitator may read lesson text and capture an oral response with learner confirmation when an approved accommodation exists. Assistance must be recorded and must not supply the judgment answer."
  ],
  assessmentPolicy: {
    scoreScale: [0, 1, 2, 3, 4],
    weightedScoreFormula: "Sum of criterion weight multiplied by criterion score divided by 4; maximum 100",
    minimumWeightedScore: 70,
    passingRule: "Weighted score is at least 70 AND every declared critical gate is met. A critical failure cannot be averaged away.",
    decisionAuthority: "Assigned independent human assessor; no self-assessment or autonomous AI credential decision",
    feedbackRule: "Record score, evidence reference, critical-gate decision and actionable feedback for each criterion.",
    retryRule: "Retries and deadlines must be published by the offering before enrollment. Do not infer a fixed retry allowance from this seed file.",
    appealRule: "A learner may request a reasoned review under the offering's published appeal policy. The appeal reviewer must be independent of the original decision."
  },
  pathways: [
    {
      id: "farmer-work-records",
      title: "Farm records and better questions with AI",
      ecosystem: "Agri Saha",
      role: "Farmer",
      level: "Foundation to applied",
      summary: "Organize an activity record, check an AI-generated summary, and prepare useful questions for an agricultural expert.",
      promise: "You can turn a simple farm record into a verified summary and explain what still needs expert input.",
      estimatedMinutes: 110,
      prerequisites: ["Understand the example currency amounts with help if needed", "Use a simple form or receive planned facilitator assistance"],
      outcomes: ["Distinguish a duplicate transaction from a separate expense", "Check totals against source records", "Spot unsupported AI claims", "Create a clear expert question brief", "Keep private or commercially sensitive records out of unapproved tools"],
      credentialClaim: "Demonstrated farm-record organization, information checking and expert-question preparation using synthetic training data",
      credentialExclusions: ["No agricultural professional qualification", "No certification to prescribe farm inputs or make agronomic decisions"],
      sourceNotice: "Synthetic farm records supplied within each activity are the only factual source for this exercise.",
      lessons: [
        {
          id: "farm-01",
          title: "Make a useful work record",
          estimatedMinutes: 25,
          objective: "Build a consistent record and verify a duplicate before calculating a total.",
          lessonText: "A useful record separates what happened from what you think it means. Start with a date, activity, transaction reference, amount and unit where needed. A repeated line may be a duplicate, but two similar expenses can also be real. Check the reference or original receipt before removing anything. In this exercise, the source packet explicitly says that T02 was copied twice and represents one transport payment. Keep a note of that correction. Add the verified amounts rather than trusting a total supplied by a tool. AI can help organize a table or explain a calculation, but it cannot know which entry is genuine without evidence. When you use your own records later, keep the master copy in your approved location and choose a tool you are permitted to use. You do not need to upload names, telephone numbers, bank information or exact location details to practise this skill.",
          steps: ["Read the source packet", "Create one row per confirmed transaction", "Record why the extra T02 line was removed", "Calculate the verified total", "Identify one field you would add for future records"],
          exercise: {
            title: "Clean the fictional farm activity record",
            sourcePacket: [
              { sourceId: "T01", date: "2026-10-01", activity: "Recordkeeping support", quantity: 3, unit: "hours", rate: 150, amount: 450, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR" },
              { sourceId: "T03", date: "2026-10-03", activity: "Storage materials", quantity: 1, unit: "lot", rate: 800, amount: 800, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR", sourceNote: "Confirmed copied line; same receipt and payment as T02 above" }
            ],
            suppliedAiDraft: "The four entries total INR 1,550. Each row is a separate expense.",
            optionalAiPrompt: "Organize the supplied fictional transactions into a table. Use the source note to handle duplicates, show the calculation, and list uncertainty. Do not infer farm area, crop performance or missing transactions.",
            learnerTask: "Produce a corrected three-row table, show your total and explain the duplicate correction.",
            expectedEvidence: ["Corrected rows with source references", "450 + 150 + 800 = 1,400", "Note that T02 was removed once because the source confirms a copied payment", "One useful future record field such as receipt reference or unit"],
            assessorReference: "There are three confirmed transactions totaling INR 1,400. The raw four-line total is INR 1,550, but that counts the confirmed T02 copy twice. A learner must not generalize that every repeated amount is a duplicate."
          },
          quiz: [
            { id: "farm-01-q1", question: "What is the verified expense total?", options: ["INR 1,400", "INR 1,550", "INR 1,250", "It must be guessed from the activities"], correctOptionIndex: 0, explanation: "T02 is a confirmed copy of the same payment. The three verified amounts are 450, 150 and 800, which total 1,400." },
            { id: "farm-01-q2", question: "Two entries have the same amount but different receipt references. What should you do?", options: ["Delete the second amount automatically", "Keep both as confirmed without checking", "Check the source records before deciding whether either is duplicated", "Ask AI to choose the genuine one without evidence"], correctOptionIndex: 2, explanation: "Equal amounts are not proof of duplication. The original references and payment evidence decide whether the expenses are separate." },
            { id: "farm-01-q3", question: "Which practice input is suitable for this activity?", options: ["Your bank login details", "The supplied fictional record", "A neighbor's private transaction history", "Any record because AI makes it anonymous"], correctOptionIndex: 1, explanation: "The fictional record provides enough information for practice. Uploading private or secret information is unnecessary and inappropriate." }
          ],
          reflectionPrompt: "Which record field would make it easier for you to check a future total, and why?",
          returnToWorkAction: "Create a blank record template in an approved location. Use it for one permitted task and check entries against the original records before any sharing."
        },
        {
          id: "farm-02",
          title: "Check an AI summary before using it",
          estimatedMinutes: 20,
          objective: "Separate supported observations, missing context and unsupported recommendations.",
          lessonText: "A summary can sound confident while mixing correct statements with invented ones. Check important statements one at a time. Ask what evidence supports each claim. A total can be checked against transaction rows. A cost per acre needs area information. A claim about crop results needs relevant evidence, rather than a guess based on expenses. In this activity, the verified spending record tells you what was recorded; it does not tell you the farm area, complete budget, crop condition or likely yield. Mark these gaps explicitly. When a claim could affect a significant farm decision, prepare a question for an appropriate expert instead of treating an AI draft as a recommendation. A useful summary includes the known total, its limited scope, and the missing information. Verification is part of the work, even when it takes more time than generating the draft.",
          steps: ["Check the total", "Label each claim supported, unsupported or unknown", "Explain what evidence a per-acre figure would need", "Rewrite the summary with limits", "Identify the claim that needs expert input"],
          exercise: {
            title: "Find the unsupported claims",
            sourcePacket: ["Verified transactions: T01 INR 450; T02 INR 150; T03 INR 800.", "Recorded total: INR 1,400.", "Farm area, crop condition, total seasonal budget and crop outcomes are not supplied."],
            suppliedAiDraft: "The recorded expenses are INR 1,400. That is INR 700 per acre. These purchases will increase yield by 30%, so the farmer should immediately repeat them.",
            optionalAiPrompt: "Summarize only the supplied synthetic expense record. For every statement distinguish source-supported facts from missing context. Do not predict yield or recommend actions.",
            learnerTask: "Annotate the draft and create a two- or three-sentence corrected summary.",
            expectedEvidence: ["Total supported by the three transaction rows", "Per-acre claim rejected because area is missing", "Yield and immediate-action claims rejected as unsupported", "Corrected summary describes recorded expenses and missing context", "Expert referral for consequential recommendations"],
            assessorReference: "The packet supports only the INR 1,400 recorded total. It does not establish cost per acre, a 30% yield effect or a decision to repeat the purchases. Accept a cautious summary using equivalent plain language."
          },
          quiz: [
            { id: "farm-02-q1", question: "Which claim is supported by the packet?", options: ["Yield will rise by 30%", "The farm has two acres", "The recorded expenses total INR 1,400", "Repeating the purchases is the right decision"], correctOptionIndex: 2, explanation: "The transaction amounts support the total. Area, yield and action advice are not in the source packet." },
            { id: "farm-02-q2", question: "Why is INR 700 per acre unverified?", options: ["It is too small", "The packet does not give the farm area", "All AI calculations are wrong", "Per-acre costs can never be calculated"], correctOptionIndex: 1, explanation: "A cost per acre requires a relevant area and a defined cost scope. The area is absent, so the figure is unsupported here." },
            { id: "farm-02-q3", question: "What is the appropriate response to the draft's yield recommendation?", options: ["Act immediately because the wording is confident", "Forward it as approved guidance", "Ask AI to make the recommendation stronger", "Mark it unsupported and seek appropriate expert input before a consequential action"], correctOptionIndex: 3, explanation: "The provided record does not support a yield prediction or action. Recognizing the limit and escalating is the responsible response." }
          ],
          reflectionPrompt: "What is one confident-sounding statement you would still need to check?",
          returnToWorkAction: "For your next permitted AI-assisted summary, label important statements as verified, unverified or requiring expert input before using the draft."
        },
        {
          id: "farm-03",
          title: "Prepare a useful expert conversation",
          estimatedMinutes: 30,
          objective: "Turn a checked record into a concise question brief without claiming an unsupported decision.",
          lessonText: "AI is useful when it helps you organize questions, rather than deciding something it cannot support. A good expert brief states the purpose, summarizes verified information, identifies missing context, and asks specific questions. Keep facts separate from assumptions. Do not turn a missing detail into a made-up answer. In this example, you can explain that three recorded expenses total INR 1,400 and that a previous draft invented a yield claim. You can ask what additional records an expert needs and how to check any recommendation. The expert may need information beyond the training packet; share it only through an approved channel and only when relevant. Keep the brief short enough to use during a conversation. Afterward, record what was confirmed, what remains uncertain and who will take the next step. This pathway demonstrates recordkeeping and information judgment, not authority to prescribe farm practices.",
          steps: ["State the conversation's purpose", "Include the checked record total and sources", "List three relevant missing details", "Write three specific expert questions", "Choose an approved way to use the brief"],
          exercise: {
            title: "Build the expert question brief",
            sourcePacket: ["Use the verified three-row record from farm-01.", "The earlier AI draft's per-acre and yield claims were unsupported.", "No farm area, crop condition or complete seasonal expense record is provided."],
            suppliedAiDraft: "Expert brief: Our two-acre farm will gain 30% yield if we repeat the purchases. Please approve this plan.",
            optionalAiPrompt: "Create a short question brief from the supplied fictional packet. Separate verified facts, missing context and questions. Do not invent area, crop condition or outcomes, and do not request approval of an unsupported plan.",
            learnerTask: "Produce a 120\u2013200 word brief or equivalent oral response with verified facts, gaps, questions and next action.",
            expectedEvidence: ["Purpose: seek informed guidance about what information is needed", "Checked INR 1,400 recorded total with transaction references", "Missing area, crop context and record completeness", "Questions about needed information and verification, rather than a demanded action", "Next action stays within recordkeeping and approved expert consultation"],
            assessorReference: "A suitable brief says the record is limited, removes invented area/yield details, asks what further information is needed and how to verify advice, and uses an approved channel. Equivalent plain-language or approved oral evidence is acceptable."
          },
          quiz: [
            { id: "farm-03-q1", question: "Which question best fits the available information?", options: ["Can you confirm the promised 30% increase?", "What additional information do you need to interpret these recorded expenses?", "Which input should everyone buy?", "Can we omit the original records?"], correctOptionIndex: 1, explanation: "The question acknowledges the limited packet and asks an expert for the missing context needed for interpretation." },
            { id: "farm-03-q2", question: "What should the brief do with the invented two-acre detail?", options: ["Keep it because it is convenient", "Describe it as verified", "Remove it and state that area is not supplied", "Replace it with another guess"], correctOptionIndex: 2, explanation: "A missing field should remain a documented gap until appropriate evidence is available." },
            { id: "farm-03-q3", question: "What does this pathway's competency credential demonstrate?", options: ["Authority to prescribe crop inputs", "A professional agricultural qualification", "A guaranteed yield improvement", "Record organization, information checking and expert-question preparation"], correctOptionIndex: 3, explanation: "The credential must describe the assessed capability accurately. It does not create professional authority or guarantee an outcome." }
          ],
          reflectionPrompt: "How would this brief help an expert understand your question without pretending that every detail is known?",
          returnToWorkAction: "Use a blank fact\u2013gap\u2013question template for one permitted work conversation. Record the expert's confirmed guidance separately from your own assumptions."
        }
      ],
      practicalAssessment: {
        id: "farm-practical-01",
        title: "A verified farm record and expert brief",
        scenario: "A facilitator asks you to prepare the fictional T01/T02/T03 record for an expert conversation. The extra T02 row is a confirmed copy. The supplied AI output contains unsupported area and yield statements.",
        submissionPrompts: [
          { id: "task", label: "What are you trying to achieve and for whom?", help: "State the purpose of the record and expert conversation." },
          { id: "record", label: "Your corrected record and calculation", help: "Include source IDs, explain the duplicate treatment and show the INR total." },
          { id: "safe-input", label: "What information is safe to use?", help: "Identify the synthetic packet and information you would exclude from an unapproved tool." },
          { id: "ai-evidence", label: "The draft you reviewed and instructions you used", help: "You may review the supplied draft without opening an AI tool. Describe instructions for a safer draft." },
          { id: "checks", label: "Checks, errors and corrections", help: "Explain the total, area gap, invented yield statement and action recommendation." },
          { id: "final", label: "Final expert question brief", help: "Separate verified facts, missing information and questions." },
          { id: "return", label: "Your return-to-work action and boundary", help: "Describe a safe action such as improving records or using an approved expert channel." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable record or brief", "1": "Major record errors or an unclear brief", "2": "Mostly usable output with a material omission", "3": "Correct three-row record, INR 1,400 total and clear brief", "4": "Correct output with concise source mapping, useful questions and a reusable structure" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts the flawed output without checks", "1": "Checks only one minor detail", "2": "Checks total and duplicate but incompletely explains unsupported claims", "3": "Shows arithmetic and source-based rejection of invented area/yield claims", "4": "Checks all material claims and clearly distinguishes confirmed facts from unknowns" }, criticalGate: "Must not retain the invented yield or immediate-action claim as verified guidance" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual secrets or inappropriate private records", "1": "Cannot identify what should be excluded", "2": "Uses the synthetic packet but gives incomplete handling reasons", "3": "Uses only synthetic evidence and identifies private information to withhold", "4": "Adds an approved-channel plan with minimal necessary sharing" }, criticalGate: "No actual private records, third-party personal information or credentials submitted or proposed for unapproved use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Acts on unsupported consequential advice", "1": "Mentions caution without a usable next step", "2": "Identifies a limit but an unclear expert question", "3": "Asks relevant expert questions and limits the immediate action to permitted work", "4": "Explains escalation, missing context and how confirmed advice will be recorded" }, criticalGate: "Consequential farm decisions are not justified by this expense packet; the brief seeks appropriate expert input" }
        ],
        samplePassingEvidence: "I counted T02 once because the source identifies its duplicate. The total is 450 + 150 + 800 = INR 1,400. No farm area or yield evidence is supplied, so I removed INR 700 per acre and 30% yield improvement. I used fictional data only. My brief asks what context and further records an expert needs. My immediate work action is to maintain a checked record and seek guidance through an approved channel.",
        sampleCriticalFailure: "The learner produces a polished brief but recommends repeating the purchases to obtain a 30% yield improvement without verification. The verification and judgment gates fail regardless of aggregate score.",
        assessorNote: "Do not require advanced agricultural terminology, typing speed or use of a particular AI brand. Assess the record, checks, handling and explanation."
      },
      followUp: { afterDays: 14, question: "Did you use a checked record or expert question brief for a permitted task?", evidenceOptions: ["A structured reflection with no private record contents", "A blank improved template", "Facilitator-confirmed use under an approved process"], successSignal: "The learner can explain one check performed and one limit or question identified", privacyNote: "Do not collect real farm documents by default." }
    },
    {
      id: "msme-customer-operations",
      title: "Customer communication and daily operations with AI",
      ecosystem: "MSME",
      role: "MSME owner or team member",
      level: "Foundation to applied",
      summary: "Draft an accurate customer response, organize a daily work checklist, and measure whether AI assistance actually helped.",
      promise: "You can produce a useful customer draft and operations checklist while checking promises, information use and task quality.",
      estimatedMinutes: 110,
      prerequisites: ["Read a short order policy with help if needed", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Separate customer-relevant facts from internal details", "Avoid invented stock, dispatch and pricing commitments", "Create a source-based action checklist", "Compare time and quality including verification work", "Keep human approval for commitments outside the stated policy"],
      credentialClaim: "Demonstrated customer-draft preparation, operations checklist creation and responsible AI checking using synthetic business records",
      credentialExclusions: ["No financial, tax or legal professional qualification", "No assurance of business results or automated customer commitments"],
      sourceNotice: "The example order policy and records are fictional fixtures, not a recommended business policy.",
      lessons: [
        {
          id: "msme-01",
          title: "Write a customer response you can stand behind",
          estimatedMinutes: 25,
          objective: "Draft an accurate response using permitted facts and withhold irrelevant internal details.",
          lessonText: "A helpful customer response is clear about what is confirmed and what still needs checking. AI can make a message sound polished, but it may invent a discount, a delivery promise or available stock. Start by listing the facts the customer needs. Keep internal costs, private contact information and unrelated customer details out of an unapproved AI prompt. In this fictional policy, an item costs INR 120, delivery is INR 60 and pickup has no delivery fee. Only four units are confirmed in stock, while the customer requests six. That means a six-unit dispatch cannot be promised yet. You can explain the confirmed stock and say the team will check options; do not assume an arrival date. Check every promise in the draft against the supplied policy and records. Treat the final response as a draft for human approval whenever it changes a commitment or exceeds your role.",
          steps: ["Read the request, stock and policy", "Identify customer-relevant facts", "Remove irrelevant internal details from the prompt", "Correct the supplied AI draft", "Mark the check needed before sending"],
          exercise: {
            title: "Respond to a six-unit request",
            sourcePacket: [
              { sourceId: "P1", type: "fictional policy", content: "Unit price INR 120. Delivery fee INR 60 per order. Pickup delivery fee INR 0. Dispatch quantity and date require stock-team confirmation. Exceptions require supervisor approval." },
              { sourceId: "O101", type: "fictional request", content: "Customer C requests six blue units and asks whether all can be delivered on Friday." },
              { sourceId: "S1", type: "fictional stock record", content: "Four blue units are confirmed available. Arrival date for additional units is unknown." },
              { sourceId: "I1", type: "internal fixture", content: "Internal unit cost INR 75; private contact marker [PRIVATE CONTACT]; unrelated account notes. These are not needed for the customer draft." }
            ],
            suppliedAiDraft: "We confirm six units for Friday delivery at INR 120 each, with free delivery and a special 10% discount. Our internal unit cost is INR 75.",
            optionalAiPrompt: "Draft a short response using fictional P1, O101 and S1 only. State confirmed stock, do not promise unconfirmed quantity or date, do not invent discounts, and do not include internal details. Mark the team check required.",
            learnerTask: "Write a corrected customer response and a separate internal note identifying the required stock check.",
            expectedEvidence: ["Response does not confirm six-unit Friday delivery", "No invented free delivery or discount", "INR 120 unit price and applicable INR 60 delivery fee stated accurately if mentioned", "Internal unit cost and private marker excluded", "Stock team check required before commitment"],
            assessorReference: "A suitable response explains that four units are confirmed, the remaining quantity/date must be checked, and published price/delivery terms apply. It does not promise a split order unless approved. A requested six-unit order would total INR 780 including delivery, but calculating that is not confirmation that the order can be fulfilled."
          },
          quiz: [
            { id: "msme-01-q1", question: "What can the response currently confirm?", options: ["Six units will arrive Friday", "Four units are recorded as available, and the rest needs a team check", "Every order has free delivery", "A 10% discount is approved"], correctOptionIndex: 1, explanation: "The stock record confirms four units only. Quantity, date and any exception need the specified human check." },
            { id: "msme-01-q2", question: "If a six-unit order is later confirmed for delivery under P1, what is the stated total?", options: ["INR 720", "INR 780", "INR 702", "INR 840"], correctOptionIndex: 1, explanation: "Six units at INR 120 are INR 720, plus INR 60 delivery, totaling INR 780. This calculation does not confirm stock or delivery timing." },
            { id: "msme-01-q3", question: "Which source should be excluded from the customer-drafting prompt?", options: ["The published unit price", "The confirmed stock count", "The internal cost and private contact marker", "The customer's requested quantity without identity details"], correctOptionIndex: 2, explanation: "The internal details are unnecessary for the draft and should not be sent to an unapproved tool or disclosed to the customer." }
          ],
          reflectionPrompt: "Which invented promise in the original draft could create a problem for the team, and how did you correct it?",
          returnToWorkAction: "For one permitted customer draft, check quantity, price, fees and timing against approved records before an authorized person sends it."
        },
        {
          id: "msme-02",
          title: "Turn records into a daily action checklist",
          estimatedMinutes: 25,
          objective: "Create actions with owners and checks without inventing completion or commitments.",
          lessonText: "A useful checklist helps someone act: it states the task, owner, source and completion check. A vague list such as 'handle orders' is hard to follow. AI can group tasks, but it must not convert an unresolved issue into a completed action. Read the current status before choosing the next step. A ready order may need pickup confirmation; a stock issue needs a stock-team check; an address issue needs a permitted customer contact. Priorities should reflect an agreed rule, not a made-up deadline. This fictional packet gives no emergency ranking, so explain your proposed order as a suggestion for the supervisor. Keep personal customer details in the approved system. A checklist can use opaque order references. Before marking an action complete, record the actual check or confirmation. This preserves accountability and helps the next team member understand what remains open.",
          steps: ["Read each order status", "Identify its next allowed action", "Assign a role rather than inventing a person's availability", "Define evidence of completion", "Label suggested priorities as requiring review"],
          exercise: {
            title: "Build the day's three-order checklist",
            sourcePacket: [
              { sourceId: "O101", status: "Stock check pending", nextCheck: "Requested six units; four confirmed; additional arrival unknown", ownerRole: "Stock team" },
              { sourceId: "O102", status: "Packed", nextCheck: "Three units packed; payment confirmed in the fictional record; pickup time not yet agreed", ownerRole: "Customer service" },
              { sourceId: "O103", status: "On hold", nextCheck: "Delivery address confirmation missing; no private address is included in the teaching packet", ownerRole: "Customer service" },
              { sourceId: "P2", status: "Policy", nextCheck: "No new surcharge or completed dispatch without approved evidence. Supervisor reviews priority suggestions.", ownerRole: "Supervisor" }
            ],
            suppliedAiDraft: "Dispatch all six O101 units now. Add INR 50 urgency fees to every order. Mark O103 resolved. O102 needs no action because it is packed.",
            optionalAiPrompt: "Create a checklist from fictional O101\u2013O103 and P2. Include order reference, next action, owner role, dependency and evidence required to mark complete. Do not invent charges, stock, pickup timing or resolution.",
            learnerTask: "Create three checklist rows and explain why the supplied draft is unsafe to use unchanged.",
            expectedEvidence: ["O101: stock-team confirmation before dispatch commitment", "O102: agree pickup time through approved customer process", "O103: obtain address confirmation through approved channel; keep on hold until confirmed", "No invented fee", "Completion evidence and responsible owner role for each row"],
            assessorReference: "Accept equivalent actionable checklists. Do not require one priority ranking because the packet has no authoritative priority rule. The learner must preserve unresolved statuses until actual confirmation."
          },
          quiz: [
            { id: "msme-02-q1", question: "Which item can be marked complete solely from the supplied packet?", options: ["O101 full dispatch", "O103 address confirmation", "O102 packing", "All three orders"], correctOptionIndex: 2, explanation: "O102 is recorded as packed. Its pickup arrangement remains open. The other listed actions require further confirmation." },
            { id: "msme-02-q2", question: "What makes a checklist item actionable?", options: ["A confident sentence with no source", "Task, owner role, dependency and completion check", "A long paragraph repeating every private detail", "Automatic completion when AI writes it"], correctOptionIndex: 1, explanation: "These fields tell the team what to do, who handles it, what must happen first and how completion will be established." },
            { id: "msme-02-q3", question: "How should the INR 50 urgency fee be handled?", options: ["Apply it because AI suggested it", "Apply it only to the oldest order without approval", "Treat it as an unsupported addition and remove it", "Hide it from the checklist"], correctOptionIndex: 2, explanation: "The packet authorizes no urgency fee. A generated addition is not a business policy or approval." }
          ],
          reflectionPrompt: "Which unresolved action is easiest to accidentally mark complete, and what evidence should prevent that?",
          returnToWorkAction: "Create a small approved checklist using order references and completion evidence, then have the relevant team member verify one completed item."
        },
        {
          id: "msme-03",
          title: "Measure usefulness, including the checking time",
          estimatedMinutes: 25,
          objective: "Compare time and quality fairly and define a safe return-to-work trial.",
          lessonText: "Fast generation is only one part of a task. Include preparation, checking, correction and approval when comparing AI-assisted work with your usual approach. A faster draft with inaccurate promises may create more work later. In this exercise, manual preparation takes 12 minutes. The assisted route takes six minutes to prepare and generate, plus five minutes to check and correct. Its total is 11 minutes, a one-minute saving in this single fictional trial. The draft initially contains two unsupported commitments, and both must be corrected before approval. This small example does not establish a general productivity gain for your business. A useful trial uses comparable tasks and the same quality standard, records limitations, and stops if information handling or quality becomes unacceptable. Choose a low-consequence task, obtain permission, and keep final sending or operational commitments with the authorized person.",
          steps: ["Add all assisted-task time components", "Compare with manual time", "Check final quality against the same standard", "Describe the sample's limits", "Plan one permitted, low-consequence work trial"],
          exercise: {
            title: "Evaluate a fictional productivity trial",
            sourcePacket: [
              { sourceId: "M1", method: "Manual", minutes: 12, finalQuality: "Meets the scenario policy" },
              { sourceId: "A1", method: "AI-assisted preparation and generation", minutes: 6, draftQuality: "Two unsupported commitments" },
              { sourceId: "A2", method: "AI-assisted verification and correction", minutes: 5, finalQuality: "Both errors corrected; meets the same policy" },
              { sourceId: "N1", note: "One fictional comparable task only. No broader business productivity evidence is supplied." }
            ],
            suppliedAiDraft: "AI cut the task time in half from 12 minutes to 6 minutes and can be used to send all customer messages automatically.",
            optionalAiPrompt: "Calculate total assisted task time including checking. Compare the single fictional trial with manual preparation, discuss final quality and limits, and do not recommend automatic sending.",
            learnerTask: "Write a short evaluation and a safe one-task trial plan.",
            expectedEvidence: ["Assisted total 6 + 5 = 11 minutes", "Saving 12 - 11 = 1 minute", "If a percentage is included, approximately 8.3%, with single-trial limitation", "Same final quality check required", "No automatic customer sending or unauthorized data use"],
            assessorReference: "The six-minute figure excludes essential review. Accept one-minute saving without a percentage. A small or absent saving can still be a valid finding; learners are not rewarded for claiming AI is always better."
          },
          quiz: [
            { id: "msme-03-q1", question: "What is the full assisted-task time?", options: ["6 minutes", "5 minutes", "11 minutes", "17 minutes"], correctOptionIndex: 2, explanation: "Preparation/generation takes six minutes and checking/correction takes five. Both belong in the assisted-task total." },
            { id: "msme-03-q2", question: "What does this single fictional trial establish?", options: ["Every task will save half its time", "The comparable task saved one minute after review, with limited evidence", "Checking can now be skipped", "AI should automatically send every message"], correctOptionIndex: 1, explanation: "The result is limited to one synthetic trial and includes the verification work. It does not justify broad claims or removal of human approval." },
            { id: "msme-03-q3", question: "If an assisted draft is faster but retains an unsupported promise, what should happen?", options: ["Accept it because speed is the only measure", "Hide the error from the comparison", "Send it and correct it later", "Correct or reject it before use and record the quality failure"], correctOptionIndex: 3, explanation: "Quality and authorized commitments matter alongside time. A speed gain does not override an unacceptable output." }
          ],
          reflectionPrompt: "What checking or approval work would your own time comparison need to include?",
          returnToWorkAction: "With approval, compare one low-consequence task using the same quality checks for both methods. Record preparation, checking, correction and approval time without collecting confidential artifacts."
        }
      ],
      practicalAssessment: {
        id: "msme-practical-01",
        title: "An accurate customer draft and operations checklist",
        scenario: "Use fictional P1, S1 and O101\u2013O103 to prepare a customer response and checklist. Evaluate the supplied productivity trial without making unsupported business claims.",
        submissionPrompts: [
          { id: "task", label: "Task, audience and success criteria", help: "State what the customer and team need from your work." },
          { id: "safe-input", label: "Information included and information withheld", help: "Identify why internal cost and private markers do not belong in the drafting prompt." },
          { id: "ai-evidence", label: "Draft and safer instructions", help: "Use the supplied draft or an optional tool with synthetic inputs only." },
          { id: "checks", label: "Promises and calculations you checked", help: "Check stock, timing, price, delivery fee, discount and invented surcharge." },
          { id: "final", label: "Corrected customer response", help: "Keep unconfirmed stock and date explicit and avoid unauthorized commitments." },
          { id: "checklist", label: "Three-row action checklist", help: "Include owner role, dependency and evidence of completion." },
          { id: "return", label: "Productivity evaluation and return-to-work plan", help: "Include verification time, quality checks, limited evidence and authorized approval." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable response or checklist", "1": "Major source errors and unclear actions", "2": "Usable draft or checklist but material omissions", "3": "Clear accurate response and three actionable checklist rows", "4": "Concise audience-appropriate work with complete owners, dependencies and checks" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented promises and calculations", "1": "Checks only a minor fact", "2": "Checks key commitments but omits an important inconsistency", "3": "Corrects stock/date/discount/fee claims and includes full assisted time", "4": "Maps all material checks to sources and reports uncertainty and trial limits clearly" }, criticalGate: "No unconfirmed six-unit Friday promise, invented discount/free delivery or INR 50 surcharge remains as an authorized commitment" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Discloses inappropriate private information or actual secrets", "1": "Cannot distinguish relevant from internal information", "2": "Uses synthetic records but incompletely explains exclusions", "3": "Uses permitted facts and excludes internal cost/private contact data", "4": "Explains minimal input, approved channels and restricted customer-record handling" }, criticalGate: "No actual private customer records or credentials used; unnecessary internal/private fields are excluded from the customer draft and unapproved prompt" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Automatically commits or dispatches based on the draft", "1": "General caution without an approval route", "2": "Recognizes review but leaves a key operational action unclear", "3": "Preserves pending status and names human approval/checks and a bounded work trial", "4": "Explains stop conditions, source-based completion and limits of productivity conclusions" }, criticalGate: "Unresolved stock/address/pickup items are not falsely completed; customer sending and operational exceptions retain authorized human review" }
        ],
        samplePassingEvidence: "Four units are confirmed; six-unit Friday delivery needs the stock team's check. I removed the discount, free delivery and internal cost. O101 needs stock confirmation; O102 needs pickup arrangement; O103 needs approved address confirmation and remains on hold. I did not add a surcharge. The assisted trial takes 11 minutes including checks, saving one minute on one synthetic task. My work trial will use an approved low-consequence task and an authorized sender.",
        sampleCriticalFailure: "The learner calculates the right price and writes an elegant response but promises Friday delivery of six units, despite only four confirmed units. The verification gate fails.",
        assessorNote: "Accept different courteous wording and supervisor-reviewed priority suggestions. Do not require a positive productivity result or treat a calculated price as confirmed order acceptance."
      },
      followUp: { afterDays: 14, question: "Did you use a checked draft or action checklist on a permitted task, and what changed?", evidenceOptions: ["Structured reflection with task category and checks", "Blank checklist template", "Aggregate time comparison without customer details"], successSignal: "A learner describes a corrected commitment or clearer operational action and includes checking effort", privacyNote: "Do not require actual customer messages, prices negotiated with named customers or business account records." }
    },
    {
      id: "public-servant-source-briefs",
      title: "Clear administrative briefs with accountable AI use",
      ecosystem: "Government",
      role: "Public servant",
      level: "Foundation to applied",
      summary: "Create a source-traceable administrative draft, verify a simple summary, and retain authorized review before official use.",
      promise: "You can prepare a clear draft from permitted reference material and show which facts and judgments need review.",
      estimatedMinutes: 110,
      prerequisites: ["Read short supplied reference material", "Know that official approval is distinct from a draft", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Classify source material before tool use", "Map claims to supplied sources", "Reject invented requirements, fees and references", "Verify totals and rates with clear denominators", "Keep accountable approval and publication within assigned authority"],
      credentialClaim: "Demonstrated administrative drafting, source verification and responsible information-handling using synthetic training material",
      credentialExclusions: ["No authority to issue official decisions", "No legal or statutory qualification", "No assurance that an external AI tool is approved by an employer"],
      sourceNotice: "Every notice, department, programme, figure and policy below is fictional. No actual law, administrative direction or citizen service rule is stated.",
      lessons: [
        {
          id: "gov-01",
          title: "Draft from permitted sources, not invented rules",
          estimatedMinutes: 25,
          objective: "Create a source-based brief and remove invented requirements and authority.",
          lessonText: "An administrative draft should make it easy to identify the source of each important fact. First confirm whether the material is permitted for the chosen tool; a source being available to you does not automatically make external upload acceptable. This exercise supplies fictional shareable references, so no real file is needed. Read the sources before reviewing the AI draft. A generated instruction such as 'attendance is mandatory' is not authority unless the source actually states it. A fee or penalty must not be invented to make a notice sound official. Keep the document visibly marked as a draft, name the intended reader, and identify the review needed before official use. If a detail is missing, ask for confirmation or omit it. Do not add a fabricated circular number or present the AI output as an approved decision.",
          steps: ["Confirm the fictional packet is the approved practice input", "Map each material fact to a source", "Remove unsupported fee, penalty and mandatory-attendance claims", "Create a clear draft brief", "Name the approval step"],
          exercise: {
            title: "Correct the fictional staff-orientation brief",
            sourcePacket: [
              { sourceId: "G1", content: "Fictional staff orientation is planned for 8 October 2026 from 10:00 to 11:00." },
              { sourceId: "G2", content: "Venue: Room B. Participants are asked to respond by 6 October 2026." },
              { sourceId: "G3", content: "Attendance is voluntary. This material is a draft for authorized administrative review. No fee, penalty or circular number is supplied." },
              { sourceId: "G4", content: "Teaching packet is fictional and approved for this practice only. It contains no actual personnel or citizen records." }
            ],
            suppliedAiDraft: "Under Circular GOV-X, every employee must attend Room B on 8 October from 10:00 to 11:00. A fee of INR 500 applies. Late responses will result in a penalty. This notice is approved for issue.",
            optionalAiPrompt: "Prepare a brief from fictional G1\u2013G4 only. Include source references, distinguish draft status and voluntary attendance, and do not invent fees, penalties or circulars. Identify authorized review before issue.",
            learnerTask: "Write a short corrected draft and a fact-to-source list.",
            expectedEvidence: ["Correct date, time, room and response date", "Voluntary attendance retained", "GOV-X, fee and penalty removed as unsupported", "Draft status and authorized review explicit", "Important facts mapped to G1\u2013G3"],
            assessorReference: "The sources support a voluntary fictional event in Room B, 8 October 10:00\u201311:00, response by 6 October. They do not support a fee, penalty, circular or approved-issue status. Equivalent brief formats are acceptable."
          },
          quiz: [
            { id: "gov-01-q1", question: "Which statement matches G3?", options: ["Attendance is compulsory", "A fee of INR 500 applies", "Attendance is voluntary and the material needs authorized review", "Circular GOV-X authorizes publication"], correctOptionIndex: 2, explanation: "G3 explicitly states voluntary attendance and draft status. The generated fee, circular and authority are unsupported." },
            { id: "gov-01-q2", question: "How should GOV-X be treated?", options: ["As valid because it looks official", "As an unsupported reference to remove or verify before any use", "As a required citation", "As a confidential password"], correctOptionIndex: 1, explanation: "No such reference is supplied. Official-looking formatting does not establish authenticity." },
            { id: "gov-01-q3", question: "What is appropriate for this external-tool practice?", options: ["Upload actual restricted personnel files", "Use the supplied approved fictional packet only", "Assume every work file is public", "Include citizen identities to make the example realistic"], correctOptionIndex: 1, explanation: "The fictional packet is designed for practice. Real work material requires the organization's approved handling and tool rules." }
          ],
          reflectionPrompt: "How can the reader tell which facts came from the sources and which parts still need approval?",
          returnToWorkAction: "Use a claim\u2013source\u2013review template with permitted material in an approved environment. Keep draft status until the authorized approval step is completed."
        },
        {
          id: "gov-02",
          title: "Check numbers and the story they tell",
          estimatedMinutes: 25,
          objective: "Calculate a correct summary and avoid unsupported explanations of cause or performance.",
          lessonText: "A numerical brief needs a clear denominator and time period. In this fictional weekly packet, 80 items were received and 55 were recorded resolved. Dividing 55 by 80 gives 68.75%. That describes the packet's recorded figures; it does not automatically establish why outcomes changed or whether every item was handled satisfactorily. An AI draft may mix a wrong rate with a persuasive explanation. Check the calculation yourself, compare it with the source rows, and state the exact scope. Do not call a record 'improved' without a comparable earlier period and an agreed quality measure. A useful brief can explain the current counts and the limits of interpretation. If someone asks for a causal conclusion, identify the additional evidence needed rather than manufacturing one. Preserve accountability by asking the relevant data owner to confirm the figures before official circulation.",
          steps: ["Total received and resolved counts", "Calculate the rate with its denominator", "Compare the draft's rate", "Remove unsupported cause and quality claims", "Write a scoped summary for review"],
          exercise: {
            title: "Verify the fictional weekly service summary",
            sourcePacket: [
              { sourceId: "W1", category: "Category A", received: 40, recordedResolved: 25 },
              { sourceId: "W2", category: "Category B", received: 25, recordedResolved: 20 },
              { sourceId: "W3", category: "Category C", received: 15, recordedResolved: 10 },
              { sourceId: "W4", scope: "One fictional reporting week; no earlier period, case-level quality evidence or cause analysis is supplied." }
            ],
            suppliedAiDraft: "The programme resolved 95% of the 80 items and its new policy caused a major improvement in service quality.",
            optionalAiPrompt: "Summarize fictional W1\u2013W4. Show counts and denominator, calculate the rate, state scope, and avoid causal or quality claims unsupported by the packet.",
            learnerTask: "Create a verified three-sentence numerical brief with a visible calculation and one interpretation limit.",
            expectedEvidence: ["Received: 40 + 25 + 15 = 80", "Recorded resolved: 25 + 20 + 10 = 55", "55 / 80 \xD7 100 = 68.75%", "95% claim corrected", "No unsupported improvement, policy causation or case-quality claim"],
            assessorReference: "Accept 68.75% or appropriately labeled rounding such as 68.8%. The source uses 'recorded resolved'; avoid turning that into independently verified service quality. No previous-period or causal claim is justified."
          },
          quiz: [
            { id: "gov-02-q1", question: "What percentage of received items is recorded resolved?", options: ["95%", "55%", "68.75%", "80%"], correctOptionIndex: 2, explanation: "There are 55 recorded resolved items out of 80 received. 55 divided by 80, multiplied by 100, is 68.75%." },
            { id: "gov-02-q2", question: "What additional evidence is needed before calling this an improvement?", options: ["A more confident AI sentence", "A comparable baseline and agreed measures", "A larger font", "A made-up prior-period figure"], correctOptionIndex: 1, explanation: "Improvement requires an appropriate comparison and defined measures. The single-week packet provides neither." },
            { id: "gov-02-q3", question: "Which wording is best supported?", options: ["The policy caused better quality", "Every item was handled satisfactorily", "The packet records 55 of 80 items resolved for one fictional week", "The result applies to every department"], correctOptionIndex: 2, explanation: "This describes the supplied counts and scope without adding unverified quality, causal or generalization claims." }
          ],
          reflectionPrompt: "What would you ask the data owner before this summary was used in an official report?",
          returnToWorkAction: "On one permitted numerical summary, record the denominator, period, calculation and data-owner check before circulation."
        },
        {
          id: "gov-03",
          title: "Keep the draft-to-official boundary clear",
          estimatedMinutes: 25,
          objective: "Build a review handoff and safe work plan without assuming publication authority.",
          lessonText: "Preparing a draft and authorizing its official use are different responsibilities. A learning role such as public servant does not give permission to view every file or issue a notice. Keep the active work context and intended recipient clear. Your review handoff should identify the draft version, source packet, checks completed, uncertainties and the person or role that must approve it. AI can suggest text, but it cannot provide organizational authority. In this exercise, the reviewer role may confirm the source figures and wording; publication remains with the designated approver. Do not bypass that handoff because the document looks finished. If the approved AI tool is unavailable, use the supplied draft or prepare the brief manually. The skill is accurate and accountable work, not dependence on a tool. Return to your work with a small permitted task and an explicit stop condition if classification, access or approval is unclear.",
          steps: ["Mark the document as a draft", "List sources, version and checks", "Identify unresolved questions", "Route to the designated review and approval roles", "Define one bounded return-to-work task"],
          exercise: {
            title: "Prepare the accountable review handoff",
            sourcePacket: [
              { sourceId: "R1", content: "Fictional review process: learner prepares draft; data owner confirms supplied figures; designated administrative approver decides official issue. No role is granted through Academy enrollment." },
              { sourceId: "R2", content: "Use corrected G1\u2013G3 event brief and W1\u2013W4 numerical summary. Both remain draft teaching materials." },
              { sourceId: "R3", content: "Actual restricted work records, access credentials and citizen identities must not be included in this practice." }
            ],
            suppliedAiDraft: "The brief looks complete. Publish it immediately using your Academy learner role and skip data-owner review.",
            optionalAiPrompt: "Create a review checklist from fictional R1\u2013R3. Preserve draft status, source checks, data-owner review and designated approval. Do not grant permissions or propose immediate publication.",
            learnerTask: "Write a review note naming the source packet, checks, questions, next reviewer, final approval step and work-trial stop condition.",
            expectedEvidence: ["Draft status explicit", "Corrected sources and calculations listed", "Data-owner review and designated approval separated", "No implied administrative privileges from Academy role", "Stop when classification, permitted tool or authority is unclear"],
            assessorReference: "A passing handoff preserves the R1 process and does not issue anything. The learner can use equivalent role labels without naming a real official. A safe work trial uses permitted material and retains employer-approved review."
          },
          quiz: [
            { id: "gov-03-q1", question: "What permission does selecting the public-servant learner role grant?", options: ["Access to all official records", "Permission to publish a notice", "No administrative or publication permission by itself", "Permission to bypass review"], correctOptionIndex: 2, explanation: "A learning context supports relevance. Actual access and authority require explicit assignments in the relevant system and process." },
            { id: "gov-03-q2", question: "What should happen when the data classification or approved tool is unclear?", options: ["Upload the file and ask later", "Stop and seek the appropriate approval or handling guidance", "Rename the file to make it public", "Assume Academy enrollment authorizes it"], correctOptionIndex: 1, explanation: "Unclear handling rules are a reason to pause the tool use and seek the responsible owner, not to guess." },
            { id: "gov-03-q3", question: "If an external AI tool is unavailable during this activity, what is acceptable?", options: ["Use another unapproved tool with restricted records", "Skip all verification", "Claim the task is passed without evidence", "Review the supplied draft or prepare the work manually with the same checks"], correctOptionIndex: 3, explanation: "The assessed skill is responsible task performance. The provided draft supports practice without tool access, and the checking standard remains the same." }
          ],
          reflectionPrompt: "What part of your handoff ensures that a polished draft is not mistaken for an approved decision?",
          returnToWorkAction: "Use a draft-review checklist for one permitted administrative task. Record sources, checks, remaining questions and the authorized approval route without submitting confidential work to Academy."
        }
      ],
      practicalAssessment: {
        id: "gov-practical-01",
        title: "A verified administrative brief and review handoff",
        scenario: "Prepare a corrected fictional staff-orientation brief, a numerical summary of W1\u2013W4, and a review handoff under R1\u2013R3. Explain why generated wording is not official authority.",
        submissionPrompts: [
          { id: "task", label: "Purpose, reader and draft status", help: "Identify the intended administrative use and why approval remains necessary." },
          { id: "safe-input", label: "Permitted input and handling boundary", help: "Use the fictional packet and identify what you would keep out of an unapproved tool." },
          { id: "ai-evidence", label: "Supplied draft and safer instructions", help: "Describe the source-bound instructions without providing any actual restricted file." },
          { id: "checks", label: "Fact-to-source map and numerical checks", help: "Check event facts, invented circular/fee/penalty, totals and rate." },
          { id: "final", label: "Corrected brief and scoped numerical summary", help: "Keep voluntary attendance, draft status and the exact count scope." },
          { id: "handoff", label: "Review and approval handoff", help: "Identify data-owner confirmation, unresolved questions and designated approval." },
          { id: "return", label: "Return-to-work task and stop conditions", help: "Choose a permitted task and explain when access, classification or authority needs clarification." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable brief or handoff", "1": "Major factual errors and unclear audience", "2": "Mostly usable work with material omissions", "3": "Clear corrected event brief, numerical summary and review note", "4": "Concise audience-appropriate work with complete source mapping and actionable handoff" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented official references and rate", "1": "Checks isolated facts only", "2": "Checks main facts but leaves an important unsupported assertion", "3": "Removes invented authority/fee/penalty and verifies 55 of 80 equals 68.75%", "4": "Maps every important assertion to sources and explains scope, denominator and interpretation limits" }, criticalGate: "No fabricated circular, fee, penalty, mandatory-attendance claim or unsupported causal improvement remains presented as source-supported fact" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual restricted records or credentials", "1": "Treats all work material as permitted", "2": "Uses synthetic material but lacks a clear tool boundary", "3": "Uses only approved fictional packet and identifies restricted information to withhold", "4": "Explains approved environment, minimum necessary sharing and a clear uncertainty stop" }, criticalGate: "No actual restricted administrative/citizen records or credentials are submitted or proposed for unapproved tool use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Issues or authorizes the draft without required authority", "1": "Mentions review but does not distinguish approval", "2": "Identifies review with an incomplete handoff", "3": "Preserves draft status, data-owner check and designated approval", "4": "Adds specific unresolved questions, stop conditions and a bounded permitted work trial" }, criticalGate: "Academy role and AI output are not treated as official authority; required review and designated approval are retained" }
        ],
        samplePassingEvidence: "G1 and G2 support the event date, time, venue and response date. G3 says attendance is voluntary and the material is a draft. I removed GOV-X, INR 500 and the penalty. W1\u2013W3 total 80 received and 55 recorded resolved, or 68.75%, for one fictional week; no causal improvement is established. My handoff requests data-owner checks and designated approval before issue. I used only the synthetic packet and will stop a work trial if classification, tool approval or authority is unclear.",
        sampleCriticalFailure: "The learner calculates the rate correctly but retains an invented circular and describes the draft as officially approved. The verification and judgment gates fail.",
        assessorNote: "Assess source accountability and authority boundaries rather than legal knowledge. Do not infer that any real organization's tool or publication policy matches the fictional process."
      },
      followUp: { afterDays: 14, question: "Did you use a source-and-review checklist for a permitted administrative task?", evidenceOptions: ["Structured reflection without document contents", "Blank claim\u2013source\u2013review template", "Authorized facilitator confirmation under the approved pilot process"], successSignal: "The learner describes a checked claim, a documented uncertainty and the correct approval handoff", privacyNote: "Do not collect actual administrative briefs, citizen records or employer-restricted information by default." }
    }
  ]
};

// ../../../work/aplyd-academy/lib/academy-curriculum.ts
var LEGACY_CONTENT_VERSION = "0.1-review-draft";
var ContentResolutionError = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
    this.name = "ContentResolutionError";
  }
  status;
};
function deepFreeze(value) {
  if (value !== null && typeof value === "object" && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) deepFreeze(child);
    Object.freeze(value);
  }
  return value;
}
function validScope(value) {
  return value === "global" || typeof value === "string" && /^tw-[a-z0-9-]{20,80}$/i.test(value);
}
function contentRef(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ContentResolutionError("The saved content reference is invalid. Contact support before continuing.");
  }
  const ref = value;
  if (Object.keys(ref).some((key) => !["scope", "programId", "versionId"].includes(key)) || !validScope(ref.scope) || typeof ref.programId !== "string" || !/^[a-z0-9][a-z0-9-]{0,99}$/i.test(ref.programId) || typeof ref.versionId !== "string" || !/^[a-z0-9][a-z0-9._-]{0,99}$/i.test(ref.versionId)) {
    throw new ContentResolutionError("The saved content reference is invalid. Contact support before continuing.");
  }
  return Object.freeze({ scope: ref.scope, programId: ref.programId, versionId: ref.versionId });
}
function contentKey(value) {
  const ref = contentRef(value);
  return JSON.stringify([ref.scope, ref.programId, ref.versionId]);
}
function pinnedRef(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ContentResolutionError("The saved learning reference is invalid.");
  }
  const record = value;
  if (Object.hasOwn(record, "contentRef")) {
    const ref = contentRef(record.contentRef);
    if (record.programId !== void 0 && record.programId !== ref.programId || record.version !== void 0 && record.version !== ref.versionId) {
      throw new ContentResolutionError("Saved learning and content references disagree. Contact support before continuing.");
    }
    return ref;
  }
  return contentRef({ scope: "global", programId: record.programId, versionId: record.version });
}
function createCurriculumRegistry(entries) {
  const index = /* @__PURE__ */ new Map();
  for (const entry of entries) {
    const ref = contentRef(entry.ref);
    if (entry.program.id !== ref.programId) {
      throw new ContentResolutionError("A content snapshot has a mismatched pathway identity.");
    }
    const key = contentKey(ref);
    if (index.has(key)) throw new ContentResolutionError("An immutable content key is already registered.");
    index.set(key, deepFreeze(structuredClone({ ...entry, ref })));
  }
  function resolve2(input, allowedScopes = ["global"]) {
    const ref = contentRef(input);
    if (!allowedScopes.includes(ref.scope)) {
      throw new ContentResolutionError("This content is not available in your learning space.", 404);
    }
    const found = index.get(contentKey(ref));
    if (!found) {
      throw new ContentResolutionError("Your pinned curriculum version is unavailable. Contact support before continuing.");
    }
    return found;
  }
  return Object.freeze({ resolve: resolve2, has: (ref, allowedScopes) => {
    try {
      resolve2(ref, allowedScopes);
      return true;
    } catch (error) {
      if (error instanceof ContentResolutionError) return false;
      throw error;
    }
  } });
}
var curriculum = deepFreeze(structuredClone(review_draft_default));
var programs = curriculum.pathways;
var seedSnapshots = programs.map((program) => ({
  ref: contentRef({ scope: "global", programId: program.id, versionId: LEGACY_CONTENT_VERSION }),
  program,
  language: curriculum.language,
  audience: curriculum.audience,
  classification: curriculum.status
}));
var curriculumRegistry = createCurriculumRegistry(seedSnapshots);
function resolvePinnedContent(record, allowedScopes, registry = curriculumRegistry) {
  return registry.resolve(pinnedRef(record), allowedScopes);
}
function tryResolvePinnedContent(record, allowedScopes, registry = curriculumRegistry) {
  try {
    return { available: true, snapshot: resolvePinnedContent(record, allowedScopes, registry) };
  } catch (error) {
    if (error instanceof ContentResolutionError) return { available: false, message: error.message };
    throw error;
  }
}

// ../../../work/aplyd-academy/lib/academy-ecosystem-guard.ts
var LEGACY_PREVIEW_MAPPINGS = [
  { partner: "agri", programId: "farmer-work-records" },
  { partner: "msme", programId: "msme-customer-operations" },
  { partner: "public", programId: "public-servant-source-briefs" }
];
var partners = [...LEGACY_PREVIEW_MAPPINGS.map((m) => m.partner), "health"];

// ../../../work/aplyd-academy/lib/academy-plan.ts
function freshLearningPlan() {
  return { goal: "explore", personalGoal: "", weeklyMinutes: 60, timeZone: "UTC", remindersEnabled: false, tasks: [] };
}

// ../../../work/aplyd-academy/lib/academy-engine.ts
var RuleError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
  }
  status;
};
function freshWorkspace() {
  return { profile: { name: "Learner", context: "msme", reading: false, networking: false }, enrollments: [], posts: [], reports: [], interests: [], connections: {}, deliveries: [], followups: [], paused: [], seen: [], learningPlan: freshLearningPlan() };
}
var contexts = { farmer: programs[0].id, msme: programs[1].id, public: programs[2].id };
function scoreDecision(p, scores, gates) {
  if (!Array.isArray(scores) || scores.length !== p.practicalAssessment.rubric.length || scores.some((n) => !Number.isInteger(n) || n < 0 || n > 4)) throw new RuleError("Score every criterion from 0 to 4.");
  const critical = p.practicalAssessment.rubric.filter((r) => r.criticalGate);
  if (!Array.isArray(gates) || gates.length !== critical.length || gates.some((b) => typeof b !== "boolean")) throw new RuleError("Review every critical safety gate.");
  const score = p.practicalAssessment.rubric.reduce((n, r, i) => n + r.weight * scores[i] / 4, 0);
  return { score, passed: score >= 70 && gates.every(Boolean) };
}

// academy-record-check.ts
var RecordCheckError = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
    this.name = "RecordCheckError";
  }
  status;
};
var plain = (v) => !!v && typeof v === "object" && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
var bounded = (v, n = 200) => typeof v === "string" && v.trim().length > 0 && v.length <= n && !/[\u0000-\u001f\u007f]/.test(v);
var refString = (v) => bounded(v, 120) && /^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(v);
function exactRequest(value, key) {
  if (!plain(value) || Object.keys(value).length !== 1 || !Object.hasOwn(value, key) || !refString(value[key])) throw new RecordCheckError("Use the exact private " + key + " reference.", 400);
  return value[key];
}
function iso(value) {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString() === value;
}
function checkContext(c) {
  if (!bounded(c.actorId) || !bounded(c.learnerId) || !["personal", "shared"].includes(c.space) || !Number.isSafeInteger(c.revision) || c.revision < 0 || !iso(c.checkedAt) || (c.space === "personal" ? c.workspaceId !== null : !refString(c.workspaceId))) throw new RecordCheckError("The authenticated record-check context is unavailable.", 400);
}
function canonical(value, seen = /* @__PURE__ */ new Set()) {
  if (value === null || typeof value === "string" || typeof value === "boolean") return JSON.stringify(value);
  if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  if (!Array.isArray(value) && !plain(value) || seen.has(value)) throw new RecordCheckError("The snapshot contains unsupported values.");
  seen.add(value);
  const text = Array.isArray(value) ? "[" + value.map((v) => canonical(v, seen)).join(",") + "]" : "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonical(value[k], seen)).join(",") + "}";
  seen.delete(value);
  return text;
}
async function snapshotChecksum(value) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonical(value))))].map((x) => x.toString(16).padStart(2, "0")).join("");
}
var decisionKeys = ["id", "score", "passed", "scores", "gates", "notes", "feedback", "actor", "actorName", "decidedAt", "mode"];
function decision(d, kind, attemptId, appealId, program, context) {
  if (!plain(d) || Object.keys(d).some((k) => !decisionKeys.includes(k)) || !refString(d.id) || !bounded(d.actor) || !iso(d.decidedAt) || Date.parse(d.decidedAt) > Date.parse(context.checkedAt) || typeof d.passed !== "boolean" || !Number.isFinite(d.score) || !Array.isArray(d.notes) || d.notes.length !== program.practicalAssessment.rubric.length || d.notes.some((n) => typeof n !== "string" || n.trim().length < 10 || n.length > 3e3) || typeof d.feedback !== "string" || d.feedback.trim().length < 30 || d.feedback.length > 3e3 || d.actorName !== void 0 && !bounded(d.actorName, 80)) throw new RecordCheckError("The saved decision metadata needs inspection.");
  let expected;
  try {
    expected = scoreDecision(program, d.scores, d.gates);
  } catch {
    throw new RecordCheckError("The saved decision does not match its exact rubric.");
  }
  if (d.score !== expected.score || d.passed !== expected.passed) throw new RecordCheckError("The saved decision and exact rubric disagree.");
  const expectedMode = context.space === "personal" ? kind === "assessment" ? "manual sample-assessor review" : "manual sample-reviewer appeal" : kind === "assessment" ? "authenticated assigned assessment" : "authenticated independent appeal";
  if (d.mode !== expectedMode || context.space === "personal" && d.actor !== (kind === "assessment" ? "assessor-a" : "reviewer-b") || context.space === "shared" && d.actor === context.learnerId) throw new RecordCheckError("The saved review provenance does not match this learning space.");
  return Object.freeze({ decisionId: d.id, kind, attemptId, appealId, actorRef: d.actor, actorDisplay: context.space === "personal" ? kind === "assessment" ? "Sample Assessor A" : "Sample Reviewer B" : d.actorName ?? "Assigned staff", decidedAt: d.decidedAt, mode: d.mode, passed: d.passed });
}
function recordShape(r, context, ref, program) {
  const keys = ["id", "issuedAt", "title", "claim", "issuer", "contentVersion", "kind", "status", "share", "workspaceId", "reviewedBy", "decisionId", "lastReviewedAt"];
  if (!plain(r) || Object.keys(r).some((k) => !keys.includes(k)) || !refString(r.id) || !iso(r.issuedAt) || Date.parse(r.issuedAt) > Date.parse(context.checkedAt) || !bounded(r.title, 300) || !bounded(r.claim, 3e3) || !bounded(r.issuer, 200) || r.contentVersion !== ref.versionId || !["active", "suspended"].includes(r.status) || typeof r.share !== "boolean" || r.title !== program.title || r.claim !== program.credentialClaim) throw new RecordCheckError("The stored practice record does not match its pinned learning.");
  if (context.space === "personal") {
    if (r.kind !== "Nonaccredited practice completion" || r.issuer !== "Aplyd Academy \xB7 private practice workspace" || ["workspaceId", "decisionId", "lastReviewedAt", "reviewedBy"].some((k) => Object.hasOwn(r, k))) throw new RecordCheckError("The stored sample record has unsupported issuer metadata.");
  } else if (r.kind !== "Reviewed practice record \xB7 draft learning content, nonaccredited" || !r.issuer.endsWith(" \xB7 Aplyd Academy") || r.workspaceId !== context.workspaceId || !refString(r.decisionId) || !iso(r.lastReviewedAt) || r.reviewedBy !== void 0 && !bounded(r.reviewedBy, 80)) throw new RecordCheckError("The stored workspace review metadata is incomplete.");
}
function history(e, program, context) {
  if (!Array.isArray(e.attempts) || e.attempts.length < 1 || e.attempts.length > 3 || !Array.isArray(e.appeals) || e.appeals.length > 3) throw new RecordCheckError("The retained review history needs inspection.");
  const attempts = /* @__PURE__ */ new Map(), appeals = /* @__PURE__ */ new Map(), ids = /* @__PURE__ */ new Set(), timeline = [];
  let pendingAssessment = false;
  for (const [index, a] of e.attempts.entries()) {
    if (!plain(a) || !refString(a.id) || attempts.has(a.id) || a.number !== index + 1 || !iso(a.submittedAt) || Date.parse(a.submittedAt) > Date.parse(context.checkedAt)) throw new RecordCheckError("The retained attempt references need inspection.");
    attempts.set(a.id, a);
    ids.add(a.id);
    if (a.decision == null) {
      if (pendingAssessment || index !== e.attempts.length - 1) throw new RecordCheckError("The pending attempt is not the latest attempt.");
      pendingAssessment = true;
    }
  }
  let openAppeal = false;
  for (const ap of e.appeals) {
    const a = attempts.get(ap?.attemptId);
    if (!plain(ap) || !refString(ap.id) || ids.has(ap.id) || !a?.decision || appeals.has(ap.attemptId) || !["open", "resolved"].includes(ap.status) || !iso(ap.createdAt) || Date.parse(ap.createdAt) > Date.parse(context.checkedAt) || (ap.status === "open" ? ap.resolution !== void 0 : !plain(ap.resolution))) throw new RecordCheckError("The retained appeal references need inspection.");
    ids.add(ap.id);
    appeals.set(ap.attemptId, ap);
    if (ap.status === "open") {
      if (openAppeal || a !== e.attempts.at(-1)) throw new RecordCheckError("The open appeal is not the latest attempt.");
      openAppeal = true;
    }
  }
  for (const [index, a] of e.attempts.entries()) {
    const previous = timeline.at(-1);
    if (index > 0 && (!previous || previous.passed || Date.parse(a.submittedAt) < Date.parse(previous.decidedAt))) throw new RecordCheckError("The retry history is not sequential or follows an active completion.");
    if (!a.decision) continue;
    const initial = decision(a.decision, "assessment", a.id, null, program, context);
    if (ids.has(initial.decisionId) || Date.parse(initial.decidedAt) < Date.parse(a.submittedAt)) throw new RecordCheckError("The retained decision references need inspection.");
    ids.add(initial.decisionId);
    timeline.push(initial);
    const ap = appeals.get(a.id);
    if (ap) {
      if (Date.parse(ap.createdAt) < Date.parse(initial.decidedAt)) throw new RecordCheckError("The appeal precedes its original decision.");
      if (ap.status === "resolved") {
        const resolved = decision(ap.resolution, "appeal", a.id, ap.id, program, context);
        if (ids.has(resolved.decisionId) || resolved.actorRef === initial.actorRef || Date.parse(resolved.decidedAt) < Date.parse(ap.createdAt)) throw new RecordCheckError("The retained independent appeal provenance needs inspection.");
        ids.add(resolved.decisionId);
        timeline.push(resolved);
      }
    }
  }
  if (openAppeal && pendingAssessment) throw new RecordCheckError("Pending assessment and appeal history disagree.");
  const firstPassing = timeline.find((d) => d.passed), effective = timeline.at(-1);
  if (!firstPassing || !effective) throw new RecordCheckError("A practice record has no retained passing decision.");
  return { timeline, firstPassing, effective, openAppeal, pendingAssessment };
}
var unavailable = (message) => Object.freeze({ outcome: "unavailable", message });
var checksumMeaning = "Checksum of this private snapshot only; not a signature, issuer approval, public credential verification or guarantee of later status.";
async function lookupOwnPracticeRecord(state, request, context) {
  checkContext(context);
  const recordId = exactRequest(request, "recordId");
  if (context.actorId !== context.learnerId) throw new RecordCheckError("This private record is unavailable for your account.", 404);
  if (!plain(state) || !Array.isArray(state.enrollments)) throw new RecordCheckError("Your saved learning needs a format review.");
  const matches = state.enrollments.filter((e2) => plain(e2) && plain(e2.record) && e2.record.id === recordId);
  if (!matches.length) throw new RecordCheckError("This private record is unavailable for your account.", 404);
  if (matches.length !== 1) return unavailable("Duplicate private record references need inspection. Export your own workspace for support.");
  const e = matches[0], resolved = tryResolvePinnedContent(e, context.content.allowedScopes, context.content.registry);
  if (!resolved.available) return unavailable("The exact saved course is unavailable. Your own stored record remains available in your workspace export; its rubric status was not checked.");
  try {
    const ref = pinnedRef(e), program = resolved.snapshot.program, r = e.record;
    if (!refString(e.id) || e.withdrawn || !Array.isArray(e.completed) || e.completed.length !== program.lessons.length || new Set(e.completed).size !== e.completed.length || program.lessons.some((l) => !e.completed.includes(l.id))) throw new RecordCheckError("The record enrollment needs inspection.");
    recordShape(r, context, ref, program);
    const h = history(e, program, context), expectedStatus = h.effective.passed ? "active" : "suspended";
    if (r.status !== expectedStatus || r.status === "active" && h.pendingAssessment || r.issuedAt !== h.firstPassing.decidedAt || context.space === "shared" && (r.decisionId !== h.effective.decisionId || r.lastReviewedAt !== h.effective.decidedAt || r.reviewedBy !== h.effective.actorDisplay)) throw new RecordCheckError("The stored record and effective review history disagree.");
    const snapshot = deepFreeze({ schemaVersion: 1, kind: "private-practice-record-status", recordId: r.id, enrollmentId: e.id, space: context.space, workspaceId: context.workspaceId, contentRef: ref, contentLanguage: resolved.snapshot.language, contentFingerprint: await snapshotChecksum(program), title: r.title, claim: r.claim, exclusions: [...program.credentialExclusions], classification: "Nonaccredited practice record", issuerDisplay: r.issuer, issuerAuthority: "Workspace display label only; no recognised issuer authority asserted", status: r.status, hasOpenAppeal: h.openAppeal, hasPendingAssessment: h.pendingAssessment, issuedAt: r.issuedAt, checkedAt: context.checkedAt, asOfRevision: context.revision, firstPassingDecision: h.firstPassing, effectiveDecision: h.effective, decisionHistory: h.timeline, limitations: ["Private authenticated saved-state check only", "Personal sample reviews remain sample when space is personal", "No raw evidence, drafts, private feedback, email or support notes in this snapshot", "Recheck current saved state after an appeal or new decision"] });
    return deepFreeze({ outcome: "checked", snapshot, integrity: { algorithm: "SHA-256", checksum: await snapshotChecksum(snapshot), meaning: checksumMeaning } });
  } catch (e2) {
    if (e2 instanceof RecordCheckError) return unavailable("The stored record or retained review history needs inspection. Your own workspace export is retained; no validated status snapshot was produced.");
    throw e2;
  }
}
async function lookupAssignedDecision(projection, request, context) {
  checkContext(context);
  const decisionId = exactRequest(request, "decisionId"), team = projection?.team;
  if (context.space !== "shared" || !plain(team) || team.currentUserId !== context.actorId || team.id !== context.workspaceId || team.active !== true || !Array.isArray(team.assigned)) throw new RecordCheckError("This assigned decision is unavailable for your account.", 404);
  const matches = team.assigned.filter((q2) => q2?.kind === "appeal" && q2.ap?.status === "open" && q2.a?.decision?.id === decisionId && q2.targetId === q2.ap.id && q2.ap.attemptId === q2.a.id && q2.e?.learnerId === context.learnerId);
  if (matches.length !== 1) throw new RecordCheckError("This assigned decision is unavailable for your account.", 404);
  const q = matches[0], resolved = tryResolvePinnedContent(q.e, context.content.allowedScopes, context.content.registry);
  if (!resolved.available) return unavailable("The exact assigned course is unavailable; its decision rubric was not checked.");
  try {
    if (!refString(q.e.id) || !refString(q.a.id) || !refString(q.ap.id) || !Number.isInteger(q.a.number) || q.a.number < 1 || q.a.number > 3 || !iso(q.a.submittedAt) || !iso(q.ap.createdAt) || Date.parse(q.ap.createdAt) > Date.parse(context.checkedAt) || q.ap.resolution !== void 0) throw new RecordCheckError("The assigned appeal references need inspection.");
    const original = decision(q.a.decision, "assessment", q.a.id, null, resolved.snapshot.program, context);
    if (original.actorRef === context.actorId || context.actorId === context.learnerId || (/* @__PURE__ */ new Set([q.a.id, q.ap.id, original.decisionId])).size !== 3 || Date.parse(original.decidedAt) < Date.parse(q.a.submittedAt) || Date.parse(q.ap.createdAt) < Date.parse(original.decidedAt)) throw new RecordCheckError("The assigned appeal is not independent or its timeline disagrees.");
    const snapshot = deepFreeze({ schemaVersion: 1, kind: "private-assigned-original-decision", workspaceId: context.workspaceId, enrollmentId: q.e.id, contentRef: pinnedRef(q.e), contentFingerprint: await snapshotChecksum(resolved.snapshot.program), classification: "Nonaccredited practice decision", decision: original, openAssignedAppealId: q.ap.id, checkedAt: context.checkedAt, asOfRevision: context.revision, limitations: ["Only the original decision already present in the current assigned appeal is checked", "No current practice-record status or other learner history is disclosed", "No raw evidence, notes, feedback, email or public bearer URL", "Current assignment/role must be rechecked by the API on each request"] });
    return deepFreeze({ outcome: "checked", snapshot, integrity: { algorithm: "SHA-256", checksum: await snapshotChecksum(snapshot), meaning: checksumMeaning } });
  } catch (e) {
    if (e instanceof RecordCheckError) return unavailable("The assigned decision metadata needs inspection; no validated snapshot was produced.");
    throw e;
  }
}

// ../../../work/aplyd-academy/lib/academy-authoring.ts
var AuthoringError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
  }
  status;
};
var copy = (value) => structuredClone(value);
function freshAuthoring() {
  return { drafts: [], publications: [] };
}
function scopedRef(host, ref) {
  try {
    const x = contentRef(ref);
    if (x.scope !== "global" && x.scope !== host.id) throw new AuthoringError("Content from another workspace is unavailable.", 404);
    return x;
  } catch (e) {
    if (e instanceof AuthoringError) throw e;
    throw new AuthoringError(e.message, e.status ?? 409);
  }
}
function workspaceRegistry(host) {
  return createCurriculumRegistry([...programs.map((program) => curriculumRegistry.resolve({ scope: "global", programId: program.id, versionId: LEGACY_CONTENT_VERSION })), ...(host.content?.publications ?? []).map((p) => p.snapshot)]);
}
function resolve(host, ref) {
  try {
    return workspaceRegistry(host).resolve(scopedRef(host, ref), ["global", host.id]);
  } catch (e) {
    if (e instanceof AuthoringError) throw e;
    throw new AuthoringError(e.message, e.status ?? 409);
  }
}
function requireAvailablePublication(host, refValue, now = (/* @__PURE__ */ new Date()).toISOString()) {
  const ref = scopedRef(host, refValue);
  if (ref.scope === "global") return resolve(host, ref);
  const p = host.content?.publications.find((p2) => p2.snapshot.ref.programId === ref.programId && p2.snapshot.ref.versionId === ref.versionId);
  if (!p || p.availability !== "available") throw new AuthoringError("This private pathway is closed to new cohort offerings and enrollment.", 409);
  if (!Number.isFinite(Date.parse(now))) throw new AuthoringError("A trusted action time is required.", 400);
  if (Date.parse(p.reviewDueAt) <= Date.parse(now)) throw new AuthoringError("Content review is due before new enrollment.", 409);
  return copy(p.snapshot);
}
function projectWorkspaceContent(host, user, neededRefs) {
  const m = host.members.find((m2) => m2.userId === user.userId);
  if (!m) throw new AuthoringError("Workspace not found.", 404);
  const admin = m.active && m.roles.includes("admin"), content = host.content ?? freshAuthoring();
  const keys = new Set(neededRefs.map((ref) => contentKey(scopedRef(host, ref))));
  const versions = content.publications.filter((p) => admin || keys.has(contentKey(p.snapshot.ref))).map((p) => copy(p.snapshot));
  return { versions, ...admin ? { drafts: copy(content.drafts), publications: content.publications.map((p) => ({ id: p.id, ref: p.snapshot.ref, title: p.snapshot.program.title, availability: p.availability, classification: p.snapshot.classification, authorName: p.authorName, reviewerName: p.reviewerName, publishedAt: p.publishedAt, reviewDueAt: p.reviewDueAt, documentHash: p.documentHash, retirement: p.retirement })) } : {} };
}
var WORST_REASON = String.fromCharCode(0).repeat(1e3);
var WORST_NAME = String.fromCharCode(0).repeat(80);

// ../../../work/aplyd-academy/lib/academy-support.ts
var SupportRuleError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "SupportRuleError";
  }
};
function member(t, userId, active = true) {
  const m = t.members.find((m2) => m2.userId === userId);
  if (!m) throw new SupportRuleError("Workspace support is unavailable for this account.", 404);
  if (active && !m.active) throw new SupportRuleError("Workspace access is no longer active. Your past requests remain available to read.", 403);
  return m;
}
var owner = (m) => m.active && m.roles.includes("admin");
function eligibleSupportHandler(t, m, r) {
  return !!m && m.active && m.userId !== r.requesterId && (owner(m) || m.roles.includes("facilitator") && ["learning", "content"].includes(r.category) && r.cohortId !== null && t.cohorts.some((c) => c.id === r.cohortId) && m.scopes.includes(r.cohortId));
}
function handler(t, r) {
  const m = t.members.find((m2) => m2.userId === r.assignedTo);
  return eligibleSupportHandler(t, m, r) ? m : null;
}
function canQueue(t, m, r) {
  return m.active && (owner(m) || m.roles.includes("facilitator") && ["learning", "content"].includes(r.category) && r.cohortId !== null && t.cohorts.some((c) => c.id === r.cohortId) && m.scopes.includes(r.cohortId));
}
function fullThread(t, r) {
  const effective = handler(t, r), { requesterId, assignedTo, ...safe } = structuredClone(r);
  return { ...safe, handlerName: effective?.name ?? null, messages: safe.messages.map(({ actorId, ...m }) => m), resolution: safe.resolution ? (({ actorId, ...v }) => v)(safe.resolution) : null, resolutions: safe.resolutions.map(({ actorId, ...v }) => v), events: safe.events.map(({ actorId, handlerId, previousHandlerId, ...e }) => e) };
}
function projectSupport(t, actorId) {
  const m = member(t, actorId, false), cases = t.support ?? [], mine = cases.filter((r) => r.requesterId === actorId).map((r) => fullThread(t, r));
  if (!m.active) return { mine, queue: [], assigned: [] };
  const queue = cases.filter((r) => canQueue(t, m, r)).map((r) => {
    const effective = handler(t, r);
    return { id: r.id, category: r.category, cohortId: r.cohortId, cohortTitle: r.cohortId ? t.cohorts.find((c) => c.id === r.cohortId)?.title ?? "Former cohort" : null, subject: r.subject, requesterName: r.requesterName, createdAt: r.createdAt, updatedAt: r.updatedAt, status: r.status, handlerName: effective?.name ?? null, canClaim: r.status === "open" && !effective && eligibleSupportHandler(t, m, r), eligibleHandlerAvailable: t.members.some((x) => eligibleSupportHandler(t, x, r)) };
  });
  const assigned = cases.filter((r) => handler(t, r)?.userId === actorId).map((r) => fullThread(t, r));
  return { mine, queue, assigned };
}

// ../../../work/aplyd-academy/lib/academy-network.ts
var network = (t) => t.network ?? { profiles: [], sessions: [] };
var canHost = (m, cid) => m.active && (m.roles.includes("admin") || m.roles.includes("facilitator") && m.scopes.includes(cid));
var eligible = (t, id2, cid, access) => {
  const m = t.members.find((x) => x.userId === id2);
  return !!m && access(t, m, cid);
};
var currentSeats = (t, s, access) => s.registrations.filter((r) => r.status === "going" && eligible(t, r.userId, s.cohortId, access));
function projectNetwork(t, m, access) {
  const n = network(t), self = n.profiles.find((p) => p.userId === m.userId), myProfile = self ? { enabled: self.enabled, bio: self.bio, focus: self.focus, cohortIds: self.cohortIds ?? [], consentedAt: self.consentedAt } : null;
  const history2 = n.sessions.flatMap((session) => {
    const r = session.registrations.find((x) => x.userId === m.userId);
    return r ? [{ id: session.id, title: session.title, cohortTitle: t.cohorts.find((x) => x.id === session.cohortId)?.title, startsAt: session.startsAt, endsAt: session.endsAt, status: session.status, myRsvp: r.status, cancellationReason: session.cancellation?.reason ?? r.cancellationReason ?? null, attendance: session.attendance.filter((a) => a.registrationId === r.id).map((a) => ({ id: a.id, status: a.status, reason: a.reason, actorName: a.actorName, createdAt: a.createdAt })) }] : [];
  });
  if (!m.active) return { myProfile, history: history2, directory: [], sessions: [] };
  const directory = n.profiles.filter((p) => p.enabled && p.cohortIds.some((id2) => access(t, m, id2) && eligible(t, p.userId, id2, access))).map((p) => ({ id: p.id, name: t.members.find((x) => x.userId === p.userId)?.name, bio: p.bio, focus: p.focus, cohortIds: p.cohortIds.filter((id2) => access(t, m, id2) && eligible(t, p.userId, id2, access)), isMe: p.userId === m.userId }));
  const sessions = n.sessions.filter((s) => access(t, m, s.cohortId)).map((s) => {
    const own = s.registrations.find((r) => r.userId === m.userId), host = s.hostId === m.userId && canHost(m, s.cohortId), seats2 = currentSeats(t, s, access), roster = s.registrations.filter((r) => eligible(t, r.userId, s.cohortId, access) && (r.status === "going" || r.cancelledAt && Date.parse(r.cancelledAt) > Date.parse(s.startsAt) && Date.parse(r.confirmedAt ?? r.createdAt) <= Date.parse(s.startsAt))), validHost = eligible(t, s.hostId, s.cohortId, access) && canHost(t.members.find((x) => x.userId === s.hostId), s.cohortId);
    const current = (rid) => {
      const a = s.attendance.filter((a2) => a2.registrationId === rid).at(-1);
      if (!a) return null;
      const { actor, ...safe } = a;
      return safe;
    };
    return { id: s.id, cohortId: s.cohortId, title: s.title, description: s.description, startsAt: s.startsAt, endsAt: s.endsAt, capacity: s.capacity, occupied: seats2.length, status: s.status, hostName: t.members.find((x) => x.userId === s.hostId)?.name, hostAvailable: validHost, isHost: host, canCancel: host || m.roles.includes("admin"), myRsvp: own?.status ?? "none", myAttendance: own ? current(own.id) : null, ...s.cancellation ? { cancellation: { reason: s.cancellation.reason, createdAt: s.cancellation.createdAt } } : {}, ...s.status === "scheduled" && validHost && (host || own?.status === "going") ? { instructions: s.instructions } : {}, ...host ? { registrations: roster.map((r) => ({ id: r.id, name: t.members.find((x) => x.userId === r.userId)?.name, attendance: current(r.id) ?? null })), attendanceHistory: s.attendance.map(({ actor, ...a }) => a) } : {} };
  });
  return { myProfile, history: history2, directory, sessions };
}

// ../../../work/aplyd-academy/lib/academy-teams.ts
var copy2 = (x) => structuredClone(x);
var label = (u) => u.fullName || "Academy member";
function member2(t, userId, active = true) {
  const m = t.members.find((m2) => m2.userId === userId);
  if (!m) throw new RuleError("Workspace not found for your account.", 404);
  if (active && !m.active) throw new RuleError("Your workspace access has been removed. Your own learning history remains readable.", 403);
  return m;
}
function cohort(t, id2) {
  const c = t.cohorts.find((c2) => c2.id === id2);
  if (!c) throw new RuleError("Cohort not found.", 404);
  return c;
}
function target(t, userId, enrollmentId) {
  const l = t.learners.find((l2) => l2.userId === userId), e = l?.state.enrollments.find((e2) => e2.id === enrollmentId);
  if (!l || !e) throw new RuleError("Enrollment not found in this workspace.", 404);
  return { l, e, c: cohort(t, e.cohortId) };
}
function boardAccess(t, m, cid) {
  return m.active && (m.roles.includes("admin") || m.scopes.includes(cid) && m.roles.some((r) => ["facilitator", "assessor", "reviewer", "moderator"].includes(r)) || m.roles.includes("learner") && t.learners.find((l) => l.userId === m.userId)?.state.enrollments.some((e) => e.cohortId === cid && !e.withdrawn));
}
function seats(t, cid) {
  return t.learners.reduce((n, l) => n + l.state.enrollments.filter((e) => e.cohortId === cid && !e.withdrawn).length, 0);
}
function pending(t) {
  return t.learners.flatMap((l) => l.state.enrollments.flatMap((e) => [
    ...e.attempts.filter((a) => !a.decision && !e.withdrawn).map((a) => ({ kind: "assessment", targetId: a.id, enrollmentId: e.id, learnerId: l.userId, cohortId: e.cohortId, programId: e.programId, number: a.number, createdAt: a.submittedAt })),
    ...e.appeals.filter((ap) => ap.status === "open" && !e.withdrawn).map((ap) => ({ kind: "appeal", targetId: ap.id, enrollmentId: e.id, learnerId: l.userId, cohortId: e.cohortId, programId: e.programId, createdAt: ap.createdAt, originalActor: e.attempts.find((a) => a.id === ap.attemptId)?.decision?.actor }))
  ]));
}
function eligible2(t, m, q) {
  return m?.active && m.userId !== q.learnerId && m.userId !== q.originalActor && m.roles.includes(q.kind === "appeal" ? "reviewer" : "assessor") && m.scopes.includes(q.cohortId);
}
function projectTeam(t, u) {
  const m = member2(t, u.userId, false), own = t.learners.find((l) => l.userId === u.userId), state = copy2(own?.state ?? freshWorkspace());
  if (!own) {
    state.profile.name = label(u);
    state.profile.context = t.context;
  }
  const admin = m.active && m.roles.includes("admin"), qs = pending(t);
  state.paused = t.cohorts.filter((c) => c.status === "paused" && state.enrollments.some((e) => e.cohortId === c.id)).map((c) => c.programId);
  const visibleCohorts = t.cohorts.filter((c) => m.active ? m.roles.includes("learner") || boardAccess(t, m, c.id) : state.enrollments.some((e) => e.cohortId === c.id));
  const isMod = (cid) => m.active && m.roles.includes("moderator") && m.scopes.includes(cid);
  state.posts = m.active ? t.posts.filter((p) => boardAccess(t, m, p.cohortId) && (p.status === "visible" || p.authorId === u.userId || isMod(p.cohortId))).map((p) => {
    const x = copy2(p);
    delete x.authorId;
    x.replies = x.replies.filter((r) => r.status === "visible" || r.authorId === u.userId || isMod(p.cohortId)).map((r) => {
      const z = copy2(r);
      delete z.authorId;
      return z;
    });
    return x;
  }) : [];
  state.reports = m.active ? t.reports.filter((r) => {
    const p = t.posts.find((p2) => p2.id === r.postId);
    return p && isMod(p.cohortId);
  }).map((r) => ({ id: r.id, postId: r.postId, reason: r.reason, status: r.status, createdAt: r.createdAt })) : [];
  const assigned = qs.filter((q) => eligible2(t, m, q) && t.assignments.some((a) => a.kind === q.kind && a.targetId === q.targetId && a.staffId === u.userId)).map((q) => {
    const { e } = target(t, q.learnerId, q.enrollmentId), ap = q.kind === "appeal" ? e.appeals.find((ap2) => ap2.id === q.targetId) : void 0, a = e.attempts.find((a2) => a2.id === (ap?.attemptId ?? q.targetId));
    return { ...q, learnerName: t.members.find((m2) => m2.userId === q.learnerId)?.name, e: { id: e.id, learnerId: q.learnerId, programId: e.programId, version: e.version, ...e.contentRef ? { contentRef: copy2(e.contentRef) } : {}, cohortId: e.cohortId }, a: copy2(a), ...ap ? { ap: copy2(ap) } : {} };
  });
  const summaries = t.learners.flatMap((l) => l.state.enrollments.filter((e) => admin || m.active && m.roles.includes("facilitator") && m.scopes.includes(e.cohortId)).map((e) => ({ learnerId: l.userId, learnerName: t.members.find((m2) => m2.userId === l.userId)?.name, cohortId: e.cohortId, programId: e.programId, completedLessons: e.completed.length, practiceRecordStatus: e.record?.status ?? null, hasOpenAppeal: !e.withdrawn && e.appeals.some((ap) => ap.status === "open"), hasPendingAssessment: !e.withdrawn && e.attempts.some((a) => !a.decision), status: e.withdrawn ? "Withdrawn" : e.record?.status === "active" ? "Practice completed" : e.appeals.some((ap) => ap.status === "open") ? "Appeal pending" : e.attempts.some((a) => !a.decision) ? "Review pending" : "Learning" })));
  const result = { state, team: { currentUserId: u.userId, id: t.id, name: t.name, purpose: t.purpose, context: t.context, roles: m.active ? m.roles : [], active: m.active, support: projectSupport(t, u.userId), network: projectNetwork(t, m, boardAccess), cohorts: visibleCohorts.map((c) => ({ ...c, ...cohortContentAvailability(t, c), occupied: seats(t, c.id), boardAccess: boardAccess(t, m, c.id), canModerate: isMod(c.id), canHost: m.active && (admin || m.roles.includes("facilitator") && m.scopes.includes(c.id)) })), moderationHistory: (t.moderation ?? []).filter((x) => isMod(x.cohortId)), ...admin ? { activity: t.activity ?? [], members: t.members.map((m2) => ({ ...m2 })), invites: t.invites.map(({ tokenHash, ...i }) => i), pending: qs.map((q) => ({ ...q, learnerName: t.members.find((m2) => m2.userId === q.learnerId)?.name, assignedTo: t.assignments.find((a) => a.kind === q.kind && a.targetId === q.targetId)?.staffId, eligibleStaff: t.members.filter((m2) => eligible2(t, m2, q)).map((m2) => ({ userId: m2.userId, name: m2.name })) })) } : {}, assigned, summaries } };
  const neededRefs = [];
  for (const record of [...result.state.enrollments, ...result.team.cohorts, ...result.team.assigned.map((q) => q.e)]) {
    try {
      const ref = pinnedRef(record);
      if (ref.scope === "global" || ref.scope === t.id) neededRefs.push(ref);
    } catch (e) {
      if (!(e instanceof ContentResolutionError)) throw e;
    }
  }
  const content = projectWorkspaceContent(t, u, neededRefs);
  return { ...result, contentVersions: content.versions, team: { ...result.team, ...admin ? { content: { drafts: content.drafts, publications: content.publications } } : {} } };
}
function cohortContentAvailability(t, c) {
  try {
    requireAvailablePublication(t, pinnedRef(c));
    return { contentOpen: true, contentNotice: null };
  } catch (e) {
    if (e instanceof AuthoringError || e instanceof ContentResolutionError) return { contentOpen: false, contentNotice: e.message };
    throw e;
  }
}

// academy-record-service.ts
var plain2 = (v) => !!v && typeof v === "object" && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
var id = (v) => typeof v === "string" && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,119}$/.test(v);
var subject = (v) => typeof v === "string" && v.trim() === v && v.length > 0 && v.length <= 300 && !/[\u0000-\u001f\u007f]/.test(v);
var revision = (v) => Number.isSafeInteger(v) && Number(v) >= 0;
var canonicalTime = (v) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(v) && Number.isFinite(Date.parse(v)) && new Date(v).toISOString() === v;
function parseRecordCheckRequest(value) {
  if (!plain2(value) || Object.keys(value).some((k) => !["workspaceId", "sourceRevision", "recordId", "decisionId"].includes(k)) || !Object.hasOwn(value, "workspaceId") || !Object.hasOwn(value, "sourceRevision") || !revision(value.sourceRevision) || value.workspaceId !== null && (typeof value.workspaceId !== "string" || !/^tw-[a-z0-9-]{20,80}$/i.test(value.workspaceId)) || Object.hasOwn(value, "recordId") === Object.hasOwn(value, "decisionId")) throw new RecordCheckError("Choose an exact private record and current saved revision.", 400);
  const own = Object.hasOwn(value, "recordId"), reference = value[own ? "recordId" : "decisionId"];
  if (!id(reference) || !own && value.workspaceId === null) throw new RecordCheckError("Choose an exact private record or currently assigned shared appeal.", 400);
  return Object.freeze({ workspaceId: value.workspaceId, sourceRevision: value.sourceRevision, target: Object.freeze({ kind: own ? "record" : "decision", id: reference }) });
}
function assertRecordRevision(actual, expected) {
  if (!revision(actual)) throw new RecordCheckError("The saved learning revision is temporarily unavailable.", 503);
  if (actual !== expected) throw new RecordCheckError("Your learning space changed. Refresh before checking this record.", 409);
}
async function checkSavedPracticeRecord(input) {
  const { user, request, row, checkedAt } = input;
  if (!subject(user.userId) || !canonicalTime(checkedAt)) throw new RecordCheckError("The authenticated record check is temporarily unavailable.", 503);
  let result;
  if (request.workspaceId === null) {
    assertRecordRevision(row?.revision ?? 0, request.sourceRevision);
    if (request.target.kind !== "record") throw new RecordCheckError("This assigned decision is unavailable for your account.", 404);
    const state = row ? JSON.parse(row.data) : freshWorkspace();
    result = await lookupOwnPracticeRecord(state, { recordId: request.target.id }, { actorId: user.userId, learnerId: user.userId, space: "personal", workspaceId: null, revision: request.sourceRevision, checkedAt, content: { registry: curriculumRegistry, allowedScopes: ["global"] } });
  } else {
    if (!row) throw new RecordCheckError("This private learning space is unavailable for your account.", 404);
    const team = JSON.parse(row.data);
    if (!plain2(team) || team.id !== request.workspaceId) throw new RecordCheckError("The saved learning space needs inspection.", 503);
    const projection = projectTeam(team, user);
    assertRecordRevision(row.revision, request.sourceRevision);
    const content = { registry: workspaceRegistry(team), allowedScopes: ["global", team.id] };
    const context = { actorId: user.userId, learnerId: user.userId, space: "shared", workspaceId: team.id, revision: request.sourceRevision, checkedAt, content };
    if (request.target.kind === "record") result = await lookupOwnPracticeRecord(projection.state, { recordId: request.target.id }, context);
    else {
      const matches = projection.team.assigned.filter((q) => q.kind === "appeal" && q.ap?.status === "open" && q.a?.decision?.id === request.target.id);
      if (matches.length !== 1 || !subject(matches[0].e?.learnerId)) throw new RecordCheckError("This assigned decision is unavailable for your account.", 404);
      result = await lookupAssignedDecision(projection, { decisionId: request.target.id }, { ...context, learnerId: matches[0].e.learnerId });
    }
  }
  return deepFreeze({ format: "aplyd-academy-private-record-check", formatVersion: 1, currentUserId: user.userId, workspaceId: request.workspaceId, sourceRevision: request.sourceRevision, checkedAt, target: request.target, result });
}

// route.ts
var headers = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer" };
var response = (value, status = 200) => Response.json(value, { status, headers });
async function POST(request) {
  try {
    const origin = request.headers.get("origin");
    if (origin && origin !== new URL(request.url).origin) throw new RecordCheckError("Use your Academy to check a private record.", 403);
    if ((request.headers.get("content-type") ?? "").split(";")[0].trim() !== "application/json") throw new RecordCheckError("Use a JSON record-check request.", 415);
    const raw = await request.text();
    if (raw.length > 2e3 || new TextEncoder().encode(raw).byteLength > 4e3) throw new RecordCheckError("This record-check request is too large.", 413);
    let value;
    try {
      value = JSON.parse(raw);
    } catch {
      throw new RecordCheckError("The record-check request is not valid JSON.", 400);
    }
    const input = parseRecordCheckRequest(value), user = await getChatGPTUser();
    if (!user) throw new RecordCheckError("Sign in to check your private learning record.", 401);
    const db = env.DB;
    if (!db) throw new RecordCheckError("Your private record check is temporarily unavailable.", 503);
    const load = () => input.workspaceId === null ? db.prepare("SELECT data,revision FROM academy_workspaces WHERE owner=?").bind(user.userId).first() : db.prepare("SELECT data,revision FROM academy_teams WHERE id=?").bind(input.workspaceId).first();
    const row = await load();
    if (input.workspaceId !== null && !row) throw new RecordCheckError("This private learning space is unavailable for your account.", 404);
    const result = await checkSavedPracticeRecord({ user, request: input, row, checkedAt: (/* @__PURE__ */ new Date()).toISOString() });
    const current = input.workspaceId === null ? await db.prepare("SELECT revision FROM academy_workspaces WHERE owner=?").bind(user.userId).first() : await db.prepare("SELECT revision FROM academy_teams WHERE id=?").bind(input.workspaceId).first();
    if (input.workspaceId !== null && !current) throw new RecordCheckError("Your learning space changed. Refresh before checking this record.", 409);
    assertRecordRevision(current?.revision ?? 0, input.sourceRevision);
    return response(result);
  } catch (error) {
    if (error instanceof RecordCheckError || error instanceof RuleError) return response({ error: error.message }, error.status);
    return response({ error: "The private record check could not be completed. No learning data was changed." }, 503);
  }
}
export {
  POST,
  env,
  setIdentity
};
