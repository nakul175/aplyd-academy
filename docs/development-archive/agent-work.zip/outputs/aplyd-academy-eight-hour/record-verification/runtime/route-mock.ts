export const env:{DB:any}={DB:null};
let identity:any=null;
export function setIdentity(value:any){identity=value;}
export async function getChatGPTUser(){return identity;}
