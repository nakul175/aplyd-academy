import assert from 'node:assert/strict';
import {withReadOnlyRoute,fetchReadOnlyResponse} from '../tests/read-only-routing.mjs';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {existsSync} from 'node:fs';
import {dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),nearby=resolve(here,'../..'),app=resolve(process.env.ACADEMY_APP_PATH??(existsSync(nearby+'/app/api/academy/route.ts')?nearby:existsSync('app/api/academy/route.ts')?'.':'work/aplyd-academy')),output=resolve(process.env.ACADEMY_OFFERING_QA_OUTPUT??here+'/../runtime'),modelUrl=pathToFileURL(resolve(process.env.ACADEMY_OFFERING_MODEL_BUNDLE??output+'/model.mjs')).href;
assert.equal(process.env.ACADEMY_EXACT_OFFERING_WORKER_READY,'1','Wait for root stable exact-offering integration Worker signal before any browser/network action.');
const fixturePath=resolve(process.env.ACADEMY_READONLY_FIXTURES??'outputs/aplyd-academy-eight-hour/record-verification/integrated/evidence/fixtures.json');
const f=JSON.parse(readFileSync(fixturePath,'utf8'));
assert.ok(f.person?.id&&f.other?.id&&f.personTeam?.id,'Use already approved existing fictional readers; this suite never creates one.');
const base=process.env.ACADEMY_LOCAL_URL??'http://127.0.0.1:8787',origin=new URL(base).origin;
assert.ok(['127.0.0.1','localhost','[::1]'].includes(new URL(base).hostname));
const headers=u=>({'oai-authenticated-user-id':u.id,'oai-authenticated-user-email':u.email,'oai-authenticated-user-full-name':encodeURIComponent(u.name),'oai-authenticated-user-full-name-encoding':'percent-encoded-utf-8'});
const httpRequests=[];
async function get(u,path){assert.ok(path.startsWith('/api/'));const r=await fetch(base+path,{method:'GET',headers:headers(u),redirect:'manual'});httpRequests.push({method:'GET',path,status:r.status});assert.equal(r.status,200,`Existing reader GET ${path}`);return r.json();}
const {createTeam,applyTeamCommand,projectTeam,applyWorkspaceContentCommand,freshWorkspace,learningNavigationHash}=await import(modelUrl);
const {chromium,browserOptions}=await import(pathToFileURL(app+'/tests/scoped-workbench-qa/browser-runtime.mjs'));
const seed=JSON.parse(readFileSync(app+'/lib/curriculum-versions/0.1-review-draft.json','utf8'));
const evidence=resolve(process.env.ACADEMY_OFFERING_BROWSER_OUTPUT??output+'/browser');mkdirSync(evidence,{recursive:true});
const save=(file,v)=>writeFileSync(evidence+'/'+file,JSON.stringify(v,null,2)+'\n');
const files=['app/academy-learning.tsx','lib/academy-offering-navigation.ts','lib/academy-before-start.mjs','lib/academy-before-start.d.mts','app/academy.tsx','app/academy-acceptance.ts','lib/academy-engine.ts','lib/academy-authoring.ts','lib/academy-curriculum.ts','lib/curriculum-versions/0.1-review-draft.json'];
const hashes=()=>Object.fromEntries(files.map(file=>[file,createHash('sha256').update(readFileSync(app+'/'+file)).digest('hex')]));
const now=new Date().toISOString(),due=new Date(Date.now()+180*86400000).toISOString(),user={userId:f.person.id,email:f.person.email,fullName:f.person.name};
let t=createTeam(user,{name:f.personTeam.name,purpose:'Ephemeral display-only private course editions; never saved.',context:'msme'},f.personTeam.id,now);
t.members.push({userId:'display-independent-reviewer',name:'In-memory reviewer',email:'display-reviewer@academy.test',active:true,roles:['admin'],scopes:[],joinedAt:now});
async function publication(sourceRef,title,prerequisite){
 t=await applyWorkspaceContentCommand(t,user,{type:'content-copy',sourceRef},now);let d=t.content.drafts.at(-1),doc=structuredClone(d.document);doc.title=title;doc.prerequisites=[prerequisite,'Use the fictional packet and ask the named reviewer when a source is uncertain.'];
 t=await applyWorkspaceContentCommand(t,user,{type:'content-save',draftId:d.id,revision:d.revision,document:doc},now);d=t.content.drafts.at(-1);
 t=await applyWorkspaceContentCommand(t,user,{type:'content-submit',draftId:d.id,revision:d.revision,reviewerId:'display-independent-reviewer',reviewDueAt:due},now);d=t.content.drafts.at(-1);
 t=await applyWorkspaceContentCommand(t,{userId:'display-independent-reviewer'},{type:'content-review',draftId:d.id,revision:d.revision,decision:'approve',note:'Read-only in-memory fixture review of fictional source, rubric, answers and safety.',checks:{sources:true,answers:true,rubric:true,safety:true,accessibility:true}},now);d=t.content.drafts.at(-1);
 t=await applyWorkspaceContentCommand(t,user,{type:'content-publish',draftId:d.id,revision:d.revision},now);return t.content.publications.at(-1).snapshot;
}
const old=await publication({scope:'global',programId:seed.pathways[1].id,versionId:seed.contentVersion},'Display fixture — earlier customer practice','Earlier edition: read the fictional order policy before making a promise.');
const newer=await publication(old.ref,'Display fixture — revised customer practice','Revised edition: read the revised source checklist before making a promise.');
t=await applyTeamCommand(t,user,{type:'cohort-create',title:'Earlier display cohort',programId:old.ref.programId,contentRef:old.ref,capacity:5},now);
t=await applyTeamCommand(t,user,{type:'cohort-create',title:'Revised display cohort',programId:newer.ref.programId,contentRef:newer.ref,capacity:5},now);
const oldCohort=t.cohorts[0].id;
function teamVariant(kind='normal'){
 let team=structuredClone(t);
 if(['withdrawn','removed','own-active'].includes(kind)){
  team=applyTeamCommand(team,user,{type:'enroll',programId:old.ref.programId,cohortId:oldCohort},now);
  const e=team.learners[0].state.enrollments[0];if(kind!=='own-active')team=applyTeamCommand(team,user,{type:'withdraw',enrollmentId:e.id},now);
  if(kind==='removed')team.members.find(m=>m.userId===user.userId).active=false;
 }
 if(kind==='no-learner')team.members.find(m=>m.userId===user.userId).roles=['admin'];
 if(kind==='closed')team.cohorts[1].status='closed';
 if(kind==='paused')team.cohorts[1].status='paused';
 if(kind==='full'){team.cohorts[1].capacity=1;team.members.find(m=>m.userId==='display-independent-reviewer').roles=['admin','learner'];team=applyTeamCommand(team,{userId:'display-independent-reviewer',email:'display-reviewer@academy.test',fullName:'In-memory reviewer'},{type:'enroll',programId:newer.ref.programId,cohortId:team.cohorts[1].id},now);}
 const projected=projectTeam(team,user);
 if(kind==='missing-policy')for(const s of projected.contentVersions)delete s.policy;
 if(kind==='unsupported-policy')for(const s of projected.contentVersions)s.policy.minimumWeightedScore=75;
 if(kind==='high-rubric')for(const s of projected.contentVersions)s.program.practicalAssessment.rubric.forEach(r=>r.weight*=2);
 if(kind==='literal')for(const s of projected.contentVersions)s.program.prerequisites=['<img src=x onerror=window.__beforeStartXss=1> is literal fictional text.'];
 if(kind==='unknown-pin'){projected.contentVersions=[];for(const c of projected.team.cohorts){c.version='unknown-retained-version';c.contentRef.versionId=c.version;c.contentOpen=false;c.contentNotice='Saved exact publication unavailable.';}}
 return projected;
}
const sourceHashes=hashes(),cases=[],requests=[],forbidden=[],errors=[],contexts=[],focusChecks=[];
const harnessFiles=['browser-readonly.mjs','read-only-routing.mjs'];
const harnessHashes=()=>Object.fromEntries(harnessFiles.map(file=>[file,createHash('sha256').update(readFileSync(resolve(here,'../tests',file))).digest('hex')]));
const inspectedHarnessHashes=harnessHashes(),modelHash=createHash('sha256').update(readFileSync(fileURLToPath(modelUrl))).digest('hex');
const runtimeDist=process.env.ACADEMY_OFFERING_RUNTIME_DIST;
const runtimeHashes=()=>runtimeDist?Object.fromEntries(['server/index.js','server/wrangler.json'].map(file=>[file,createHash('sha256').update(readFileSync(resolve(runtimeDist,file))).digest('hex')])):null;
assert.ok(runtimeDist,'Root frozen dist path is required before browser acceptance.');
assert.ok(process.env.ACADEMY_QA_WORKER,'Root stable Worker session is required.');
const copiedRuntimeHashes=runtimeHashes(),builtEntry=resolve(process.env.ACADEMY_OFFERING_BUILT_ENTRY??app+'/dist/server/index.js');
const builtEntryHash=()=>createHash('sha256').update(readFileSync(builtEntry)).digest('hex');
const sourceBuildHash=builtEntryHash();assert.equal(copiedRuntimeHashes['server/index.js'],sourceBuildHash,'Root built entry must equal frozen preview entry.');
let browser,passed=false;
async function scenario(name,fn){try{await fn();cases.push({name,passed:true});console.log(name+': passed');}catch(e){cases.push({name,passed:false,error:String(e)});throw e;}}
const panel=p=>p.locator('section.source-packet').filter({has:p.getByRole('heading',{name:'Before you start',exact:true})});
const frames=p=>p.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
async function mainHasFocus(p,stage){await frames(p);const info=await p.evaluate(()=>({id:document.activeElement?.id??null,tag:document.activeElement?.tagName??null,role:document.activeElement?.getAttribute('role')??null,mainExists:!!document.getElementById('main')}));focusChecks.push({stage,...info});assert.equal(info.id,'main',stage+': existing full-route navigation should focus main; actual '+JSON.stringify(info));}
async function page({u=f.other,workspace=null,variant=null,empty=false,width=1440,pathway=null,hash=null}={}){
 const c=await browser.newContext({extraHTTPHeaders:headers(u),viewport:{width,height:1000}}),p=await c.newPage();contexts.push(c);p.setDefaultTimeout(12000);
 await p.route('**/*',route=>withReadOnlyRoute(route,origin,forbidden,async safe=>{const response=await fetchReadOnlyResponse(safe,origin,forbidden);if(response)return safe.fulfill({response});}));
 if(empty)await p.route('**/api/academy',route=>withReadOnlyRoute(route,origin,forbidden,async safe=>{const response=await fetchReadOnlyResponse(safe,origin,forbidden);if(!response)return;const json=await response.json();assert.equal(json.currentUserId,u.id);const state=freshWorkspace();state.profile={...state.profile,...json.state.profile};json.state=state;return safe.fulfill({response,json});}));
 if(variant)await p.route('**/api/teams?*',route=>withReadOnlyRoute(route,origin,forbidden,async safe=>{const url=new URL(safe.request().url());if(url.searchParams.get('id')!==workspace){const response=await fetchReadOnlyResponse(safe,origin,forbidden);if(response)return safe.fulfill({response});return;}const response=await fetchReadOnlyResponse(safe,origin,forbidden);if(!response)return;const json=await response.json();assert.equal(json.team.currentUserId,u.id);assert.equal(json.team.id,workspace);return safe.fulfill({response,json:{...json,...structuredClone(variant)}});}));
 p.on('request',r=>requests.push({method:r.method(),path:new URL(r.url()).pathname}));p.on('pageerror',e=>errors.push(e.message));
 await p.goto(base+'/'+(workspace?'?workspace='+encodeURIComponent(workspace):'')+(hash?'#'+hash:pathway?'#learn/'+encodeURIComponent(pathway):'#programs'));
 await p.locator('[data-save-state="loaded"]').waitFor();return {p,c};
}
async function choose(p,title){await p.locator('.pathway-card').filter({has:p.getByRole('heading',{name:title,exact:true})}).click();await panel(p).waitFor();}
async function textEquals(p,snapshot){const section=panel(p);await section.waitFor();assert.deepEqual(await section.locator('li').allTextContents(),snapshot.program.prerequisites);await p.getByRole('heading',{name:snapshot.program.title,exact:true}).waitFor();}
const target=snapshot=>({workspaceId:f.personTeam.id,cohortId:t.cohorts.find(c=>c.contentRef.versionId===snapshot.ref.versionId).id,contentRef:snapshot.ref});
const hash=snapshot=>learningNavigationHash('learn',snapshot.ref.programId,{offering:target(snapshot)});

const diagnostics=[];
async function capture(p,stage){const state=await p.evaluate(stage=>{const e=document.activeElement;return {stage,at:performance.now(),hash:location.hash,active:{tag:e?.tagName??null,role:e?.getAttribute('role')??null,id:e?.id??null,text:e?.textContent?.trim()??null},expanded:document.querySelector('[role=combobox][aria-label="Cohort for this pathway"]')?.getAttribute('aria-expanded'),options:[...document.querySelectorAll('[role=option]')].map(e=>({text:e.textContent?.trim(),selected:e.getAttribute('aria-selected'),state:e.getAttribute('data-state'),focused:e===document.activeElement})),heading:document.querySelector('main h1')?.textContent,prerequisites:[...document.querySelectorAll('section.source-packet li')].map(e=>e.textContent)};},stage);return state;}
async function observe(p){await p.evaluate(()=>{window.__offeringPickerTrace=[];for(const type of ['focusin','keydown','keyup'])document.addEventListener(type,event=>{const e=document.activeElement;window.__offeringPickerTrace.push({type,key:event.key??null,at:performance.now(),tag:e?.tagName??null,role:e?.getAttribute('role')??null,text:e?.getAttribute('role')==='option'||e?.getAttribute('role')==='combobox'?e.textContent?.trim():null,hash:location.hash});},true);});}
const optionFocus=(p,text)=>p.waitForFunction(text=>document.activeElement?.getAttribute('role')==='option'&&document.activeElement.textContent?.trim()===text,text);
try{
 browser=await chromium.launch(browserOptions);
 for(const doubled of [false,true])for(const mode of ['original-fast','focused-readiness']){
  const record={width:390,bodyPx:doubled?32:16,mode,stages:[],events:[]};diagnostics.push(record);
  const {p,c}=await page({u:f.person,workspace:f.personTeam.id,variant:teamVariant(),width:390,hash:hash(newer)});
  await textEquals(p,newer);if(doubled)await p.addStyleTag({content:'html, body { font-size:32px !important; }'});await frames(p);await observe(p);
  const picker=p.getByRole('combobox',{name:'Cohort for this pathway',exact:true});await picker.focus();await p.keyboard.press('Enter');await p.getByRole('option',{name:'Earlier display cohort · 5 places',exact:true}).waitFor();
  record.stages.push(await capture(p,'immediately after options visible'));
  if(mode==='focused-readiness'){await frames(p);record.stages.push(await capture(p,'after two animation frames'));await optionFocus(p,'Revised display cohort · 5 places');record.stages.push(await capture(p,'focused selected option before Home'));}
  else record.stages.push(await capture(p,'before fast Home'));
  await p.keyboard.press('Home');
  if(mode==='focused-readiness'){record.stages.push(await capture(p,'immediately after Home'));await optionFocus(p,'Earlier display cohort · 5 places');record.stages.push(await capture(p,'focused earlier option before Enter'));}
  await p.keyboard.press('Enter');await p.waitForFunction(()=>document.querySelector('[role=combobox][aria-label="Cohort for this pathway"]')?.getAttribute('aria-expanded')==='false');record.stages.push(await capture(p,'after Enter popup closed'));await frames(p);record.stages.push(await capture(p,'after final two animation frames'));record.events=await p.evaluate(()=>window.__offeringPickerTrace);
  record.selectedEarlier=new URL(p.url()).hash==='#'+hash(old);record.finalPickerFocus=await picker.evaluate(e=>e===document.activeElement);record.currentCohortText=await picker.innerText();
  if(mode==='focused-readiness'){await textEquals(p,old);assert.equal(record.selectedEarlier,true);assert.equal(record.finalPickerFocus,true);}
  await p.screenshot({path:evidence+`/picker-${mode}-${doubled?'body32':'normal'}.png`,fullPage:false});await c.close();
 }
 assert.deepEqual(forbidden,[]);assert.deepEqual(errors,[]);assert.ok(requests.every(r=>['GET','HEAD'].includes(r.method)));assert.deepEqual(hashes(),sourceHashes);assert.deepEqual(runtimeHashes(),copiedRuntimeHashes);assert.equal(builtEntryHash(),sourceBuildHash);passed=true;
}catch(e){for(const [i,c]of contexts.entries())for(const p of c.pages())await p.screenshot({path:evidence+'/diagnostic-failure-'+i+'.png',fullPage:false}).catch(()=>{});throw e;}
finally{if(browser)await browser.close();save('picker-diagnostic.json',{passed,at:new Date().toISOString(),worker:process.env.ACADEMY_QA_WORKER,base,runtimeDist,copiedRuntimeHashes,builtEntry,sourceBuildHash,modelHash,sourceHashes,diagnostics,requests,httpRequests,forbidden,pageErrors:errors,baselineInvarianceChecked:false,limits:['Bounded read-only diagnostic; browser event listeners observe focus/key metadata only.','Existing approved reader; pure-domain memory-only GET-display team projection; no command or persisted fixture.','All transport same-origin GET/HEAD with maxRedirects0; redirects refused.','Full baseline before/after equality is pending the final full rerun; this diagnostic does not claim it.','Original failed browser-final is retained unchanged; its unconditional before/after wording did not indicate whether the final equality gate ran.','32px body is text enlargement, not measured browser zoom.']});console.log(JSON.stringify({passed,diagnosticCases:diagnostics.length,results:diagnostics.map(x=>({mode:x.mode,bodyPx:x.bodyPx,selectedEarlier:x.selectedEarlier,finalPickerFocus:x.finalPickerFocus})),forbidden:forbidden.length,pageErrors:errors.length}));}
