M5 exact offering navigation — independent read-only acceptance plan

Status: source review only; every runtime case below is PLANNED / NOT EXECUTED.
Root owns adoption, application typecheck/build, frozen preview, Git and publication.
functional_integration_qa owns the mutable candidate. This reviewer changed only
files in this folder; no checkout edit, command/API call, browser, Worker, test run,
server, synthetic persisted record or hosted Site was used for this review.

Finding and intended result
The retained M4 report proves that one collapsed private catalog card can display
its final cohort's newer document while a click opens the first open cohort's older
document. Current checkout app/academy.tsx builds that collapsed Map and passes
only programId; app/academy-learning.tsx chooses its default cohort independently.
The proposed helper carries (workspaceId, cohortId, scope, programId, versionId)
together. A course card's title, cohort label, preparation material and exact URL
must agree, and an active own enrollment remains the primary saved source.

The candidate inspected here is not frozen. inspected-sources.json identifies the
reviewed bytes. Its owner reports 30 pure groups and UI syntax checks; this reviewer
has not independently run those checks or accepted integrated runtime behavior.
The source-level assertions in acceptance-cases.tsv describe the acceptance oracle,
not a pass report. Refresh candidate/source hashes after root adoption.

Required fixture recommendations (memory-only display variants)
F0: Approved existing personal reader + own saved global enrollment; use its actual
lesson IDs and completion state for legacy direct links. Never invent a persisted
completion or account to make a test pass.
F1: Approved existing workspace reader + current exact accepted workspace projection.
In memory only, use the actual pure authoring/team functions to derive earlier and
revised private publications of the same program and two independently pinned open
cohorts. Give their titles, prerequisites and cohort labels distinct fictional text.
Return that projection only for this reader's verified same-origin current GET.
F2: Derive F1 but remove only the selected publication from contentVersions. Keep
its cohort ID and full contentRef unchanged. The cohort can now have contentOpen
false and an unavailable-source notice, as the real projector would provide. Leave
the alternate publication/cohort available. This proves missing source is different
from missing or repointed cohort and cannot trigger alternate/global fallback.
F3: Derive an own older active enrollment in F1 purely in memory through the actual
team command, then drop only its exact older snapshot. Retain the new publication
and new cohort. Keep own enrollment ID/pin/progress intact. Open the new exact
URL; the unavailable saved enrollment must win over the available new offering.
F4: Derive F1 adverse client states: no learner permission, inactive membership,
closed/paused/full/content-review-due, and a withheld/denied current GET. Respect
actual accepted projection shapes; do not add private snapshots from a foreign
workspace. For a foreign intent, alter only bounded URL metadata.
F5: Derive F1 with own withdrawn history only. It must not override the explicit
current offering, yet the retained history must not be changed by navigation.

Execution gates and evidence
Do not execute until root adopts the reviewed candidate, passes the required full
application checks and explicitly signals a stable new frozen Worker/dist. Use only
existing approved reader IDs or clearly labelled in-memory GET-display variants.
The automatic-review rejection of persisted fictional fixture creation is still
binding; this plan is not an authorization to create or mutate a fixture.
Every request handler, including specific display intercepts, must independently
reject non-GET/HEAD and external origins before fetch, continue or fulfil. A later
Playwright route takes priority over an earlier catch-all route. The initial
candidate review identified this bypass opportunity; its owner has now routed all
three intercepts through a shared guard before fetch/continue and set intercepted
fetch maxRedirects=0. The follow-up source review is recorded separately in
harness-followup-review.json; it is not executed runtime acceptance. Treat a
forbidden attempted request as a failure even when blocked.
Do not click Start, Save, Complete, Withdraw, Review, enrollment or any command
control. Inspect the Start button's enabled/disabled state only. A separate future
authorized server-command suite must establish auth, capacity and CAS behavior;
this read-only suite cannot establish those writes or new enrollment persistence.

Capture exact root source hashes, candidate adoption diff, root built entry hash,
frozen copied entry/configuration hashes and root Worker ID before and after. The
copied entry must equal the root's built entry. Record case IDs/assertions, actual
URL, displayed title/prerequisites/cohort/version, focus and viewport metrics,
requests, blocked requests, page errors and labelled screenshots. Before/after GET
responses for each existing reader/workspace must preserve actual state, revision
and team projection exactly; variants are never written to the server. Include the
unmodified mismatch report and original evidence as history; never overwrite it.
Close all created browser contexts and browser processes even after a failure;
explicitly signal root when no checks remain so the frozen Worker can be stopped.

Scope and focus expectations
Manual in-page cohort selection should preserve the mounted picker and its focus,
without scrolling the learner back to the top. Full go()/hash history navigation
continues to focus main; do not demand picker focus after Back/Forward or a course
card navigation. Check keyboard activation of the native catalog card (Enter/Space), picker
Enter/Home/End/Escape and explicit selection,
visible selected cohort text, readable label and visible focus. Test 390, 768 and
1440 CSS-pixel widths at normal and enlarged body text (32px vs 16px). This is a
text-size test, not proof of browser zoom. Add 320px reflow and real 200% zoom only
when the available browser actually supports/measures them; report unsupported
rather than relabelling text enlargement. Assert scrollWidth <= viewport width,
no clipped selected title/message/control, and usable targets at least 44px for
new actions. Include long cohort labels; do not shrink font sizes to hide overflow.
Layout/keyboard evidence does not establish formal screen-reader conformance.

Minimum release acceptance
Run NAV-01 through NAV-16 after root freezes the new exact source. NAV-15 is the
six width/text-size combinations above; NAV-16 is the global no-write/source and
fixture-invariance gate. Missing publication (NAV-07) and unavailable own saved
pin (NAV-11) are explicit additions to the initial candidate runtime coverage.
The expanded matrix contains 16 core IDs, not a claim of 16 executed scenarios.
If the stable candidate includes more negative branches, keep its stronger suite.
