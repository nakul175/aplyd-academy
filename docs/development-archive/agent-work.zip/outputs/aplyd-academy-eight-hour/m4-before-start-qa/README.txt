M4 Before you start — exact current private scoring guard and read-only QA

Adoption:
1. Apply private-policy.patch after adopting the initial Before you start kit, or copy lib/academy-before-start.mjs from this kit. Initial UI/declaration are unchanged.
2. Copy repository-tests files to tests/before-start-qa. Defaults detect actual checkout; generated models/evidence go only to .sites-runtime/before-start-qa. For candidate tests, ACADEMY_BEFORE_START_PROJECTION can explicitly choose this staged .mjs.
3. Run node tests/before-start-qa/build-model.mjs then node --test tests/before-start-qa/policy.test.mjs.

Guard scope:
The current authoring publication literal and actual scoreDecision support minimumWeightedScore70, scoreMaximum4, criticalGates'all'; authoring supports integer criterion weights1..97 totaling100 and null/or bounded real text critical gates. The private pass-rule display now requires those values. Unsupported/malformed policies preserve the resolved edition's own valid prerequisites but expose passRule:null so existing UI shows the assessment-unavailable instruction. No global fallback, content pin replacement or new scoring standard.
This narrow display guard does not claim to validate an entire publication/document or authorize its availability. Existing exact content resolver and independent publication workflow remain responsible for those boundaries.

Current evidence:
18 pure groups pass against actual adopted root scoreDecision, validateDocument and content-copy, plus staged display guard. Compiled input hashes in runtime/source-evidence.json. Concrete70-point actual score passes while unsupported75 policy stays unavailable; doubled200/fractional100/99 rubric fails authoring and display checks. Network/Worker/browser not run.

Integrated evidence after root adoption:
Frozen M4 Worker51441 passed16 read-only cases:10journeys and6layout/keyboard checks at390/768/1440 normal and true200%body32px. No browser page error, no forbidden mutation/external request; actual two personal states plus one shared state/revision equal before/after. All browsers closed. Evidence runtime/browser/browser-evidence.json; exact copied entry/config hashes in runtime/browser/runtime-artifact.json. Initial selector-assumption and keyboard closing-transition probe failures are retained in distinct runtime folders; neither was counted as passing. Catalog/default mismatch recorded separately in catalog-preview-mismatch.txt, to address in a future offering-selection milestone.
Latest portable browser adds explicit three-global count and exact older-page-heading assertions; these stronger assertions are syntax checked and ready for the final CSS Worker rerun, distinct from this accepted16-case run.

Final CSS rerun:
Wait a new root stable Worker signal. ACADEMY_BEFORE_START_WORKER_READY=1 and ACADEMY_QA_WORKER=<root session> are required; supply ACADEMY_READONLY_FIXTURES=<existing approved fixture JSON> when run from checkout. Run browser-readonly.mjs with ACADEMY_BEFORE_START_BROWSER_OUTPUT set to a fresh outside evidence directory. Only existing approved reader and clearly labelled browser-only GET display variants; GET/HEAD only, no fixture/account/enrollment/save POST, no provider/hosted traffic. No enrollment clicks. Never use this suite to bypass the pending explicit user approval for mutating fictional fixtures.
