M5 retained-learning export correction — candidate, not an application edit

Concrete trigger
app/academy-learning.tsx:22 finds the own active enrollment by program, then independently chooses a default first-open preview cohort. At line 25, the unavailable-own-content export currently combines that own enrollment with selectedCohort. For an own private-v1 enrollment while a newer private-v2 cohort is first-open, the resulting JSON describes unrelated cohort metadata beside the original enrollment.

Bounded correction
Copy lib/academy-retained-export.ts to the checkout's lib/ and apply integration.patch. The three TSX edits add the helper import, read current activeWorkspace from existing context, and replace only the retained export's cohort field. The app snapshot is for inspection/syntax validation; do not copy the whole file.

The helper searches only the currently accepted team's cohort projection for exactly e.cohortId. It requires the current workspace to match team.id, private scope to match that workspace, and full actual pinnedRef/contentKey equality (program, scope, version). Missing, malformed, removed or repointed cohort metadata produces null. A matching older cohort remains exportable even when its exact content snapshot is unavailable. Personal lab enrollments never add cohort metadata. Removed membership does not discard already accepted own matching history. The returned own cohort is a detached copy. For no enrollment, previewCohort ?? null is unchanged.

No new permission, endpoint, command, registry lookup, default version, enrollment mutation or schema is introduced. Unknown exact pins remain unavailable; the helper never substitutes newer content or metadata. Input state and cohort objects remain unchanged.

Checks completed outside checkout
Strict TypeScript helper check passed; staged TSX parsing passed.
22 focused pure groups / 25 assertions passed using actual checkout academy-curriculum.ts and immutable archived curriculum, plus staged helper. fetch is disabled in test runtime. Fixtures are in-memory projected metadata only.
source-manifest.json records the current exact LearningView, offering helper and curriculum hashes. runtime/source-evidence.json records bundled inputs; runtime/pure-test-evidence.json records count and limits.

Portable root adoption
The two scripts may be copied to tests/retained-export-qa/. They detect the application root from their own location or ACADEMY_APP_PATH. After helper adoption they use the actual checkout helper and output .sites-runtime/retained-export-qa by default; ACADEMY_RETAINED_EXPORT_QA_OUTPUT can choose an outside directory.

From workspace root, before adoption:
node outputs/aplyd-academy-eight-hour/m5-retained-export-fix/tests/build-model.mjs
node --test outputs/aplyd-academy-eight-hour/m5-retained-export-fix/tests/retained-export.test.mjs

From application root, after adoption:
node tests/retained-export-qa/build-model.mjs
node --test tests/retained-export-qa/retained-export.test.mjs

Root-owned runtime acceptance proposed (not run here)
1. GET-display existing own older unavailable private enrollment, newer first-open cohort plus matching old cohort: download preserves exact own e and old metadata, not newer.
2. Same projection with old cohort removed, version-repointed, program-changed or scope-changed: download preserves e, cohort null.
3. Own global legacy unavailable enrollment with exact matching cohort: matching metadata retained using actual legacy pinnedRef rules.
4. Personal unavailable own enrollment: cohort null.
5. No enrollment and explicit unavailable preview cohort: prior preview-only JSON unchanged.
6. Download does not send POST or change before/after state/revision; keyboard action and new-tab/history behavior remain unchanged.

No Worker, browser, API, SQL, persisted fixtures, checkout edits, app build, Git or publication were run by this candidate.
