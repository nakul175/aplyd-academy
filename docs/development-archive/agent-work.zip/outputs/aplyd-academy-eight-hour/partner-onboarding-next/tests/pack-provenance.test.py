"""Read original teaching source sections without modifying them or any checkout file."""
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import json,os,hashlib
here=Path(__file__).resolve().parents[1]
app=Path(os.environ.get('ACADEMY_QA_APP',str(here.parents[2]/'work/aplyd-academy')))
snapshot=json.loads((here/'source-snapshot.json').read_text())
library=(app/'lib/academy-library.ts').read_text()
catalog=json.loads(library[library.index('['):library.rindex(']')+1])
resources={r['id']:r for c in catalog for r in c['resources']}
cases=[]
for ref in snapshot['references']:
    r=resources[ref['id']];path=app/'public'/r['href'].lstrip('/')
    assert hashlib.sha256(path.read_bytes()).hexdigest()==ref['sha256']
    with ZipFile(path) as z:
        root=ET.fromstring(z.read('word/document.xml'))
    paragraphs=[''.join(p.itertext()) for p in root.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p')]
    for section in ref['sections']:
        assert section in paragraphs, f'Section is not an exact original heading: {ref["id"]}: {section}'
        cases.append(f'{ref["id"]}: exact original section {section}')
evidence={'passed':True,'groups':len(cases),'cases':cases,'mode':'original-read-only-docx-text-and-checksum','limits':['Teaching provenance only. Source sections do not establish institutional authority, partner approval or current law. No original file modified.']}
(here/'provenance-test-evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
print(f'{len(cases)} original source section checks passed.')
