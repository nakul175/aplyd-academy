/** HOLD: root must adopt/build and provide a new stable M4 signal before execution. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const here=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const app=process.env.ACADEMY_QA_APP??resolve(here,'../../../work/aplyd-academy');
if(!process.env.ACADEMY_PARTNER_REVIEW_WORKER)throw new Error('Wait for root adoption/build and a new stable M4 read-only Worker signal.');
process.env.ACADEMY_APP_PATH=app;
const {base,headers,get,current,success}=await import(pathToFileURL(resolve(app,'tests/local-qa.mjs')).href);
assert.equal(new URL(base).hostname,'127.0.0.1','This suite is loopback-only.');
const fixturePath=process.env.ACADEMY_PARTNER_REVIEW_FIXTURES??resolve(here,'../record-verification/integrated/evidence/fixtures.json');
const f=JSON.parse(readFileSync(fixturePath,'utf8'));
const {renderPartnerReviewPack,buildPartnerReviewPack}=await import(pathToFileURL(resolve(app,'lib/academy-partner-review-pack.mjs')).href);
const {chromium,browserOptions}=await import(pathToFileURL(resolve(app,'tests/scoped-workbench-qa/browser-runtime.mjs')).href);
const evidence=process.env.ACADEMY_PARTNER_REVIEW_EVIDENCE?resolve(process.env.ACADEMY_PARTNER_REVIEW_EVIDENCE):resolve(here,'evidence-readonly');mkdirSync(evidence,{recursive:true});
const files=['lib/academy-partner-review-pack.mjs','lib/academy-partner-review-pack.d.mts','app/academy-partner-readiness.tsx','lib/academy-ecosystems.ts','lib/academy-engine.ts','lib/academy-library.ts','lib/curriculum-versions/0.1-review-draft.json','app/academy-ecosystems.tsx','app/academy.tsx','app/academy-context.tsx'];
const hashes=()=>Object.fromEntries(files.map(x=>[x,createHash('sha256').update(readFileSync(resolve(app,x))).digest('hex')]));
const beforeHashes=hashes(),browser=await chromium.launch(browserOptions),contexts=[],cases=[],requests=[],forbidden=[],errors=[];let passed=false;
const ownRead=async user=>success(await get(user,'/api/academy'));
const card=(p,id)=>p.locator(`[data-ecosystem-adapter="${id}"]`),inspector=(p,id)=>p.locator(`[data-partner-inspection="${id}"]`);
const button=(p,id)=>inspector(p,id).getByRole('button',{name:'Download printable review checklist',exact:true});
async function scenario(name,fn){try{await fn();cases.push({name,passed:true});console.log(name+': passed');}catch(e){cases.push({name,passed:false,error:String(e)});throw e;}}
function monitor(p,allowApp=true){
  p.on('pageerror',e=>errors.push(e.message));
  p.on('request',r=>requests.push({method:r.method(),path:new URL(r.url()).pathname}));
  return p.route('**/*',route=>{const r=route.request(),u=new URL(r.url());if(r.method()!=='GET'||!allowApp||u.origin!==new URL(base).origin){forbidden.push({method:r.method(),path:u.pathname,origin:u.origin});return route.abort('blockedbyclient');}return route.continue();});
}
async function page({workspace=null,viewport={width:1440,height:1000},privateSentinel=false,wrongSubject=false}={}) {
  const c=await browser.newContext({extraHTTPHeaders:headers(f.person),viewport,acceptDownloads:true}),p=await c.newPage();contexts.push(c);p.setDefaultTimeout(15000);await monitor(p);
  if(privateSentinel||wrongSubject)await p.route('**/api/academy',async route=>{const response=await route.fetch(),json=await response.json();if(wrongSubject)json.currentUserId=f.other.id;else{json.state.profile.name='DISPLAY_ONLY_PRIVATE_SENTINEL';for(const e of json.state.enrollments){const key=Object.keys(e.draft??{})[0];if(key)e.draft={...e.draft,[key]:'DISPLAY_ONLY_PRIVATE_TASK'};}}return route.fulfill({response,json});});
  await p.goto(base+'/'+(workspace?'?workspace='+encodeURIComponent(workspace):'')+'#connections');
  if(wrongSubject)await p.getByRole('alert').first().waitFor();else await p.locator('[data-save-state="loaded"]').waitFor();
  if(!workspace)await card(p,'msme').getByRole('heading',{name:'MSME',exact:true}).waitFor();return {p,c};
}
async function open(p,id){const m=inspector(p,id);await m.locator('summary').click();await m.getByText('No live partner connection',{exact:true}).waitFor();return m;}
async function download(p,id) {const event=p.waitForEvent('download');await button(p,id).click();const d=await event,file=resolve(evidence,`checklist-${id}-${cases.length}.html`);assert.equal(d.suggestedFilename(),`aplyd-${id}-review-checklist.html`);await d.saveAs(file);return readFileSync(file,'utf8');}
const storage=p=>p.evaluate(()=>JSON.stringify({...localStorage}));
const frames=p=>p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
try {
  const realBefore=await ownRead(f.person),sharedBefore=success(await current(f.person,f.personTeam.id));
  for(const id of ['agri','msme','public'])await scenario(`${id}: actual downloaded checklist is exact generic material, with no API or storage side effects`,async()=>{
    const {p,c}=await page();await open(p,id);const beforeStorage=await storage(p),start=requests.length,html=await download(p,id);
    assert.equal(html,renderPartnerReviewPack(id));assert.equal(requests.length,start);assert.equal(await storage(p),beforeStorage);
    const values=[f.person.id,f.person.email,...realBefore.state.enrollments.map(e=>e.id),...realBefore.state.enrollments.filter(e=>e.record).map(e=>e.record.id),...(realBefore.state.ecosystemGrants??[]).map(g=>g.id),...(realBefore.state.ecosystemReceipts??[]).map(r=>r.id)];
    for(const value of values)assert.ok(!html.includes(value));assert.equal(buildPartnerReviewPack(id).decisions.every(d=>d.status==='open'),true);await c.close();
  });
  await scenario('Health has no checklist action or domain mapping; existing generic brief stays available',async()=>{const {p,c}=await page();await open(p,'health');assert.equal(await button(p,'health').count(),0);assert.equal(await inspector(p,'health').getByRole('button',{name:'Download partner discussion brief',exact:true}).count(),1);assert.equal(await card(p,'health').getByRole('button',{name:'Save local test choice',exact:true}).count(),0);await c.close();});
  await scenario('Actual shared workspace offers no personal inspector or checklist download',async()=>{const {p,c}=await page({workspace:f.personTeam.id});await p.getByRole('heading',{name:'Ecosystem tests live in your personal lab',exact:true}).waitFor();assert.equal(await p.locator('[data-partner-inspection]').count(),0);assert.equal(await p.getByRole('button',{name:'Download printable review checklist',exact:true}).count(),0);await c.close();});
  await scenario('In-memory private display fields never enter any generic checklist',async()=>{const {p,c}=await page({privateSentinel:true});for(const id of ['agri','msme','public']){await open(p,id);const html=await download(p,id);assert.equal(html,renderPartnerReviewPack(id));assert.ok(!html.includes('DISPLAY_ONLY_PRIVATE_'));}await c.close();});
  await scenario('Masked wrong-subject read cannot contaminate an independent generic download',async()=>{const {p,c}=await page({wrongSubject:true});await open(p,'msme');assert.equal(await inspector(p,'msme').locator('[aria-label="MSME current local summary"]').count(),0);assert.equal(await download(p,'msme'),renderPartnerReviewPack('msme'));await c.close();});
  for(const width of [390,768,1440])await scenario(`${width}px: native keyboard download and 200% text remain within the viewport`,async()=>{const {p,c}=await page({viewport:{width,height:1000}});const m=inspector(p,'msme');await m.locator('summary').focus();await p.keyboard.press('Enter');await button(p,'msme').waitFor();await button(p,'msme').focus();assert.equal(await button(p,'msme').evaluate(e=>document.activeElement===e&&e.getBoundingClientRect().height>=44),true);const event=p.waitForEvent('download');await p.keyboard.press('Enter');const d=await event;await d.saveAs(resolve(evidence,`keyboard-${width}.html`));await p.addStyleTag({content:'html{font-size:200% !important}'});await frames(p);assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await p.screenshot({path:resolve(evidence,`action-${width}-200-percent.png`),fullPage:true});await c.close();});
  await scenario('Standalone offline HTML has readable mobile, enlarged-text and print field tables without any network request',async()=>{
    const c=await browser.newContext({viewport:{width:390,height:1000}}),p=await c.newPage();contexts.push(c);await monitor(p,false);const start=requests.length;
    for(const id of ['agri','msme','public']){await p.setContent(renderPartnerReviewPack(id));assert.equal(await p.locator('table tbody tr').count(),16);assert.equal(await p.locator('.decision').count(),7);assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await p.addStyleTag({content:'html{font-size:200% !important}'});await frames(p);assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await p.screenshot({path:resolve(evidence,`offline-${id}-390.png`),fullPage:true});await p.setViewportSize({width:794,height:1123});await p.emulateMedia({media:'print'});await p.screenshot({path:resolve(evidence,`offline-${id}-print.png`),fullPage:true});assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await p.emulateMedia({media:'screen'});await p.setViewportSize({width:390,height:1000});}
    assert.equal(requests.length,start);await c.close();
  });
  const realAfter=await ownRead(f.person),sharedAfter=success(await current(f.person,f.personTeam.id));assert.deepEqual(realAfter.state,realBefore.state);assert.equal(realAfter.revision,realBefore.revision);assert.deepEqual(sharedAfter.state,sharedBefore.state);assert.equal(sharedAfter.revision,sharedBefore.revision);assert.deepEqual(hashes(),beforeHashes);assert.deepEqual(forbidden,[]);assert.deepEqual(errors,[]);passed=true;
} catch(e) {for(const [i,c]of contexts.entries())for(const p of c.pages())await p.screenshot({path:resolve(evidence,`failure-${i}.png`),fullPage:false}).catch(()=>{});throw e;}
finally{await browser.close();writeFileSync(resolve(evidence,'browser-evidence.json'),JSON.stringify({passed,worker:process.env.ACADEMY_PARTNER_REVIEW_WORKER,cases,requests,forbidden,pageErrors:errors,sourceHashes:beforeHashes,contract:{methods:'GET loopback only',writes:false,outgoingPartnerCalls:false,downloads:'fixed generic HTML only',displayVariants:'GET response interception only, never saved'},limits:['Existing approved fictional accounts/records only. No create/save/grant/receipt/member/role/profile mutation.','Actual downloaded generic proposals do not prove partner UAT, institutional approval, identity linking or production operation.','Screenshots and layout/native keyboard assertions do not establish human screen-reader conformance or complete printed pagination.']},null,2)+'\n');console.log(JSON.stringify({passed,scenarios:cases.length,pageErrors:errors.length,forbidden:forbidden.length}));}
