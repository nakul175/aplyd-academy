import {readFileSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url));
if(!process.env.ACADEMY_PARTNER_REVIEW_WORKER)throw new Error('Need root stable signal.');
const app=process.env.ACADEMY_QA_APP;
const {renderPartnerReviewPack}=await import(pathToFileURL(resolve(app,'lib/academy-partner-review-pack.mjs')).href);
const {chromium,browserOptions}=await import(pathToFileURL(resolve(app,'tests/scoped-workbench-qa/browser-runtime.mjs')).href);
const browser=await chromium.launch(browserOptions);let requests=[];
try{
 const p=await browser.newPage({viewport:{width:390,height:1000}});
 p.on('request',r=>requests.push(r.url()));await p.route('**/*',r=>r.abort('blockedbyclient'));
 await p.setContent(renderPartnerReviewPack('agri'));await p.addStyleTag({content:'html{font-size:200% !important}'});
 const diagnostic=await p.evaluate(()=>({width:innerWidth,documentWidth:document.documentElement.scrollWidth,offenders:[...document.querySelectorAll('body *')].filter(e=>e.clientWidth>0&&e.scrollWidth>e.clientWidth+1).map(e=>({tag:e.tagName,class:e.className,text:e.textContent?.slice(0,140),clientWidth:e.clientWidth,scrollWidth:e.scrollWidth,font:getComputedStyle(e).fontSize,overflowWrap:getComputedStyle(e).overflowWrap}))}));
 await p.screenshot({path:resolve(here,'print-evidence/agri-mobile-200-before-wrap.png'),fullPage:true});
 writeFileSync(resolve(here,'print-evidence/mobile-wrap-diagnostic.json'),JSON.stringify({...diagnostic,requests},null,2)+'\n');
 await p.addStyleTag({content:'.source p{overflow-wrap:anywhere}'});
 const fixed=await p.evaluate(()=>({width:innerWidth,documentWidth:document.documentElement.scrollWidth,offenders:[...document.querySelectorAll('body *')].filter(e=>e.clientWidth>0&&e.scrollWidth>e.clientWidth+1).map(e=>({tag:e.tagName,class:e.className,clientWidth:e.clientWidth,scrollWidth:e.scrollWidth}))}));
 await p.screenshot({path:resolve(here,'print-evidence/agri-mobile-200-proposed-wrap.png'),fullPage:true});
 writeFileSync(resolve(here,'print-evidence/mobile-wrap-proposed-fix.json'),JSON.stringify({displayOnly:true,rootSourcesChanged:false,proposedRule:'.source p{overflow-wrap:anywhere}',before:diagnostic,after:fixed,requests},null,2)+'\n');
 if(fixed.documentWidth!==fixed.width)throw new Error('Proposed wrapping rule does not resolve mobile overflow.');
 console.log(JSON.stringify({actualBefore:diagnostic.documentWidth,candidateAfter:fixed.documentWidth,requests:requests.length}));
}finally{await browser.close();}
