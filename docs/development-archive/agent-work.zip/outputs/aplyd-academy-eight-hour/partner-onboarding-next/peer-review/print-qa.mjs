/** Offline QA only. Hold until root sends the frozen M4 runtime signal. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url));
if(!process.env.ACADEMY_PARTNER_REVIEW_WORKER)throw new Error('Wait for root stable M4 signal before browser execution.');
const app=resolve(process.env.ACADEMY_QA_APP??resolve(here,'../../../../work/aplyd-academy'));
const modulePath=process.env.ACADEMY_PARTNER_REVIEW_MODULE??resolve(app,'lib/academy-partner-review-pack.mjs');
const candidateOnly=Boolean(process.env.ACADEMY_PARTNER_REVIEW_MODULE);
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
const sourceHash=hash(modulePath);
const {renderPartnerReviewPack}=await import(pathToFileURL(modulePath).href);
const {chromium,browserOptions}=await import(pathToFileURL(resolve(app,'tests/scoped-workbench-qa/browser-runtime.mjs')).href);
const output=process.env.ACADEMY_PARTNER_PRINT_EVIDENCE?resolve(process.env.ACADEMY_PARTNER_PRINT_EVIDENCE):resolve(here,candidateOnly?'print-candidate-evidence':'print-evidence');mkdirSync(output,{recursive:true});
const browser=await chromium.launch(browserOptions),requests=[],errors=[],documents=[];
let passed=false;
try{
  const context=await browser.newContext({viewport:{width:390,height:1000}});
  const page=await context.newPage();
  page.on('request',r=>requests.push({method:r.method(),url:r.url()}));
  page.on('pageerror',e=>errors.push(e.message));
  await page.route('**/*',r=>r.abort('blockedbyclient'));
  for(const partner of ['agri','msme','public']){
    const html=renderPartnerReviewPack(partner);
    await page.setContent(html);
    assert.equal(await page.locator('.decision').count(),7);
    assert.equal(await page.locator('table tbody tr').count(),16);
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
    const metrics=await page.evaluate(()=>Object.fromEntries(['header > p:not(.eyebrow)','.open','.meta','code','table td','h3'].map(s=>[s,Number.parseFloat(getComputedStyle(document.querySelector(s)).fontSize)])));
    assert.equal(metrics['header > p:not(.eyebrow)'],16);assert.ok(Object.values(metrics).every(v=>v>=14));
    await page.screenshot({path:resolve(output,`${partner}-mobile-normal.png`),fullPage:true});
    await page.addStyleTag({content:'html{font-size:200% !important}'});
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
    await page.screenshot({path:resolve(output,`${partner}-mobile-enlarged.png`),fullPage:true});
    await page.setContent(html);
    await page.emulateMedia({media:'print'});
    const pdf=resolve(output,`${partner}-a4.pdf`);
    await page.pdf({path:pdf,format:'A4',printBackground:true,preferCSSPageSize:true});
    documents.push({partner,moduleSha256:sourceHash,htmlSha256:createHash('sha256').update(html).digest('hex'),pdfSha256:hash(pdf),screenFontSizesPx:metrics,pdf,rendering:candidateOnly?'Staged fixed renderer only; normal browser A4 print, CSS page margin14mm':'Actual adopted fixed renderer; normal browser A4 print, CSS page margin14mm',visualReview:'pending rendered-page inspection'});
    await page.emulateMedia({media:'screen'});
    console.log(`${partner}: offline mobile/200% text and A4 print capture passed`);
  }
  assert.deepEqual(requests,[]);assert.deepEqual(errors,[]);assert.equal(hash(modulePath),sourceHash);passed=true;
  await context.close();
}finally{
  await browser.close();
  writeFileSync(resolve(output,'print-capture-evidence.json'),JSON.stringify({passed,worker:process.env.ACADEMY_PARTNER_REVIEW_WORKER,sourceHash,modulePath,candidateOnly,documents,requests,pageErrors:errors,limits:['Offline rendered fixed generic materials only; no HTTP requests, stored data or partner account.','PDF page-break quality remains pending image inspection, not established by successful capture.']},null,2)+'\n');
}
