"""Read-only PDF extraction and bounds QA after actual offline print capture."""
from pathlib import Path
import hashlib,json,re,os
from pypdf import PdfReader
import pdfplumber

here=Path(__file__).resolve().parent
output=Path(os.environ.get('ACADEMY_PARTNER_PRINT_EVIDENCE',str(here/'print-evidence')))
capture=json.loads((output/'print-capture-evidence.json').read_text())
results=[]
for document in capture['documents']:
    path=Path(document['pdf'])
    assert hashlib.sha256(path.read_bytes()).hexdigest()==document['pdfSha256']
    reader=PdfReader(path)
    pages=[page.extract_text() or '' for page in reader.pages]
    text=''.join(pages)
    normalized=re.sub(r'\s+','',text)
    fields=['contract_version','mode','partner','event_id','occurred_at','enrollment_ref','pathway_id','content_version','purpose','scopes','learning.completed_lessons','learning.total_lessons','learning.status','practice_record.status','practice_record.claim_type','practice_record.review_mode']
    required=['Current local contract and field definitions','Decisions to record with the partner','Boundary checks to discuss','Reference trail','Every decision below is open.','Current learning claim:','aplyd.partner-review-checklist/1','APLYD_C1_Trainer_Handbook.docx','APLYD_C5_Trainer_Handbook.docx','APLYD_C2_Trainer_Handbook.docx']
    missing=[value for value in fields+required if re.sub(r'\s+','',value) not in normalized]
    assert not missing,missing
    assert text.count('decision required')==7
    assert all(len(page.strip())>40 for page in pages),'Blank or near-empty PDF page'
    bounds=[]
    with pdfplumber.open(path) as pdf:
        for index,page in enumerate(pdf.pages,1):
            chars=[c for c in page.chars if c['text'].strip()]
            geometry={'page':index,'widthPt':page.width,'heightPt':page.height,'textCharacters':len(chars),'leftPt':min(c['x0'] for c in chars),'rightPt':max(c['x1'] for c in chars),'topPt':min(c['top'] for c in chars),'bottomPt':max(c['bottom'] for c in chars)}
            assert geometry['leftPt']>=35 and geometry['rightPt']<=page.width-35,geometry
            assert geometry['topPt']>=35 and geometry['bottomPt']<=page.height-35,geometry
            bounds.append(geometry)
    result={'partner':document['partner'],'pdf':str(path),'pages':len(pages),'textPresencePassed':True,'nonBlankPagesPassed':True,'all16FieldNamesPresent':True,'openDecisionsPresent':7,'pageBounds':bounds,'visualReview':'pending rendered PNG inspection'}
    results.append(result)
    print(f"{document['partner']}: {len(pages)} A4 pages,16 fields,7 decisions and margin bounds verified")
(output/'print-extraction-evidence.json').write_text(json.dumps({'passed':True,'documents':results,'limitations':['Text extraction and page bounds supplement rendered-page inspection; they do not prove all layout quality.','No original source or product artifact changed.']},indent=2)+'\n')
