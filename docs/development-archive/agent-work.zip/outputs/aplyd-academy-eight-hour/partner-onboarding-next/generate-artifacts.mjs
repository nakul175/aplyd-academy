import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {buildPartnerReviewPack,renderPartnerReviewPack} from './candidate/lib/academy-partner-review-pack.mjs';
const here=fileURLToPath(new URL('.',import.meta.url));
const output=resolve(here,'downloads');mkdirSync(output,{recursive:true});
const artifacts=[];
for(const partner of ['agri','msme','public']) {
  for(const [ext,body] of [['html',renderPartnerReviewPack(partner)],['json',JSON.stringify(buildPartnerReviewPack(partner),null,2)+'\n']]) {
    const filename=`aplyd-${partner}-review-checklist.${ext}`;writeFileSync(resolve(output,filename),body);
    artifacts.push({partner,filename,bytes:Buffer.byteLength(body),sha256:createHash('sha256').update(body).digest('hex')});
  }
}
writeFileSync(resolve(here,'artifact-manifest.json'),JSON.stringify({format:'aplyd.partner-review-artifacts/1',artifactGeneration:'Plain file generation only; no app compiler, server, browser or API.',artifacts,sourceSnapshot:JSON.parse(readFileSync(resolve(here,'source-snapshot.json'),'utf8'))},null,2)+'\n');
console.log(`Prepared ${artifacts.length} generic offline review files.`);
