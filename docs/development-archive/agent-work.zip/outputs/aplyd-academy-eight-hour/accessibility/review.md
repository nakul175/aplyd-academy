# Workstream 8 — accessibility and mobile review

This review inspects source and prepares root-integration candidates. The lead owns application edits, builds, the preview lifecycle, API/browser execution, and publication. No browser/server/API test was run during this review; there was no stable preview authorization.

## Findings that affect the new release

| Priority | Finding and source | Concrete action |
|---|---|---|
| P1 | Offline and existing personal-delete `AlertDialogContent` has no height/scroll limit: `components/ui/alert-dialog.tsx:47–65`. `app/globals.css:27` limits only ordinary `dialog-content`. At 390px and doubled text the confirmation description and actions can extend beyond the screen. | Apply the bounded height/scroll rule to `alert-dialog-content`; verify descriptions and both actions remain keyboard reachable. Candidate in `candidates/alert-dialog-and-offline-focus.txt`. |
| P2 | Offline discard close-focus callback tests only current scope and connected opener: candidate `app/academy-offline.tsx:57`. After a successful lock, its opener is disabled because the queue is empty. `.focus()` on that disabled element cannot restore focus. | Check enabled/visible state and fall back to `#main` within the captured scope. Keep the scope boundary to avoid focusing controls in another account/workspace. |
| P2 | `LessonReadAloud` retains completion/error handlers on a cancelled utterance: `app/academy-inclusive-learning.tsx:31,34,37`. An intentional stop or delayed callback from an earlier read can announce an error or set speaking false during a newer read. | Detach handlers and invalidate a generation before cancellation. Adopt the bounded replacement candidate in `candidates/LessonReadAloud.tsx`; test delayed cancel/error, repeat reads, navigation, account/workspace change and actual device voices. |
| P2 | Offline draft textareas put prompt and help inside one wrapping label: candidate `app/academy-offline.tsx:57`. The accessible name includes the full help paragraph, making fields more verbose and exact prompt selection ambiguous. | Use a prompt-only explicit label and connect the help through `aria-describedby`. Preserve exact draft field IDs and privacy scope. |
| P2 | Comfortable reading mode still fixes its own inherited text at `18px` (`app/globals.css:27`), despite the body now using rem. Root-font enlargement can leave its inherited text/inputs at that fixed size. | Replace with `1.125rem`, retaining 18px at the ordinary 16px root and allowing true doubled text. Include reading mode on and off in the layout matrix. |
| P3 | Passphrase rule is expressed only as an input `minLength`: candidate `app/academy-offline.tsx:57`. Controls do not use a native validating form, and the 12-character requirement is not stated beside the field. | Add visible, associated minimum-length help. Do not show a saved passphrase or expose one in announcements. |

## Confirmed improvements retained from the previous review

`components/ui/dialog.tsx` now captures an opener and falls back to `#main` when it is gone. `app/globals.css:23` now uses a rem-sized body, so root font resizing affects inherited body/input text. The page shell uses one main landmark and focuses it for navigation. Existing fields, switches and selects generally have accessible names. New capture declarations are explicit learner choices, and the interface explains that they do not grant a helper account access. Draft comparison is deliberate and does not post or complete learning. Snapshot inspection keeps the selected file in the browser and exposes an accessible status/error. Current language selections are accurately labelled requests; there is no implied translated course edition.

## Reviewed scope protections

- Read-aloud takes `lesson.lessonText`, never private submitted evidence or draft text, and uses browser-reported local voice metadata. Account, workspace, enrollment pin and lesson changes cancel it.
- Unsent normal pathway input remains in account/workspace-keyed memory; draft comparison loads saved text only after a deliberate click.
- Read-back confirmation must be repeated after editing any response; the helper receives no new Academy permission.
- Snapshot output validates the current account and checksum before a download. No restore/import action is offered by file inspection.
- Offline confirmations must not restore focus into a changed account/workspace. Candidates retain that guard.

## Browser acceptance plan

See `browser-vectors.md`. It distinguishes actual executed results from proposed checks, and includes keyboard, delayed speech callbacks, 390px/doubled-text dialogs, error recovery, file-selection boundaries and unsent text privacy. Static inspection is not a screen-reader or WCAG conformance claim.
