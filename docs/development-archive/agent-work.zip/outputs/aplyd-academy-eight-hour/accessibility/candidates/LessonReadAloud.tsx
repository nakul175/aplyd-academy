'use client';
// Replacement candidate for the existing LessonReadAloud function only.
// Import useRef into academy-inclusive-learning.tsx if the lead adopts it.
import {useEffect,useRef,useState} from 'react';
import {Volume2} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {readAccessPreferences,freshAccessPreferences,languageAvailability,readAloudPlan,type AccessPreferences} from '@/lib/academy-inclusive-learning';
import {useAcademy} from './academy-context';

/** User-started exact public lesson text; local browser-reported voice only. */
export function LessonReadAloud({lesson,enrollment}:{lesson:any;enrollment:any}){
 const {state,contentContext,accountKey,activeWorkspace}=useAcademy();
 const [voices,setVoices]=useState<SpeechSynthesisVoice[]>([]),[loaded,setLoaded]=useState(false),[supported,setSupported]=useState(false),[speaking,setSpeaking]=useState(false),[error,setError]=useState('');
 const utterance=useRef<SpeechSynthesisUtterance|null>(null),generation=useRef(0);
 let preferences:AccessPreferences;try{preferences=readAccessPreferences(state.learningAccess)}catch{preferences=freshAccessPreferences();}
 const available=languageAvailability(enrollment,contentContext,preferences),plan=readAloudPlan(available,{supported,voicesLoaded:loaded,voices:voices.map(v=>({language:v.lang,localService:v.localService}))});

 function cancelOwnSpeech(){
  ++generation.current;
  if(utterance.current){utterance.current.onend=null;utterance.current.onerror=null;utterance.current=null;}
  window.speechSynthesis?.cancel();
 }
 useEffect(()=>{
  const synth=window.speechSynthesis;setSpeaking(false);setError('');setLoaded(false);setSupported(!!synth);
  if(!synth){setLoaded(true);return;}
  const update=()=>{const found=synth.getVoices();setVoices(found);setLoaded(found.length>0);};
  update();synth.addEventListener('voiceschanged',update);
  const timer=window.setTimeout(()=>{update();setLoaded(true);},1500);
  return()=>{window.clearTimeout(timer);synth.removeEventListener('voiceschanged',update);cancelOwnSpeech();};
 },[accountKey,activeWorkspace,enrollment.id,JSON.stringify(enrollment.contentRef??enrollment.version),lesson.id]);
 function listen(){
  if(speaking){cancelOwnSpeech();setSpeaking(false);setError('');return;}
  if(plan.status!=='ready')return;
  const voice=voices.find(v=>v.localService&&v.lang.toLowerCase()===plan.utteranceLanguage!.toLowerCase());
  if(!voice){setError('That browser voice is no longer available. Try again after the voice list refreshes.');return;}
  // Detach the earlier utterance's handlers before cancel. A delayed interrupted
  // event must not report an error for an intentional stop or affect a new read.
  cancelOwnSpeech();
  const ticket=generation.current,speech=new SpeechSynthesisUtterance(lesson.lessonText);
  utterance.current=speech;speech.lang=voice.lang;speech.voice=voice;
  const finish=(failed:boolean)=>{
   if(generation.current!==ticket||utterance.current!==speech)return;
   speech.onend=null;speech.onerror=null;utterance.current=null;setSpeaking(false);
   if(failed)setError('The browser could not finish reading. Your lesson text and saved work are still here.');
  };
  speech.onend=()=>finish(false);speech.onerror=()=>finish(true);
  setError('');setSpeaking(true);window.speechSynthesis.speak(speech);
 }
 return <div><Button variant="outline" size="sm" disabled={!speaking&&plan.status!=='ready'} onClick={listen}><Volume2 size={16}/>{speaking?'Stop reading':'Read aloud'}</Button>{(error||plan.status!=='ready')&&<p className="form-hint" role="status">{error||plan.message}</p>}{preferences.readAloudMode==='ask'&&plan.status==='ready'&&<p className="form-hint">Your read-aloud reminder: start reading when you are ready.</p>}</div>;
}
