import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
export {chromium} from '/Users/athena/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
export const output=path.dirname(fileURLToPath(import.meta.url));
export const app=path.resolve(process.env.ACADEMY_APP_PATH??'/Users/athena/.codex/.chatgpt-projects/g-p-6ab89116b65c81919bb561fed2d716c0/work/aplyd-academy');
export const base=process.env.ACADEMY_LOCAL_URL??'http://127.0.0.1:8787';
assert.ok(['localhost','127.0.0.1','[::1]'].includes(new URL(base).hostname),'Loopback synthetic tests only');
export const browserOptions={executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true};
export const curriculum=JSON.parse(fs.readFileSync(path.join(app,'lib/curriculum.json'),'utf8'));
export const program=curriculum.pathways[1];
export const identity=role=>({id:'eight-hour-'+role+'-'+crypto.randomUUID(),email:role+'-'+crypto.randomUUID()+'@academy.test',name:'Synthetic '+role});
export const headers=user=>({'Content-Type':'application/json','oai-authenticated-user-id':user.id,'oai-authenticated-user-email':user.email,'oai-authenticated-user-full-name':encodeURIComponent(user.name),'oai-authenticated-user-full-name-encoding':'percent-encoded-utf-8'});
export async function get(user){const r=await fetch(base+'/api/academy',{headers:headers(user)});assert.equal(r.status,200);return r.json();}
export async function command(user,value){const current=await get(user),r=await fetch(base+'/api/academy',{method:'POST',headers:headers(user),body:JSON.stringify({revision:current.revision,actionId:crypto.randomUUID(),command:value})});assert.equal(r.status,200,'Synthetic fixture command '+value.type+' failed');return r.json();}
export async function enroll(user,complete=false){let x=await command(user,{type:'enroll',programId:program.id}),id=x.state.enrollments[0].id;if(complete)for(const lesson of program.lessons)x=await command(user,{type:'lesson',enrollmentId:id,lessonId:lesson.id,practice:'A fictional source check removes unsupported promises and keeps the human review route.',answers:lesson.quiz.map(q=>q.correctOptionIndex)});return {id,state:x};}
export async function navigate(page,hash){await page.evaluate(value=>location.hash=value,hash);await page.locator('#main h1').first().waitFor();}
export async function settled(page){await page.getByText('Saved privately',{exact:true}).waitFor();}
export const button=(page,name)=>page.getByRole('button',{name,exact:true});
export function reporter(name,sources){const checks=[],errors=[];let passed=false;return {checks,errors,ok:(value,label)=>{assert.ok(value,label);checks.push(label);},pass:()=>{passed=true;},finish(){const result={passed,at:new Date().toISOString(),worker:base,checks:checks.length,checkNames:checks,errors,sourceHashes:Object.fromEntries(sources.map(file=>[file,createHash('sha256').update(fs.readFileSync(path.join(app,file))).digest('hex')])),limits:['Synthetic trusted-header local accounts only; no hosted authentication, actual users or production access proof.','Text checks resize CSS roots; no human screen-reader or genuine browser zoom certification.']};fs.writeFileSync(path.join(output,name+'-result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({passed,checks:checks.length,errors,output:path.join(output,name+'-result.json')}));}};}
export async function assertDialog(page,dialog,check,label){await dialog.waitFor();check(await dialog.evaluate(e=>e.contains(document.activeElement)),label+' receives focus');for(let i=0;i<12;i++){await page.keyboard.press(i<6?'Tab':'Shift+Tab');check(await dialog.evaluate(e=>e.contains(document.activeElement)),label+' traps keyboard '+i);}}
export async function bounds(page,dialog,check,label){const value=await dialog.evaluate(e=>{const r=e.getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:innerWidth,height:innerHeight,scrollWidth:e.scrollWidth,clientWidth:e.clientWidth,overflow:getComputedStyle(e).overflowY};});check(value.left>=-1&&value.right<=value.width+1&&value.scrollWidth<=value.clientWidth+1,label+' contains horizontal layout');check(value.top>=-1&&value.bottom<=value.height+1&&['auto','scroll'].includes(value.overflow),label+' has bounded scrollable height');}
export async function textSize(page,double){await page.evaluate(value=>document.documentElement.style.fontSize=value?'32px':'16px',double);}
