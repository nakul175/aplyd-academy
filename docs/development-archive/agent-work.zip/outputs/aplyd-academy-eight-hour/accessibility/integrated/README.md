# Executed integrated accessibility and offline browser checks

Both suites passed against the root-announced stable local Worker at `http://127.0.0.1:8787` (root-owned session 89617), using separate fictional accounts. No application files were edited; no build/server lifecycle or production call was performed by this workstream.

| Executed suite | Passed assertions | Evidence |
|---|---:|---|
| Inclusive learning, speech lifecycle, captured-response review, own draft comparison and snapshot inspection | 67 | `inclusive-browser-result.json` |
| Offline source downloads, real browser encrypted storage, keyboard/phone confirmations, draft-only saves, conflicts, lost response, account isolation and expiry | 89 | `offline-browser-result.json` |
| Total | 156 | Counts are assertions, not 156 independent test cases. |

`preview-build.json` records the Worker configuration, server entry and generated asset manifest hashes and timestamps. Each result also carries hashes of the relevant source files. Scripts and artifact evidence are in this directory. The downloaded snapshots, sealed bytes and reference packets contain only fictional fixtures.

## What was actually exercised

- Language preferences save through the real local API and preserve exact enrollment/progress/evidence. A requested Hindi language is clearly unavailable in the pinned English edition.
- A controlled browser speech fixture reads the exact public lesson text only after a click. Stop/navigation detach callbacks. A delayed error from a previous read cannot interrupt the current one; a genuine current failure keeps learning usable. This is lifecycle evidence, not proof of actual device voices.
- Captured-response declarations use a named modal with keyboard containment and focus return. Confirmation performs no POST. Editing a response invalidates the declaration and blocks assisted submission until another read-back.
- Own compare/load draft actions perform no POST. Loading online text is explicit, and removal of the comparison returns focus through the main fallback.
- A fresh private snapshot is actually downloaded and inspected locally with a matching carried checksum; inspection performs no POST.
- The downloaded reference HTML renders through a connection gap as a standalone file. HTML and JSON exclude own saved evidence, account/enrollment references, quiz answer indices, sample passing evidence and rubric material. The file contains all three exact fictional lesson texts and has no script/form/iframe/image assets or network requests. Downloading leaves the saved revision unchanged.
- Actual browser WebCrypto produces the device/file sealed copies. The saved outer bytes exclude the passphrase, account, enrollment, title, baseline and unsent response text. Wrong passphrase unlocks nothing; correct passphrase restores exact own text. A real switch to another synthetic account masks old plaintext, and the old file refuses unlock for that account.
- Offline entry text is explicitly labelled and associated with its help. Typing sends no POST. Cancellation retains text and returns focus; confirmed lock clears it and focuses main when the original button is disabled.
- Refresh is read-only. A separate confirmed save makes one `lesson-draft` POST, preserves current online quiz choices, and never completes lessons, submits evidence or creates a record. A confirmed receipt clears the corresponding local generation.
- A concurrent actual saved-field change requires comparison and a deliberate local merge. Merge performs no POST; a later explicit save preserves the fresh online quiz choices.
- The suite commits a draft through the actual Worker, then intentionally drops the browser response. The UI retains its local text, requires a newer read, and never automatically retries. The new read detects the already-committed draft with no additional POST.
- A 25-hour client-clock fixture installed before the page's timers hides temporary plaintext. This proves the client guard only; it changes no server clock and is no authorization/remote-erasure proof.

## Layout and keyboard scope

The suites exercised six captured-response dialog variants (1440/768/390 pixels, ordinary and doubled root text), six offline page variants, seven offline confirmation variants (including 390px/200% text with a 500px short viewport), and Preferences/snapshot at 390px/200% text. Actual computed input sizes were checked; Comfortable reading mode is included. Dialog bounds, vertical scrolling, page horizontal overflow, action reachability, initial focus, trapping and close focus were checked. Saved screenshots are `inclusive-phone200.png` and `offline-discard-phone200.png`.

Earlier incomplete runs exposed harness timing problems, not confirmed product defects: modal restoration happens after unmount, the current canonical read completes after its directory read, and a client clock must be installed before the relevant timers. The final suites wait for those boundaries and both pass.

## Reproduce

Run the bundled Node executable on `inclusive-browser.mjs` and `offline-browser.mjs` after the lead confirms a stable built local Worker. They create new separate fixtures on every run and reject non-loopback URLs. `ACADEMY_LOCAL_URL` and `ACADEMY_APP_PATH` may override local paths. They do not start, build, restart or publish the application.

Hosted authentication/recipient access, genuine browser zoom, actual phone keyboards/native pickers, real installed speech voices, human VoiceOver reading order and WCAG conformance remain separate checks. No actual learner information, helper permission, provider request or external message was involved.
