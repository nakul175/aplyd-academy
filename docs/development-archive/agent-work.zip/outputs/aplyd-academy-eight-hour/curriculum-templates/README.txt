Candidate only; root is the application writer and publisher.

Use the integration contract and narrow patch, not the team overlay, for adoption. The four template definitions and optional origin note are complete. Tests execute only pure in-memory actual model logic plus proposed team dispatch. Existing sources/ and all20 public reference originals remain untouched.

Run from project workspace:
node outputs/aplyd-academy-eight-hour/curriculum-templates/build-candidate.mjs
node --test outputs/aplyd-academy-eight-hour/curriculum-templates/templates.test.mjs

Evidence: runtime/compilation-evidence.json, runtime/test-evidence.json, runtime/library-source-evidence.json and runtime/fact-key-audit.json. Runtime bundles/output are artifacts, not application source.

No root checkout edit, Git action, SQL mutation, root build/server, API/browser, provider/partner/hosted call or publication was performed for this candidate. Operator vectors remain pending integration and a stable local Worker.
