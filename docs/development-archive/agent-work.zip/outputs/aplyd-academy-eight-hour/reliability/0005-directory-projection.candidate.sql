-- Candidate only. Root must generate/review migration 0005 with Drizzle,
-- preserving 0000--0004 and their journal entries. No live DB execution here.
-- Schema-only migration. NO existing-data INSERT/UPDATE/DELETE/backfill.
-- Existing rows remain directory_projected=0 and readable through canonical fallback.
-- This table narrows discovery; canonical aggregate membership remains authority.
CREATE TABLE academy_team_directory (
  user_id TEXT NOT NULL CHECK(length(trim(user_id)) > 0),
  team_id TEXT NOT NULL,
  PRIMARY KEY(user_id, team_id)
);
--> statement-breakpoint
CREATE INDEX idx_academy_team_directory_team
  ON academy_team_directory(team_id, user_id);
--> statement-breakpoint
ALTER TABLE academy_teams ADD COLUMN directory_projected INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
CREATE INDEX idx_academy_teams_directory_legacy ON academy_teams(id)
  WHERE directory_projected = 0;
--> statement-breakpoint
CREATE TRIGGER academy_team_directory_insert
AFTER INSERT ON academy_teams
BEGIN
  INSERT INTO academy_team_directory(user_id, team_id)
  SELECT json_extract(m.value, '$.userId'), NEW.id
  FROM json_each(NEW.data, '$.members') m;
  UPDATE academy_teams SET directory_projected = 1 WHERE id = NEW.id;
END;
--> statement-breakpoint
CREATE TRIGGER academy_team_directory_members_changed
AFTER UPDATE OF data ON academy_teams
WHEN OLD.directory_projected = 0
  OR json_extract(OLD.data, '$.members') IS NOT json_extract(NEW.data, '$.members')
BEGIN
  DELETE FROM academy_team_directory WHERE team_id = NEW.id;
  INSERT INTO academy_team_directory(user_id, team_id)
  SELECT json_extract(m.value, '$.userId'), NEW.id
  FROM json_each(NEW.data, '$.members') m;
  UPDATE academy_teams SET directory_projected = 1 WHERE id = NEW.id;
END;
--> statement-breakpoint
CREATE TRIGGER academy_team_directory_delete
AFTER DELETE ON academy_teams
BEGIN
  DELETE FROM academy_team_directory WHERE team_id = OLD.id;
END;
