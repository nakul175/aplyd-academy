-- Read-only candidate, not executed. Rows block migration/backfill.
-- Output opaque team IDs and generic diagnostics, never member/evidence data.
SELECT id AS affected_team_id, 'unrecognized_membership_shape' AS diagnostic
FROM academy_teams
WHERE CASE
  WHEN json_valid(data) = 0 THEN 1
  WHEN json_type(data, '$') != 'object' THEN 1
  WHEN json_type(data, '$.members') IS NOT 'array' THEN 1
  WHEN json_array_length(data, '$.members') > 100 THEN 1
  ELSE EXISTS (
    SELECT 1 FROM json_each(data, '$.members') m
    WHERE CASE
      WHEN m.type != 'object' THEN 1
      WHEN json_type(m.value, '$.userId') IS NOT 'text' THEN 1
      WHEN length(trim(json_extract(m.value, '$.userId'))) = 0 THEN 1
      ELSE 0
    END
  ) OR (
    SELECT COUNT(*) FROM json_each(data, '$.members')
  ) != (
    SELECT COUNT(DISTINCT CASE WHEN m.type = 'object'
      THEN json_extract(m.value, '$.userId') ELSE NULL END)
    FROM json_each(data, '$.members') m
  )
END = 1;
