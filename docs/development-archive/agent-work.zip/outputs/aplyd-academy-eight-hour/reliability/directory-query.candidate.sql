-- Same directory response shape. Bind the trusted server userId three times.
-- Inactive retained members remain discoverable with active=false and roles=[].
-- The projection contains no role grant, name, email, evidence or support body.
WITH candidates AS (
  SELECT team_id FROM academy_team_directory WHERE user_id = ?
  UNION
  SELECT legacy.id FROM academy_teams legacy
  WHERE legacy.directory_projected = 0 AND EXISTS (
    SELECT 1 FROM json_each(legacy.data, '$.members') lm
    WHERE json_extract(lm.value, '$.userId') = ?
  )
)
SELECT t.id,
       json_extract(t.data, '$.name') AS name,
       json_extract(t.data, '$.context') AS context,
       json_extract(m.value, '$.roles') AS roles,
       json_extract(m.value, '$.active') AS active
FROM academy_teams t
JOIN json_each(t.data, '$.members') m
WHERE t.id IN (SELECT team_id FROM candidates)
AND json_extract(m.value, '$.userId') = ?
ORDER BY t.updated_at DESC, t.id ASC;
