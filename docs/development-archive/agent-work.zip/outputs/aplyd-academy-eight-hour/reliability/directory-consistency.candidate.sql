-- Read-only after successful preflight; no repair or aggregate modification.
WITH expected AS (
  SELECT json_extract(m.value, '$.userId') AS user_id, t.id AS team_id
  FROM academy_teams t JOIN json_each(t.data, '$.members') m
  WHERE t.directory_projected = 1
), missing AS (
  SELECT user_id, team_id FROM expected
  EXCEPT SELECT user_id, team_id FROM academy_team_directory
), extra AS (
  SELECT d.user_id, d.team_id FROM academy_team_directory d
  JOIN academy_teams t ON t.id=d.team_id WHERE t.directory_projected=1
  EXCEPT SELECT user_id, team_id FROM expected
)
SELECT 'missing_pairs' AS diagnostic, COUNT(*) AS affected_count FROM missing
UNION ALL
SELECT 'extra_pairs' AS diagnostic, COUNT(*) AS affected_count FROM extra;
