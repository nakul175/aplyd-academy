M5 retained export — combined read-only runtime preparation

Prepared, not executed. Root must first adopt the reviewed helper/UI patch, rebuild
the actual model and app, freeze a new Worker/dist and authorize this combined run.
The previous accepted 25-case report applies to its old source/build and remains
unchanged under m5-navigation-qa. It is not presented as acceptance of this fix.

Combined suite: 30 scenarios = all corrected 25 exact-offering cases + five local
JSON downloads. Existing focused-option readiness, exact source/hash checks,
redirect-safe transport, actual baseline state/team/contentVersions/revision
comparisons and truthful equality-completion flag remain. The guard and its 80
fake-route source cases are byte-for-byte copies of the reviewed adopted versions.
Only syntax checks were run here; no browser, model build, API, Worker or mutation.

Added download oracles
1. Own older active enrollment with its source unavailable, newer first-open cohort
and matching old cohort retained: download must contain the exact own enrollment
and matching old cohort object. It must never attach the newer preview metadata.
2. Same own enrollment with matching old cohort removed: enrollment unchanged,
cohort null, although newer cohort remains available and first-open.
3. Same old cohort ID repointed to new exact version: enrollment unchanged, cohort
null. It cannot use repointed/newer metadata beside the old saved enrollment.
4. Approved actual personal learner's own enrollment is cloned only in memory to
an unavailable global version, preserving its own other fields: download enrollment
matches that display projection exactly and cohort is null.
5. No enrollment, explicit private preview cohort with unknown exact body: download
has enrollment null and only the explicitly selected cohort, preserving previous
preview-only behavior; an available alternate edition never replaces that metadata.

Every case uses the real Export my retained learning button, captures its Blob
download, saves the JSON under the new evidence folder and parses the saved bytes.
Checks cover suggested filename, local blob origin, top-level shape, timestamp,
full enrollment/cohort equality, unchanged URL and read-only request log. Export
metadata and file hashes are recorded. No Start, Save, enrollment, completion or
other mutating action is clicked. The generic exporter file and new retained helper
are included among 12 product source hashes for the combined frozen acceptance.

Accepted display shapes
Personal state is cloned from an approved current GET envelope; only its own exact
version/reference are changed in memory. The intercept verifies the actual actor
and preserves all envelope fields before supplying that state. Preview projection
comes from the same actual pure-domain teamVariant used by the passing 25 cases;
its exact reference is made explicitly unavailable in memory. Source review found
both valid under current acceptance shapes; actual UI acceptance remains pending.
All specific/fallback handlers use the unchanged shared request/response guard:
same-origin GET/HEAD only, maxRedirects0, no route.continue, and rejection of 3xx,
Location or foreign response origin before JSON/fulfill. No persisted fictional
records are created; pending permission for such creation is not bypassed.

New required gate: ACADEMY_RETAINED_EXPORT_WORKER_READY=1. Keep the existing exact
Worker gate/session, actual fresh model bundle, application path, approved fixture
file, frozen dist and built-entry flags. Set ACADEMY_OFFERING_BROWSER_OUTPUT to a
fresh outside folder under this QA destination. The source built entry must equal
the new frozen copied entry. Full model/harness/source/build/runtime hash checks and
three actual before/after projection hashes must pass. All browsers close on every
path before root is told it may stop the Worker.

Portable files are under tests/. Output/model default to this folder's runtime;
explicit ACADEMY_OFFERING_MODEL_BUNDLE / ACADEMY_OFFERING_QA_OUTPUT may reference
root's freshly prepared actual bundle. Root alone adopts/builds/publishes; this
reviewer only writes outside QA materials.

Focused pure-only edges remain explicit: changed program/scope, malformed or mixed
legacy pins, duplicate cohort IDs, legacy global pin and removed-membership accepted
history are candidate focused pure cases, not extra browser passes here. This suite
does not prove server writes/CAS, live AI, external transport, measured browser zoom,
formal accessibility or field UAT. The 32px matrix tests body-text enlargement.
