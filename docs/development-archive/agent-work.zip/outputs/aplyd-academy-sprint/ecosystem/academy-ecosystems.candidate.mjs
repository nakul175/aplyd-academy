// ../../outputs/aplyd-academy-sprint/ecosystem/academy-ecosystems.candidate.ts
var RETURN_CONTRACT = "aplyd.learning-return/1.0-test";
var LAUNCH_CONTRACT = "aplyd.learning-launch/1.0-test";
var TEST_PURPOSE = "local-return-contract-review";
var MAX_GRANT_DAYS = 30;
var ADAPTERS = [
  { id: "agri", name: "Agri Saha", pathwayId: "farmer-work-records", task: "farm-record-brief", status: "test-only" },
  { id: "msme", name: "MSME", pathwayId: "msme-customer-operations", task: "customer-response-check", status: "test-only" },
  { id: "public", name: "Public service", pathwayId: "public-servant-source-briefs", task: "source-based-public-brief", status: "test-only" },
  { id: "health", name: "Health Saha", pathwayId: null, task: null, status: "domain-review-needed" }
];
var RETURN_SCOPES = ["learning.progress", "practice.record"];
var AdapterError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "AdapterError";
  }
  status;
};
var forbiddenLaunchKeys = ["return_to", "redirect", "url", "learner", "email", "user", "subject", "token", "evidence"];
function plain(v) {
  return !!v && typeof v === "object" && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
}
function exact(v, keys, label) {
  if (!plain(v) || Object.keys(v).some((k) => !keys.includes(k))) throw new AdapterError(`${label} contains unsupported fields.`);
}
function id(v, label) {
  if (typeof v !== "string" || !/^[a-zA-Z0-9_-]{1,100}$/.test(v)) throw new AdapterError(`${label} is invalid.`);
  return v;
}
function version(v) {
  if (typeof v !== "string" || !/^[a-zA-Z0-9._-]{1,100}$/.test(v)) throw new AdapterError("Content version is invalid.");
  return v;
}
function timestamp(v, label) {
  if (typeof v !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(v) || !Number.isFinite(Date.parse(v)) || new Date(v).toISOString().replace(".000Z", "Z") !== v.replace(".000Z", "Z")) throw new AdapterError(`${label} must be a valid UTC timestamp.`);
  return v;
}
function scopes(v) {
  if (!Array.isArray(v) || !v.length || v.length > RETURN_SCOPES.length || v.some((s) => !RETURN_SCOPES.includes(s)) || new Set(v).size !== v.length) throw new AdapterError("Choose supported return fields once each.");
  return RETURN_SCOPES.filter((s) => v.includes(s));
}
function adapter(partner) {
  const a = ADAPTERS.find((a2) => a2.id === partner);
  if (!a) throw new AdapterError("Ecosystem not found.", 404);
  return a;
}
function available(partner) {
  const a = adapter(partner);
  if (a.status !== "test-only" || !a.pathwayId || !a.task) throw new AdapterError("This ecosystem requires domain review before return tests are available.", 409);
  return a;
}
function match(partner, enrollment) {
  const a = available(partner);
  id(enrollment.id, "Enrollment reference");
  version(enrollment.version);
  if (enrollment.withdrawn) throw new AdapterError("Withdrawn learning cannot be used for a return test.", 409);
  if (enrollment.programId !== a.pathwayId) throw new AdapterError("Choose the pathway mapped to this ecosystem.", 409);
  return a;
}
function createLaunchIntent(partner) {
  const a = available(partner);
  return { contractVersion: LAUNCH_CONTRACT, partner: a.id, task: a.task, pathwayId: a.pathwayId, mode: "test-only" };
}
function parseLaunchIntent(query) {
  const hasIntent = query.has("ecosystem") || query.has("task") || query.has("launch_version");
  if (!hasIntent) return null;
  const allowed = ["ecosystem", "task", "launch_version", "workspace"];
  for (const key of query.keys()) if (!allowed.includes(key) || forbiddenLaunchKeys.includes(key)) throw new AdapterError("The learning link contains unsupported context. Open the Academy directly.", 400);
  for (const key of allowed) if (query.getAll(key).length > 1) throw new AdapterError("The learning link repeats a context field.", 400);
  if (query.get("launch_version") !== LAUNCH_CONTRACT) throw new AdapterError("This learning-link version is unavailable.", 409);
  const intent = createLaunchIntent(query.get("ecosystem"));
  if (query.get("task") !== intent.task) throw new AdapterError("The task does not match this ecosystem.", 400);
  const workspace = query.get("workspace");
  if (workspace && !/^tw-[a-zA-Z0-9_-]{20,80}$/.test(workspace)) throw new AdapterError("Workspace context is invalid.", 400);
  return intent;
}
function launchPath(partner) {
  const intent = createLaunchIntent(partner);
  const query = new URLSearchParams({ ecosystem: intent.partner, task: intent.task, launch_version: intent.contractVersion });
  return `/?${query.toString()}#connections`;
}
function createTestGrant(input, enrollment, now, grantId) {
  exact(input, ["partner", "enrollmentId", "scopes", "expiresAt"], "Grant");
  const a = match(input.partner, enrollment);
  if (input.enrollmentId !== enrollment.id) throw new AdapterError("Grant enrollment does not match saved learning.", 404);
  const createdAt = timestamp(now, "Current time"), expiresAt = timestamp(input.expiresAt, "Expiry");
  const duration = Date.parse(expiresAt) - Date.parse(createdAt);
  if (duration <= 0 || duration > MAX_GRANT_DAYS * 864e5) throw new AdapterError(`Choose an expiry within the next ${MAX_GRANT_DAYS} days.`);
  return { id: id(grantId, "Grant reference"), partner: a.id, enrollmentId: enrollment.id, contentVersion: enrollment.version, purpose: TEST_PURPOSE, contractVersion: RETURN_CONTRACT, scopes: scopes(input.scopes), createdAt, expiresAt, revokedAt: null };
}
function revokeTestGrant(grant, now) {
  return { ...grant, revokedAt: grant.revokedAt ?? timestamp(now, "Withdrawal time") };
}
function grantStatus(grant, now) {
  timestamp(now, "Current time");
  timestamp(grant.createdAt, "Grant creation");
  timestamp(grant.expiresAt, "Grant expiry");
  const duration = Date.parse(grant.expiresAt) - Date.parse(grant.createdAt);
  if (duration <= 0 || duration > MAX_GRANT_DAYS * 864e5 || Date.parse(grant.createdAt) > Date.parse(now)) throw new AdapterError("Saved grant timing is invalid.", 409);
  if (grant.revokedAt) {
    timestamp(grant.revokedAt, "Grant withdrawal");
    return "withdrawn";
  }
  if (Date.parse(now) >= Date.parse(grant.expiresAt)) return "expired";
  return "active";
}
function buildReturnReceipt(grant, enrollment, totalLessons, now, eventId) {
  const a = match(grant.partner, enrollment);
  timestamp(now, "Current time");
  id(eventId, "Event reference");
  if (grantStatus(grant, now) !== "active") throw new AdapterError("This test grant is no longer active.", 403);
  if (grant.purpose !== TEST_PURPOSE || grant.contractVersion !== RETURN_CONTRACT) throw new AdapterError("This grant contract is unavailable. Make a new test choice.", 409);
  if (grant.enrollmentId !== enrollment.id || grant.contentVersion !== enrollment.version) throw new AdapterError("This grant belongs to different learning or a different version.", 403);
  const permitted = scopes(grant.scopes);
  if (!Number.isInteger(totalLessons) || totalLessons < 1 || totalLessons > 100 || !Array.isArray(enrollment.completed) || new Set(enrollment.completed).size !== enrollment.completed.length || enrollment.completed.length > totalLessons) throw new AdapterError("The saved progress summary is invalid.", 409);
  const payload = { contract_version: RETURN_CONTRACT, mode: "local-test", partner: a.id, event_id: eventId, occurred_at: now, enrollment_ref: enrollment.id, pathway_id: enrollment.programId, content_version: enrollment.version, purpose: TEST_PURPOSE, scopes: permitted };
  if (permitted.includes("learning.progress")) payload.learning = { completed_lessons: enrollment.completed.length, total_lessons: totalLessons, status: enrollment.completed.length === totalLessons ? "completed" : "in-progress" };
  if (permitted.includes("practice.record")) {
    const recordStatus = enrollment.record?.status ?? "not-issued";
    if (!["active", "suspended", "not-issued"].includes(recordStatus)) throw new AdapterError("The current practice-record status is unavailable.", 409);
    payload.practice_record = { status: recordStatus, claim_type: "nonaccredited-practice", review_mode: !enrollment.record ? "not-reviewed" : enrollment.record.workspaceId ? "assigned-human-review" : "sample-workflow" };
  }
  validateReturnPayload(payload);
  return { id: eventId, partner: a.id, enrollmentId: enrollment.id, grantId: grant.id, contractVersion: RETURN_CONTRACT, createdAt: now, status: "simulated", payload, checks: ["Partner/pathway mapping", "Current grant and expiry", "Requested field allowlist", "Pinned learning version", "Versioned contract shape", "Evidence and identity excluded"].map((name) => ({ name, passed: true })), note: "Validated locally. No partner was contacted and no data was sent." };
}
function validateReturnPayload(input) {
  exact(input, ["contract_version", "mode", "partner", "event_id", "occurred_at", "enrollment_ref", "pathway_id", "content_version", "purpose", "scopes", "learning", "practice_record"], "Return payload");
  if (input.contract_version !== RETURN_CONTRACT || input.mode !== "local-test" || input.purpose !== TEST_PURPOSE) throw new AdapterError("Return contract or mode is unavailable.");
  const a = available(input.partner);
  if (input.pathway_id !== a.pathwayId) throw new AdapterError("Return pathway does not match the ecosystem.");
  id(input.event_id, "Event reference");
  id(input.enrollment_ref, "Enrollment reference");
  timestamp(input.occurred_at, "Event time");
  version(input.content_version);
  const requested = scopes(input.scopes);
  if (Object.hasOwn(input, "learning") !== requested.includes("learning.progress") || Object.hasOwn(input, "practice_record") !== requested.includes("practice.record")) throw new AdapterError("Return fields do not match the chosen scopes.");
  if (requested.includes("learning.progress")) {
    exact(input.learning, ["completed_lessons", "total_lessons", "status"], "Progress summary");
    const l = input.learning;
    if (!Number.isInteger(l.completed_lessons) || !Number.isInteger(l.total_lessons) || l.completed_lessons < 0 || l.total_lessons < 1 || l.total_lessons > 100 || l.completed_lessons > l.total_lessons || l.status !== (l.completed_lessons === l.total_lessons ? "completed" : "in-progress")) throw new AdapterError("Progress summary is invalid.");
  }
  if (requested.includes("practice.record")) {
    exact(input.practice_record, ["status", "claim_type", "review_mode"], "Practice-record summary");
    const r = input.practice_record;
    if (!["not-issued", "active", "suspended"].includes(r.status) || r.claim_type !== "nonaccredited-practice" || !["not-reviewed", "sample-workflow", "assigned-human-review"].includes(r.review_mode) || r.status === "not-issued" !== (r.review_mode === "not-reviewed")) throw new AdapterError("Practice-record summary is invalid.");
  }
}
export {
  ADAPTERS,
  AdapterError,
  LAUNCH_CONTRACT,
  MAX_GRANT_DAYS,
  RETURN_CONTRACT,
  RETURN_SCOPES,
  TEST_PURPOSE,
  adapter,
  buildReturnReceipt,
  createLaunchIntent,
  createTestGrant,
  grantStatus,
  launchPath,
  parseLaunchIntent,
  revokeTestGrant,
  validateReturnPayload
};
