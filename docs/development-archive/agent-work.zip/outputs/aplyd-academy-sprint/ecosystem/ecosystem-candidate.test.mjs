import {test} from 'node:test';
import assert from 'node:assert/strict';
import {ADAPTERS, RETURN_CONTRACT, LAUNCH_CONTRACT, TEST_PURPOSE, AdapterError, adapter, createLaunchIntent, parseLaunchIntent, launchPath, createTestGrant, revokeTestGrant, grantStatus, buildReturnReceipt, validateReturnPayload} from './academy-ecosystems.candidate.mjs';
const now = '2026-10-05T08:00:00.000Z', expiry = '2026-10-12T08:00:00.000Z';
const enrollment = (changes = {}) => ({id: 'enrollment-123', programId: 'msme-customer-operations', version: '0.1-review-draft', withdrawn: false, completed: ['msme-01'], record: null, ...changes});
const grant = (chosen = ['learning.progress'], changes = {}) => createTestGrant({partner: 'msme', enrollmentId: 'enrollment-123', scopes: chosen, expiresAt: expiry, ...changes}, enrollment(), now, 'grant-123');
const receipt = (g = grant(), e = enrollment()) => buildReturnReceipt(g, e, 3, now, 'event-123');
const rejects = (fn, status) => assert.throws(fn, e => e instanceof AdapterError && (status === undefined || e.status === status));
test('three bounded task mappings are available; Health requires review', () => {
  assert.equal(ADAPTERS.filter(a => a.status === 'test-only').length, 3);
  for (const partner of ['agri', 'msme', 'public']) assert.equal(createLaunchIntent(partner).mode, 'test-only');
  rejects(() => createLaunchIntent('health'), 409);
});
test('unknown and inherited partner names do not resolve', () => {
  for (const partner of ['__proto__', 'toString', 'constructor', '', null]) rejects(() => adapter(partner), 404);
});
test('launch round trip carries a public task only', () => {
  const url = new URL(launchPath('msme'), 'https://example.test');
  assert.deepEqual(parseLaunchIntent(url.searchParams), createLaunchIntent('msme'));
  assert.equal(url.hash, '#connections');
  assert.equal(url.searchParams.has('email'), false);
});
test('no launch context leaves ordinary navigation unchanged', () => {
  assert.equal(parseLaunchIntent(new URLSearchParams('workspace=tw-12345678901234567890')), null);
});
test('external destinations and private identity in launch are rejected', () => {
  const base = new URL(launchPath('msme'), 'https://example.test');
  for (const key of ['return_to', 'redirect', 'url', 'email', 'subject', 'evidence', 'token']) {
    const q = new URLSearchParams(base.searchParams); q.set(key, 'https://evil.test');
    rejects(() => parseLaunchIntent(q), 400);
  }
});
test('duplicate, mismatched and unavailable launch context rejects', () => {
  const base = new URL(launchPath('msme'), 'https://example.test').searchParams;
  const duplicate = new URLSearchParams(base); duplicate.append('ecosystem', 'agri'); rejects(() => parseLaunchIntent(duplicate), 400);
  const task = new URLSearchParams(base); task.set('task', 'farm-record-brief'); rejects(() => parseLaunchIntent(task), 400);
  const v = new URLSearchParams(base); v.set('launch_version', 'future'); rejects(() => parseLaunchIntent(v), 409);
  const workspace = new URLSearchParams(base); workspace.set('workspace', 'another-owner'); rejects(() => parseLaunchIntent(workspace), 400);
});
test('test grant is bound to exact learning, version, fields and purpose', () => {
  const g = grant(['practice.record', 'learning.progress']);
  assert.deepEqual(g.scopes, ['learning.progress', 'practice.record']);
  assert.equal(g.contentVersion, enrollment().version); assert.equal(g.purpose, TEST_PURPOSE); assert.equal(g.contractVersion, RETURN_CONTRACT);
});
test('wrong enrollment or pathway cannot receive a test grant', () => {
  rejects(() => grant(['learning.progress'], {enrollmentId: 'foreign'}), 404);
  rejects(() => grant(['learning.progress'], {partner: 'agri'}), 409);
  rejects(() => grant(['learning.progress'], {partner: 'health'}), 409);
});
test('unknown fields, unsupported fields and duplicate scope reject', () => {
  for (const scopes of [[], ['email'], ['learning.progress', 'learning.progress'], ['learning.progress', 'practice.record', 'fields']]) rejects(() => grant(scopes));
  rejects(() => grant(['learning.progress'], {email: 'private@example.test'}));
  rejects(() => grant(['learning.progress'], {purpose: 'live-delivery'}));
});
test('invalid, past, calendar-normalized and overlong expiry reject', () => {
  for (const expiresAt of ['invalid', now, '2026-10-04T08:00:00.000Z', '2026-11-06T08:00:00.000Z', '2026-02-31T08:00:00.000Z']) rejects(() => grant(['learning.progress'], {expiresAt}));
});
test('expiry is authoritative at its exact boundary', () => {
  const g = grant();
  assert.equal(grantStatus(g, '2026-10-12T07:59:59.999Z'), 'active');
  assert.equal(grantStatus(g, expiry), 'expired');
  rejects(() => buildReturnReceipt(g, enrollment(), 3, expiry, 'next-event'), 403);
});
test('withdrawal is idempotent and blocks new tests without rewriting history', () => {
  const g = grant(), before = receipt(g), revoked = revokeTestGrant(g, now);
  assert.equal(grantStatus(revoked, now), 'withdrawn');
  assert.deepEqual(revokeTestGrant(revoked, expiry), revoked);
  rejects(() => receipt(revoked), 403);
  assert.equal(before.status, 'simulated'); assert.equal(before.payload.learning.completed_lessons, 1);
});
test('malformed or future saved timing fails closed', () => {
  rejects(() => receipt({...grant(), expiresAt: 'garbage'}));
  rejects(() => receipt({...grant(), createdAt: '2026-10-06T08:00:00.000Z'}), 409);
});
test('progress-only snapshot excludes record and all private canaries', () => {
  const e = enrollment({profile: {name: 'SECRET NAME', email: 'private@example.test'}, draft: {task: 'SECRET DRAFT'}, attempts: [{fields: {task: 'SECRET EVIDENCE'}, decision: {score: 100, notes: ['SECRET NOTE'], actor: 'SECRET ACTOR'}}], record: {id: 'SECRET RECORD ID', status: 'active', reviewedBy: 'SECRET REVIEWER'}});
  const r = receipt(grant(), e), json = JSON.stringify(r);
  assert.equal(r.payload.practice_record, undefined);
  for (const marker of ['SECRET', 'private@example.test', 'score', 'notes', 'fields', 'reviewedBy']) assert.equal(json.includes(marker), false);
  assert.equal(r.note, 'Validated locally. No partner was contacted and no data was sent.');
});
test('record-only snapshot excludes lesson counts and preserves nonaccredited claim', () => {
  const r = receipt(grant(['practice.record']), enrollment({record: {id: 'record-123', status: 'active'}}));
  assert.equal(r.payload.learning, undefined);
  assert.deepEqual(r.payload.practice_record, {status: 'active', claim_type: 'nonaccredited-practice', review_mode: 'sample-workflow'});
});
test('test after adverse appeal reflects current suspended status', () => {
  const g = grant(['practice.record']), original = receipt(g, enrollment({record: {id: 'record-123', status: 'active', workspaceId: 'tw-workspace'}}));
  const updated = receipt(g, enrollment({record: {id: 'record-123', status: 'suspended', workspaceId: 'tw-workspace'}}));
  assert.equal(original.payload.practice_record.status, 'active'); assert.equal(updated.payload.practice_record.status, 'suspended');
  assert.equal(updated.payload.practice_record.review_mode, 'assigned-human-review');
});
test('retesting must use current same enrollment and pinned version', () => {
  rejects(() => receipt(grant(), enrollment({id: 'other'})), 403);
  rejects(() => receipt(grant(), enrollment({version: 'v2'})), 403);
  rejects(() => receipt(grant(), enrollment({programId: 'farmer-work-records'})), 409);
  rejects(() => receipt(grant(), enrollment({withdrawn: true})), 409);
});
test('receipt is a versioned inspectable local snapshot', () => {
  const r = receipt();
  assert.equal(r.contractVersion, RETURN_CONTRACT); assert.equal(r.payload.mode, 'local-test');
  assert.equal(r.grantId, 'grant-123'); assert.equal(r.payload.event_id, r.id);
  assert.equal(r.checks.length, 6); assert.ok(r.checks.every(c => c.passed));
  validateReturnPayload(r.payload);
});
test('validator rejects forbidden top-level and nested merges', () => {
  const p = receipt(grant(['learning.progress', 'practice.record'])).payload;
  for (const key of ['email', 'fields', 'attempts', 'scores', 'reviewer', '__proto__']) {
    const modified = JSON.parse(JSON.stringify(p)); Object.defineProperty(modified, key, {value: 'private', enumerable: true});
    rejects(() => validateReturnPayload(modified));
  }
  rejects(() => validateReturnPayload({...p, learning: {...p.learning, evidence: 'private'}}));
  rejects(() => validateReturnPayload({...p, practice_record: {...p.practice_record, score: 100}}));
});
test('validator rejects stale mode, mismatched scope and inconsistent status', () => {
  const p = receipt().payload;
  rejects(() => validateReturnPayload({...p, mode: 'live'}));
  rejects(() => validateReturnPayload({...p, contract_version: 'future'}));
  rejects(() => validateReturnPayload({...p, scopes: ['practice.record']}));
  rejects(() => validateReturnPayload({...p, learning: {...p.learning, status: 'completed'}}));
  const rp = receipt(grant(['practice.record'])).payload;
  rejects(() => validateReturnPayload({...rp, practice_record: {...rp.practice_record, status: 'active'}}));
});
test('duplicate or impossible stored progress rejects instead of overstating completion', () => {
  rejects(() => receipt(grant(), enrollment({completed: ['a', 'a']})), 409);
  rejects(() => receipt(grant(), enrollment({completed: ['a', 'b', 'c', 'd']})), 409);
  assert.equal(receipt(grant(), enrollment({completed: ['a', 'b', 'c']})).payload.learning.status, 'completed');
});
