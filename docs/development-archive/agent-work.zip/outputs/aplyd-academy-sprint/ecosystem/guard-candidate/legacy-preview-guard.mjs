// outputs/aplyd-academy-sprint/ecosystem/guard-candidate/legacy-preview-guard.ts
var LegacyPreviewError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "LegacyPreviewError";
  }
  status;
};
var LEGACY_PREVIEW_MAPPINGS = [
  { partner: "agri", programId: "farmer-work-records" },
  { partner: "msme", programId: "msme-customer-operations" },
  { partner: "public", programId: "public-servant-source-briefs" }
];
var partners = [...LEGACY_PREVIEW_MAPPINGS.map((m) => m.partner), "health"];
function exact(command, keys) {
  if (!command || typeof command !== "object" || Array.isArray(command) || Object.keys(command).some((k) => !keys.includes(k))) throw new LegacyPreviewError("Use only the supported local preview fields.", 400);
}
function partner(value) {
  if (typeof value !== "string" || !partners.includes(value)) throw new LegacyPreviewError("Ecosystem not found.", 404);
  return value;
}
function available(value) {
  const p = partner(value);
  if (p === "health") throw new LegacyPreviewError("Health Saha requires domain and privacy review. Local return previews are unavailable.", 409);
  return LEGACY_PREVIEW_MAPPINGS.find((m) => m.partner === p);
}
function validateLegacyConnectionCommand(command) {
  exact(command, ["type", "partner", "enabled"]);
  if (command.type !== "connection") throw new LegacyPreviewError("Use a local preview preference command.", 400);
  const p = partner(command.partner);
  if (typeof command.enabled !== "boolean") throw new LegacyPreviewError("Choose a local preview preference.");
  if (command.enabled) available(p);
  return { partner: p, enabled: command.enabled, permissionKind: "legacy-preview-preference" };
}
function validateLegacyReturnCommand(state, command, curriculum) {
  exact(command, ["type", "partner", "enrollmentId"]);
  if (command.type !== "deliver") throw new LegacyPreviewError("Use a local return preview command.", 400);
  const mapping = available(command.partner);
  if (typeof command.enrollmentId !== "string" || !command.enrollmentId) throw new LegacyPreviewError("Choose saved learning for this local preview.", 400);
  if (!state.connections || !Object.hasOwn(state.connections, mapping.partner) || state.connections[mapping.partner] !== true) throw new LegacyPreviewError("Enable this local preview preference before testing a summary.", 403);
  const e = state.enrollments.find((e2) => e2.id === command.enrollmentId);
  if (!e) throw new LegacyPreviewError("Enrollment not found in your learning space.", 404);
  if (e.withdrawn !== false) throw new LegacyPreviewError("Withdrawn learning cannot be used for a local return preview.", 409);
  if (e.programId !== mapping.programId) throw new LegacyPreviewError("Choose the pathway mapped to this ecosystem.", 409);
  const p = curriculum.pathways.find((p2) => p2.id === mapping.programId);
  if (!p || e.version !== curriculum.contentVersion) throw new LegacyPreviewError("The pinned learning version is unavailable for this local preview.", 409);
  if (state.paused?.includes(e.programId)) throw new LegacyPreviewError("This pathway is paused for content review. Previous local previews remain available.", 409);
  const allowed = new Set(p.lessons.map((l) => l.id));
  if (!Array.isArray(e.completed) || new Set(e.completed).size !== e.completed.length || e.completed.some((id) => !allowed.has(id))) throw new LegacyPreviewError("The saved progress references are unavailable for this local preview.", 409);
  const status = e.record?.status ?? "not-issued";
  if (!["not-issued", "active", "suspended"].includes(status)) throw new LegacyPreviewError("The current practice-record status is unavailable.", 409);
  return { partner: mapping.partner, enrollmentId: e.id, programId: e.programId, contentVersion: e.version, completedLessons: e.completed.length, recordStatus: status, mode: "local-simulation", permissionKind: "legacy-preview-preference" };
}
export {
  LEGACY_PREVIEW_MAPPINGS,
  LegacyPreviewError,
  validateLegacyConnectionCommand,
  validateLegacyReturnCommand
};
