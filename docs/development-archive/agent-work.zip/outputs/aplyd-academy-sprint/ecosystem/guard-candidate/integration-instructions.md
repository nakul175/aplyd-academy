# Immediate ecosystem preview guard for v0.4

Yes: the lead can ship a small compatibility guard before the full enrollment-scoped grant workbench. It can correct the contradictory Health behavior and cross-partner selection now, while continuing to describe the feature truthfully as a local simulator. This guard alone is not scoped consent, a versioned return contract, identity federation or an external integration.

## Exact engine integration

Copy the reviewed `legacy-preview-guard.ts` candidate to `lib/academy-ecosystem-guard.ts`. Replace its standalone `LegacyPreviewError` declaration with the existing engine `RuleError` imported under that alias, or translate every guard error to `new RuleError(e.message, e.status)` in the engine. Existing API handlers catch the engine class by identity.

In `lib/academy-engine.ts`, import:

```ts
import {validateLegacyConnectionCommand,validateLegacyReturnCommand} from './academy-ecosystem-guard';
```

Replace the current `connection` and `deliver` cases with these reviewed equivalents. Keep the current outer `structuredClone`, owner API, revision CAS, durable audit and pilot receipt count. Preserve historical local receipt data without trying to reinterpret its old shape.

```ts
case 'connection': {
  const choice=validateLegacyConnectionCommand(c);
  s.connections[choice.partner]=choice.enabled;
  if(!choice.enabled) s.deliveries=s.deliveries.map(d=>
    d.partner===choice.partner&&d.status==='queued'
      ? {...d,status:'cancelled'} : d);
  break;
}
case 'deliver': {
  const summary=validateLegacyReturnCommand(s,c,{
    contentVersion:CONTENT_VERSION,pathways:programs
  });
  if(s.deliveries.length>=100)throw new RuleError('Connection test limit reached.');
  s.deliveries.unshift({
    id:crypto.randomUUID(),partner:summary.partner,
    enrollmentId:summary.enrollmentId,
    revision:s.deliveries.filter(d=>d.enrollmentId===summary.enrollmentId).length+1,
    status:'simulated',createdAt:now,
    payload:{learner_ref:summary.enrollmentId,pathway:summary.programId,
      completedLessons:summary.completedLessons,recordStatus:summary.recordStatus},
    note:'Local mapping preview. No scoped grant, external connection or send was created.'
  });
  break;
}
```

Keeping `learner_ref` here preserves the existing simulator payload shape; document that it is an enrollment reference, not a linked partner learner subject. The eventual versioned workbench should use the clearer `enrollment_ref` field in its separate contract. Do not change old receipts or label them as that new contract.

The guard enforces exact allowed command fields; known partner IDs; Health enable/test denial; a current own Boolean preview preference; owner-resolved saved enrollment; exact partner/pathway mapping; current available content version; nonwithdrawn learning; no content pause; valid unique activity IDs; and current practice status. The helpers perform no mutation, grant creation or network I/O.

Disabling a historical Health preference is intentionally allowed. Historical simulated Health/mismatched receipts remain readable as historical local snapshots. They do not become valid examples of an approved mapping, and later new tests cannot recreate them. No schema or table migration is required for this guard.

## UI changes required with the guard

The current UI calls Boolean preferences “grants” and uses one enrollment selection across every card. Update it in the same release:

1. Change **Allow achievement return tests** to **Allow local summary previews**; status/toast copy becomes **Local preview preference enabled/disabled**. Explain that this preference creates no scoped permission or external connection. Existing true values may remain selected solely as local preview preferences.
2. Keep Health Saha without grant or preview controls. Its server rejection must remain effective if someone crafts a request.
3. Filter each card's choices to nonwithdrawn enrollments whose `programId` matches that card's mapped pathway. Keep selection separately by partner, or use a clearly local card component. If the selected ID no longer matches, disable the button and ask for matching learning rather than using another card's stale ID.
4. Rename the button **Preview local summary**. If no matching enrollment exists, offer the mapped learning action and show “Save learning in this pathway before previewing a summary.”
5. Preserve the entire own historical `deliveries` table. Show a notice that earlier local snapshots may predate current mapping checks and are not evidence of partner receipt or current record status. New previews use current saved status.
6. Keep shared `connection`/`deliver` commands rejected. The guard must not bypass the Team API or expose another learner's state. Offer the personal lab for local previews instead.

## Future scoped-grant migration boundary

Do **not** initialize `ecosystemGrants` from `connections`, convert true Booleans into enrollment/field/expiry grants, attach the new return-contract version to old receipts, or infer that current historical receipts grant permission. The guard produces no such data.

When explicit scoped grant UI ships, require a fresh enrollment, purpose, summary fields and expiry choice. That new `ecosystem-test` command must use an active saved scoped grant; a legacy Boolean cannot authorize it. Keep legacy history read-only. At that point the old `deliver` route should either be disabled with a renewal prompt or remain a clearly separate legacy local simulator with no grant semantics. It must never become a live send path.

## Review and verification

Executed candidate evidence: strict standalone TypeScript check passed; the guard's 15 pure tests passed. They include all three mappings, all six cross-partner combinations, historical Health flags/history, inherited keys, injected fields, current-version/pause/withdrawal checks, private canary exclusion and no grant migration.

Prepared but not executed:

- `engine-guard-integration-candidate.test.mjs` uses the lead's freshly rebuilt `.sites-runtime/engine.mjs` to prove the real engine guard rejects Health/cross-mapping, preserves old invalid simulated history and uses current suspended status.
- `guard-api-candidate.mjs` operates only on a loopback local Worker with fresh synthetic identities. It checks real API guard behavior, private draft exclusion, separate owner state, history retention, no silent grants and an actual same-revision preview/withdrawal race.

Run from the project workspace after integration and rebuilding the local Worker:

```sh
node --test outputs/aplyd-academy-sprint/ecosystem/guard-candidate/legacy-preview-guard.test.mjs
node --test outputs/aplyd-academy-sprint/ecosystem/guard-candidate/engine-guard-integration-candidate.test.mjs
node outputs/aplyd-academy-sprint/ecosystem/guard-candidate/guard-api-candidate.mjs
```

Browser verification remains required for independent filtered selections, missing matching learning, stale selection/reload, useful server errors, retained history and responsive/200% text layouts. These candidates neither contact a partner nor verify hosted authentication.
