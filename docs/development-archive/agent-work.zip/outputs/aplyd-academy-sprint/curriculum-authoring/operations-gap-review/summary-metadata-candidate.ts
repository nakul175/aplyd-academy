/** Narrow server-side metadata helper, after current summary authorization.
 * Do not expose attempts, decisions, score arrays, appeal reason or learner drafts.
 * The existing status label remains intact for earlier clients. */
export function reviewSummaryMetadata(enrollment:any):{
 practiceRecordStatus:'active'|'suspended'|null;
 hasOpenAppeal:boolean;
 hasPendingAssessment:boolean;
}{
 return {
  practiceRecordStatus:['active','suspended'].includes(enrollment.record?.status)?enrollment.record.status:null,
  hasOpenAppeal:!enrollment.withdrawn&&enrollment.appeals.some((appeal:any)=>appeal.status==='open'),
  hasPendingAssessment:!enrollment.withdrawn&&enrollment.attempts.some((attempt:any)=>!attempt.decision),
 };
}
