// lib/curriculum-versions/0.1-review-draft.json
var review_draft_default = {
  schemaVersion: "1.0",
  contentVersion: "0.1-review-draft",
  product: "Aplyd Academy",
  status: "Review draft: not approved sector training, accredited curriculum, or professional advice",
  language: "en",
  audience: "Adult learners",
  designNotes: [
    "All people, orders, records, documents, policies and AI outputs in this file are fictional teaching fixtures.",
    "Supplied AI drafts allow the whole journey to work without an external AI account or API call.",
    "An approved external AI tool may optionally produce another draft using the synthetic packet only. Learners must not enter real confidential material or credentials.",
    "Quiz feedback supports learning. A quiz score alone must not issue a competency credential.",
    "Practical assessment requires an assigned human reviewer. Rubric weights and critical gates are proposed, published training standards for this draft.",
    "A facilitator may read lesson text and capture an oral response with learner confirmation when an approved accommodation exists. Assistance must be recorded and must not supply the judgment answer."
  ],
  assessmentPolicy: {
    scoreScale: [0, 1, 2, 3, 4],
    weightedScoreFormula: "Sum of criterion weight multiplied by criterion score divided by 4; maximum 100",
    minimumWeightedScore: 70,
    passingRule: "Weighted score is at least 70 AND every declared critical gate is met. A critical failure cannot be averaged away.",
    decisionAuthority: "Assigned independent human assessor; no self-assessment or autonomous AI credential decision",
    feedbackRule: "Record score, evidence reference, critical-gate decision and actionable feedback for each criterion.",
    retryRule: "Retries and deadlines must be published by the offering before enrollment. Do not infer a fixed retry allowance from this seed file.",
    appealRule: "A learner may request a reasoned review under the offering's published appeal policy. The appeal reviewer must be independent of the original decision."
  },
  pathways: [
    {
      id: "farmer-work-records",
      title: "Farm records and better questions with AI",
      ecosystem: "Agri Saha",
      role: "Farmer",
      level: "Foundation to applied",
      summary: "Organize an activity record, check an AI-generated summary, and prepare useful questions for an agricultural expert.",
      promise: "You can turn a simple farm record into a verified summary and explain what still needs expert input.",
      estimatedMinutes: 110,
      prerequisites: ["Understand the example currency amounts with help if needed", "Use a simple form or receive planned facilitator assistance"],
      outcomes: ["Distinguish a duplicate transaction from a separate expense", "Check totals against source records", "Spot unsupported AI claims", "Create a clear expert question brief", "Keep private or commercially sensitive records out of unapproved tools"],
      credentialClaim: "Demonstrated farm-record organization, information checking and expert-question preparation using synthetic training data",
      credentialExclusions: ["No agricultural professional qualification", "No certification to prescribe farm inputs or make agronomic decisions"],
      sourceNotice: "Synthetic farm records supplied within each activity are the only factual source for this exercise.",
      lessons: [
        {
          id: "farm-01",
          title: "Make a useful work record",
          estimatedMinutes: 25,
          objective: "Build a consistent record and verify a duplicate before calculating a total.",
          lessonText: "A useful record separates what happened from what you think it means. Start with a date, activity, transaction reference, amount and unit where needed. A repeated line may be a duplicate, but two similar expenses can also be real. Check the reference or original receipt before removing anything. In this exercise, the source packet explicitly says that T02 was copied twice and represents one transport payment. Keep a note of that correction. Add the verified amounts rather than trusting a total supplied by a tool. AI can help organize a table or explain a calculation, but it cannot know which entry is genuine without evidence. When you use your own records later, keep the master copy in your approved location and choose a tool you are permitted to use. You do not need to upload names, telephone numbers, bank information or exact location details to practise this skill.",
          steps: ["Read the source packet", "Create one row per confirmed transaction", "Record why the extra T02 line was removed", "Calculate the verified total", "Identify one field you would add for future records"],
          exercise: {
            title: "Clean the fictional farm activity record",
            sourcePacket: [
              { sourceId: "T01", date: "2026-10-01", activity: "Recordkeeping support", quantity: 3, unit: "hours", rate: 150, amount: 450, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR" },
              { sourceId: "T03", date: "2026-10-03", activity: "Storage materials", quantity: 1, unit: "lot", rate: 800, amount: 800, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR", sourceNote: "Confirmed copied line; same receipt and payment as T02 above" }
            ],
            suppliedAiDraft: "The four entries total INR 1,550. Each row is a separate expense.",
            optionalAiPrompt: "Organize the supplied fictional transactions into a table. Use the source note to handle duplicates, show the calculation, and list uncertainty. Do not infer farm area, crop performance or missing transactions.",
            learnerTask: "Produce a corrected three-row table, show your total and explain the duplicate correction.",
            expectedEvidence: ["Corrected rows with source references", "450 + 150 + 800 = 1,400", "Note that T02 was removed once because the source confirms a copied payment", "One useful future record field such as receipt reference or unit"],
            assessorReference: "There are three confirmed transactions totaling INR 1,400. The raw four-line total is INR 1,550, but that counts the confirmed T02 copy twice. A learner must not generalize that every repeated amount is a duplicate."
          },
          quiz: [
            { id: "farm-01-q1", question: "What is the verified expense total?", options: ["INR 1,400", "INR 1,550", "INR 1,250", "It must be guessed from the activities"], correctOptionIndex: 0, explanation: "T02 is a confirmed copy of the same payment. The three verified amounts are 450, 150 and 800, which total 1,400." },
            { id: "farm-01-q2", question: "Two entries have the same amount but different receipt references. What should you do?", options: ["Delete the second amount automatically", "Keep both as confirmed without checking", "Check the source records before deciding whether either is duplicated", "Ask AI to choose the genuine one without evidence"], correctOptionIndex: 2, explanation: "Equal amounts are not proof of duplication. The original references and payment evidence decide whether the expenses are separate." },
            { id: "farm-01-q3", question: "Which practice input is suitable for this activity?", options: ["Your bank login details", "The supplied fictional record", "A neighbor's private transaction history", "Any record because AI makes it anonymous"], correctOptionIndex: 1, explanation: "The fictional record provides enough information for practice. Uploading private or secret information is unnecessary and inappropriate." }
          ],
          reflectionPrompt: "Which record field would make it easier for you to check a future total, and why?",
          returnToWorkAction: "Create a blank record template in an approved location. Use it for one permitted task and check entries against the original records before any sharing."
        },
        {
          id: "farm-02",
          title: "Check an AI summary before using it",
          estimatedMinutes: 20,
          objective: "Separate supported observations, missing context and unsupported recommendations.",
          lessonText: "A summary can sound confident while mixing correct statements with invented ones. Check important statements one at a time. Ask what evidence supports each claim. A total can be checked against transaction rows. A cost per acre needs area information. A claim about crop results needs relevant evidence, rather than a guess based on expenses. In this activity, the verified spending record tells you what was recorded; it does not tell you the farm area, complete budget, crop condition or likely yield. Mark these gaps explicitly. When a claim could affect a significant farm decision, prepare a question for an appropriate expert instead of treating an AI draft as a recommendation. A useful summary includes the known total, its limited scope, and the missing information. Verification is part of the work, even when it takes more time than generating the draft.",
          steps: ["Check the total", "Label each claim supported, unsupported or unknown", "Explain what evidence a per-acre figure would need", "Rewrite the summary with limits", "Identify the claim that needs expert input"],
          exercise: {
            title: "Find the unsupported claims",
            sourcePacket: ["Verified transactions: T01 INR 450; T02 INR 150; T03 INR 800.", "Recorded total: INR 1,400.", "Farm area, crop condition, total seasonal budget and crop outcomes are not supplied."],
            suppliedAiDraft: "The recorded expenses are INR 1,400. That is INR 700 per acre. These purchases will increase yield by 30%, so the farmer should immediately repeat them.",
            optionalAiPrompt: "Summarize only the supplied synthetic expense record. For every statement distinguish source-supported facts from missing context. Do not predict yield or recommend actions.",
            learnerTask: "Annotate the draft and create a two- or three-sentence corrected summary.",
            expectedEvidence: ["Total supported by the three transaction rows", "Per-acre claim rejected because area is missing", "Yield and immediate-action claims rejected as unsupported", "Corrected summary describes recorded expenses and missing context", "Expert referral for consequential recommendations"],
            assessorReference: "The packet supports only the INR 1,400 recorded total. It does not establish cost per acre, a 30% yield effect or a decision to repeat the purchases. Accept a cautious summary using equivalent plain language."
          },
          quiz: [
            { id: "farm-02-q1", question: "Which claim is supported by the packet?", options: ["Yield will rise by 30%", "The farm has two acres", "The recorded expenses total INR 1,400", "Repeating the purchases is the right decision"], correctOptionIndex: 2, explanation: "The transaction amounts support the total. Area, yield and action advice are not in the source packet." },
            { id: "farm-02-q2", question: "Why is INR 700 per acre unverified?", options: ["It is too small", "The packet does not give the farm area", "All AI calculations are wrong", "Per-acre costs can never be calculated"], correctOptionIndex: 1, explanation: "A cost per acre requires a relevant area and a defined cost scope. The area is absent, so the figure is unsupported here." },
            { id: "farm-02-q3", question: "What is the appropriate response to the draft's yield recommendation?", options: ["Act immediately because the wording is confident", "Forward it as approved guidance", "Ask AI to make the recommendation stronger", "Mark it unsupported and seek appropriate expert input before a consequential action"], correctOptionIndex: 3, explanation: "The provided record does not support a yield prediction or action. Recognizing the limit and escalating is the responsible response." }
          ],
          reflectionPrompt: "What is one confident-sounding statement you would still need to check?",
          returnToWorkAction: "For your next permitted AI-assisted summary, label important statements as verified, unverified or requiring expert input before using the draft."
        },
        {
          id: "farm-03",
          title: "Prepare a useful expert conversation",
          estimatedMinutes: 30,
          objective: "Turn a checked record into a concise question brief without claiming an unsupported decision.",
          lessonText: "AI is useful when it helps you organize questions, rather than deciding something it cannot support. A good expert brief states the purpose, summarizes verified information, identifies missing context, and asks specific questions. Keep facts separate from assumptions. Do not turn a missing detail into a made-up answer. In this example, you can explain that three recorded expenses total INR 1,400 and that a previous draft invented a yield claim. You can ask what additional records an expert needs and how to check any recommendation. The expert may need information beyond the training packet; share it only through an approved channel and only when relevant. Keep the brief short enough to use during a conversation. Afterward, record what was confirmed, what remains uncertain and who will take the next step. This pathway demonstrates recordkeeping and information judgment, not authority to prescribe farm practices.",
          steps: ["State the conversation's purpose", "Include the checked record total and sources", "List three relevant missing details", "Write three specific expert questions", "Choose an approved way to use the brief"],
          exercise: {
            title: "Build the expert question brief",
            sourcePacket: ["Use the verified three-row record from farm-01.", "The earlier AI draft's per-acre and yield claims were unsupported.", "No farm area, crop condition or complete seasonal expense record is provided."],
            suppliedAiDraft: "Expert brief: Our two-acre farm will gain 30% yield if we repeat the purchases. Please approve this plan.",
            optionalAiPrompt: "Create a short question brief from the supplied fictional packet. Separate verified facts, missing context and questions. Do not invent area, crop condition or outcomes, and do not request approval of an unsupported plan.",
            learnerTask: "Produce a 120\u2013200 word brief or equivalent oral response with verified facts, gaps, questions and next action.",
            expectedEvidence: ["Purpose: seek informed guidance about what information is needed", "Checked INR 1,400 recorded total with transaction references", "Missing area, crop context and record completeness", "Questions about needed information and verification, rather than a demanded action", "Next action stays within recordkeeping and approved expert consultation"],
            assessorReference: "A suitable brief says the record is limited, removes invented area/yield details, asks what further information is needed and how to verify advice, and uses an approved channel. Equivalent plain-language or approved oral evidence is acceptable."
          },
          quiz: [
            { id: "farm-03-q1", question: "Which question best fits the available information?", options: ["Can you confirm the promised 30% increase?", "What additional information do you need to interpret these recorded expenses?", "Which input should everyone buy?", "Can we omit the original records?"], correctOptionIndex: 1, explanation: "The question acknowledges the limited packet and asks an expert for the missing context needed for interpretation." },
            { id: "farm-03-q2", question: "What should the brief do with the invented two-acre detail?", options: ["Keep it because it is convenient", "Describe it as verified", "Remove it and state that area is not supplied", "Replace it with another guess"], correctOptionIndex: 2, explanation: "A missing field should remain a documented gap until appropriate evidence is available." },
            { id: "farm-03-q3", question: "What does this pathway's competency credential demonstrate?", options: ["Authority to prescribe crop inputs", "A professional agricultural qualification", "A guaranteed yield improvement", "Record organization, information checking and expert-question preparation"], correctOptionIndex: 3, explanation: "The credential must describe the assessed capability accurately. It does not create professional authority or guarantee an outcome." }
          ],
          reflectionPrompt: "How would this brief help an expert understand your question without pretending that every detail is known?",
          returnToWorkAction: "Use a blank fact\u2013gap\u2013question template for one permitted work conversation. Record the expert's confirmed guidance separately from your own assumptions."
        }
      ],
      practicalAssessment: {
        id: "farm-practical-01",
        title: "A verified farm record and expert brief",
        scenario: "A facilitator asks you to prepare the fictional T01/T02/T03 record for an expert conversation. The extra T02 row is a confirmed copy. The supplied AI output contains unsupported area and yield statements.",
        submissionPrompts: [
          { id: "task", label: "What are you trying to achieve and for whom?", help: "State the purpose of the record and expert conversation." },
          { id: "record", label: "Your corrected record and calculation", help: "Include source IDs, explain the duplicate treatment and show the INR total." },
          { id: "safe-input", label: "What information is safe to use?", help: "Identify the synthetic packet and information you would exclude from an unapproved tool." },
          { id: "ai-evidence", label: "The draft you reviewed and instructions you used", help: "You may review the supplied draft without opening an AI tool. Describe instructions for a safer draft." },
          { id: "checks", label: "Checks, errors and corrections", help: "Explain the total, area gap, invented yield statement and action recommendation." },
          { id: "final", label: "Final expert question brief", help: "Separate verified facts, missing information and questions." },
          { id: "return", label: "Your return-to-work action and boundary", help: "Describe a safe action such as improving records or using an approved expert channel." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable record or brief", "1": "Major record errors or an unclear brief", "2": "Mostly usable output with a material omission", "3": "Correct three-row record, INR 1,400 total and clear brief", "4": "Correct output with concise source mapping, useful questions and a reusable structure" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts the flawed output without checks", "1": "Checks only one minor detail", "2": "Checks total and duplicate but incompletely explains unsupported claims", "3": "Shows arithmetic and source-based rejection of invented area/yield claims", "4": "Checks all material claims and clearly distinguishes confirmed facts from unknowns" }, criticalGate: "Must not retain the invented yield or immediate-action claim as verified guidance" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual secrets or inappropriate private records", "1": "Cannot identify what should be excluded", "2": "Uses the synthetic packet but gives incomplete handling reasons", "3": "Uses only synthetic evidence and identifies private information to withhold", "4": "Adds an approved-channel plan with minimal necessary sharing" }, criticalGate: "No actual private records, third-party personal information or credentials submitted or proposed for unapproved use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Acts on unsupported consequential advice", "1": "Mentions caution without a usable next step", "2": "Identifies a limit but an unclear expert question", "3": "Asks relevant expert questions and limits the immediate action to permitted work", "4": "Explains escalation, missing context and how confirmed advice will be recorded" }, criticalGate: "Consequential farm decisions are not justified by this expense packet; the brief seeks appropriate expert input" }
        ],
        samplePassingEvidence: "I counted T02 once because the source identifies its duplicate. The total is 450 + 150 + 800 = INR 1,400. No farm area or yield evidence is supplied, so I removed INR 700 per acre and 30% yield improvement. I used fictional data only. My brief asks what context and further records an expert needs. My immediate work action is to maintain a checked record and seek guidance through an approved channel.",
        sampleCriticalFailure: "The learner produces a polished brief but recommends repeating the purchases to obtain a 30% yield improvement without verification. The verification and judgment gates fail regardless of aggregate score.",
        assessorNote: "Do not require advanced agricultural terminology, typing speed or use of a particular AI brand. Assess the record, checks, handling and explanation."
      },
      followUp: { afterDays: 14, question: "Did you use a checked record or expert question brief for a permitted task?", evidenceOptions: ["A structured reflection with no private record contents", "A blank improved template", "Facilitator-confirmed use under an approved process"], successSignal: "The learner can explain one check performed and one limit or question identified", privacyNote: "Do not collect real farm documents by default." }
    },
    {
      id: "msme-customer-operations",
      title: "Customer communication and daily operations with AI",
      ecosystem: "MSME",
      role: "MSME owner or team member",
      level: "Foundation to applied",
      summary: "Draft an accurate customer response, organize a daily work checklist, and measure whether AI assistance actually helped.",
      promise: "You can produce a useful customer draft and operations checklist while checking promises, information use and task quality.",
      estimatedMinutes: 110,
      prerequisites: ["Read a short order policy with help if needed", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Separate customer-relevant facts from internal details", "Avoid invented stock, dispatch and pricing commitments", "Create a source-based action checklist", "Compare time and quality including verification work", "Keep human approval for commitments outside the stated policy"],
      credentialClaim: "Demonstrated customer-draft preparation, operations checklist creation and responsible AI checking using synthetic business records",
      credentialExclusions: ["No financial, tax or legal professional qualification", "No assurance of business results or automated customer commitments"],
      sourceNotice: "The example order policy and records are fictional fixtures, not a recommended business policy.",
      lessons: [
        {
          id: "msme-01",
          title: "Write a customer response you can stand behind",
          estimatedMinutes: 25,
          objective: "Draft an accurate response using permitted facts and withhold irrelevant internal details.",
          lessonText: "A helpful customer response is clear about what is confirmed and what still needs checking. AI can make a message sound polished, but it may invent a discount, a delivery promise or available stock. Start by listing the facts the customer needs. Keep internal costs, private contact information and unrelated customer details out of an unapproved AI prompt. In this fictional policy, an item costs INR 120, delivery is INR 60 and pickup has no delivery fee. Only four units are confirmed in stock, while the customer requests six. That means a six-unit dispatch cannot be promised yet. You can explain the confirmed stock and say the team will check options; do not assume an arrival date. Check every promise in the draft against the supplied policy and records. Treat the final response as a draft for human approval whenever it changes a commitment or exceeds your role.",
          steps: ["Read the request, stock and policy", "Identify customer-relevant facts", "Remove irrelevant internal details from the prompt", "Correct the supplied AI draft", "Mark the check needed before sending"],
          exercise: {
            title: "Respond to a six-unit request",
            sourcePacket: [
              { sourceId: "P1", type: "fictional policy", content: "Unit price INR 120. Delivery fee INR 60 per order. Pickup delivery fee INR 0. Dispatch quantity and date require stock-team confirmation. Exceptions require supervisor approval." },
              { sourceId: "O101", type: "fictional request", content: "Customer C requests six blue units and asks whether all can be delivered on Friday." },
              { sourceId: "S1", type: "fictional stock record", content: "Four blue units are confirmed available. Arrival date for additional units is unknown." },
              { sourceId: "I1", type: "internal fixture", content: "Internal unit cost INR 75; private contact marker [PRIVATE CONTACT]; unrelated account notes. These are not needed for the customer draft." }
            ],
            suppliedAiDraft: "We confirm six units for Friday delivery at INR 120 each, with free delivery and a special 10% discount. Our internal unit cost is INR 75.",
            optionalAiPrompt: "Draft a short response using fictional P1, O101 and S1 only. State confirmed stock, do not promise unconfirmed quantity or date, do not invent discounts, and do not include internal details. Mark the team check required.",
            learnerTask: "Write a corrected customer response and a separate internal note identifying the required stock check.",
            expectedEvidence: ["Response does not confirm six-unit Friday delivery", "No invented free delivery or discount", "INR 120 unit price and applicable INR 60 delivery fee stated accurately if mentioned", "Internal unit cost and private marker excluded", "Stock team check required before commitment"],
            assessorReference: "A suitable response explains that four units are confirmed, the remaining quantity/date must be checked, and published price/delivery terms apply. It does not promise a split order unless approved. A requested six-unit order would total INR 780 including delivery, but calculating that is not confirmation that the order can be fulfilled."
          },
          quiz: [
            { id: "msme-01-q1", question: "What can the response currently confirm?", options: ["Six units will arrive Friday", "Four units are recorded as available, and the rest needs a team check", "Every order has free delivery", "A 10% discount is approved"], correctOptionIndex: 1, explanation: "The stock record confirms four units only. Quantity, date and any exception need the specified human check." },
            { id: "msme-01-q2", question: "If a six-unit order is later confirmed for delivery under P1, what is the stated total?", options: ["INR 720", "INR 780", "INR 702", "INR 840"], correctOptionIndex: 1, explanation: "Six units at INR 120 are INR 720, plus INR 60 delivery, totaling INR 780. This calculation does not confirm stock or delivery timing." },
            { id: "msme-01-q3", question: "Which source should be excluded from the customer-drafting prompt?", options: ["The published unit price", "The confirmed stock count", "The internal cost and private contact marker", "The customer's requested quantity without identity details"], correctOptionIndex: 2, explanation: "The internal details are unnecessary for the draft and should not be sent to an unapproved tool or disclosed to the customer." }
          ],
          reflectionPrompt: "Which invented promise in the original draft could create a problem for the team, and how did you correct it?",
          returnToWorkAction: "For one permitted customer draft, check quantity, price, fees and timing against approved records before an authorized person sends it."
        },
        {
          id: "msme-02",
          title: "Turn records into a daily action checklist",
          estimatedMinutes: 25,
          objective: "Create actions with owners and checks without inventing completion or commitments.",
          lessonText: "A useful checklist helps someone act: it states the task, owner, source and completion check. A vague list such as 'handle orders' is hard to follow. AI can group tasks, but it must not convert an unresolved issue into a completed action. Read the current status before choosing the next step. A ready order may need pickup confirmation; a stock issue needs a stock-team check; an address issue needs a permitted customer contact. Priorities should reflect an agreed rule, not a made-up deadline. This fictional packet gives no emergency ranking, so explain your proposed order as a suggestion for the supervisor. Keep personal customer details in the approved system. A checklist can use opaque order references. Before marking an action complete, record the actual check or confirmation. This preserves accountability and helps the next team member understand what remains open.",
          steps: ["Read each order status", "Identify its next allowed action", "Assign a role rather than inventing a person's availability", "Define evidence of completion", "Label suggested priorities as requiring review"],
          exercise: {
            title: "Build the day's three-order checklist",
            sourcePacket: [
              { sourceId: "O101", status: "Stock check pending", nextCheck: "Requested six units; four confirmed; additional arrival unknown", ownerRole: "Stock team" },
              { sourceId: "O102", status: "Packed", nextCheck: "Three units packed; payment confirmed in the fictional record; pickup time not yet agreed", ownerRole: "Customer service" },
              { sourceId: "O103", status: "On hold", nextCheck: "Delivery address confirmation missing; no private address is included in the teaching packet", ownerRole: "Customer service" },
              { sourceId: "P2", status: "Policy", nextCheck: "No new surcharge or completed dispatch without approved evidence. Supervisor reviews priority suggestions.", ownerRole: "Supervisor" }
            ],
            suppliedAiDraft: "Dispatch all six O101 units now. Add INR 50 urgency fees to every order. Mark O103 resolved. O102 needs no action because it is packed.",
            optionalAiPrompt: "Create a checklist from fictional O101\u2013O103 and P2. Include order reference, next action, owner role, dependency and evidence required to mark complete. Do not invent charges, stock, pickup timing or resolution.",
            learnerTask: "Create three checklist rows and explain why the supplied draft is unsafe to use unchanged.",
            expectedEvidence: ["O101: stock-team confirmation before dispatch commitment", "O102: agree pickup time through approved customer process", "O103: obtain address confirmation through approved channel; keep on hold until confirmed", "No invented fee", "Completion evidence and responsible owner role for each row"],
            assessorReference: "Accept equivalent actionable checklists. Do not require one priority ranking because the packet has no authoritative priority rule. The learner must preserve unresolved statuses until actual confirmation."
          },
          quiz: [
            { id: "msme-02-q1", question: "Which item can be marked complete solely from the supplied packet?", options: ["O101 full dispatch", "O103 address confirmation", "O102 packing", "All three orders"], correctOptionIndex: 2, explanation: "O102 is recorded as packed. Its pickup arrangement remains open. The other listed actions require further confirmation." },
            { id: "msme-02-q2", question: "What makes a checklist item actionable?", options: ["A confident sentence with no source", "Task, owner role, dependency and completion check", "A long paragraph repeating every private detail", "Automatic completion when AI writes it"], correctOptionIndex: 1, explanation: "These fields tell the team what to do, who handles it, what must happen first and how completion will be established." },
            { id: "msme-02-q3", question: "How should the INR 50 urgency fee be handled?", options: ["Apply it because AI suggested it", "Apply it only to the oldest order without approval", "Treat it as an unsupported addition and remove it", "Hide it from the checklist"], correctOptionIndex: 2, explanation: "The packet authorizes no urgency fee. A generated addition is not a business policy or approval." }
          ],
          reflectionPrompt: "Which unresolved action is easiest to accidentally mark complete, and what evidence should prevent that?",
          returnToWorkAction: "Create a small approved checklist using order references and completion evidence, then have the relevant team member verify one completed item."
        },
        {
          id: "msme-03",
          title: "Measure usefulness, including the checking time",
          estimatedMinutes: 25,
          objective: "Compare time and quality fairly and define a safe return-to-work trial.",
          lessonText: "Fast generation is only one part of a task. Include preparation, checking, correction and approval when comparing AI-assisted work with your usual approach. A faster draft with inaccurate promises may create more work later. In this exercise, manual preparation takes 12 minutes. The assisted route takes six minutes to prepare and generate, plus five minutes to check and correct. Its total is 11 minutes, a one-minute saving in this single fictional trial. The draft initially contains two unsupported commitments, and both must be corrected before approval. This small example does not establish a general productivity gain for your business. A useful trial uses comparable tasks and the same quality standard, records limitations, and stops if information handling or quality becomes unacceptable. Choose a low-consequence task, obtain permission, and keep final sending or operational commitments with the authorized person.",
          steps: ["Add all assisted-task time components", "Compare with manual time", "Check final quality against the same standard", "Describe the sample's limits", "Plan one permitted, low-consequence work trial"],
          exercise: {
            title: "Evaluate a fictional productivity trial",
            sourcePacket: [
              { sourceId: "M1", method: "Manual", minutes: 12, finalQuality: "Meets the scenario policy" },
              { sourceId: "A1", method: "AI-assisted preparation and generation", minutes: 6, draftQuality: "Two unsupported commitments" },
              { sourceId: "A2", method: "AI-assisted verification and correction", minutes: 5, finalQuality: "Both errors corrected; meets the same policy" },
              { sourceId: "N1", note: "One fictional comparable task only. No broader business productivity evidence is supplied." }
            ],
            suppliedAiDraft: "AI cut the task time in half from 12 minutes to 6 minutes and can be used to send all customer messages automatically.",
            optionalAiPrompt: "Calculate total assisted task time including checking. Compare the single fictional trial with manual preparation, discuss final quality and limits, and do not recommend automatic sending.",
            learnerTask: "Write a short evaluation and a safe one-task trial plan.",
            expectedEvidence: ["Assisted total 6 + 5 = 11 minutes", "Saving 12 - 11 = 1 minute", "If a percentage is included, approximately 8.3%, with single-trial limitation", "Same final quality check required", "No automatic customer sending or unauthorized data use"],
            assessorReference: "The six-minute figure excludes essential review. Accept one-minute saving without a percentage. A small or absent saving can still be a valid finding; learners are not rewarded for claiming AI is always better."
          },
          quiz: [
            { id: "msme-03-q1", question: "What is the full assisted-task time?", options: ["6 minutes", "5 minutes", "11 minutes", "17 minutes"], correctOptionIndex: 2, explanation: "Preparation/generation takes six minutes and checking/correction takes five. Both belong in the assisted-task total." },
            { id: "msme-03-q2", question: "What does this single fictional trial establish?", options: ["Every task will save half its time", "The comparable task saved one minute after review, with limited evidence", "Checking can now be skipped", "AI should automatically send every message"], correctOptionIndex: 1, explanation: "The result is limited to one synthetic trial and includes the verification work. It does not justify broad claims or removal of human approval." },
            { id: "msme-03-q3", question: "If an assisted draft is faster but retains an unsupported promise, what should happen?", options: ["Accept it because speed is the only measure", "Hide the error from the comparison", "Send it and correct it later", "Correct or reject it before use and record the quality failure"], correctOptionIndex: 3, explanation: "Quality and authorized commitments matter alongside time. A speed gain does not override an unacceptable output." }
          ],
          reflectionPrompt: "What checking or approval work would your own time comparison need to include?",
          returnToWorkAction: "With approval, compare one low-consequence task using the same quality checks for both methods. Record preparation, checking, correction and approval time without collecting confidential artifacts."
        }
      ],
      practicalAssessment: {
        id: "msme-practical-01",
        title: "An accurate customer draft and operations checklist",
        scenario: "Use fictional P1, S1 and O101\u2013O103 to prepare a customer response and checklist. Evaluate the supplied productivity trial without making unsupported business claims.",
        submissionPrompts: [
          { id: "task", label: "Task, audience and success criteria", help: "State what the customer and team need from your work." },
          { id: "safe-input", label: "Information included and information withheld", help: "Identify why internal cost and private markers do not belong in the drafting prompt." },
          { id: "ai-evidence", label: "Draft and safer instructions", help: "Use the supplied draft or an optional tool with synthetic inputs only." },
          { id: "checks", label: "Promises and calculations you checked", help: "Check stock, timing, price, delivery fee, discount and invented surcharge." },
          { id: "final", label: "Corrected customer response", help: "Keep unconfirmed stock and date explicit and avoid unauthorized commitments." },
          { id: "checklist", label: "Three-row action checklist", help: "Include owner role, dependency and evidence of completion." },
          { id: "return", label: "Productivity evaluation and return-to-work plan", help: "Include verification time, quality checks, limited evidence and authorized approval." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable response or checklist", "1": "Major source errors and unclear actions", "2": "Usable draft or checklist but material omissions", "3": "Clear accurate response and three actionable checklist rows", "4": "Concise audience-appropriate work with complete owners, dependencies and checks" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented promises and calculations", "1": "Checks only a minor fact", "2": "Checks key commitments but omits an important inconsistency", "3": "Corrects stock/date/discount/fee claims and includes full assisted time", "4": "Maps all material checks to sources and reports uncertainty and trial limits clearly" }, criticalGate: "No unconfirmed six-unit Friday promise, invented discount/free delivery or INR 50 surcharge remains as an authorized commitment" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Discloses inappropriate private information or actual secrets", "1": "Cannot distinguish relevant from internal information", "2": "Uses synthetic records but incompletely explains exclusions", "3": "Uses permitted facts and excludes internal cost/private contact data", "4": "Explains minimal input, approved channels and restricted customer-record handling" }, criticalGate: "No actual private customer records or credentials used; unnecessary internal/private fields are excluded from the customer draft and unapproved prompt" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Automatically commits or dispatches based on the draft", "1": "General caution without an approval route", "2": "Recognizes review but leaves a key operational action unclear", "3": "Preserves pending status and names human approval/checks and a bounded work trial", "4": "Explains stop conditions, source-based completion and limits of productivity conclusions" }, criticalGate: "Unresolved stock/address/pickup items are not falsely completed; customer sending and operational exceptions retain authorized human review" }
        ],
        samplePassingEvidence: "Four units are confirmed; six-unit Friday delivery needs the stock team's check. I removed the discount, free delivery and internal cost. O101 needs stock confirmation; O102 needs pickup arrangement; O103 needs approved address confirmation and remains on hold. I did not add a surcharge. The assisted trial takes 11 minutes including checks, saving one minute on one synthetic task. My work trial will use an approved low-consequence task and an authorized sender.",
        sampleCriticalFailure: "The learner calculates the right price and writes an elegant response but promises Friday delivery of six units, despite only four confirmed units. The verification gate fails.",
        assessorNote: "Accept different courteous wording and supervisor-reviewed priority suggestions. Do not require a positive productivity result or treat a calculated price as confirmed order acceptance."
      },
      followUp: { afterDays: 14, question: "Did you use a checked draft or action checklist on a permitted task, and what changed?", evidenceOptions: ["Structured reflection with task category and checks", "Blank checklist template", "Aggregate time comparison without customer details"], successSignal: "A learner describes a corrected commitment or clearer operational action and includes checking effort", privacyNote: "Do not require actual customer messages, prices negotiated with named customers or business account records." }
    },
    {
      id: "public-servant-source-briefs",
      title: "Clear administrative briefs with accountable AI use",
      ecosystem: "Government",
      role: "Public servant",
      level: "Foundation to applied",
      summary: "Create a source-traceable administrative draft, verify a simple summary, and retain authorized review before official use.",
      promise: "You can prepare a clear draft from permitted reference material and show which facts and judgments need review.",
      estimatedMinutes: 110,
      prerequisites: ["Read short supplied reference material", "Know that official approval is distinct from a draft", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Classify source material before tool use", "Map claims to supplied sources", "Reject invented requirements, fees and references", "Verify totals and rates with clear denominators", "Keep accountable approval and publication within assigned authority"],
      credentialClaim: "Demonstrated administrative drafting, source verification and responsible information-handling using synthetic training material",
      credentialExclusions: ["No authority to issue official decisions", "No legal or statutory qualification", "No assurance that an external AI tool is approved by an employer"],
      sourceNotice: "Every notice, department, programme, figure and policy below is fictional. No actual law, administrative direction or citizen service rule is stated.",
      lessons: [
        {
          id: "gov-01",
          title: "Draft from permitted sources, not invented rules",
          estimatedMinutes: 25,
          objective: "Create a source-based brief and remove invented requirements and authority.",
          lessonText: "An administrative draft should make it easy to identify the source of each important fact. First confirm whether the material is permitted for the chosen tool; a source being available to you does not automatically make external upload acceptable. This exercise supplies fictional shareable references, so no real file is needed. Read the sources before reviewing the AI draft. A generated instruction such as 'attendance is mandatory' is not authority unless the source actually states it. A fee or penalty must not be invented to make a notice sound official. Keep the document visibly marked as a draft, name the intended reader, and identify the review needed before official use. If a detail is missing, ask for confirmation or omit it. Do not add a fabricated circular number or present the AI output as an approved decision.",
          steps: ["Confirm the fictional packet is the approved practice input", "Map each material fact to a source", "Remove unsupported fee, penalty and mandatory-attendance claims", "Create a clear draft brief", "Name the approval step"],
          exercise: {
            title: "Correct the fictional staff-orientation brief",
            sourcePacket: [
              { sourceId: "G1", content: "Fictional staff orientation is planned for 8 October 2026 from 10:00 to 11:00." },
              { sourceId: "G2", content: "Venue: Room B. Participants are asked to respond by 6 October 2026." },
              { sourceId: "G3", content: "Attendance is voluntary. This material is a draft for authorized administrative review. No fee, penalty or circular number is supplied." },
              { sourceId: "G4", content: "Teaching packet is fictional and approved for this practice only. It contains no actual personnel or citizen records." }
            ],
            suppliedAiDraft: "Under Circular GOV-X, every employee must attend Room B on 8 October from 10:00 to 11:00. A fee of INR 500 applies. Late responses will result in a penalty. This notice is approved for issue.",
            optionalAiPrompt: "Prepare a brief from fictional G1\u2013G4 only. Include source references, distinguish draft status and voluntary attendance, and do not invent fees, penalties or circulars. Identify authorized review before issue.",
            learnerTask: "Write a short corrected draft and a fact-to-source list.",
            expectedEvidence: ["Correct date, time, room and response date", "Voluntary attendance retained", "GOV-X, fee and penalty removed as unsupported", "Draft status and authorized review explicit", "Important facts mapped to G1\u2013G3"],
            assessorReference: "The sources support a voluntary fictional event in Room B, 8 October 10:00\u201311:00, response by 6 October. They do not support a fee, penalty, circular or approved-issue status. Equivalent brief formats are acceptable."
          },
          quiz: [
            { id: "gov-01-q1", question: "Which statement matches G3?", options: ["Attendance is compulsory", "A fee of INR 500 applies", "Attendance is voluntary and the material needs authorized review", "Circular GOV-X authorizes publication"], correctOptionIndex: 2, explanation: "G3 explicitly states voluntary attendance and draft status. The generated fee, circular and authority are unsupported." },
            { id: "gov-01-q2", question: "How should GOV-X be treated?", options: ["As valid because it looks official", "As an unsupported reference to remove or verify before any use", "As a required citation", "As a confidential password"], correctOptionIndex: 1, explanation: "No such reference is supplied. Official-looking formatting does not establish authenticity." },
            { id: "gov-01-q3", question: "What is appropriate for this external-tool practice?", options: ["Upload actual restricted personnel files", "Use the supplied approved fictional packet only", "Assume every work file is public", "Include citizen identities to make the example realistic"], correctOptionIndex: 1, explanation: "The fictional packet is designed for practice. Real work material requires the organization's approved handling and tool rules." }
          ],
          reflectionPrompt: "How can the reader tell which facts came from the sources and which parts still need approval?",
          returnToWorkAction: "Use a claim\u2013source\u2013review template with permitted material in an approved environment. Keep draft status until the authorized approval step is completed."
        },
        {
          id: "gov-02",
          title: "Check numbers and the story they tell",
          estimatedMinutes: 25,
          objective: "Calculate a correct summary and avoid unsupported explanations of cause or performance.",
          lessonText: "A numerical brief needs a clear denominator and time period. In this fictional weekly packet, 80 items were received and 55 were recorded resolved. Dividing 55 by 80 gives 68.75%. That describes the packet's recorded figures; it does not automatically establish why outcomes changed or whether every item was handled satisfactorily. An AI draft may mix a wrong rate with a persuasive explanation. Check the calculation yourself, compare it with the source rows, and state the exact scope. Do not call a record 'improved' without a comparable earlier period and an agreed quality measure. A useful brief can explain the current counts and the limits of interpretation. If someone asks for a causal conclusion, identify the additional evidence needed rather than manufacturing one. Preserve accountability by asking the relevant data owner to confirm the figures before official circulation.",
          steps: ["Total received and resolved counts", "Calculate the rate with its denominator", "Compare the draft's rate", "Remove unsupported cause and quality claims", "Write a scoped summary for review"],
          exercise: {
            title: "Verify the fictional weekly service summary",
            sourcePacket: [
              { sourceId: "W1", category: "Category A", received: 40, recordedResolved: 25 },
              { sourceId: "W2", category: "Category B", received: 25, recordedResolved: 20 },
              { sourceId: "W3", category: "Category C", received: 15, recordedResolved: 10 },
              { sourceId: "W4", scope: "One fictional reporting week; no earlier period, case-level quality evidence or cause analysis is supplied." }
            ],
            suppliedAiDraft: "The programme resolved 95% of the 80 items and its new policy caused a major improvement in service quality.",
            optionalAiPrompt: "Summarize fictional W1\u2013W4. Show counts and denominator, calculate the rate, state scope, and avoid causal or quality claims unsupported by the packet.",
            learnerTask: "Create a verified three-sentence numerical brief with a visible calculation and one interpretation limit.",
            expectedEvidence: ["Received: 40 + 25 + 15 = 80", "Recorded resolved: 25 + 20 + 10 = 55", "55 / 80 \xD7 100 = 68.75%", "95% claim corrected", "No unsupported improvement, policy causation or case-quality claim"],
            assessorReference: "Accept 68.75% or appropriately labeled rounding such as 68.8%. The source uses 'recorded resolved'; avoid turning that into independently verified service quality. No previous-period or causal claim is justified."
          },
          quiz: [
            { id: "gov-02-q1", question: "What percentage of received items is recorded resolved?", options: ["95%", "55%", "68.75%", "80%"], correctOptionIndex: 2, explanation: "There are 55 recorded resolved items out of 80 received. 55 divided by 80, multiplied by 100, is 68.75%." },
            { id: "gov-02-q2", question: "What additional evidence is needed before calling this an improvement?", options: ["A more confident AI sentence", "A comparable baseline and agreed measures", "A larger font", "A made-up prior-period figure"], correctOptionIndex: 1, explanation: "Improvement requires an appropriate comparison and defined measures. The single-week packet provides neither." },
            { id: "gov-02-q3", question: "Which wording is best supported?", options: ["The policy caused better quality", "Every item was handled satisfactorily", "The packet records 55 of 80 items resolved for one fictional week", "The result applies to every department"], correctOptionIndex: 2, explanation: "This describes the supplied counts and scope without adding unverified quality, causal or generalization claims." }
          ],
          reflectionPrompt: "What would you ask the data owner before this summary was used in an official report?",
          returnToWorkAction: "On one permitted numerical summary, record the denominator, period, calculation and data-owner check before circulation."
        },
        {
          id: "gov-03",
          title: "Keep the draft-to-official boundary clear",
          estimatedMinutes: 25,
          objective: "Build a review handoff and safe work plan without assuming publication authority.",
          lessonText: "Preparing a draft and authorizing its official use are different responsibilities. A learning role such as public servant does not give permission to view every file or issue a notice. Keep the active work context and intended recipient clear. Your review handoff should identify the draft version, source packet, checks completed, uncertainties and the person or role that must approve it. AI can suggest text, but it cannot provide organizational authority. In this exercise, the reviewer role may confirm the source figures and wording; publication remains with the designated approver. Do not bypass that handoff because the document looks finished. If the approved AI tool is unavailable, use the supplied draft or prepare the brief manually. The skill is accurate and accountable work, not dependence on a tool. Return to your work with a small permitted task and an explicit stop condition if classification, access or approval is unclear.",
          steps: ["Mark the document as a draft", "List sources, version and checks", "Identify unresolved questions", "Route to the designated review and approval roles", "Define one bounded return-to-work task"],
          exercise: {
            title: "Prepare the accountable review handoff",
            sourcePacket: [
              { sourceId: "R1", content: "Fictional review process: learner prepares draft; data owner confirms supplied figures; designated administrative approver decides official issue. No role is granted through Academy enrollment." },
              { sourceId: "R2", content: "Use corrected G1\u2013G3 event brief and W1\u2013W4 numerical summary. Both remain draft teaching materials." },
              { sourceId: "R3", content: "Actual restricted work records, access credentials and citizen identities must not be included in this practice." }
            ],
            suppliedAiDraft: "The brief looks complete. Publish it immediately using your Academy learner role and skip data-owner review.",
            optionalAiPrompt: "Create a review checklist from fictional R1\u2013R3. Preserve draft status, source checks, data-owner review and designated approval. Do not grant permissions or propose immediate publication.",
            learnerTask: "Write a review note naming the source packet, checks, questions, next reviewer, final approval step and work-trial stop condition.",
            expectedEvidence: ["Draft status explicit", "Corrected sources and calculations listed", "Data-owner review and designated approval separated", "No implied administrative privileges from Academy role", "Stop when classification, permitted tool or authority is unclear"],
            assessorReference: "A passing handoff preserves the R1 process and does not issue anything. The learner can use equivalent role labels without naming a real official. A safe work trial uses permitted material and retains employer-approved review."
          },
          quiz: [
            { id: "gov-03-q1", question: "What permission does selecting the public-servant learner role grant?", options: ["Access to all official records", "Permission to publish a notice", "No administrative or publication permission by itself", "Permission to bypass review"], correctOptionIndex: 2, explanation: "A learning context supports relevance. Actual access and authority require explicit assignments in the relevant system and process." },
            { id: "gov-03-q2", question: "What should happen when the data classification or approved tool is unclear?", options: ["Upload the file and ask later", "Stop and seek the appropriate approval or handling guidance", "Rename the file to make it public", "Assume Academy enrollment authorizes it"], correctOptionIndex: 1, explanation: "Unclear handling rules are a reason to pause the tool use and seek the responsible owner, not to guess." },
            { id: "gov-03-q3", question: "If an external AI tool is unavailable during this activity, what is acceptable?", options: ["Use another unapproved tool with restricted records", "Skip all verification", "Claim the task is passed without evidence", "Review the supplied draft or prepare the work manually with the same checks"], correctOptionIndex: 3, explanation: "The assessed skill is responsible task performance. The provided draft supports practice without tool access, and the checking standard remains the same." }
          ],
          reflectionPrompt: "What part of your handoff ensures that a polished draft is not mistaken for an approved decision?",
          returnToWorkAction: "Use a draft-review checklist for one permitted administrative task. Record sources, checks, remaining questions and the authorized approval route without submitting confidential work to Academy."
        }
      ],
      practicalAssessment: {
        id: "gov-practical-01",
        title: "A verified administrative brief and review handoff",
        scenario: "Prepare a corrected fictional staff-orientation brief, a numerical summary of W1\u2013W4, and a review handoff under R1\u2013R3. Explain why generated wording is not official authority.",
        submissionPrompts: [
          { id: "task", label: "Purpose, reader and draft status", help: "Identify the intended administrative use and why approval remains necessary." },
          { id: "safe-input", label: "Permitted input and handling boundary", help: "Use the fictional packet and identify what you would keep out of an unapproved tool." },
          { id: "ai-evidence", label: "Supplied draft and safer instructions", help: "Describe the source-bound instructions without providing any actual restricted file." },
          { id: "checks", label: "Fact-to-source map and numerical checks", help: "Check event facts, invented circular/fee/penalty, totals and rate." },
          { id: "final", label: "Corrected brief and scoped numerical summary", help: "Keep voluntary attendance, draft status and the exact count scope." },
          { id: "handoff", label: "Review and approval handoff", help: "Identify data-owner confirmation, unresolved questions and designated approval." },
          { id: "return", label: "Return-to-work task and stop conditions", help: "Choose a permitted task and explain when access, classification or authority needs clarification." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable brief or handoff", "1": "Major factual errors and unclear audience", "2": "Mostly usable work with material omissions", "3": "Clear corrected event brief, numerical summary and review note", "4": "Concise audience-appropriate work with complete source mapping and actionable handoff" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented official references and rate", "1": "Checks isolated facts only", "2": "Checks main facts but leaves an important unsupported assertion", "3": "Removes invented authority/fee/penalty and verifies 55 of 80 equals 68.75%", "4": "Maps every important assertion to sources and explains scope, denominator and interpretation limits" }, criticalGate: "No fabricated circular, fee, penalty, mandatory-attendance claim or unsupported causal improvement remains presented as source-supported fact" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual restricted records or credentials", "1": "Treats all work material as permitted", "2": "Uses synthetic material but lacks a clear tool boundary", "3": "Uses only approved fictional packet and identifies restricted information to withhold", "4": "Explains approved environment, minimum necessary sharing and a clear uncertainty stop" }, criticalGate: "No actual restricted administrative/citizen records or credentials are submitted or proposed for unapproved tool use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Issues or authorizes the draft without required authority", "1": "Mentions review but does not distinguish approval", "2": "Identifies review with an incomplete handoff", "3": "Preserves draft status, data-owner check and designated approval", "4": "Adds specific unresolved questions, stop conditions and a bounded permitted work trial" }, criticalGate: "Academy role and AI output are not treated as official authority; required review and designated approval are retained" }
        ],
        samplePassingEvidence: "G1 and G2 support the event date, time, venue and response date. G3 says attendance is voluntary and the material is a draft. I removed GOV-X, INR 500 and the penalty. W1\u2013W3 total 80 received and 55 recorded resolved, or 68.75%, for one fictional week; no causal improvement is established. My handoff requests data-owner checks and designated approval before issue. I used only the synthetic packet and will stop a work trial if classification, tool approval or authority is unclear.",
        sampleCriticalFailure: "The learner calculates the rate correctly but retains an invented circular and describes the draft as officially approved. The verification and judgment gates fail.",
        assessorNote: "Assess source accountability and authority boundaries rather than legal knowledge. Do not infer that any real organization's tool or publication policy matches the fictional process."
      },
      followUp: { afterDays: 14, question: "Did you use a source-and-review checklist for a permitted administrative task?", evidenceOptions: ["Structured reflection without document contents", "Blank claim\u2013source\u2013review template", "Authorized facilitator confirmation under the approved pilot process"], successSignal: "The learner describes a checked claim, a documented uncertainty and the correct approval handoff", privacyNote: "Do not collect actual administrative briefs, citizen records or employer-restricted information by default." }
    }
  ]
};

// lib/academy-curriculum.ts
var LEGACY_CONTENT_VERSION = "0.1-review-draft";
var CONTENT_VERSION = LEGACY_CONTENT_VERSION;
var ContentResolutionError = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
    this.name = "ContentResolutionError";
  }
};
function deepFreeze(value) {
  if (value !== null && typeof value === "object" && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) deepFreeze(child);
    Object.freeze(value);
  }
  return value;
}
function validScope(value) {
  return value === "global" || typeof value === "string" && /^tw-[a-z0-9-]{20,80}$/i.test(value);
}
function contentRef(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ContentResolutionError("The saved content reference is invalid. Contact support before continuing.");
  }
  const ref = value;
  if (Object.keys(ref).some((key) => !["scope", "programId", "versionId"].includes(key)) || !validScope(ref.scope) || typeof ref.programId !== "string" || !/^[a-z0-9][a-z0-9-]{0,99}$/i.test(ref.programId) || typeof ref.versionId !== "string" || !/^[a-z0-9][a-z0-9._-]{0,99}$/i.test(ref.versionId)) {
    throw new ContentResolutionError("The saved content reference is invalid. Contact support before continuing.");
  }
  return Object.freeze({ scope: ref.scope, programId: ref.programId, versionId: ref.versionId });
}
function contentKey(value) {
  const ref = contentRef(value);
  return JSON.stringify([ref.scope, ref.programId, ref.versionId]);
}
function pinnedRef(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ContentResolutionError("The saved learning reference is invalid.");
  }
  const record2 = value;
  if (Object.hasOwn(record2, "contentRef")) {
    const ref = contentRef(record2.contentRef);
    if (record2.programId !== void 0 && record2.programId !== ref.programId || record2.version !== void 0 && record2.version !== ref.versionId) {
      throw new ContentResolutionError("Saved learning and content references disagree. Contact support before continuing.");
    }
    return ref;
  }
  return contentRef({ scope: "global", programId: record2.programId, versionId: record2.version });
}
function createCurriculumRegistry(entries) {
  const index = /* @__PURE__ */ new Map();
  for (const entry of entries) {
    const ref = contentRef(entry.ref);
    if (entry.program.id !== ref.programId) {
      throw new ContentResolutionError("A content snapshot has a mismatched pathway identity.");
    }
    const key = contentKey(ref);
    if (index.has(key)) throw new ContentResolutionError("An immutable content key is already registered.");
    index.set(key, deepFreeze(structuredClone({ ...entry, ref })));
  }
  function resolve2(input, allowedScopes = ["global"]) {
    const ref = contentRef(input);
    if (!allowedScopes.includes(ref.scope)) {
      throw new ContentResolutionError("This content is not available in your learning space.", 404);
    }
    const found = index.get(contentKey(ref));
    if (!found) {
      throw new ContentResolutionError("Your pinned curriculum version is unavailable. Contact support before continuing.");
    }
    return found;
  }
  return Object.freeze({ resolve: resolve2, has: (ref, allowedScopes) => {
    try {
      resolve2(ref, allowedScopes);
      return true;
    } catch (error) {
      if (error instanceof ContentResolutionError) return false;
      throw error;
    }
  } });
}
var curriculum = deepFreeze(structuredClone(review_draft_default));
var programs = curriculum.pathways;
var seedSnapshots = programs.map((program2) => ({
  ref: contentRef({ scope: "global", programId: program2.id, versionId: LEGACY_CONTENT_VERSION }),
  program: program2,
  language: curriculum.language,
  audience: curriculum.audience,
  classification: curriculum.status
}));
var curriculumRegistry = createCurriculumRegistry(seedSnapshots);
function currentRef(programId) {
  return contentRef({ scope: "global", programId, versionId: CONTENT_VERSION });
}
function resolveCurrentProgram(programId) {
  if (!programs.some((program2) => program2.id === programId)) {
    throw new ContentResolutionError("Pathway not found.", 404);
  }
  return curriculumRegistry.resolve(currentRef(programId)).program;
}
function resolvePinnedContent(record2, allowedScopes, registry = curriculumRegistry) {
  return registry.resolve(pinnedRef(record2), allowedScopes);
}
function resolvePinnedProgram(record2, allowedScopes, registry = curriculumRegistry) {
  return resolvePinnedContent(record2, allowedScopes, registry).program;
}

// lib/academy-authoring.ts
var AUTHORING_CLASSIFICATION = "Private workspace practice draft \xB7 nonaccredited";
var AUTHORING_LIMITS = { activeDrafts: 4, publications: 8, totalDrafts: 24, documentBytes: 65536, contentBytes: 65e4 };
var CLAIM = "Demonstrated the published synthetic practice exercise through checked work, careful information handling and human review";
var EXCLUSIONS = ["Nonaccredited private practice record", "No medical, legal, financial, agricultural or other professional qualification", "No authority to make consequential professional decisions"];
var NOTICE = "All sources, people, work records and AI drafts in this pathway are fictional teaching fixtures. Submit no actual private work records or credentials.";
var AuthoringError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
  }
};
var savedName = (value) => String(value || "Workspace owner").slice(0, 80);
var activeDraft = (d) => !["published", "archived"].includes(d.state);
var copy = (value) => structuredClone(value);
function freshAuthoring() {
  return { drafts: [], publications: [] };
}
var CONTENT_COMMANDS = ["content-copy", "content-save", "content-submit", "content-recall", "content-review", "content-publish", "content-retire", "content-archive"];
function isContentCommand(c) {
  return !!c && CONTENT_COMMANDS.includes(c.type);
}
function member(host, user) {
  const m = host.members.find((m2) => m2.userId === user.userId);
  if (!m || !m.active) throw new AuthoringError("This workspace is unavailable for your current account.", 404);
  return m;
}
function owner(host, user) {
  const m = member(host, user);
  if (!m.roles.includes("admin")) throw new AuthoringError("A current workspace owner permission is required.", 403);
  return m;
}
function exact(c, allowed) {
  if (!c || typeof c !== "object" || Array.isArray(c) || Object.keys(c).some((k) => !["type", ...allowed].includes(k))) throw new AuthoringError("This content action has unsupported fields.", 400);
}
function text(v, label2, min, max) {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new AuthoringError(`${label2} needs ${min}\u2013${max} characters.`);
  return v.trim();
}
function scopedRef(host, ref) {
  try {
    const x = contentRef(ref);
    if (x.scope !== "global" && x.scope !== host.id) throw new AuthoringError("Content from another workspace is unavailable.", 404);
    return x;
  } catch (e) {
    if (e instanceof AuthoringError) throw e;
    throw new AuthoringError(e.message, e.status ?? 409);
  }
}
function workspaceRegistry(host) {
  return createCurriculumRegistry([...programs.map((program2) => curriculumRegistry.resolve({ scope: "global", programId: program2.id, versionId: LEGACY_CONTENT_VERSION })), ...(host.content?.publications ?? []).map((p) => p.snapshot)]);
}
function resolve(host, ref) {
  try {
    return workspaceRegistry(host).resolve(scopedRef(host, ref), ["global", host.id]);
  } catch (e) {
    if (e instanceof AuthoringError) throw e;
    throw new AuthoringError(e.message, e.status ?? 409);
  }
}
function template(host, draft) {
  const doc = copy(resolve(host, draft.baseRef).program);
  doc.id = draft.programId;
  doc.estimatedMinutes = Math.max(doc.estimatedMinutes, doc.lessons.reduce((sum, l) => sum + l.estimatedMinutes, 0));
  doc.credentialClaim = CLAIM;
  doc.credentialExclusions = copy(EXCLUSIONS);
  doc.sourceNotice = NOTICE;
  doc.lessons.forEach((lesson) => {
    const seen = /* @__PURE__ */ new Set();
    lesson.exercise.sourcePacket = lesson.exercise.sourcePacket.map((row, index) => {
      const item = typeof row === "string" ? { sourceId: lesson.id + "-source-" + (index + 1), content: row } : row;
      const id2 = item.sourceId.trim();
      if (draft.baseRef.scope === "global" && seen.has(id2) && typeof item.sourceNote === "string" && /confirmed copied line/i.test(item.sourceNote)) item.duplicateOf = id2;
      seen.add(id2);
      return item;
    });
  });
  return doc;
}
function plain(v) {
  if (!v || typeof v !== "object" || Array.isArray(v)) return false;
  const p = Object.getPrototypeOf(v);
  return p === Object.prototype || p === null;
}
function canonicalJson(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(canonicalJson).join(",") + "]";
  return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonicalJson(value[k])).join(",") + "}";
}
async function documentHash(document) {
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalJson(document))))).map((x) => x.toString(16).padStart(2, "0")).join("");
}
function validateDocument(document, expected) {
  const issues = [], issue = (path, kind, message) => issues.push({ path, kind, message });
  const locked = /* @__PURE__ */ new Set(["id", "ecosystem", "role", "level", "credentialClaim", "credentialExclusions", "sourceNotice", "followUp"]);
  function walk(v, t, path) {
    if (path.endsWith(".sourcePacket")) {
      if (!Array.isArray(v) || v.length < 1 || v.length > 20) {
        issue(path, "shape", "Provide 1\u201320 fictional source records.");
        return;
      }
      v.forEach((row, i) => {
        if (!plain(row) || Object.keys(row).length < 2 || Object.keys(row).length > 15) {
          issue(path + "." + i, "shape", "A source record needs a reference and bounded plain facts.");
          return;
        }
        if (typeof row.sourceId !== "string" || row.sourceId.trim().length < 1 || row.sourceId.length > 80) issue(path + "." + i + ".sourceId", "shape", "Provide a source reference of 1\u201380 characters.");
        for (const [key, value] of Object.entries(row)) {
          if (key.length > 60 || ["__proto__", "constructor", "prototype"].includes(key)) {
            issue(path + "." + i, "shape", "This source field name is unsupported.");
            continue;
          }
          if (typeof value === "string") {
            if (value.length > 2e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value)) issue(path + "." + i + "." + key, "limit", "Keep source facts within 2,000 characters using ordinary text.");
          } else if (typeof value === "number") {
            if (!Number.isFinite(value) || Math.abs(value) > 1e12) issue(path + "." + i + "." + key, "shape", "Use a finite bounded number.");
          } else if (value !== null && typeof value !== "boolean") issue(path + "." + i + "." + key, "shape", "Source facts must be plain text, numbers or simple flags.");
        }
      });
      return;
    }
    if (Array.isArray(t)) {
      if (!Array.isArray(v)) {
        issue(path, "shape", "This field must be a list.");
        return;
      }
      const fixed = /\.(lessons|quiz|options|submissionPrompts|rubric)$/.test(path);
      if (fixed && v.length !== t.length || !fixed && (v.length < 1 || v.length > 20)) {
        issue(path, "shape", fixed ? `This pilot keeps exactly ${t.length} entries here.` : "Provide 1\u201320 entries.");
        return;
      }
      v.forEach((child, i) => walk(child, fixed ? t[i] : t[0], path + "." + i));
      return;
    }
    if (t === null) {
      if (v !== null) issue(path, "locked", "This pilot preserves the original critical-gate structure.");
      return;
    }
    if (typeof t === "object") {
      if (!plain(v)) {
        issue(path, "shape", "Provide a plain content object.");
        return;
      }
      if (Object.keys(v).some((k) => !Object.hasOwn(t, k)) || Object.keys(t).some((k) => !Object.hasOwn(v, k))) {
        issue(path, "shape", "Content fields are missing or unsupported.");
        return;
      }
      for (const key of Object.keys(t)) {
        if (path === "program" && locked.has(key) || key === "id") {
          if (canonicalJson(v[key]) !== canonicalJson(t[key])) issue(path + "." + key, "locked", "Published identity, classification and supported structure are fixed for this pilot.");
        } else walk(v[key], t[key], path + "." + key);
      }
      return;
    }
    if (typeof v !== typeof t) {
      issue(path, "shape", "This field has an unsupported value type.");
      return;
    }
    if (typeof v === "string" && (v.length > 12e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v))) issue(path, "limit", "Use ordinary text within the field limit.");
    if (typeof v === "number" && !Number.isFinite(v)) issue(path, "shape", "Use a finite number.");
  }
  walk(document, expected, "program");
  try {
    if (new TextEncoder().encode(JSON.stringify(document)).length > AUTHORING_LIMITS.documentBytes) issue("program", "limit", "This pathway exceeds the 64 KiB pilot document limit.");
  } catch {
    issue("program", "shape", "Content must be serializable text and facts.");
  }
  if (issues.some((x) => ["shape", "locked", "limit"].includes(x.kind))) return issues;
  function required(value, path, min = 10, max = 2e3) {
    if (typeof value !== "string" || value.trim().length < min) issue(path, "required", `Add at least ${min} characters.`);
    else if (value.length > max) issue(path, "limit", `Keep this field within ${max} characters.`);
  }
  function minutes2(value, path) {
    if (!Number.isInteger(value) || value < 5 || value > 720) issue(path, "consistency", "Use whole minutes between 5 and 720.");
  }
  required(document.title, "program.title", 3, 160);
  required(document.summary, "program.summary", 20, 2e3);
  required(document.promise, "program.promise", 20, 1e3);
  minutes2(document.estimatedMinutes, "program.estimatedMinutes");
  for (const key of ["prerequisites", "outcomes"]) document[key].forEach((v, i) => required(v, "program." + key + "." + i, 10, 500));
  if (document.estimatedMinutes < document.lessons.reduce((sum, l) => sum + l.estimatedMinutes, 0)) issue("program.estimatedMinutes", "consistency", "Total learning time must include all lesson estimates.");
  for (const [i, l] of document.lessons.entries()) {
    const base = "program.lessons." + i;
    required(l.title, base + ".title", 3, 160);
    required(l.objective, base + ".objective", 20, 1e3);
    required(l.lessonText, base + ".lessonText", 100, 12e3);
    minutes2(l.estimatedMinutes, base + ".estimatedMinutes");
    l.steps.forEach((v, j) => required(v, base + ".steps." + j, 5, 500));
    required(l.reflectionPrompt, base + ".reflectionPrompt", 15, 1e3);
    required(l.returnToWorkAction, base + ".returnToWorkAction", 30, 2e3);
    const ex = l.exercise;
    const sourceIds = /* @__PURE__ */ new Set();
    for (const [j, row] of ex.sourcePacket.entries()) {
      const id2 = row.sourceId.trim();
      if (sourceIds.has(id2) && !(row.duplicateOf === id2 && typeof row.sourceNote === "string" && row.sourceNote.trim().length >= 10)) issue(base + ".exercise.sourcePacket." + j + ".sourceId", "consistency", "Give distinct sources separate references, or explicitly mark and explain a teaching duplicate.");
      if (Object.hasOwn(row, "duplicateOf") && (!sourceIds.has(id2) || row.duplicateOf !== id2)) issue(base + ".exercise.sourcePacket." + j + ".duplicateOf", "consistency", "A teaching duplicate must identify an earlier same-reference source.");
      sourceIds.add(id2);
      if (!Object.entries(row).some(([key, value]) => !["sourceId", "duplicateOf", "sourceNote", "type"].includes(key) && value !== null && (typeof value !== "string" || value.trim().length > 0))) issue(base + ".exercise.sourcePacket." + j, "required", "Add at least one meaningful fictional source fact.");
      if (Object.hasOwn(row, "content") && typeof row.content === "string" && !row.content.trim()) issue(base + ".exercise.sourcePacket." + j + ".content", "required", "Add the fictional source text.");
    }
    for (const key of ["title", "suppliedAiDraft", "optionalAiPrompt", "learnerTask", "assessorReference"]) required(ex[key], base + ".exercise." + key, key === "title" ? 3 : 30, key === "title" ? 160 : 4e3);
    ex.expectedEvidence.forEach((v, j) => required(v, base + ".exercise.expectedEvidence." + j, 10, 700));
    for (const [j, q] of l.quiz.entries()) {
      required(q.question, base + ".quiz." + j + ".question", 10, 1e3);
      required(q.explanation, base + ".quiz." + j + ".explanation", 20, 2e3);
      q.options.forEach((v, k) => required(v, base + ".quiz." + j + ".options." + k, 1, 500));
      if (new Set(q.options.map((option) => option.trim())).size !== q.options.length) issue(base + ".quiz." + j + ".options", "consistency", "Use four distinct answer options.");
      if (!Number.isInteger(q.correctOptionIndex) || q.correctOptionIndex < 0 || q.correctOptionIndex > 3) issue(base + ".quiz." + j + ".correctOptionIndex", "consistency", "Choose one of the four answer options.");
    }
  }
  const a = document.practicalAssessment;
  required(a.title, "program.practicalAssessment.title", 3, 160);
  required(a.scenario, "program.practicalAssessment.scenario", 30, 5e3);
  for (const [i, p] of a.submissionPrompts.entries()) {
    required(p.label, "program.practicalAssessment.submissionPrompts." + i + ".label", 3, 160);
    required(p.help, "program.practicalAssessment.submissionPrompts." + i + ".help", 10, 1e3);
  }
  for (const [i, r] of a.rubric.entries()) {
    const b = "program.practicalAssessment.rubric." + i;
    required(r.dimension, b + ".dimension", 3, 160);
    if (!Number.isInteger(r.weight) || r.weight < 1 || r.weight > 97) issue(b + ".weight", "consistency", "Use a positive whole weight, keeping the total at 100.");
    for (const level of ["0", "1", "2", "3", "4"]) required(r.anchors[level], b + ".anchors." + level, 10, 1e3);
    if (r.criticalGate !== null) required(r.criticalGate, b + ".criticalGate", 30, 2e3);
  }
  if (a.rubric.reduce((n, r) => n + r.weight, 0) !== 100) issue("program.practicalAssessment.rubric", "consistency", "Criterion weights must total exactly 100.");
  for (const key of ["samplePassingEvidence", "sampleCriticalFailure", "assessorNote"]) required(a[key], "program.practicalAssessment." + key, 30, 5e3);
  return issues;
}
function findDraft(host, id2, revision) {
  const d = host.content?.drafts.find((d2) => d2.id === id2);
  if (!d) throw new AuthoringError("Content draft not found in this workspace.", 404);
  if (!Number.isInteger(revision) || revision !== d.revision) throw new AuthoringError("This content draft changed. Reload its latest revision before saving.", 409);
  return d;
}
function byAuthor(d, user) {
  if (d.authorId !== user.userId) throw new AuthoringError("Only this draft author may edit or submit it.", 403);
}
function due(value, now) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value) || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString() !== value || Date.parse(value) <= Date.parse(now) || Date.parse(value) > Date.parse(now) + 730 * 864e5) throw new AuthoringError("Choose a future content review date within two years.");
  return value;
}
function bump(d, actor, action, now, note) {
  d.revision++;
  d.updatedAt = now;
  d.history.push({ id: crypto.randomUUID(), actor: actor.userId, actorName: savedName(actor.name), action, at: now, ...note ? { note } : {} });
  if (d.history.length > (action === "archived private practice draft" ? 101 : 100)) throw new AuthoringError("This draft reached its pilot history limit. Copy its latest publication or seek support.", 409);
}
var complete = (issues) => {
  if (issues.length) throw new AuthoringError("Resolve the content preview issues before requesting review or publishing.");
};
async function applyWorkspaceContentCommand(original, user, c, now = (/* @__PURE__ */ new Date()).toISOString()) {
  if (!isContentCommand(c)) throw new AuthoringError("Unknown content action.", 400);
  if (!Number.isFinite(Date.parse(now))) throw new AuthoringError("A trusted action time is required.", 400);
  now = new Date(now).toISOString();
  if (now.length !== 24) throw new AuthoringError("A four-digit-year action time is required.", 400);
  const t = copy(original), actor = owner(t, user);
  t.content ??= freshAuthoring();
  switch (c.type) {
    case "content-copy": {
      exact(c, ["sourceRef"]);
      if (t.content.drafts.filter(activeDraft).length >= AUTHORING_LIMITS.activeDrafts) throw new AuthoringError("This pilot supports four active content drafts per workspace.", 409);
      if (t.content.drafts.length >= AUTHORING_LIMITS.totalDrafts) throw new AuthoringError("This pilot retains up to 24 source drafts including archived history.", 409);
      const source = scopedRef(t, c.sourceRef), resolved = resolve(t, source), programId = source.scope === t.id ? source.programId : "path-" + crypto.randomUUID(), id2 = "cd-" + crypto.randomUUID();
      const draft = { id: id2, programId, baseRef: source, authorId: user.userId, authorName: savedName(actor.name), state: "draft", revision: 1, documentRevision: 1, document: {}, createdAt: now, updatedAt: now, history: [{ id: crypto.randomUUID(), actor: user.userId, actorName: savedName(actor.name), action: "copied", at: now }] };
      draft.document = template(t, draft);
      t.content.drafts.push(draft);
      break;
    }
    case "content-save": {
      exact(c, ["draftId", "revision", "document"]);
      const d = findDraft(t, c.draftId, c.revision);
      byAuthor(d, user);
      if (d.state !== "draft") throw new AuthoringError("Recall the draft before editing reviewed content.", 409);
      const issues = validateDocument(c.document, template(t, d));
      if (issues.some((x) => ["shape", "locked", "limit"].includes(x.kind))) throw new AuthoringError("Keep the supported content structure, classification and text limits.");
      d.document = copy(c.document);
      d.documentRevision++;
      delete d.approval;
      bump(d, actor, "saved", now);
      break;
    }
    case "content-submit": {
      exact(c, ["draftId", "revision", "reviewerId", "reviewDueAt"]);
      const d = findDraft(t, c.draftId, c.revision);
      byAuthor(d, user);
      if (d.state !== "draft") throw new AuthoringError("Only an editable draft can request review.", 409);
      complete(validateDocument(d.document, template(t, d)));
      const reviewer = t.members.find((m) => m.userId === c.reviewerId && m.active && m.roles.includes("admin"));
      if (!reviewer || reviewer.userId === d.authorId) throw new AuthoringError("Choose another active workspace owner for independent content review.", 403);
      d.reviewerId = reviewer.userId;
      d.reviewDueAt = due(c.reviewDueAt, now);
      d.state = "in_review";
      delete d.approval;
      bump(d, actor, "submitted for independent review", now);
      break;
    }
    case "content-recall": {
      exact(c, ["draftId", "revision", "reason"]);
      const d = findDraft(t, c.draftId, c.revision);
      byAuthor(d, user);
      if (!["in_review", "approved"].includes(d.state)) throw new AuthoringError("Only unpublished reviewed content may be recalled.", 409);
      const reason = text(c.reason, "Reason for recall", 10, 1e3);
      d.state = "draft";
      delete d.approval;
      bump(d, actor, "recalled for editing", now, reason);
      break;
    }
    case "content-review": {
      exact(c, ["draftId", "revision", "decision", "note", "checks"]);
      const d = findDraft(t, c.draftId, c.revision);
      if (d.state !== "in_review") throw new AuthoringError("This draft is not awaiting review.", 409);
      if (d.reviewerId !== user.userId || d.authorId === user.userId) throw new AuthoringError("Only the assigned independent owner may review this content.", 403);
      if (!["approve", "changes"].includes(c.decision)) throw new AuthoringError("Choose approval or request changes.");
      const note = text(c.note, "Content review note", 30, 2e3);
      if (c.decision === "changes") {
        d.state = "draft";
        delete d.approval;
        bump(d, actor, "changes requested", now, note);
        break;
      }
      const keys = ["sources", "answers", "rubric", "safety", "accessibility"];
      if (!plain(c.checks) || Object.keys(c.checks).some((k) => !keys.includes(k)) || keys.some((k) => c.checks[k] !== true)) throw new AuthoringError("Record every required content review check before approval.");
      complete(validateDocument(d.document, template(t, d)));
      due(d.reviewDueAt, now);
      d.approval = { reviewerId: user.userId, reviewerName: savedName(actor.name), documentRevision: d.documentRevision, documentHash: await documentHash(d.document), reviewedAt: now, note, checks: copy(c.checks) };
      d.state = "approved";
      bump(d, actor, "approved private practice draft", now, note);
      break;
    }
    case "content-publish": {
      exact(c, ["draftId", "revision"]);
      const d = findDraft(t, c.draftId, c.revision);
      if (d.state !== "approved" || !d.approval) throw new AuthoringError("Publish only content approved by an independent owner.", 409);
      const reviewer = t.members.find((m) => m.userId === d.approval.reviewerId && m.active && m.roles.includes("admin"));
      if (!reviewer || reviewer.userId === d.authorId) throw new AuthoringError("Independent reviewer permission changed. Request a current content review.", 403);
      complete(validateDocument(d.document, template(t, d)));
      due(d.reviewDueAt, now);
      const hash = await documentHash(d.document);
      if (d.approval.documentRevision !== d.documentRevision || hash !== d.approval.documentHash) throw new AuthoringError("The document differs from the independently approved revision.", 409);
      if (t.content.publications.length >= AUTHORING_LIMITS.publications) throw new AuthoringError("This pilot supports eight immutable workspace publications.", 409);
      const ref = contentRef({ scope: t.id, programId: d.programId, versionId: "cp-" + crypto.randomUUID() });
      t.content.publications.push({ id: ref.versionId, snapshot: { ref, program: copy(d.document), language: "en", audience: "Adult learners", classification: AUTHORING_CLASSIFICATION, policy: { minimumWeightedScore: 70, scoreMaximum: 4, criticalGates: "all", maxAttempts: 3, appealDays: 14, lessonCount: 3, questionsPerLesson: 3, optionsPerQuestion: 4, submissionFieldCount: 7, evidenceMinCharacters: 30, evidenceMaxCharacters: 1e4 } }, documentHash: hash, authorId: d.authorId, authorName: d.authorName, reviewerId: d.approval.reviewerId, reviewerName: d.approval.reviewerName, reviewedAt: d.approval.reviewedAt, publishedBy: user.userId, publishedByName: savedName(actor.name), publishedAt: now, reviewDueAt: d.reviewDueAt, availability: "available" });
      d.state = "published";
      d.publishedRef = ref;
      bump(d, actor, "published immutable private practice draft", now);
      break;
    }
    case "content-archive": {
      exact(c, ["draftId", "revision", "reason"]);
      const d = findDraft(t, c.draftId, c.revision);
      if (!activeDraft(d)) throw new AuthoringError("Only an unpublished active draft can be archived.", 409);
      const reason = text(c.reason, "Reason for archiving", 10, 1e3);
      d.state = "archived";
      bump(d, actor, "archived private practice draft", now, reason);
      break;
    }
    case "content-retire": {
      exact(c, ["publicationId", "reason"]);
      const p = t.content.publications.find((p2) => p2.id === c.publicationId);
      if (!p) throw new AuthoringError("Publication not found in this workspace.", 404);
      if (p.availability === "retired") throw new AuthoringError("This publication is already closed to new enrollment.", 409);
      const reason = text(c.reason, "Reason for closing new enrollment", 10, 1e3);
      p.availability = "retired";
      p.retirement = { reason, actor: user.userId, actorName: savedName(actor.name), at: now };
      break;
    }
  }
  const oldEffective = utf8JsonBytes(original.content ?? freshAuthoring()) + authoringClosureReserve(original), newEffective = utf8JsonBytes(t.content) + authoringClosureReserve(t);
  if (newEffective > oldEffective && newEffective > AUTHORING_LIMITS.contentBytes) throw new AuthoringError("This workspace must retain room to archive drafts and close publications. Keep your edits and seek support before adding more content.", 413);
  return t;
}
function requireAvailablePublication(host, refValue, now = (/* @__PURE__ */ new Date()).toISOString()) {
  const ref = scopedRef(host, refValue);
  if (ref.scope === "global") return resolve(host, ref);
  const p = host.content?.publications.find((p2) => p2.snapshot.ref.programId === ref.programId && p2.snapshot.ref.versionId === ref.versionId);
  if (!p || p.availability !== "available") throw new AuthoringError("This private pathway is closed to new cohort offerings and enrollment.", 409);
  if (!Number.isFinite(Date.parse(now))) throw new AuthoringError("A trusted action time is required.", 400);
  if (Date.parse(p.reviewDueAt) <= Date.parse(now)) throw new AuthoringError("Content review is due before new enrollment.", 409);
  return copy(p.snapshot);
}
function projectWorkspaceContent(host, user, neededRefs) {
  const m = host.members.find((m2) => m2.userId === user.userId);
  if (!m) throw new AuthoringError("Workspace not found.", 404);
  const admin = m.active && m.roles.includes("admin"), content = host.content ?? freshAuthoring();
  const keys = new Set(neededRefs.map((ref) => contentKey(scopedRef(host, ref))));
  const versions = content.publications.filter((p) => admin || keys.has(contentKey(p.snapshot.ref))).map((p) => copy(p.snapshot));
  return { versions, ...admin ? { drafts: copy(content.drafts), publications: content.publications.map((p) => ({ id: p.id, ref: p.snapshot.ref, title: p.snapshot.program.title, availability: p.availability, classification: p.snapshot.classification, authorName: p.authorName, reviewerName: p.reviewerName, publishedAt: p.publishedAt, reviewDueAt: p.reviewDueAt, documentHash: p.documentHash, retirement: p.retirement })) } : {} };
}
var utf8JsonBytes = (value) => new TextEncoder().encode(JSON.stringify(value)).length;
var WORST_REASON = String.fromCharCode(0).repeat(1e3);
var WORST_NAME = String.fromCharCode(0).repeat(80);
var CLOCK = "2000-01-01T00:00:00.000Z";
function largestSavedActorId(host) {
  let actor = "";
  for (const m of host.members) {
    if (utf8JsonBytes(m.userId) > utf8JsonBytes(actor)) actor = m.userId;
  }
  return actor;
}
function retirementGrowth(publication, actorId) {
  if (publication.availability !== "available") return 0;
  return Math.max(0, utf8JsonBytes({ ...publication, availability: "retired", retirement: { reason: WORST_REASON, actor: actorId, actorName: WORST_NAME, at: CLOCK } }) - utf8JsonBytes(publication));
}
function archiveGrowth(draft, actorId) {
  if (!activeDraft(draft)) return 0;
  return Math.max(0, utf8JsonBytes({ ...draft, state: "archived", revision: draft.revision + 1, updatedAt: CLOCK, history: [...draft.history, { id: "0".repeat(36), actor: actorId, actorName: WORST_NAME, action: "archived private practice draft", at: CLOCK, note: WORST_REASON }] }) - utf8JsonBytes(draft));
}
function authoringRetirementReserve(host) {
  const actor = largestSavedActorId(host);
  return (host.content?.publications ?? []).reduce((sum, p) => sum + retirementGrowth(p, actor), 0);
}
function authoringClosureReserve(host) {
  const actor = largestSavedActorId(host);
  return authoringRetirementReserve(host) + (host.content?.drafts ?? []).reduce((sum, d) => sum + archiveGrowth(d, actor), 0);
}

// lib/academy-support.ts
var SupportRuleError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "SupportRuleError";
  }
};
var SUPPORT_CATEGORIES = ["access", "learning", "technical", "content", "accessibility", "privacy"];
var MAX_SUPPORT_BYTES = 25e4;
var MAX_REQUESTS = 100;
var MAX_OPEN = 5;
var MAX_MESSAGES = 20;
var MAX_EVENTS = 100;
var MAX_RESOLUTIONS = 20;
var snapshotName = (name) => String(name || "Academy member").slice(0, 80);
var commands = /* @__PURE__ */ new Set(["support-open", "support-claim", "support-reply", "support-resolve", "support-reopen", "support-withdraw"]);
var exact2 = (c, keys) => {
  if (Object.keys(c).some((k) => !["type", ...keys].includes(k))) throw new SupportRuleError("This support request includes unsupported fields.", 400);
};
function text2(v, label2, min, max) {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new SupportRuleError(`${label2} needs ${min}\u2013${max} characters.`);
  return v.trim();
}
function member2(t, userId, active2 = true) {
  const m = t.members.find((m2) => m2.userId === userId);
  if (!m) throw new SupportRuleError("Workspace support is unavailable for this account.", 404);
  if (active2 && !m.active) throw new SupportRuleError("Workspace access is no longer active. Your past requests remain available to read.", 403);
  return m;
}
var owner2 = (m) => m.active && m.roles.includes("admin");
function eligibleSupportHandler(t, m, r) {
  return !!m && m.active && m.userId !== r.requesterId && (owner2(m) || m.roles.includes("facilitator") && ["learning", "content"].includes(r.category) && r.cohortId !== null && t.cohorts.some((c) => c.id === r.cohortId) && m.scopes.includes(r.cohortId));
}
function handler(t, r) {
  const m = t.members.find((m2) => m2.userId === r.assignedTo);
  return eligibleSupportHandler(t, m, r) ? m : null;
}
function reconcileSupportAssignments(t) {
  let released = 0;
  for (const r of t.support ?? []) {
    if (r.assignedTo && !handler(t, r)) {
      r.assignedTo = null;
      released++;
    }
  }
  return released;
}
function canQueue(t, m, r) {
  return m.active && (owner2(m) || m.roles.includes("facilitator") && ["learning", "content"].includes(r.category) && r.cohortId !== null && t.cohorts.some((c) => c.id === r.cohortId) && m.scopes.includes(r.cohortId));
}
function request(t, c, m) {
  if (typeof c.requestId !== "string") throw new SupportRuleError("Choose a support request.", 400);
  const r = t.support?.find((r2) => r2.id === c.requestId);
  if (!r || r.requesterId !== m.userId && !canQueue(t, m, r) && handler(t, r)?.userId !== m.userId) throw new SupportRuleError("Support request not found for this account.", 404);
  return r;
}
function intakeCohort(t, m, id2) {
  if (id2 === null) return null;
  if (typeof id2 !== "string") throw new SupportRuleError("Choose a current cohort or workspace access.", 400);
  const c = t.cohorts.find((c2) => c2.id === id2);
  if (!c) throw new SupportRuleError("Current workspace cohort not found.", 404);
  if (!owner2(m) && !m.roles.includes("learner") && !(m.scopes.includes(id2) && m.roles.some((r) => ["facilitator", "assessor", "reviewer", "moderator"].includes(r)))) throw new SupportRuleError("This cohort is outside your current request scope.", 403);
  return c.id;
}
function appendMessage(r, m, kind, body, now) {
  if (r.messages.length >= MAX_MESSAGES) throw new SupportRuleError("This pilot request reached its 20-message limit. Keep your input and ask the workspace owner for support.", 409);
  r.messages.push({ id: crypto.randomUUID(), actorId: m.userId, actorName: snapshotName(m.name), authorKind: kind, body, createdAt: now });
}
function event(r, m, type, now, extra = {}) {
  if (r.events.length >= MAX_EVENTS && type !== "withdrawn") throw new SupportRuleError("This pilot request reached its lifecycle history limit.", 409);
  r.events.push({ id: crypto.randomUUID(), type, actorId: m.userId, actorName: snapshotName(m.name), createdAt: now, ...extra });
}
function mustOpen(r) {
  if (r.status !== "open") throw new SupportRuleError("Only open requests allow this action.", 409);
}
function assertOwn(r, m) {
  if (r.requesterId !== m.userId) throw new SupportRuleError("Only the requester can do this.", 403);
}
function assertHandler(t, r, m) {
  if (handler(t, r)?.userId !== m.userId) throw new SupportRuleError("Only the currently assigned eligible handler can do this.", 403);
}
function applySupportCommand(t, actorId, c, now) {
  if (!c || typeof c !== "object" || !commands.has(c.type)) return false;
  if (typeof now !== "string" || !Number.isFinite(Date.parse(now))) throw new SupportRuleError("A valid support timestamp is required.", 400);
  now = new Date(now).toISOString();
  if (now.length !== 24) throw new SupportRuleError("A four-digit-year support timestamp is required.", 400);
  const actor = member2(t, actorId), next = { members: t.members, cohorts: t.cohorts, support: structuredClone(t.support ?? []) }, cases = next.support;
  switch (c.type) {
    case "support-open": {
      exact2(c, ["category", "cohortId", "subject", "body", "audienceAcknowledged"]);
      if (c.audienceAcknowledged !== true) throw new SupportRuleError("Acknowledge who can see the request before submitting.");
      if (!SUPPORT_CATEGORIES.includes(c.category)) throw new SupportRuleError("Choose an existing support category.");
      const cohortId = intakeCohort(next, actor, c.cohortId), subject2 = text2(c.subject, "Request title", 5, 160), body = text2(c.body, "Request description", 10, 2e3);
      if (cases.length >= MAX_REQUESTS) throw new SupportRuleError("This pilot workspace reached its 100-request limit. Keep your input and ask the workspace owner for support.", 409);
      if (cases.filter((r2) => r2.requesterId === actorId && r2.status === "open").length >= MAX_OPEN) throw new SupportRuleError("You already have five open requests. Continue an existing request before opening another.", 409);
      const r = { id: crypto.randomUUID(), requesterId: actorId, requesterName: snapshotName(actor.name), category: c.category, cohortId, subject: subject2, status: "open", createdAt: now, updatedAt: now, assignedTo: null, messages: [], resolution: null, resolutions: [], events: [] };
      appendMessage(r, actor, "requester", body, now);
      event(r, actor, "opened", now);
      cases.push(r);
      break;
    }
    case "support-claim": {
      exact2(c, ["requestId"]);
      const r = request(next, c, actor);
      mustOpen(r);
      if (!eligibleSupportHandler(next, actor, r)) throw new SupportRuleError("A current eligible staff member independent of the requester must handle this request.", 403);
      if (handler(next, r)) throw new SupportRuleError("This request already has a current eligible handler.", 409);
      const prior = next.members.find((m) => m.userId === r.assignedTo);
      event(r, actor, "claimed", now, { previousHandlerId: r.assignedTo, previousHandlerName: prior ? snapshotName(prior.name) : null, handlerId: actorId, handlerName: snapshotName(actor.name) });
      r.assignedTo = actorId;
      r.updatedAt = now;
      break;
    }
    case "support-reply": {
      exact2(c, ["requestId", "body"]);
      const r = request(next, c, actor);
      mustOpen(r);
      const kind = r.requesterId === actorId ? "requester" : "handler";
      if (kind === "handler") assertHandler(next, r, actor);
      appendMessage(r, actor, kind, text2(c.body, "Reply", 10, 2e3), now);
      r.updatedAt = now;
      break;
    }
    case "support-resolve": {
      exact2(c, ["requestId", "resolution"]);
      const r = request(next, c, actor);
      mustOpen(r);
      assertHandler(next, r, actor);
      if (r.resolutions.length >= MAX_RESOLUTIONS) throw new SupportRuleError("This pilot request reached its resolution history limit.", 409);
      const resolution = { id: crypto.randomUUID(), actorId, actorName: snapshotName(actor.name), body: text2(c.resolution, "Resolution", 20, 2e3), resolvedAt: now };
      r.resolutions.push(resolution);
      r.resolution = structuredClone(resolution);
      event(r, actor, "resolved", now);
      r.status = "resolved";
      r.updatedAt = now;
      break;
    }
    case "support-reopen": {
      exact2(c, ["requestId", "body"]);
      const r = request(next, c, actor);
      assertOwn(r, actor);
      if (r.status !== "resolved") throw new SupportRuleError("Only a resolved request can be reopened. Withdrawn requests stay read only.", 409);
      if (cases.filter((x) => x.requesterId === actorId && x.status === "open").length >= MAX_OPEN) throw new SupportRuleError("You already have five open requests. Continue an existing request first.", 409);
      appendMessage(r, actor, "requester", text2(c.body, "Reason for reopening", 10, 2e3), now);
      event(r, actor, "reopened", now);
      r.resolution = null;
      r.status = "open";
      r.updatedAt = now;
      break;
    }
    case "support-withdraw": {
      exact2(c, ["requestId"]);
      const r = request(next, c, actor);
      assertOwn(r, actor);
      mustOpen(r);
      event(r, actor, "withdrawn", now);
      r.status = "withdrawn";
      r.updatedAt = now;
      break;
    }
  }
  const bytes = new TextEncoder().encode(JSON.stringify(cases)).length;
  if (bytes + supportClosureReserve(next) > MAX_SUPPORT_BYTES) throw new SupportRuleError("This pilot workspace reached its support storage limit. Keep your input and ask the workspace owner for support.", 413);
  t.support = cases;
  return true;
}
function fullThread(t, r) {
  const effective = handler(t, r), { requesterId, assignedTo, ...safe } = structuredClone(r);
  return { ...safe, handlerName: effective?.name ?? null, messages: safe.messages.map(({ actorId, ...m }) => m), resolution: safe.resolution ? (({ actorId, ...v }) => v)(safe.resolution) : null, resolutions: safe.resolutions.map(({ actorId, ...v }) => v), events: safe.events.map(({ actorId, handlerId, previousHandlerId, ...e }) => e) };
}
function projectSupport(t, actorId) {
  const m = member2(t, actorId, false), cases = t.support ?? [], mine = cases.filter((r) => r.requesterId === actorId).map((r) => fullThread(t, r));
  if (!m.active) return { mine, queue: [], assigned: [] };
  const queue = cases.filter((r) => canQueue(t, m, r)).map((r) => {
    const effective = handler(t, r);
    return { id: r.id, category: r.category, cohortId: r.cohortId, cohortTitle: r.cohortId ? t.cohorts.find((c) => c.id === r.cohortId)?.title ?? "Former cohort" : null, subject: r.subject, requesterName: r.requesterName, createdAt: r.createdAt, updatedAt: r.updatedAt, status: r.status, handlerName: effective?.name ?? null, canClaim: r.status === "open" && !effective && eligibleSupportHandler(t, m, r), eligibleHandlerAvailable: t.members.some((x) => eligibleSupportHandler(t, x, r)) };
  });
  const assigned = cases.filter((r) => handler(t, r)?.userId === actorId).map((r) => fullThread(t, r));
  return { mine, queue, assigned };
}
function supportClosureReserve(t) {
  const bytes = (v) => new TextEncoder().encode(JSON.stringify(v)).length;
  return (t.support ?? []).filter((r) => r.status === "open").reduce((total, r) => {
    const final = { id: "0".repeat(36), type: "withdrawn", actorId: r.requesterId, actorName: "\0".repeat(80), createdAt: "2000-01-01T00:00:00.000Z" };
    return total + bytes(final) + (r.events.length ? 1 : 0) + 5 + Math.max(0, 24 - r.updatedAt.length);
  }, 0);
}

// lib/academy-plan.ts
var PLAN_COMMANDS = ["learning-plan", "plan-task", "plan-task-status", "plan-task-remove"];
var PLAN_LIMITS = { totalTasks: 200, openTasks: 30, maxTitle: 100, maxNote: 500, maxGoal: 200 };
var PLAN_GOALS = ["explore", "records", "check-draft", "clear-response", "expert-questions"];
var LearningPlanError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "LearningPlanError";
  }
};
var clone = (v) => structuredClone(v);
var has = (v, key) => Object.prototype.hasOwnProperty.call(v, key);
function fail(message, status = 422) {
  throw new LearningPlanError(message, status);
}
function exact3(c, keys) {
  if (!c || typeof c !== "object" || Array.isArray(c) || typeof c.type !== "string") fail("Choose a valid planning action.", 400);
  if (Object.keys(c).some((k) => !["type", ...keys].includes(k))) fail("This planning action includes unsupported fields.", 400);
}
function boundedText(value, label2, min, max) {
  if (typeof value !== "string" || value.trim().length < min || value.length > max) fail(`${label2} needs ${min}\u2013${max} characters.`);
  return value.trim();
}
function minutes(value, label2, min, max) {
  if (!Number.isInteger(value) || value < min || value > max) fail(`${label2} must be a whole number from ${min} to ${max}.`);
  return value;
}
function timestamp(value) {
  if (typeof value !== "string" || !Number.isFinite(Date.parse(value))) fail("A valid planning timestamp is required.", 400);
  return new Date(value).toISOString();
}
function validatePlanDate(value) {
  if (value === null) return null;
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) fail("Choose a valid date or leave it unscheduled.");
  const year = Number(value.slice(0, 4));
  if (year < 1900 || year > 2200) fail("Choose a date between 1900 and 2200.");
  const date = /* @__PURE__ */ new Date(value + "T12:00:00.000Z");
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) fail("Choose a real calendar date.");
  return value;
}
function validatePlanTimeZone(value) {
  if (typeof value !== "string" || value.length < 1 || value.length > 80 || /^[+-]/.test(value)) fail("Choose a supported timezone.");
  try {
    new Intl.DateTimeFormat("en", { timeZone: value }).format(0);
  } catch {
    fail("Choose a supported timezone.");
  }
  return value;
}
function freshLearningPlan() {
  return { goal: "explore", personalGoal: "", weeklyMinutes: 60, timeZone: "UTC", remindersEnabled: false, tasks: [] };
}
function readLearningPlan(state) {
  if (state.learningPlan === void 0) return freshLearningPlan();
  const saved = state.learningPlan;
  if (!saved || typeof saved !== "object" || !Array.isArray(saved.tasks)) fail("Your saved learning plan needs a format review. Your learning is retained.", 409);
  return clone({ ...freshLearningPlan(), ...saved });
}
function isLearningPlanCommand(c) {
  return !!c && typeof c === "object" && !Array.isArray(c) && PLAN_COMMANDS.some((type) => type === c.type);
}
function ownEnrollment(state, id2) {
  const enrollment2 = (state.enrollments ?? []).find((e) => e.id === id2);
  if (!enrollment2) fail("Enrollment not found in your learning space.", 404);
  return enrollment2;
}
function paused(state, e, options) {
  return (state.paused ?? []).includes(e.programId) || !!options.cohorts?.some((c) => c.id === e.cohortId && c.status === "paused");
}
function pinned(e, options) {
  const program2 = options.resolveProgram(e.programId, e.version, e);
  if (!program2) fail("The pinned learning content is unavailable. Your plan and evidence are retained.", 409);
  return program2;
}
function nextUndecided(e) {
  return (e.attempts ?? []).find((a) => !a.decision);
}
function openAppeal(e) {
  return (e.appeals ?? []).find((a) => a.status === "open");
}
function ownTask(plan, id2) {
  const task = plan.tasks.find((t) => t.id === id2);
  if (!task) fail("Planning activity not found in your learning space.", 404);
  return task;
}
function taskLink(state, kind, enrollmentId, lessonId, options) {
  if (kind === "practice") {
    if (enrollmentId != null || lessonId != null) fail("A private practice activity has no enrollment or lesson link.", 400);
    return { enrollmentId: null, lessonId: null, title: "", defaultMinutes: 15 };
  }
  const e = ownEnrollment(state, enrollmentId);
  if (e.withdrawn) fail("This enrollment was withdrawn. Your planning history is retained.", 409);
  if (kind === "reflection") {
    if (lessonId != null) fail("A reflection is linked to its enrollment, not a lesson.", 400);
    if (e.record?.status !== "active") fail("An active reviewed practice record is needed before planning a work reflection.", 409);
    return { enrollmentId: e.id, lessonId: null, title: `Reflect on ${e.record.title || e.programId}`, defaultMinutes: 15 };
  }
  if (options.canLearn === false) fail("Your current membership does not permit learning activities.", 403);
  if (paused(state, e, options)) fail("Learning is paused here. Your plan and saved work are retained.", 409);
  const program2 = pinned(e, options);
  if (kind === "lesson") {
    const lesson = program2.lessons.find((l) => l.id === lessonId);
    if (!lesson) fail("Lesson not found in this pinned pathway.", 404);
    if ((e.completed ?? []).includes(lesson.id)) fail("This lesson is already complete. Choose your next activity.", 409);
    return { enrollmentId: e.id, lessonId: lesson.id, title: lesson.title, defaultMinutes: Math.min(240, Math.max(5, lesson.estimatedMinutes ?? 25)) };
  }
  if (lessonId != null) fail("Practical submission planning has no lesson link.", 400);
  if (e.record?.status === "active") fail("This pathway already has an active completion record.", 409);
  if (nextUndecided(e) || openAppeal(e)) fail("Wait for the current review or appeal before planning another submission.", 409);
  if ((e.attempts ?? []).length >= 3) fail("All three attempts are used. Review feedback and ask for support.", 409);
  return { enrollmentId: e.id, lessonId: null, title: program2.practicalAssessment?.title || `Demonstrate ${program2.title}`, defaultMinutes: 35 };
}
function applyLearningPlanCommand(state, c, options) {
  if (options.memberActive === false) fail("Workspace access was removed. Your own history remains available.", 403);
  const now = timestamp(options.now);
  const plan = readLearningPlan(state);
  switch (c?.type) {
    case "learning-plan": {
      exact3(c, ["goal", "personalGoal", "weeklyMinutes", "timeZone", "remindersEnabled"]);
      if (Object.keys(c).length === 1) fail("Choose a planning preference to save.");
      if (has(c, "goal")) {
        if (!PLAN_GOALS.some((g) => g === c.goal)) fail("Choose an existing learning goal.");
        plan.goal = c.goal;
      }
      if (has(c, "personalGoal")) plan.personalGoal = boundedText(c.personalGoal, "Personal goal", 0, PLAN_LIMITS.maxGoal);
      if (has(c, "weeklyMinutes")) plan.weeklyMinutes = minutes(c.weeklyMinutes, "Weekly learning budget", 10, 600);
      if (has(c, "timeZone")) plan.timeZone = validatePlanTimeZone(c.timeZone);
      if (has(c, "remindersEnabled")) {
        if (typeof c.remindersEnabled !== "boolean") fail("Choose whether to show optional in-app reminders.");
        plan.remindersEnabled = c.remindersEnabled;
      }
      break;
    }
    case "plan-task": {
      exact3(c, ["taskId", "kind", "enrollmentId", "lessonId", "title", "dueDate", "plannedMinutes", "note"]);
      if (has(c, "taskId")) {
        const task = ownTask(plan, c.taskId);
        if (Object.keys(c).length === 2) fail("Choose an activity field to change.");
        for (const key of ["kind", "enrollmentId", "lessonId"]) if (has(c, key) && c[key] !== task[key]) fail("A planning activity cannot be retargeted. Create another activity instead.", 400);
        if (has(c, "title")) {
          if (task.kind !== "practice") fail("Linked activity titles come from the pinned learning record.", 400);
          task.title = boundedText(c.title, "Practice activity title", 3, PLAN_LIMITS.maxTitle);
        }
        if (has(c, "dueDate")) task.dueDate = validatePlanDate(c.dueDate);
        if (has(c, "plannedMinutes")) task.plannedMinutes = minutes(c.plannedMinutes, "Planned minutes", 5, 240);
        if (has(c, "note")) task.note = boundedText(c.note, "Private planning note", 0, PLAN_LIMITS.maxNote);
        task.updatedAt = now;
      } else {
        if (!["lesson", "practical", "reflection", "practice"].includes(c.kind)) fail("Choose a planning activity type.");
        if (plan.tasks.length >= PLAN_LIMITS.totalTasks) fail("This private plan reached its activity limit. Remove an old planning item before adding another.", 409);
        if (projectPlanTasks(state, plan, options).filter((t) => t.status === "planned").length >= PLAN_LIMITS.openTasks) fail("This private plan supports 30 open activities. Finish, skip or remove one before adding another.", 409);
        const link = taskLink(state, c.kind, c.enrollmentId, c.lessonId, options);
        if (c.kind !== "practice" && has(c, "title")) fail("Linked activity titles come from the pinned learning record.", 400);
        if (c.kind !== "practice" && plan.tasks.some((t) => t.status === "planned" && t.kind === c.kind && t.enrollmentId === link.enrollmentId && t.lessonId === link.lessonId && taskProgress(state, t, options).status === "planned")) fail("This activity is already in your plan.", 409);
        const id2 = (options.newId ?? (() => crypto.randomUUID()))();
        if (typeof id2 !== "string" || id2.length < 1 || id2.length > 100 || plan.tasks.some((t) => t.id === id2)) fail("A unique planning activity reference is required.", 409);
        plan.tasks.push({
          id: id2,
          kind: c.kind,
          enrollmentId: link.enrollmentId,
          lessonId: link.lessonId,
          title: c.kind === "practice" ? boundedText(c.title, "Practice activity title", 3, PLAN_LIMITS.maxTitle) : link.title,
          dueDate: has(c, "dueDate") ? validatePlanDate(c.dueDate) : null,
          plannedMinutes: has(c, "plannedMinutes") ? minutes(c.plannedMinutes, "Planned minutes", 5, 240) : link.defaultMinutes,
          note: has(c, "note") ? boundedText(c.note, "Private planning note", 0, PLAN_LIMITS.maxNote) : "",
          status: "planned",
          createdAt: now,
          updatedAt: now,
          completedAt: null
        });
      }
      break;
    }
    case "plan-task-status": {
      exact3(c, ["taskId", "status"]);
      const task = ownTask(plan, c.taskId);
      if (!["planned", "done", "skipped"].includes(c.status)) fail("Choose planned, completed, or skipped.");
      if (c.status === "done" && task.kind !== "practice") fail("Linked activities complete through their saved lesson, submission, or reflection.");
      if (c.status === "planned" && task.status !== "planned") {
        if (projectPlanTasks(state, plan, options).filter((t) => t.status === "planned").length >= PLAN_LIMITS.openTasks) fail("This private plan supports 30 open activities.", 409);
        if (task.kind !== "practice") {
          taskLink(state, task.kind, task.enrollmentId, task.lessonId, options);
          if (plan.tasks.some((other) => other.id !== task.id && other.kind === task.kind && other.enrollmentId === task.enrollmentId && other.lessonId === task.lessonId && taskProgress(state, other, options).status === "planned")) fail("This activity is already in your plan.", 409);
        }
      }
      task.status = c.status;
      task.completedAt = c.status === "done" ? task.completedAt ?? now : null;
      task.updatedAt = now;
      break;
    }
    case "plan-task-remove": {
      exact3(c, ["taskId"]);
      ownTask(plan, c.taskId);
      plan.tasks = plan.tasks.filter((t) => t.id !== c.taskId);
      break;
    }
    default:
      fail("Choose a supported learner planning action.", 400);
  }
  return plan;
}
function taskProgress(state, task, options) {
  const storedStatus = task.kind !== "practice" && task.status === "done" ? "planned" : task.status;
  const base = { status: storedStatus, label: storedStatus === "skipped" ? "Skipped" : "Planned", completedAt: task.kind === "practice" ? task.completedAt : null, blocked: false, blockedReason: null };
  if (task.status === "skipped") return base;
  if (task.kind === "practice") return { ...base, label: task.status === "done" ? "Self-reported practice" : "Planned practice", blocked: options.memberActive === false, blockedReason: options.memberActive === false ? "Workspace access was removed." : null };
  const e = (state.enrollments ?? []).find((e2) => e2.id === task.enrollmentId);
  if (!e) return { ...base, blocked: true, blockedReason: "This enrollment is unavailable in your learning space." };
  let completedAt = null;
  let completed = false;
  let label2 = "Planned";
  if (task.kind === "lesson") {
    completed = (e.completed ?? []).includes(task.lessonId);
    completedAt = e.practice?.[task.lessonId]?.completedAt ?? null;
    label2 = "Lesson completed";
  } else if (task.kind === "practical") {
    const attempt = (e.attempts ?? []).find((a) => Date.parse(a.submittedAt) >= Date.parse(task.createdAt));
    completed = !!attempt;
    completedAt = attempt?.submittedAt ?? null;
    label2 = "Evidence submitted";
  } else {
    const reflection = (state.followups ?? []).find((f) => f.enrollmentId === e.id && Date.parse(f.createdAt) >= Date.parse(task.createdAt));
    completed = !!reflection;
    completedAt = reflection?.createdAt ?? null;
    label2 = "Reflection saved";
  }
  if (completed) return { status: "done", label: label2, completedAt, blocked: false, blockedReason: null };
  const block = (reason) => ({ ...base, blocked: true, blockedReason: reason });
  if (options.memberActive === false) return block("Workspace access was removed. Your own history remains available.");
  if (e.withdrawn) return block("This enrollment was withdrawn.");
  if (task.kind === "reflection") return e.record?.status === "active" ? { ...base, label: "Planned reflection" } : block("An active reviewed practice record is needed for a new reflection.");
  if (options.canLearn === false) return block("Your current membership does not permit learning activities.");
  if (paused(state, e, options)) return block("Learning is paused. Your saved work is retained.");
  const program2 = options.resolveProgram(e.programId, e.version, e);
  if (!program2) return block("The pinned learning content is unavailable.");
  if (task.kind === "lesson") {
    const index = program2.lessons.findIndex((l) => l.id === task.lessonId);
    if (index < 0) return block("This lesson is unavailable in the pinned pathway.");
    if (index > 0 && !(e.completed ?? []).includes(program2.lessons[index - 1].id)) return block("Complete the previous lesson before starting this activity.");
    return { ...base, label: "Planned lesson" };
  }
  if (nextUndecided(e) || openAppeal(e)) return block("Wait for the current review or appeal.");
  if ((e.attempts ?? []).length >= 3) return block("All three attempts are used. Review feedback and ask for support.");
  if (e.record?.status === "active") return block("This pathway already has an active completion record.");
  if (!program2.lessons.every((l) => (e.completed ?? []).includes(l.id))) return block("Complete the pathway lessons before submitting evidence.");
  return { ...base, label: "Planned evidence submission" };
}
function planToday(now, timeZone) {
  const valid = timestamp(now);
  validatePlanTimeZone(timeZone);
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date(valid));
  const part = (type) => parts.find((p) => p.type === type).value;
  return `${part("year")}-${part("month")}-${part("day")}`;
}
function projectPlanTasks(state, plan, options) {
  const today = planToday(options.now, plan.timeZone);
  return plan.tasks.map((task) => {
    const progress = taskProgress(state, task, options);
    const due2 = !task.dueDate ? "unscheduled" : task.dueDate < today ? "earlier" : task.dueDate === today ? "today" : "upcoming";
    return { ...clone(task), ...progress, due: due2 };
  }).sort((a, b) => (a.dueDate ?? "9999-12-31").localeCompare(b.dueDate ?? "9999-12-31") || a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id));
}

// lib/academy-ecosystem-guard.ts
var LegacyPreviewError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
    this.name = "LegacyPreviewError";
  }
};
var LEGACY_PREVIEW_MAPPINGS = [
  { partner: "agri", programId: "farmer-work-records" },
  { partner: "msme", programId: "msme-customer-operations" },
  { partner: "public", programId: "public-servant-source-briefs" }
];
var partners = [...LEGACY_PREVIEW_MAPPINGS.map((m) => m.partner), "health"];
function exact4(command, keys) {
  if (!command || typeof command !== "object" || Array.isArray(command) || Object.keys(command).some((k) => !keys.includes(k))) throw new LegacyPreviewError("Use only the supported local preview fields.", 400);
}
function partner(value) {
  if (typeof value !== "string" || !partners.includes(value)) throw new LegacyPreviewError("Ecosystem not found.", 404);
  return value;
}
function available(value) {
  const p = partner(value);
  if (p === "health") throw new LegacyPreviewError("Health Saha requires domain and privacy review. Local return previews are unavailable.", 409);
  return LEGACY_PREVIEW_MAPPINGS.find((m) => m.partner === p);
}
function validateLegacyConnectionCommand(command) {
  exact4(command, ["type", "partner", "enabled"]);
  if (command.type !== "connection") throw new LegacyPreviewError("Use a local preview preference command.", 400);
  const p = partner(command.partner);
  if (typeof command.enabled !== "boolean") throw new LegacyPreviewError("Choose a local preview preference.");
  if (command.enabled) available(p);
  return { partner: p, enabled: command.enabled, permissionKind: "legacy-preview-preference" };
}
function validateLegacyReturnCommand(state, command, curriculum2) {
  exact4(command, ["type", "partner", "enrollmentId"]);
  if (command.type !== "deliver") throw new LegacyPreviewError("Use a local return preview command.", 400);
  const mapping = available(command.partner);
  if (typeof command.enrollmentId !== "string" || !command.enrollmentId) throw new LegacyPreviewError("Choose saved learning for this local preview.", 400);
  if (!state.connections || !Object.hasOwn(state.connections, mapping.partner) || state.connections[mapping.partner] !== true) throw new LegacyPreviewError("Enable this local preview preference before testing a summary.", 403);
  const e = state.enrollments.find((e2) => e2.id === command.enrollmentId);
  if (!e) throw new LegacyPreviewError("Enrollment not found in your learning space.", 404);
  if (e.withdrawn !== false) throw new LegacyPreviewError("Withdrawn learning cannot be used for a local return preview.", 409);
  if (e.programId !== mapping.programId) throw new LegacyPreviewError("Choose the pathway mapped to this ecosystem.", 409);
  const p = curriculum2.pathways.find((p2) => p2.id === mapping.programId);
  if (!p || e.version !== curriculum2.contentVersion) throw new LegacyPreviewError("The pinned learning version is unavailable for this local preview.", 409);
  if (state.paused?.includes(e.programId)) throw new LegacyPreviewError("This pathway is paused for content review. Previous local previews remain available.", 409);
  const allowed = new Set(p.lessons.map((l) => l.id));
  if (!Array.isArray(e.completed) || new Set(e.completed).size !== e.completed.length || e.completed.some((id2) => !allowed.has(id2))) throw new LegacyPreviewError("The saved progress references are unavailable for this local preview.", 409);
  const status = e.record?.status ?? "not-issued";
  if (!["not-issued", "active", "suspended"].includes(status)) throw new LegacyPreviewError("The current practice-record status is unavailable.", 409);
  return { partner: mapping.partner, enrollmentId: e.id, programId: e.programId, contentVersion: e.version, completedLessons: e.completed.length, recordStatus: status, mode: "local-simulation", permissionKind: "legacy-preview-preference" };
}

// lib/academy-engine.ts
var RuleError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
  }
};
function freshWorkspace() {
  return { profile: { name: "Learner", context: "msme", reading: false, networking: false }, enrollments: [], posts: [], reports: [], interests: [], connections: {}, deliveries: [], followups: [], paused: [], seen: [], learningPlan: freshLearningPlan() };
}
var contexts = { farmer: programs[0].id, msme: programs[1].id, public: programs[2].id };
function optionalMinutes(v) {
  if (v === void 0 || v === null || typeof v === "string" && v.trim() === "") return null;
  if (!["number", "string"].includes(typeof v) || !Number.isFinite(Number(v)) || Number(v) < 0 || Number(v) > 1e4) throw new RuleError("Times must be between 0 and 10,000 minutes, or left blank.");
  return Number(v);
}
function text3(v, label2, min = 1, max = 1e4) {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new RuleError(`${label2} needs ${min}\u2013${max} characters.`);
  return v.trim();
}
function checkedContent(fn) {
  try {
    return fn();
  } catch (e) {
    if (e instanceof ContentResolutionError) throw new RuleError(e.message, e.status);
    throw e;
  }
}
function program(id2) {
  return checkedContent(() => resolveCurrentProgram(id2));
}
function pinnedProgram(e, context) {
  return checkedContent(() => resolvePinnedProgram(e, context?.allowedScopes, context?.registry));
}
function planOptions(now, extra = {}, context) {
  return { now, contextPrograms: contexts, resolveProgram: (id2, version, record2) => {
    try {
      return resolvePinnedProgram(record2 ?? { programId: id2, version }, context?.allowedScopes, context?.registry);
    } catch (e) {
      if (e instanceof ContentResolutionError) return void 0;
      throw e;
    }
  }, ...extra };
}
function applyOwnPlan(state, c, options) {
  try {
    return applyLearningPlanCommand(state, c, options);
  } catch (e) {
    if (e instanceof LearningPlanError) throw new RuleError(e.message, e.status);
    throw e;
  }
}
function enrollment(s, id2) {
  const e = s.enrollments.find((e2) => e2.id === id2);
  if (!e) throw new RuleError("Enrollment not found in your learning space.", 404);
  return e;
}
function active(s, e) {
  if (e.withdrawn) throw new RuleError("This enrollment was withdrawn.", 409);
  if (s.paused.includes(e.programId)) throw new RuleError("This pathway is paused for content review. Your work is saved.", 409);
}
function scoreDecision(p, scores, gates) {
  if (!Array.isArray(scores) || scores.length !== p.practicalAssessment.rubric.length || scores.some((n) => !Number.isInteger(n) || n < 0 || n > 4)) throw new RuleError("Score every criterion from 0 to 4.");
  const critical = p.practicalAssessment.rubric.filter((r) => r.criticalGate);
  if (!Array.isArray(gates) || gates.length !== critical.length || gates.some((b) => typeof b !== "boolean")) throw new RuleError("Review every critical safety gate.");
  const score = p.practicalAssessment.rubric.reduce((n, r, i) => n + r.weight * scores[i] / 4, 0);
  return { score, passed: score >= 70 && gates.every(Boolean) };
}
function record(e, p, now) {
  if (!e.record) e.record = { id: crypto.randomUUID(), issuedAt: now, title: p.title, claim: p.credentialClaim, issuer: "Aplyd Academy \xB7 private practice workspace", contentVersion: e.version, kind: "Nonaccredited practice completion", status: "active", share: false };
  else e.record.status = "active";
}
function applyCommand(original, c, now = (/* @__PURE__ */ new Date()).toISOString(), staff, enrollmentContentRef, contentContext) {
  const s = structuredClone(original);
  if (!c || typeof c.type !== "string") throw new RuleError("Choose a valid action.");
  if (isLearningPlanCommand(c)) {
    s.learningPlan = applyOwnPlan(s, c, planOptions(now, {}, contentContext));
    return s;
  }
  switch (c.type) {
    case "profile": {
      const name = text3(c.name, "Display name", 1, 80);
      if (!Object.hasOwn(contexts, c.context) || typeof c.reading !== "boolean" || typeof c.networking !== "boolean") throw new RuleError("Choose a valid work context and preferences.");
      s.profile = { name, context: c.context, reading: c.reading, networking: c.networking };
      break;
    }
    case "enroll": {
      if (Object.keys(c).some((k) => !["type", "programId", "cohortId"].includes(k))) throw new RuleError("This enrollment includes unsupported fields.", 400);
      if (!enrollmentContentRef) program(c.programId);
      const ref = checkedContent(() => enrollmentContentRef ?? currentRef(c.programId));
      if (ref.programId !== c.programId) throw new RuleError("Choose the cohort for this pathway.", 409);
      const p = checkedContent(() => (contentContext?.registry ?? curriculumRegistry).resolve(ref, contentContext?.allowedScopes).program);
      if (s.paused.includes(p.id)) throw new RuleError("New enrollment is paused for this pathway.", 409);
      const existing = s.enrollments.find((e) => e.programId === p.id && !e.withdrawn);
      if (existing) break;
      s.enrollments.push({ id: crypto.randomUUID(), programId: p.id, version: ref.versionId, contentRef: ref, startedAt: now, completed: [], practice: {}, draft: {}, attempts: [], appeals: [], record: null, withdrawn: false });
      break;
    }
    case "lesson-draft": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext);
      if (!p.lessons.some((l) => l.id === c.lessonId)) throw new RuleError("Lesson not found.", 404);
      if (typeof c.practice !== "string" || c.practice.length > 1e4 || !Array.isArray(c.answers) || c.answers.length !== 3 || c.answers.some((a) => a !== null && (!Number.isInteger(a) || a < 0 || a > 3))) throw new RuleError("Invalid practice draft.");
      e.lessonDrafts ??= {};
      e.lessonDrafts[c.lessonId] = { practice: c.practice, answers: c.answers };
      break;
    }
    case "lesson": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext), lesson = p.lessons.find((l) => l.id === c.lessonId);
      if (!lesson) throw new RuleError("Lesson not found.", 404);
      const index = p.lessons.findIndex((l) => l.id === lesson.id);
      if (index > 0 && !e.completed.includes(p.lessons[index - 1].id)) throw new RuleError("Complete the previous lesson first.");
      if (!Array.isArray(c.answers) || c.answers.length !== lesson.quiz.length || c.answers.some((a, i) => a !== lesson.quiz[i].correctOptionIndex)) throw new RuleError("Check each answer using the source packet, then try again.");
      e.practice[lesson.id] = { answer: text3(c.practice, "Practice response", 30, 1e4), completedAt: now };
      if (!e.completed.includes(lesson.id)) e.completed.push(lesson.id);
      break;
    }
    case "draft": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext);
      if (!c.fields || typeof c.fields !== "object") throw new RuleError("Draft fields are required.");
      const draft = { ...e.draft };
      const allowed = p.practicalAssessment.submissionPrompts.map((f) => f.id);
      if (Object.keys(c.fields).some((k) => !allowed.includes(k))) throw new RuleError("Unknown draft field.");
      for (const [key, value] of Object.entries(c.fields)) {
        if (typeof value !== "string" || value.length > 1e4) throw new RuleError("Draft responses must be text of at most 10,000 characters.");
        draft[key] = value;
      }
      e.draft = draft;
      break;
    }
    case "submit": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext);
      if (e.completed.length !== p.lessons.length) throw new RuleError("Complete all lessons before submitting.");
      if (e.attempts.some((a) => !a.decision)) throw new RuleError("Your current attempt is awaiting review.", 409);
      if (e.appeals.some((a) => a.status === "open")) throw new RuleError("Wait for your open appeal before a new attempt.", 409);
      if (e.record?.status === "active") throw new RuleError("This pathway is already complete.", 409);
      if (e.attempts.length >= 3) throw new RuleError("The private pilot allows three attempts. Ask for support before continuing.", 409);
      if (c.confirmed !== true) throw new RuleError("Confirm that this evidence uses only fictional or permitted information.");
      const fields = {};
      for (const f of p.practicalAssessment.submissionPrompts) fields[f.id] = text3(c.fields?.[f.id], f.label, 30);
      e.draft = fields;
      e.attempts.push({ id: crypto.randomUUID(), number: e.attempts.length + 1, fields: structuredClone(fields), submittedAt: now, assisted: !!c.assisted, decision: null });
      break;
    }
    case "assess": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext), a = e.attempts.find((a2) => a2.id === c.attemptId);
      if (!a) throw new RuleError("Submission not found.", 404);
      if (a.decision) throw new RuleError("This attempt has already been reviewed.", 409);
      if (!staff && c.actor !== "assessor-a") throw new RuleError("Use the assigned sample assessor.", 403);
      const notes = p.practicalAssessment.rubric.map((r, i) => text3(c.notes?.[i], r.dimension + " evidence reference", 10, 3e3));
      const result = scoreDecision(p, c.scores, c.gates);
      a.decision = { id: crypto.randomUUID(), ...result, scores: c.scores, gates: c.gates, notes, feedback: text3(c.feedback, "Actionable feedback", 30, 3e3), actor: staff?.userId ?? c.actor, actorName: staff?.name, decidedAt: now, mode: staff ? "authenticated assigned assessment" : "manual sample-assessor review" };
      if (result.passed) record(e, p, now);
      break;
    }
    case "appeal": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const a = e.attempts.find((a2) => a2.id === c.attemptId);
      if (!a?.decision) throw new RuleError("Appeals need an assessment decision.", 409);
      if (e.appeals.some((x) => x.attemptId === a.id)) throw new RuleError("An appeal already exists for this decision.", 409);
      if (Date.parse(now) - Date.parse(a.decision.decidedAt) > 14 * 864e5) throw new RuleError("The 14-day appeal window has ended.", 409);
      if (a.id !== e.attempts.at(-1).id) throw new RuleError("Appeal the latest attempt before starting a retry.", 409);
      e.appeals.push({ id: crypto.randomUUID(), attemptId: a.id, reason: text3(c.reason, "Appeal reason", 30, 3e3), status: "open", createdAt: now });
      break;
    }
    case "resolve": {
      const e = enrollment(s, c.enrollmentId);
      active(s, e);
      const p = pinnedProgram(e, contentContext), appeal = e.appeals.find((a2) => a2.id === c.appealId);
      if (!appeal || appeal.status !== "open") throw new RuleError("No open appeal found.", 409);
      const a = e.attempts.find((a2) => a2.id === appeal.attemptId), actor = staff?.userId ?? c.actor;
      if (!staff && c.actor !== "reviewer-b" || actor === a.decision.actor) throw new RuleError("An independent reviewer must resolve the appeal.", 403);
      const notes = p.practicalAssessment.rubric.map((r, i) => text3(c.notes?.[i], r.dimension + " evidence reference", 10, 3e3));
      const result = scoreDecision(p, c.scores, c.gates);
      appeal.status = "resolved";
      appeal.resolution = { id: crypto.randomUUID(), ...result, scores: c.scores, gates: c.gates, notes, actor, actorName: staff?.name, mode: staff ? "authenticated independent appeal" : "manual sample-reviewer appeal", feedback: text3(c.feedback, "Review explanation", 30, 3e3), decidedAt: now };
      if (result.passed) record(e, p, now);
      else if (e.record) e.record.status = "suspended";
      break;
    }
    case "share": {
      const e = enrollment(s, c.enrollmentId);
      if (!e.record) throw new RuleError("No record to share.", 404);
      if (typeof c.enabled !== "boolean") throw new RuleError("Sharing choice is required.");
      e.record.share = c.enabled;
      break;
    }
    case "withdraw": {
      const e = enrollment(s, c.enrollmentId);
      if (e.record) throw new RuleError("Completed learning cannot be withdrawn.", 409);
      if (e.attempts.some((a) => !a.decision) || e.appeals.some((a) => a.status === "open")) throw new RuleError("Wait for the active review before withdrawing.", 409);
      e.withdrawn = true;
      break;
    }
    case "post": {
      if (s.posts.length >= 200) throw new RuleError("This private pilot has reached its discussion limit.", 409);
      const scope = c.scope || "all";
      if (scope !== "all" && !programs.some((p) => p.id === scope)) throw new RuleError("Choose an existing learning circle.");
      s.posts.unshift({ id: crypto.randomUUID(), scope, title: text3(c.title, "Discussion title", 5, 140), body: text3(c.body, "Discussion", 20, 3e3), author: s.profile.name, createdAt: now, status: "pending", replies: [] });
      break;
    }
    case "reply": {
      const p = s.posts.find((p2) => p2.id === c.postId && p2.status === "visible");
      if (!p) throw new RuleError("This discussion is not available.", 404);
      if (p.replies.length >= 50) throw new RuleError("Reply limit reached.");
      p.replies.push({ id: crypto.randomUUID(), body: text3(c.body, "Reply", 10, 1500), author: s.profile.name, createdAt: now, status: "pending" });
      break;
    }
    case "report": {
      const p = s.posts.find((p2) => p2.id === c.postId && p2.status === "visible");
      if (!p) throw new RuleError("Discussion not found.", 404);
      s.reports.push({ id: crypto.randomUUID(), postId: p.id, reason: text3(c.reason, "Report reason", 10, 1e3), status: "open", createdAt: now });
      break;
    }
    case "moderate": {
      const p = s.posts.find((p2) => p2.id === c.postId);
      if (!p) throw new RuleError("Discussion not found.", 404);
      if (!["visible", "hidden"].includes(c.status)) throw new RuleError("Choose publish or hide.");
      if (c.replyId) {
        const r = p.replies.find((r2) => r2.id === c.replyId);
        if (!r) throw new RuleError("Reply not found.", 404);
        r.status = c.status;
      } else p.status = c.status;
      if (!c.replyId) for (const r of s.reports.filter((r2) => r2.postId === p.id)) r.status = "resolved";
      break;
    }
    case "interest": {
      if (!["peer-circle", "practice-clinic", "mentor-hour"].includes(c.opportunityId)) throw new RuleError("Opportunity not found.", 404);
      if (typeof c.enabled !== "boolean") throw new RuleError("Choose an interest setting.");
      s.interests = s.interests.filter((x) => x !== c.opportunityId);
      if (c.enabled) s.interests.push(c.opportunityId);
      break;
    }
    case "connection": {
      let choice;
      try {
        choice = validateLegacyConnectionCommand(c);
      } catch (e) {
        if (e instanceof LegacyPreviewError) throw new RuleError(e.message, e.status);
        throw e;
      }
      s.connections[choice.partner] = choice.enabled;
      if (!choice.enabled) s.deliveries = s.deliveries.map((d) => d.partner === choice.partner && d.status === "queued" ? { ...d, status: "cancelled" } : d);
      break;
    }
    case "deliver": {
      const own = enrollment(s, c.enrollmentId);
      pinnedProgram(own, contentContext);
      let summary;
      try {
        summary = validateLegacyReturnCommand(s, c, { contentVersion: CONTENT_VERSION, pathways: programs });
      } catch (e) {
        if (e instanceof LegacyPreviewError) throw new RuleError(e.message, e.status);
        throw e;
      }
      if (s.deliveries.length >= 100) throw new RuleError("Connection test limit reached.");
      s.deliveries.unshift({ id: crypto.randomUUID(), partner: summary.partner, enrollmentId: summary.enrollmentId, revision: s.deliveries.filter((d) => d.enrollmentId === summary.enrollmentId).length + 1, status: "simulated", createdAt: now, payload: { learner_ref: summary.enrollmentId, pathway: summary.programId, completedLessons: summary.completedLessons, recordStatus: summary.recordStatus }, note: "Local mapping preview. No scoped grant, external connection or send was created." });
      break;
    }
    case "followup": {
      const minutesBefore = optionalMinutes(c.before), minutesAfter = optionalMinutes(c.after), e = enrollment(s, c.enrollmentId);
      if (e.record?.status !== "active") throw new RuleError("Finish the practical review before logging a work reflection.");
      s.followups.unshift({ id: crypto.randomUUID(), enrollmentId: e.id, reflection: text3(c.reflection, "Reflection", 30, 3e3), minutesBefore, minutesAfter, createdAt: now });
      break;
    }
    case "pause": {
      program(c.programId);
      if (typeof c.paused !== "boolean") throw new RuleError("Choose a content state.");
      s.paused = s.paused.filter((x) => x !== c.programId);
      if (c.paused) s.paused.push(c.programId);
      break;
    }
    case "reset":
      return freshWorkspace();
    default:
      throw new RuleError("Unknown Academy action.");
  }
  if (staff) {
    for (const e of s.enrollments) if (e.id === c.enrollmentId && e.record) {
      e.record.issuer = staff.workspaceName + " \xB7 Aplyd Academy";
      e.record.kind = "Reviewed practice record \xB7 draft learning content, nonaccredited";
      e.record.workspaceId = staff.workspaceId;
      const latest = e.attempts.at(-1), decision = e.appeals.find((ap) => ap.attemptId === latest?.id)?.resolution ?? latest?.decision;
      e.record.reviewedBy = decision?.actorName;
      e.record.decisionId = decision?.id;
      e.record.lastReviewedAt = decision?.decidedAt;
    }
  }
  return s;
}

// lib/academy-network.ts
var NETWORK_FOCUS = ["Checking AI drafts", "Work records", "Customer operations", "Source-based briefs", "Careful information handling"];
var text4 = (v, label2, min, max) => {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new RuleError(`${label2} needs ${min}\u2013${max} characters.`);
  return v.trim();
};
var exact5 = (c, keys) => {
  if (Object.keys(c).some((k) => !["type", ...keys].includes(k))) throw new RuleError("This request includes unsupported fields.", 400);
};
var network = (t) => t.network ?? { profiles: [], sessions: [] };
var canHost = (m, cid) => m.active && (m.roles.includes("admin") || m.roles.includes("facilitator") && m.scopes.includes(cid));
var eligible = (t, id2, cid, access) => {
  const m = t.members.find((x) => x.userId === id2);
  return !!m && access(t, m, cid);
};
var currentSeats = (t, s, access) => s.registrations.filter((r) => r.status === "going" && eligible(t, r.userId, s.cohortId, access));
function reconcileNetworkAccess(t, now, access) {
  if (!t.network) return;
  for (const p of t.network.profiles) {
    const remaining = p.cohortIds.filter((id2) => eligible(t, p.userId, id2, access));
    if (remaining.length !== p.cohortIds.length) {
      p.cohortIds = remaining;
      p.updatedAt = now;
      if (!remaining.length) {
        p.enabled = false;
        p.accessRevokedAt = now;
      }
    }
  }
  for (const session2 of t.network.sessions) if (Date.parse(session2.startsAt) > Date.parse(now)) {
    for (const r of session2.registrations) if (r.status === "going" && !eligible(t, r.userId, session2.cohortId, access)) Object.assign(r, { status: "cancelled", cancelledAt: now, updatedAt: now, cancellationReason: "Cohort access ended. Reserve again after access returns." });
  }
}
function session(t, m, id2, access) {
  const s = network(t).sessions.find((s2) => s2.id === id2);
  if (!s || !access(t, m, s.cohortId)) throw new RuleError("Session not found for your cohort.", 404);
  return s;
}
function hosted(s, m) {
  if (s.hostId !== m.userId || !canHost(m, s.cohortId)) throw new RuleError("Only the current scoped session host can do this.", 403);
}
function time(v, label2) {
  if (typeof v !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/.test(v) || !Number.isFinite(Date.parse(v)) || new Date(v).toISOString() !== v.replace(/:([0-9]{2})Z$/, ":$1.000Z")) throw new RuleError(`${label2} needs a valid UTC date and time.`);
  return Date.parse(v);
}
function applyNetworkCommand(t, m, c, now, access) {
  t.network ??= { profiles: [], sessions: [] };
  const n = t.network;
  switch (c.type) {
    case "network-profile": {
      exact5(c, ["enabled", "bio", "focus", "cohortIds"]);
      if (typeof c.enabled !== "boolean") throw new RuleError("Choose a directory sharing setting.");
      let p = n.profiles.find((p2) => p2.userId === m.userId);
      if (!c.enabled) {
        if (p) {
          p.enabled = false;
          p.updatedAt = now;
        }
        break;
      }
      if (!Array.isArray(c.cohortIds) || !c.cohortIds.length || c.cohortIds.length > 5 || new Set(c.cohortIds).size !== c.cohortIds.length || c.cohortIds.some((id2) => !t.cohorts.some((x) => x.id === id2) || !access(t, m, id2))) throw new RuleError("Choose up to five cohorts you can currently access.", 403);
      if (!NETWORK_FOCUS.includes(c.focus)) throw new RuleError("Choose a learning focus.");
      const bio = text4(c.bio, "Profile introduction", 10, 300);
      if (!p) {
        p = { id: crypto.randomUUID(), userId: m.userId };
        n.profiles.push(p);
      }
      Object.assign(p, { enabled: true, bio, focus: c.focus, cohortIds: c.cohortIds, consentVersion: "cohort-directory-1", consentedAt: now, updatedAt: now });
      break;
    }
    case "session-create": {
      exact5(c, ["cohortId", "title", "description", "startsAt", "endsAt", "capacity", "instructions"]);
      const co = t.cohorts.find((x) => x.id === c.cohortId);
      if (!co || !access(t, m, co.id)) throw new RuleError("Cohort not found.", 404);
      if (!canHost(m, co.id)) throw new RuleError("A workspace owner or scoped facilitator must host sessions.", 403);
      if (co.status === "paused") throw new RuleError("This cohort is paused.", 409);
      if (n.sessions.length >= 100) throw new RuleError("This pilot supports 100 sessions per workspace.", 409);
      const start = time(c.startsAt, "Start"), end = time(c.endsAt, "End"), clock = Date.parse(now);
      if (start <= clock || start > clock + 180 * 864e5 || end <= start || end - start > 180 * 6e4) throw new RuleError("Schedule a future session within 180 days, lasting up to three hours.");
      if (!Number.isInteger(c.capacity) || c.capacity < 1 || c.capacity > 100) throw new RuleError("Set a session capacity between 1 and 100.");
      n.sessions.push({ id: crypto.randomUUID(), cohortId: co.id, hostId: m.userId, title: text4(c.title, "Session title", 5, 120), description: text4(c.description, "Session purpose", 20, 1e3), instructions: text4(c.instructions, "Joining instructions", 10, 2e3), startsAt: new Date(start).toISOString(), endsAt: new Date(end).toISOString(), capacity: c.capacity, status: "scheduled", createdAt: now, registrations: [], attendance: [] });
      break;
    }
    case "session-rsvp": {
      exact5(c, ["sessionId", "going"]);
      if (typeof c.going !== "boolean") throw new RuleError("Choose an attendance preference.");
      const s = session(t, m, c.sessionId, access);
      let r = s.registrations.find((r2) => r2.userId === m.userId);
      if (!c.going) {
        if (r && r.status === "going") {
          r.status = "cancelled";
          r.cancelledAt = now;
          r.updatedAt = now;
        }
        break;
      }
      if (s.status !== "scheduled" || Date.parse(s.startsAt) <= Date.parse(now)) throw new RuleError("This session is no longer accepting places.", 409);
      if (t.cohorts.find((x) => x.id === s.cohortId)?.status === "paused") throw new RuleError("This cohort is paused.", 409);
      if (!eligible(t, s.hostId, s.cohortId, access) || !canHost(t.members.find((x) => x.userId === s.hostId), s.cohortId)) throw new RuleError("The host no longer has access. Ask the workspace owner to arrange another session.", 409);
      if (r?.status === "going") break;
      if (currentSeats(t, s, access).length >= s.capacity) throw new RuleError("This session is full. Choose another session or check again after a cancellation.", 409);
      if (!r) {
        r = { id: crypto.randomUUID(), userId: m.userId, createdAt: now };
        s.registrations.push(r);
      }
      Object.assign(r, { status: "going", confirmedAt: now, cancelledAt: null, updatedAt: now });
      break;
    }
    case "session-cancel": {
      exact5(c, ["sessionId", "reason"]);
      const s = session(t, m, c.sessionId, access);
      if (!(m.roles.includes("admin") && m.active)) hosted(s, m);
      if (s.status === "cancelled" || Date.parse(s.endsAt) <= Date.parse(now)) throw new RuleError("This session is cancelled or has ended.", 409);
      s.status = "cancelled";
      s.cancellation = { reason: text4(c.reason, "Cancellation reason", 10, 1e3), actor: m.userId, actorName: m.name, createdAt: now };
      break;
    }
    case "session-attendance": {
      exact5(c, ["sessionId", "registrationId", "status", "reason"]);
      const s = session(t, m, c.sessionId, access);
      hosted(s, m);
      if (s.status !== "scheduled") throw new RuleError("Cancelled sessions cannot record attendance.", 409);
      const clock = Date.parse(now);
      if (clock < Date.parse(s.startsAt) || clock > Date.parse(s.endsAt) + 7 * 864e5) throw new RuleError("Record attendance from the start until seven days after the session.");
      const r = s.registrations.find((r2) => r2.id === c.registrationId && Date.parse(r2.confirmedAt ?? r2.createdAt) <= Date.parse(s.startsAt) && (!r2.cancelledAt || Date.parse(r2.cancelledAt) > Date.parse(s.startsAt)));
      if (!r || !eligible(t, r.userId, s.cohortId, access)) throw new RuleError("Eligible registration at the session start not found.", 404);
      if (!["attended", "absent"].includes(c.status)) throw new RuleError("Choose attended or absent.");
      if (s.attendance.length >= 300) throw new RuleError("This session reached its attendance history limit.", 409);
      s.attendance.push({ id: crypto.randomUUID(), registrationId: r.id, status: c.status, reason: text4(c.reason, "Attendance basis", 10, 500), actor: m.userId, actorName: m.name, createdAt: now });
      break;
    }
    default:
      return false;
  }
  return true;
}
function projectNetwork(t, m, access) {
  const n = network(t), self = n.profiles.find((p) => p.userId === m.userId), myProfile = self ? { enabled: self.enabled, bio: self.bio, focus: self.focus, cohortIds: self.cohortIds ?? [], consentedAt: self.consentedAt } : null;
  const history = n.sessions.flatMap((session2) => {
    const r = session2.registrations.find((x) => x.userId === m.userId);
    return r ? [{ id: session2.id, title: session2.title, cohortTitle: t.cohorts.find((x) => x.id === session2.cohortId)?.title, startsAt: session2.startsAt, endsAt: session2.endsAt, status: session2.status, myRsvp: r.status, cancellationReason: session2.cancellation?.reason ?? r.cancellationReason ?? null, attendance: session2.attendance.filter((a) => a.registrationId === r.id).map((a) => ({ id: a.id, status: a.status, reason: a.reason, actorName: a.actorName, createdAt: a.createdAt })) }] : [];
  });
  if (!m.active) return { myProfile, history, directory: [], sessions: [] };
  const directory = n.profiles.filter((p) => p.enabled && p.cohortIds.some((id2) => access(t, m, id2) && eligible(t, p.userId, id2, access))).map((p) => ({ id: p.id, name: t.members.find((x) => x.userId === p.userId)?.name, bio: p.bio, focus: p.focus, cohortIds: p.cohortIds.filter((id2) => access(t, m, id2) && eligible(t, p.userId, id2, access)), isMe: p.userId === m.userId }));
  const sessions = n.sessions.filter((s) => access(t, m, s.cohortId)).map((s) => {
    const own = s.registrations.find((r) => r.userId === m.userId), host = s.hostId === m.userId && canHost(m, s.cohortId), seats2 = currentSeats(t, s, access), roster = s.registrations.filter((r) => eligible(t, r.userId, s.cohortId, access) && (r.status === "going" || r.cancelledAt && Date.parse(r.cancelledAt) > Date.parse(s.startsAt) && Date.parse(r.confirmedAt ?? r.createdAt) <= Date.parse(s.startsAt))), validHost = eligible(t, s.hostId, s.cohortId, access) && canHost(t.members.find((x) => x.userId === s.hostId), s.cohortId);
    const current = (rid) => {
      const a = s.attendance.filter((a2) => a2.registrationId === rid).at(-1);
      if (!a) return null;
      const { actor, ...safe } = a;
      return safe;
    };
    return { id: s.id, cohortId: s.cohortId, title: s.title, description: s.description, startsAt: s.startsAt, endsAt: s.endsAt, capacity: s.capacity, occupied: seats2.length, status: s.status, hostName: t.members.find((x) => x.userId === s.hostId)?.name, hostAvailable: validHost, isHost: host, canCancel: host || m.roles.includes("admin"), myRsvp: own?.status ?? "none", myAttendance: own ? current(own.id) : null, ...s.cancellation ? { cancellation: { reason: s.cancellation.reason, createdAt: s.cancellation.createdAt } } : {}, ...s.status === "scheduled" && validHost && (host || own?.status === "going") ? { instructions: s.instructions } : {}, ...host ? { registrations: roster.map((r) => ({ id: r.id, name: t.members.find((x) => x.userId === r.userId)?.name, attendance: current(r.id) ?? null })), attendanceHistory: s.attendance.map(({ actor, ...a }) => a) } : {} };
  });
  return { myProfile, history, directory, sessions };
}

// lib/academy-teams.ts
var TEAM_ROLES = ["admin", "learner", "facilitator", "assessor", "reviewer", "moderator"];
var copy2 = (x) => structuredClone(x);
var label = (u) => u.fullName || "Academy member";
function txt(v, name, min = 1, max = 200) {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new RuleError(`${name} needs ${min}\u2013${max} characters.`);
  return v.trim();
}
var normalizeEmail = (v) => v.trim().toLowerCase();
function email(v) {
  const x = txt(v, "Recipient email", 3, 254);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x)) throw new RuleError("Enter a valid account email.");
  return normalizeEmail(x);
}
function member3(t, userId, active2 = true) {
  const m = t.members.find((m2) => m2.userId === userId);
  if (!m) throw new RuleError("Workspace not found for your account.", 404);
  if (active2 && !m.active) throw new RuleError("Your workspace access has been removed. Your own learning history remains readable.", 403);
  return m;
}
function requireRole(m, role, cohortId) {
  if (!m.roles.includes(role) || cohortId && !m.scopes.includes(cohortId)) throw new RuleError("Your current membership does not permit this action.", 403);
}
function roles(v) {
  if (!Array.isArray(v) || !v.length || v.length > TEAM_ROLES.length || new Set(v).size !== v.length || v.some((r) => !TEAM_ROLES.includes(r))) throw new RuleError("Choose existing workspace roles.");
  return v;
}
function scopes(t, v) {
  if (!Array.isArray(v) || new Set(v).size !== v.length || v.some((id2) => !t.cohorts.some((c) => c.id === id2))) throw new RuleError("Choose existing cohorts for staff access.");
  return v;
}
function exact6(c, keys) {
  if (Object.keys(c).some((k) => !["type", ...keys].includes(k))) throw new RuleError("This request includes unsupported fields.", 400);
}
function cohort(t, id2) {
  const c = t.cohorts.find((c2) => c2.id === id2);
  if (!c) throw new RuleError("Cohort not found.", 404);
  return c;
}
function learner(t, u) {
  let l = t.learners.find((l2) => l2.userId === u.userId);
  if (!l) {
    const state = freshWorkspace();
    state.profile.name = label(u);
    state.profile.context = t.context;
    l = { userId: u.userId, state };
    t.learners.push(l);
  }
  return l;
}
function target(t, userId, enrollmentId) {
  const l = t.learners.find((l2) => l2.userId === userId), e = l?.state.enrollments.find((e2) => e2.id === enrollmentId);
  if (!l || !e) throw new RuleError("Enrollment not found in this workspace.", 404);
  return { l, e, c: cohort(t, e.cohortId) };
}
function boardAccess(t, m, cid) {
  return m.active && (m.roles.includes("admin") || m.scopes.includes(cid) && m.roles.some((r) => ["facilitator", "assessor", "reviewer", "moderator"].includes(r)) || m.roles.includes("learner") && t.learners.find((l) => l.userId === m.userId)?.state.enrollments.some((e) => e.cohortId === cid && !e.withdrawn));
}
function seats(t, cid) {
  return t.learners.reduce((n, l) => n + l.state.enrollments.filter((e) => e.cohortId === cid && !e.withdrawn).length, 0);
}
function pending(t) {
  return t.learners.flatMap((l) => l.state.enrollments.flatMap((e) => [
    ...e.attempts.filter((a) => !a.decision && !e.withdrawn).map((a) => ({ kind: "assessment", targetId: a.id, enrollmentId: e.id, learnerId: l.userId, cohortId: e.cohortId, programId: e.programId, number: a.number, createdAt: a.submittedAt })),
    ...e.appeals.filter((ap) => ap.status === "open" && !e.withdrawn).map((ap) => ({ kind: "appeal", targetId: ap.id, enrollmentId: e.id, learnerId: l.userId, cohortId: e.cohortId, programId: e.programId, createdAt: ap.createdAt, originalActor: e.attempts.find((a) => a.id === ap.attemptId)?.decision?.actor }))
  ]));
}
function eligible2(t, m, q) {
  return m?.active && m.userId !== q.learnerId && m.userId !== q.originalActor && m.roles.includes(q.kind === "appeal" ? "reviewer" : "assessor") && m.scopes.includes(q.cohortId);
}
function createTeam(u, c, id2, now = (/* @__PURE__ */ new Date()).toISOString()) {
  exact6(c, ["name", "purpose", "context"]);
  if (!Object.hasOwn(contexts, c.context)) throw new RuleError("Choose a work context.");
  return { id: id2, name: txt(c.name, "Workspace name", 3, 80), purpose: txt(c.purpose, "Workspace purpose", 10, 500), context: c.context, createdAt: now, createdBy: u.userId, members: [{ userId: u.userId, email: normalizeEmail(u.email), name: label(u), roles: ["admin", "learner"], scopes: [], active: true, joinedAt: now }], invites: [], cohorts: [], learners: [], assignments: [], posts: [], reports: [], moderation: [], activity: [] };
}
function invitation(t, hash, u, now = (/* @__PURE__ */ new Date()).toISOString()) {
  const i = t.invites.find((i2) => i2.tokenHash === hash);
  if (!i || i.email !== normalizeEmail(u.email)) throw new RuleError("This invitation is unavailable for your signed-in account.", 404);
  if (i.status === "accepted" && i.acceptedBy === u.userId) {
    member3(t, u.userId);
    return i;
  }
  if (!t.members.some((m2) => m2.userId === i.createdBy && m2.active && m2.roles.includes("admin"))) throw new RuleError("This invitation issuer no longer has workspace authority. Ask a current owner for a new link.", 409);
  if (i.status !== "active" || Date.parse(i.expiresAt) <= Date.parse(now)) throw new RuleError("This invitation expired or was revoked. Ask the workspace owner for a new link.", 409);
  const m = t.members.find((m2) => m2.userId === u.userId);
  if (m && !m.active) throw new RuleError("An invitation cannot restore removed access. Ask a workspace owner to restore your membership.", 403);
  return i;
}
function finishAccess(t, now) {
  reconcileNetworkAccess(t, now, boardAccess);
  reconcileSupportAssignments(t);
  return t;
}
function applyTeamCommand(original, u, c, now = (/* @__PURE__ */ new Date()).toISOString()) {
  const t = copy2(original);
  if (!c || typeof c.type !== "string") throw new RuleError("Choose a valid workspace action.", 400);
  if (c.type === "accept") {
    exact6(c, ["tokenHash"]);
    const i = invitation(t, c.tokenHash, u, now);
    if (i.status === "accepted") return finishAccess(t, now);
    if (t.members.length >= 100 && !t.members.some((m2) => m2.userId === u.userId)) throw new RuleError("This pilot workspace supports up to 100 members.", 409);
    if (!t.members.some((m2) => m2.userId === u.userId)) t.members.push({ userId: u.userId, email: normalizeEmail(u.email), name: label(u), roles: i.roles, scopes: i.scopes, active: true, joinedAt: now });
    i.status = "accepted";
    i.acceptedBy = u.userId;
    i.acceptedAt = now;
    return finishAccess(t, now);
  }
  const m = member3(t, u.userId);
  if (isContentCommand(c)) return applyWorkspaceContentCommand(t, u, c, now).then((next) => {
    finishAccess(next, now);
    next.activity ??= [];
    if (!["content-retire", "content-archive"].includes(c.type)) next.activity.push({ id: crypto.randomUUID(), actor: u.userId, actorName: String(m.name || "Workspace owner").slice(0, 80), action: c.type, createdAt: new Date(now).toISOString(), detail: { draftId: c.draftId, publicationId: c.publicationId } });
    return next;
  }).catch((error) => {
    if (error instanceof AuthoringError) throw new RuleError(error.message, error.status);
    throw error;
  });
  let registryContext;
  const contentContext = () => registryContext ??= { registry: workspaceRegistry(t), allowedScopes: ["global", t.id] };
  if (isLearningPlanCommand(c)) {
    const l = learner(t, u);
    l.state.learningPlan = applyOwnPlan(l.state, c, planOptions(now, { memberActive: m.active, canLearn: m.roles.includes("learner"), cohorts: t.cohorts }, contentContext()));
    return finishAccess(t, now);
  }
  if (applyNetworkCommand(t, m, c, now, boardAccess)) return finishAccess(t, now);
  try {
    if (applySupportCommand(t, u.userId, c, now)) return finishAccess(t, now);
  } catch (e) {
    if (e instanceof SupportRuleError) throw new RuleError(e.message, e.status);
    throw e;
  }
  switch (c.type) {
    case "invite": {
      requireRole(m, "admin");
      exact6(c, ["email", "roles", "scopes", "tokenHash"]);
      if (t.invites.length >= 200) throw new RuleError("Invitation limit reached for this pilot.", 409);
      const recipient = email(c.email), r = roles(c.roles), s = scopes(t, c.scopes);
      if (t.members.some((m2) => m2.active && m2.email === recipient)) throw new RuleError("This account is already a member. Use membership settings to change its roles.", 409);
      if (t.invites.some((i) => i.email === recipient && i.status === "active" && Date.parse(i.expiresAt) > Date.parse(now))) throw new RuleError("An active invitation already exists. Revoke it before creating a replacement.", 409);
      if (typeof c.tokenHash !== "string" || !/^[a-f0-9]{64}$/.test(c.tokenHash)) throw new RuleError("A secure invitation token is required.");
      if (t.invites.some((i) => i.tokenHash === c.tokenHash)) throw new RuleError("This invitation token was already used. Generate a new link.", 409);
      t.invites.push({ id: crypto.randomUUID(), email: recipient, roles: r, scopes: s, tokenHash: c.tokenHash, status: "active", createdBy: u.userId, createdAt: now, expiresAt: new Date(Date.parse(now) + 7 * 864e5).toISOString() });
      break;
    }
    case "revoke-invite": {
      requireRole(m, "admin");
      exact6(c, ["inviteId"]);
      const i = t.invites.find((i2) => i2.id === c.inviteId);
      if (!i) throw new RuleError("Invitation not found.", 404);
      if (i.status !== "active") throw new RuleError("This invitation is no longer active.", 409);
      i.status = "revoked";
      break;
    }
    case "member": {
      requireRole(m, "admin");
      exact6(c, ["userId", "roles", "scopes", "active"]);
      const target2 = member3(t, c.userId, false), r = roles(c.roles), s = scopes(t, c.scopes);
      if (typeof c.active !== "boolean") throw new RuleError("Choose an access state.");
      if (target2.active && target2.roles.includes("admin") && (!c.active || !r.includes("admin")) && t.members.filter((x) => x.active && x.roles.includes("admin")).length === 1) throw new RuleError("Keep at least one active workspace owner.", 409);
      Object.assign(target2, { roles: r, scopes: s, active: c.active });
      if (!target2.active || !target2.roles.includes("admin")) for (const i of t.invites.filter((i2) => i2.createdBy === target2.userId && i2.status === "active")) i.status = "revoked";
      t.assignments = t.assignments.filter((a) => {
        const q = pending(t).find((q2) => q2.targetId === a.targetId && q2.kind === a.kind);
        return !q || eligible2(t, t.members.find((x) => x.userId === a.staffId), q);
      });
      break;
    }
    case "cohort-create": {
      requireRole(m, "admin");
      exact6(c, ["title", "programId", "capacity", "contentRef"]);
      let ref, snapshot;
      try {
        ref = c.contentRef ?? currentRef(c.programId);
        if (ref.programId !== c.programId) throw new RuleError("Choose the matching publication reference.", 409);
        snapshot = requireAvailablePublication(t, ref, now);
      } catch (e) {
        if (e instanceof AuthoringError || e instanceof ContentResolutionError) throw new RuleError(e.message, e.status);
        throw e;
      }
      const p = snapshot.program;
      if (!Number.isInteger(c.capacity) || c.capacity < 1 || c.capacity > 100) throw new RuleError("Set a capacity between 1 and 100.");
      if (t.cohorts.length >= 20) throw new RuleError("This pilot supports 20 cohorts per workspace.", 409);
      t.cohorts.push({ id: crypto.randomUUID(), title: txt(c.title, "Cohort name", 3, 100), programId: p.id, version: ref.versionId, contentRef: ref, capacity: c.capacity, status: "open", createdAt: now });
      break;
    }
    case "cohort-status": {
      requireRole(m, "admin");
      exact6(c, ["cohortId", "status"]);
      const x = cohort(t, c.cohortId);
      if (!["open", "paused", "closed"].includes(c.status)) throw new RuleError("Choose an existing cohort state.");
      x.status = c.status;
      break;
    }
    case "assign": {
      requireRole(m, "admin");
      exact6(c, ["kind", "targetId", "staffId"]);
      const q = pending(t).find((q2) => q2.kind === c.kind && q2.targetId === c.targetId);
      if (!q) throw new RuleError("Pending review not found.", 404);
      const staff = member3(t, c.staffId);
      if (!eligible2(t, staff, q)) throw new RuleError("Assign a scoped staff member who is independent of the learner and original assessor.", 403);
      t.assignments = t.assignments.filter((a) => !(a.kind === q.kind && a.targetId === q.targetId));
      t.assignments.push({ id: crypto.randomUUID(), kind: q.kind, targetId: q.targetId, staffId: staff.userId, assignedBy: u.userId, assignedAt: now });
      break;
    }
    case "assess":
    case "resolve": {
      exact6(c, ["enrollmentId", "learnerId", "attemptId", "appealId", "scores", "gates", "notes", "feedback"]);
      const { l, e, c: co } = target(t, c.learnerId, c.enrollmentId), kind = c.type === "resolve" ? "appeal" : "assessment", targetId = c.type === "resolve" ? c.appealId : c.attemptId, q = pending(t).find((q2) => q2.kind === kind && q2.targetId === targetId && q2.enrollmentId === e.id && q2.learnerId === l.userId);
      if (u.userId === l.userId) throw new RuleError("A learner cannot assess or resolve their own evidence.", 403);
      if (c.type === "resolve" && e.attempts.find((a) => a.id === e.appeals.find((ap) => ap.id === c.appealId)?.attemptId)?.decision?.actor === u.userId) throw new RuleError("The original assessor cannot resolve this appeal.", 403);
      if (!q || !t.assignments.some((a) => a.kind === kind && a.targetId === targetId && a.staffId === u.userId)) throw new RuleError("This review is not assigned to your account.", 404);
      if (!eligible2(t, m, q)) throw new RuleError("Your current scoped role does not permit this review.", 403);
      if (co.status === "paused") throw new RuleError("This cohort is paused for content review.", 409);
      l.state = applyCommand(l.state, c, now, { userId: u.userId, name: m.name, workspaceId: t.id, workspaceName: t.name }, void 0, contentContext());
      break;
    }
    case "post": {
      exact6(c, ["cohortId", "title", "body"]);
      const co = cohort(t, c.cohortId);
      if (!boardAccess(t, m, co.id)) throw new RuleError("This cohort discussion is unavailable.", 404);
      if (co.status === "paused") throw new RuleError("This cohort is paused.", 409);
      if (t.posts.length >= 500) throw new RuleError("Pilot discussion limit reached.", 409);
      t.posts.unshift({ id: crypto.randomUUID(), scope: co.programId, cohortId: co.id, title: txt(c.title, "Title", 5, 140), body: txt(c.body, "Discussion", 20, 3e3), author: m.name, authorId: u.userId, status: "pending", createdAt: now, replies: [] });
      break;
    }
    case "reply":
    case "report":
    case "moderate": {
      const p = t.posts.find((p2) => p2.id === c.postId);
      if (!p || !boardAccess(t, m, p.cohortId)) throw new RuleError("Discussion not found.", 404);
      if (c.type === "moderate") {
        exact6(c, ["postId", "replyId", "status", "reason"]);
        requireRole(m, "moderator", p.cohortId);
        if (!["visible", "hidden"].includes(c.status)) throw new RuleError("Choose publish or hide.");
        const reason = txt(c.reason, "Moderation reason", 10, 1e3), previousStatus = c.replyId ? p.replies.find((r) => r.id === c.replyId)?.status : p.status;
        t.moderation ??= [];
        t.moderation.push({ id: crypto.randomUUID(), postId: p.id, replyId: c.replyId || null, cohortId: p.cohortId, actor: u.userId, actorName: m.name, reason, previousStatus, status: c.status, createdAt: now });
        if (c.replyId) {
          const r = p.replies.find((r2) => r2.id === c.replyId);
          if (!r) throw new RuleError("Reply not found.", 404);
          r.status = c.status;
        } else {
          p.status = c.status;
          for (const r of t.reports.filter((r2) => r2.postId === p.id)) r.status = "resolved";
        }
        break;
      }
      if (p.status !== "visible") throw new RuleError("This discussion is not available.", 404);
      if (c.type === "reply") {
        exact6(c, ["postId", "body"]);
        if (cohort(t, p.cohortId).status === "paused") throw new RuleError("This cohort is paused.", 409);
        if (p.replies.length >= 50) throw new RuleError("Reply limit reached.");
        p.replies.push({ id: crypto.randomUUID(), body: txt(c.body, "Reply", 10, 1500), author: m.name, authorId: u.userId, status: "pending", createdAt: now });
      } else {
        exact6(c, ["postId", "reason"]);
        if (t.reports.some((r) => r.postId === p.id && r.reporterId === u.userId && r.status === "open")) throw new RuleError("Your report is already awaiting review.", 409);
        t.reports.push({ id: crypto.randomUUID(), postId: p.id, reporterId: u.userId, reason: txt(c.reason, "Report reason", 10, 1e3), status: "open", createdAt: now });
      }
      break;
    }
    case "enroll": {
      exact6(c, ["programId", "cohortId"]);
      requireRole(m, "learner");
      const co = cohort(t, c.cohortId);
      if (co.programId !== c.programId) throw new RuleError("Choose the cohort for this pathway.");
      let ref;
      try {
        resolvePinnedContent(co, contentContext().allowedScopes, contentContext().registry);
        ref = pinnedRef(co);
      } catch (e2) {
        if (e2 instanceof ContentResolutionError) throw new RuleError(e2.message, e2.status);
        throw e2;
      }
      const l = learner(t, u), existing = l.state.enrollments.find((e2) => e2.programId === co.programId && !e2.withdrawn);
      if (existing) {
        if (existing.cohortId !== co.id) throw new RuleError("Finish or withdraw the existing enrollment before joining another cohort for this pathway.", 409);
        break;
      }
      try {
        requireAvailablePublication(t, ref, now);
      } catch (e2) {
        if (e2 instanceof AuthoringError || e2 instanceof ContentResolutionError) throw new RuleError(e2.message, e2.status);
        throw e2;
      }
      if (co.status !== "open") throw new RuleError("This cohort is not open for enrollment.", 409);
      if (seats(t, co.id) >= co.capacity) throw new RuleError("This cohort just filled. Choose another offering or ask the owner for support.", 409);
      l.state = applyCommand(l.state, c, now, void 0, ref, contentContext());
      const e = l.state.enrollments.at(-1);
      e.cohortId = co.id;
      e.claimPolicy = "Draft content \xB7 authenticated assigned review \xB7 nonaccredited";
      break;
    }
    case "profile":
    case "lesson-draft":
    case "lesson":
    case "draft":
    case "submit":
    case "appeal":
    case "share":
    case "withdraw":
    case "followup":
    case "interest": {
      if (Object.hasOwn(c, "learnerId") || Object.hasOwn(c, "actor")) throw new RuleError("Use only your own learning actions.", 400);
      const l = learner(t, u);
      if (c.enrollmentId) {
        const { c: co } = target(t, u.userId, c.enrollmentId);
        if (co.status === "paused" && !["appeal", "share", "withdraw", "followup"].includes(c.type)) throw new RuleError("This cohort is paused. Your saved work is retained.", 409);
      }
      if (["lesson-draft", "lesson", "draft", "submit"].includes(c.type)) requireRole(m, "learner");
      l.state = applyCommand(l.state, c, now, void 0, void 0, contentContext());
      if (c.type === "profile") m.name = l.state.profile.name;
      break;
    }
    default:
      throw new RuleError("This action belongs in your personal practice lab or is unavailable in shared workspaces.", 400);
  }
  finishAccess(t, now);
  if (["invite", "revoke-invite", "member", "cohort-create", "cohort-status", "assign"].includes(c.type)) {
    t.activity ??= [];
    t.activity.push({ id: crypto.randomUUID(), actor: u.userId, actorName: m.name, action: c.type, createdAt: now, detail: c.type === "invite" ? { inviteId: t.invites.at(-1).id, roles: c.roles, scopes: c.scopes } : c.type === "member" ? { userId: c.userId, roles: c.roles, scopes: c.scopes, active: c.active } : c.type === "assign" ? { kind: c.kind, targetId: c.targetId, staffId: c.staffId } : c.type === "revoke-invite" ? { inviteId: c.inviteId } : c.type === "cohort-status" ? { cohortId: c.cohortId, status: c.status } : { cohortId: t.cohorts.at(-1).id } });
  }
  return t;
}
function projectTeam(t, u) {
  const m = member3(t, u.userId, false), own = t.learners.find((l) => l.userId === u.userId), state = copy2(own?.state ?? freshWorkspace());
  if (!own) {
    state.profile.name = label(u);
    state.profile.context = t.context;
  }
  const admin = m.active && m.roles.includes("admin"), qs = pending(t);
  state.paused = t.cohorts.filter((c) => c.status === "paused" && state.enrollments.some((e) => e.cohortId === c.id)).map((c) => c.programId);
  const visibleCohorts = t.cohorts.filter((c) => m.active ? m.roles.includes("learner") || boardAccess(t, m, c.id) : state.enrollments.some((e) => e.cohortId === c.id));
  const isMod = (cid) => m.active && m.roles.includes("moderator") && m.scopes.includes(cid);
  state.posts = m.active ? t.posts.filter((p) => boardAccess(t, m, p.cohortId) && (p.status === "visible" || p.authorId === u.userId || isMod(p.cohortId))).map((p) => {
    const x = copy2(p);
    delete x.authorId;
    x.replies = x.replies.filter((r) => r.status === "visible" || r.authorId === u.userId || isMod(p.cohortId)).map((r) => {
      const z = copy2(r);
      delete z.authorId;
      return z;
    });
    return x;
  }) : [];
  state.reports = m.active ? t.reports.filter((r) => {
    const p = t.posts.find((p2) => p2.id === r.postId);
    return p && isMod(p.cohortId);
  }).map((r) => ({ id: r.id, postId: r.postId, reason: r.reason, status: r.status, createdAt: r.createdAt })) : [];
  const assigned = qs.filter((q) => eligible2(t, m, q) && t.assignments.some((a) => a.kind === q.kind && a.targetId === q.targetId && a.staffId === u.userId)).map((q) => {
    const { e } = target(t, q.learnerId, q.enrollmentId), ap = q.kind === "appeal" ? e.appeals.find((ap2) => ap2.id === q.targetId) : void 0, a = e.attempts.find((a2) => a2.id === (ap?.attemptId ?? q.targetId));
    return { ...q, learnerName: t.members.find((m2) => m2.userId === q.learnerId)?.name, e: { id: e.id, learnerId: q.learnerId, programId: e.programId, version: e.version, ...e.contentRef ? { contentRef: copy2(e.contentRef) } : {}, cohortId: e.cohortId }, a: copy2(a), ...ap ? { ap: copy2(ap) } : {} };
  });
  const summaries = t.learners.flatMap((l) => l.state.enrollments.filter((e) => admin || m.active && m.roles.includes("facilitator") && m.scopes.includes(e.cohortId)).map((e) => ({ learnerId: l.userId, learnerName: t.members.find((m2) => m2.userId === l.userId)?.name, cohortId: e.cohortId, programId: e.programId, completedLessons: e.completed.length, practiceRecordStatus: e.record?.status ?? null, hasOpenAppeal: !e.withdrawn && e.appeals.some((ap) => ap.status === "open"), hasPendingAssessment: !e.withdrawn && e.attempts.some((a) => !a.decision), status: e.withdrawn ? "Withdrawn" : e.record?.status === "active" ? "Practice completed" : e.appeals.some((ap) => ap.status === "open") ? "Appeal pending" : e.attempts.some((a) => !a.decision) ? "Review pending" : "Learning" })));
  const result = { state, team: { currentUserId: u.userId, id: t.id, name: t.name, purpose: t.purpose, context: t.context, roles: m.active ? m.roles : [], active: m.active, support: projectSupport(t, u.userId), network: projectNetwork(t, m, boardAccess), cohorts: visibleCohorts.map((c) => ({ ...c, ...cohortContentAvailability(t, c), occupied: seats(t, c.id), boardAccess: boardAccess(t, m, c.id), canModerate: isMod(c.id), canHost: m.active && (admin || m.roles.includes("facilitator") && m.scopes.includes(c.id)) })), moderationHistory: (t.moderation ?? []).filter((x) => isMod(x.cohortId)), ...admin ? { activity: t.activity ?? [], members: t.members.map((m2) => ({ ...m2 })), invites: t.invites.map(({ tokenHash, ...i }) => i), pending: qs.map((q) => ({ ...q, learnerName: t.members.find((m2) => m2.userId === q.learnerId)?.name, assignedTo: t.assignments.find((a) => a.kind === q.kind && a.targetId === q.targetId)?.staffId, eligibleStaff: t.members.filter((m2) => eligible2(t, m2, q)).map((m2) => ({ userId: m2.userId, name: m2.name })) })) } : {}, assigned, summaries } };
  const neededRefs = [];
  for (const record2 of [...result.state.enrollments, ...result.team.cohorts, ...result.team.assigned.map((q) => q.e)]) {
    try {
      const ref = pinnedRef(record2);
      if (ref.scope === "global" || ref.scope === t.id) neededRefs.push(ref);
    } catch (e) {
      if (!(e instanceof ContentResolutionError)) throw e;
    }
  }
  const content = projectWorkspaceContent(t, u, neededRefs);
  return { ...result, contentVersions: content.versions, team: { ...result.team, ...admin ? { content: { drafts: content.drafts, publications: content.publications } } : {} } };
}
function cohortContentAvailability(t, c) {
  try {
    requireAvailablePublication(t, pinnedRef(c));
    return { contentOpen: true, contentNotice: null };
  } catch (e) {
    if (e instanceof AuthoringError || e instanceof ContentResolutionError) return { contentOpen: false, contentNotice: e.message };
    throw e;
  }
}

// lib/academy-operations.ts
var OPERATIONS_LIMITS = { cohorts: 20, summaries: 5e3, pending: 5e3, assigned: 5e3, support: 100, sessions: 100, drafts: 24, publications: 8, rows: 8 };
var DAY = 864e5;
var clean = (v, fallback = "", max = 160) => typeof v === "string" ? v.slice(0, max) : fallback;
var id = (v) => typeof v === "string" && v.length > 0 && v.length <= 160 ? v : null;
var subject = (v) => typeof v === "string" && v.length > 0 && v.length <= 18e5 ? v : null;
var amount = (v, max = 5e5) => typeof v === "number" && Number.isInteger(v) && v >= 0 && v <= max ? v : null;
var iso = (v) => {
  if (typeof v !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(v) || !Number.isFinite(Date.parse(v))) return null;
  return new Date(v).toISOString() === v ? v : null;
};
var age = (v, clock) => {
  const date = iso(v);
  return date && Date.parse(date) <= clock ? Math.floor((clock - Date.parse(date)) / DAY) : null;
};
var list = (v, cap) => v === void 0 ? [] : Array.isArray(v) && v.length <= cap ? v : null;
var sameKey = (q) => `${q?.kind}:${q?.targetId}`;
var oldest = (a, b) => (a.createdAt ? Date.parse(a.createdAt) : Infinity) - (b.createdAt ? Date.parse(b.createdAt) : Infinity) || a.id.localeCompare(b.id);
function canShowWorkspaceOperations(team) {
  return !!team && team.active === true && Array.isArray(team.roles) && team.roles.some((r) => r === "admin" || r === "facilitator");
}
function deriveWorkspaceOperations(team, now) {
  if (!canShowWorkspaceOperations(team) || !iso(now) || !id(team.id)) return null;
  const owner3 = team.roles.includes("admin"), clock = Date.parse(now);
  const cohorts = list(team.cohorts, OPERATIONS_LIMITS.cohorts), summaries = list(team.summaries, OPERATIONS_LIMITS.summaries), pending2 = list(team.pending, OPERATIONS_LIMITS.pending), assigned = list(team.assigned, OPERATIONS_LIMITS.assigned), queue = list(team.support?.queue, OPERATIONS_LIMITS.support), handledRequests = list(team.support?.assigned, OPERATIONS_LIMITS.support), sessions = list(team.network?.sessions, OPERATIONS_LIMITS.sessions), drafts = owner3 ? list(team.content?.drafts, OPERATIONS_LIMITS.drafts) : [], publications = owner3 ? list(team.content?.publications, OPERATIONS_LIMITS.publications) : [], members = owner3 ? list(team.members, 100) : [];
  if (!cohorts || !summaries || !pending2 || !assigned || !queue || !handledRequests || !sessions || !drafts || !publications || !members) return null;
  const scoped = cohorts.filter((c) => c && id(c.id) && c.canHost === true), byId = /* @__PURE__ */ new Map();
  for (const c of scoped) {
    if (byId.has(c.id)) continue;
    byId.set(c.id, { id: c.id, title: clean(c.title, "Unnamed cohort", 100), status: ["open", "closed", "paused"].includes(c.status) ? c.status : "unknown", capacity: amount(c.capacity, 100), occupied: amount(c.occupied, 100), newEnrollmentBlocked: c.contentOpen === false || c.status === "closed" || c.status === "paused", contentNotice: c.contentOpen === false ? clean(c.contentNotice, "New enrollment is unavailable.", 300) : null, enrollments: 0, nonWithdrawn: 0, learning: 0, reviewPending: 0, appealPending: 0, practiceCompleted: 0, suspendedPracticeRecords: 0, withdrawn: 0, other: 0, savedLessons: 0 });
  }
  for (const row of summaries) {
    const co = byId.get(row?.cohortId);
    if (!co) continue;
    co.enrollments++;
    co.savedLessons += amount(row.completedLessons, 100) ?? 0;
    if (row.status === "Learning") co.learning++;
    else if (row.status === "Withdrawn") co.withdrawn++;
    else if (!["Review pending", "Appeal pending", "Practice completed"].includes(row.status)) co.other++;
    if (row.status !== "Withdrawn") co.nonWithdrawn++;
    if (Object.hasOwn(row, "practiceRecordStatus") ? row.practiceRecordStatus === "active" : row.status === "Practice completed") co.practiceCompleted++;
    if (row.practiceRecordStatus === "suspended") co.suspendedPracticeRecords++;
    if (typeof row.hasPendingAssessment === "boolean" ? row.hasPendingAssessment : row.status === "Review pending") co.reviewPending++;
    if (typeof row.hasOpenAppeal === "boolean" ? row.hasOpenAppeal : row.status === "Appeal pending") co.appealPending++;
  }
  const names = /* @__PURE__ */ new Map();
  if (owner3) {
    for (const m of members) if (subject(m?.userId)) names.set(m.userId, clean(m.name, "Workspace member", 80));
  }
  const myKeys = new Set(assigned.filter((q) => byId.has(q?.cohortId)).map(sameKey)), reviewRows = [], seenReview = /* @__PURE__ */ new Set();
  for (const q of owner3 ? pending2 : assigned) {
    const co = byId.get(q?.cohortId), target2 = id(q?.targetId);
    if (!co || !target2 || !["assessment", "appeal"].includes(q.kind) || seenReview.has(sameKey(q))) continue;
    seenReview.add(sameKey(q));
    if (q.assignedTo != null && !subject(q.assignedTo)) return null;
    const mine = myKeys.has(sameKey(q)), assignedId = subject(q.assignedTo);
    reviewRows.push({ id: target2, kind: q.kind, cohortId: co.id, cohortTitle: co.title, learnerName: clean(q.learnerName, "Learner", 80), createdAt: iso(q.createdAt), ageDays: age(q.createdAt, clock), assignment: mine ? "mine" : assignedId ? "assigned" : "unassigned", assignedName: mine ? "You" : assignedId ? names.get(assignedId) ?? "Assigned staff" : null, eligibleStaffCount: owner3 && Array.isArray(q.eligibleStaff) ? q.eligibleStaff.length : null, paused: co.status === "paused", destination: mine ? { view: "studio", id: target2 } : { view: "teams", section: "assignments", id: target2 } });
  }
  reviewRows.sort(oldest);
  const contentRows = [], dueSoon = clock + 7 * DAY;
  if (owner3) {
    for (const p of publications) {
      if (!id(p?.id) || p.availability !== "available") continue;
      const due2 = iso(p.reviewDueAt), value = due2 ? Date.parse(due2) : NaN;
      if (due2 && value > dueSoon) continue;
      contentRows.push({ id: p.id, title: clean(p.title, "Private publication", 200), kind: "publication", state: !due2 ? "review_date_unknown" : value <= clock ? "review_due" : "review_soon", reviewDueAt: due2, waitingSince: null, ageDays: null, reviewerName: clean(p.reviewerName, "Reviewer", 80), reviewerAvailable: null });
    }
    for (const d of drafts) {
      if (!id(d?.id) || !["in_review", "approved"].includes(d.state)) continue;
      const reviewer = members.find((m) => m?.userId === d.reviewerId);
      contentRows.push({ id: d.id, title: clean(d.document?.title, "Untitled private draft", 200), kind: "draft", state: d.state, reviewDueAt: iso(d.reviewDueAt), waitingSince: iso(d.updatedAt), ageDays: age(d.updatedAt, clock), reviewerName: reviewer ? clean(reviewer.name, "Reviewer", 80) : null, reviewerAvailable: !!reviewer && reviewer.active === true && Array.isArray(reviewer.roles) && reviewer.roles.includes("admin") && reviewer.userId !== d.authorId });
    }
    const priority = { review_due: 0, review_date_unknown: 1, in_review: 2, approved: 3, review_soon: 4 };
    contentRows.sort((a, b) => priority[a.state] - priority[b.state] || (a.reviewDueAt ? Date.parse(a.reviewDueAt) : Infinity) - (b.reviewDueAt ? Date.parse(b.reviewDueAt) : Infinity) || a.id.localeCompare(b.id));
  }
  const handled = new Set(handledRequests.map((r) => r?.id)), supportRows = [], supportSeen = /* @__PURE__ */ new Set();
  for (const r of queue) {
    if (!id(r?.id) || r.status !== "open" || supportSeen.has(r.id)) continue;
    const co = r.cohortId === null ? null : byId.get(r.cohortId);
    if (!owner3 && (!co || !["learning", "content"].includes(r.category))) continue;
    supportSeen.add(r.id);
    supportRows.push({ id: r.id, category: clean(r.category, "support", 30), cohortId: co?.id ?? id(r.cohortId), cohortTitle: co?.title ?? (r.cohortId === null ? "Workspace support" : clean(r.cohortTitle, "Former cohort", 100)), createdAt: iso(r.createdAt), updatedAt: iso(r.updatedAt), openedDaysAgo: age(r.createdAt, clock), handledByMe: handled.has(r.id), handlerName: typeof r.handlerName === "string" ? clean(r.handlerName, "", 80) : null, needsHandler: r.handlerName === null, independentHandlerAvailable: r.eligibleHandlerAvailable === true, canClaim: r.canClaim === true });
  }
  supportRows.sort((a, b) => Number(b.needsHandler) - Number(a.needsHandler) || oldest(a, b));
  const sessionRows = [], sessionSeen = /* @__PURE__ */ new Set();
  for (const s of sessions) {
    const co = byId.get(s?.cohortId);
    if (!co || !id(s?.id) || s.status !== "scheduled" || sessionSeen.has(s.id)) continue;
    const start = iso(s.startsAt), end = iso(s.endsAt);
    if (!start || !end || Date.parse(end) <= Date.parse(start)) continue;
    const roster = s.isHost === true ? list(s.registrations, 100) : [];
    if (!roster) return null;
    const begins = Date.parse(start), ends = Date.parse(end), unrecorded = s.isHost === true ? roster.filter((r) => r && r.attendance === null).length : null, active2 = ends > clock && begins <= dueSoon, attendance = s.isHost === true && begins <= clock && clock <= ends + 7 * DAY && (unrecorded ?? 0) > 0;
    if (!active2 && !attendance) continue;
    sessionSeen.add(s.id);
    sessionRows.push({ id: s.id, title: clean(s.title, "Practice session", 120), cohortId: co.id, cohortTitle: co.title, startsAt: start, endsAt: end, capacity: amount(s.capacity, 100), occupied: amount(s.occupied, 100), isHost: s.isHost === true, hostAvailable: s.hostAvailable === true, paused: co.status === "paused", unrecordedAttendance: unrecorded, phase: ends <= clock ? "attendance_window" : begins <= clock ? "in_progress" : "upcoming" });
  }
  sessionRows.sort((a, b) => Date.parse(a.startsAt) - Date.parse(b.startsAt) || a.id.localeCompare(b.id));
  const cohortRows = [...byId.values()];
  return { workspaceId: team.id, workspaceName: clean(team.name, "Workspace", 80), audience: owner3 ? "owner" : "facilitator", asOf: now, cohorts: cohortRows, totals: { cohorts: cohortRows.length, nonWithdrawnEnrollments: cohortRows.reduce((n, c) => n + c.nonWithdrawn, 0), practiceRecords: cohortRows.reduce((n, c) => n + c.practiceCompleted, 0), savedLessons: cohortRows.reduce((n, c) => n + c.savedLessons, 0) }, reviews: { scope: owner3 ? "workspace" : "my_assignments", total: reviewRows.length, assessments: reviewRows.filter((q) => q.kind === "assessment").length, appeals: reviewRows.filter((q) => q.kind === "appeal").length, unassigned: owner3 ? reviewRows.filter((q) => q.assignment === "unassigned").length : null, withoutEligibleStaff: owner3 ? reviewRows.filter((q) => q.eligibleStaffCount === 0).length : null, paused: reviewRows.filter((q) => q.paused).length, oldestDays: reviewRows.reduce((n, q) => q.ageDays === null ? n : n === null ? q.ageDays : Math.max(n, q.ageDays), null), items: reviewRows.slice(0, OPERATIONS_LIMITS.rows) }, content: { available: owner3, reviewDue: contentRows.filter((c) => c.state === "review_due").length, reviewDateUnknown: contentRows.filter((c) => c.state === "review_date_unknown").length, reviewSoon: contentRows.filter((c) => c.state === "review_soon").length, awaitingReview: contentRows.filter((c) => c.state === "in_review").length, approved: contentRows.filter((c) => c.state === "approved").length, items: contentRows.slice(0, OPERATIONS_LIMITS.rows) }, support: { totalOpen: supportRows.length, needsHandler: supportRows.filter((r) => r.needsHandler).length, withoutIndependentHandler: supportRows.filter((r) => r.needsHandler && !r.independentHandlerAvailable).length, handledByMe: supportRows.filter((r) => r.handledByMe).length, items: supportRows.slice(0, OPERATIONS_LIMITS.rows) }, sessions: { total: sessionRows.length, nextSevenDays: sessionRows.filter((s) => s.phase !== "attendance_window").length, hostUnavailable: sessionRows.filter((s) => s.phase !== "attendance_window" && !s.hostAvailable).length, attendanceToRecord: sessionRows.filter((s) => s.isHost && s.phase !== "upcoming").reduce((n, s) => n + (s.unrecordedAttendance ?? 0), 0), items: sessionRows.slice(0, OPERATIONS_LIMITS.rows) } };
}
export {
  applyTeamCommand,
  createTeam,
  currentRef,
  deriveWorkspaceOperations,
  pinnedRef,
  programs,
  projectTeam,
  resolvePinnedContent,
  workspaceRegistry
};
