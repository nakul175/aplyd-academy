"use client";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// work/aplyd-academy/node_modules/tailwind-merge/dist/bundle-cjs.js
var require_bundle_cjs = __commonJS({
  "work/aplyd-academy/node_modules/tailwind-merge/dist/bundle-cjs.js"(exports) {
    "use strict";
    Object.defineProperty(exports, Symbol.toStringTag, {
      value: "Module"
    });
    var concatArrays = (array1, array2) => {
      const combinedArray = new Array(array1.length + array2.length);
      for (let i = 0; i < array1.length; i++) {
        combinedArray[i] = array1[i];
      }
      for (let i = 0; i < array2.length; i++) {
        combinedArray[array1.length + i] = array2[i];
      }
      return combinedArray;
    };
    var createClassValidatorObject = (classGroupId, validator) => ({
      classGroupId,
      validator
    });
    var createClassPartObject = (nextPart = /* @__PURE__ */ new Map(), validators2 = null, classGroupId) => ({
      nextPart,
      validators: validators2,
      classGroupId
    });
    var CLASS_PART_SEPARATOR = "-";
    var EMPTY_CONFLICTS = [];
    var ARBITRARY_PROPERTY_PREFIX = "arbitrary..";
    var createClassGroupUtils = (config) => {
      const classMap = createClassMap(config);
      const {
        conflictingClassGroups,
        conflictingClassGroupModifiers
      } = config;
      const getClassGroupId = (className) => {
        if (className.startsWith("[") && className.endsWith("]")) {
          return getGroupIdForArbitraryProperty(className);
        }
        const classParts = className.split(CLASS_PART_SEPARATOR);
        const startIndex = classParts[0] === "" && classParts.length > 1 ? 1 : 0;
        return getGroupRecursive(classParts, startIndex, classMap);
      };
      const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
        if (hasPostfixModifier) {
          const modifierConflicts = conflictingClassGroupModifiers[classGroupId];
          const baseConflicts = conflictingClassGroups[classGroupId];
          if (modifierConflicts) {
            if (baseConflicts) {
              return concatArrays(baseConflicts, modifierConflicts);
            }
            return modifierConflicts;
          }
          return baseConflicts || EMPTY_CONFLICTS;
        }
        return conflictingClassGroups[classGroupId] || EMPTY_CONFLICTS;
      };
      return {
        getClassGroupId,
        getConflictingClassGroupIds
      };
    };
    var getGroupRecursive = (classParts, startIndex, classPartObject) => {
      const classPathsLength = classParts.length - startIndex;
      if (classPathsLength === 0) {
        return classPartObject.classGroupId;
      }
      const currentClassPart = classParts[startIndex];
      const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
      if (nextClassPartObject) {
        const result = getGroupRecursive(classParts, startIndex + 1, nextClassPartObject);
        if (result) return result;
      }
      const validators2 = classPartObject.validators;
      if (validators2 === null) {
        return void 0;
      }
      const classRest = startIndex === 0 ? classParts.join(CLASS_PART_SEPARATOR) : classParts.slice(startIndex).join(CLASS_PART_SEPARATOR);
      const validatorsLength = validators2.length;
      for (let i = 0; i < validatorsLength; i++) {
        const validatorObj = validators2[i];
        if (validatorObj.validator(classRest)) {
          return validatorObj.classGroupId;
        }
      }
      return void 0;
    };
    var getGroupIdForArbitraryProperty = (className) => className.slice(1, -1).indexOf(":") === -1 ? void 0 : (() => {
      const content = className.slice(1, -1);
      const colonIndex = content.indexOf(":");
      const property = content.slice(0, colonIndex);
      return property ? ARBITRARY_PROPERTY_PREFIX + property : void 0;
    })();
    var createClassMap = (config) => {
      const {
        theme,
        classGroups
      } = config;
      return processClassGroups(classGroups, theme);
    };
    var processClassGroups = (classGroups, theme) => {
      const classMap = createClassPartObject();
      for (const classGroupId in classGroups) {
        const group = classGroups[classGroupId];
        processClassesRecursively(group, classMap, classGroupId, theme);
      }
      return classMap;
    };
    var processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
      const len = classGroup.length;
      for (let i = 0; i < len; i++) {
        const classDefinition = classGroup[i];
        processClassDefinition(classDefinition, classPartObject, classGroupId, theme);
      }
    };
    var processClassDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
      if (typeof classDefinition === "string") {
        processStringDefinition(classDefinition, classPartObject, classGroupId);
        return;
      }
      if (typeof classDefinition === "function") {
        processFunctionDefinition(classDefinition, classPartObject, classGroupId, theme);
        return;
      }
      processObjectDefinition(classDefinition, classPartObject, classGroupId, theme);
    };
    var processStringDefinition = (classDefinition, classPartObject, classGroupId) => {
      const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
      classPartObjectToEdit.classGroupId = classGroupId;
    };
    var processFunctionDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
      if (isThemeGetter(classDefinition)) {
        processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
        return;
      }
      if (classPartObject.validators === null) {
        classPartObject.validators = [];
      }
      classPartObject.validators.push(createClassValidatorObject(classGroupId, classDefinition));
    };
    var processObjectDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
      const entries = Object.entries(classDefinition);
      const len = entries.length;
      for (let i = 0; i < len; i++) {
        const [key, value] = entries[i];
        processClassesRecursively(value, getPart(classPartObject, key), classGroupId, theme);
      }
    };
    var getPart = (classPartObject, path) => {
      let current = classPartObject;
      const parts = path.split(CLASS_PART_SEPARATOR);
      const len = parts.length;
      for (let i = 0; i < len; i++) {
        const part = parts[i];
        let next = current.nextPart.get(part);
        if (!next) {
          next = createClassPartObject();
          current.nextPart.set(part, next);
        }
        current = next;
      }
      return current;
    };
    var isThemeGetter = (func) => "isThemeGetter" in func && func.isThemeGetter === true;
    var createLruCache = (maxCacheSize) => {
      if (maxCacheSize < 1) {
        return {
          get: () => void 0,
          set: () => {
          }
        };
      }
      let cacheSize = 0;
      let cache = /* @__PURE__ */ Object.create(null);
      let previousCache = /* @__PURE__ */ Object.create(null);
      const update = (key, value) => {
        cache[key] = value;
        cacheSize++;
        if (cacheSize > maxCacheSize) {
          cacheSize = 0;
          previousCache = cache;
          cache = /* @__PURE__ */ Object.create(null);
        }
      };
      return {
        get(key) {
          let value = cache[key];
          if (value !== void 0) {
            return value;
          }
          if ((value = previousCache[key]) !== void 0) {
            update(key, value);
            return value;
          }
        },
        set(key, value) {
          if (key in cache) {
            cache[key] = value;
          } else {
            update(key, value);
          }
        }
      };
    };
    var IMPORTANT_MODIFIER = "!";
    var MODIFIER_SEPARATOR = ":";
    var EMPTY_MODIFIERS = [];
    var createResultObject = (modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition, isExternal) => ({
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition,
      isExternal
    });
    var createParseClassName = (config) => {
      const {
        prefix,
        experimentalParseClassName
      } = config;
      let parseClassName = (className) => {
        const modifiers = [];
        let bracketDepth = 0;
        let parenDepth = 0;
        let modifierStart = 0;
        let postfixModifierPosition;
        const len = className.length;
        for (let index = 0; index < len; index++) {
          const currentCharacter = className[index];
          if (bracketDepth === 0 && parenDepth === 0) {
            if (currentCharacter === MODIFIER_SEPARATOR) {
              modifiers.push(className.slice(modifierStart, index));
              modifierStart = index + 1;
              continue;
            }
            if (currentCharacter === "/") {
              postfixModifierPosition = index;
              continue;
            }
          }
          if (currentCharacter === "[") bracketDepth++;
          else if (currentCharacter === "]") bracketDepth--;
          else if (currentCharacter === "(") parenDepth++;
          else if (currentCharacter === ")") parenDepth--;
        }
        const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.slice(modifierStart);
        let baseClassName = baseClassNameWithImportantModifier;
        let hasImportantModifier = false;
        if (baseClassNameWithImportantModifier.endsWith(IMPORTANT_MODIFIER)) {
          baseClassName = baseClassNameWithImportantModifier.slice(0, -1);
          hasImportantModifier = true;
        } else if (
          /**
           * In Tailwind CSS v3 the important modifier was at the start of the base class name. This is still supported for legacy reasons.
           * @see https://github.com/dcastil/tailwind-merge/issues/513#issuecomment-2614029864
           */
          baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER)
        ) {
          baseClassName = baseClassNameWithImportantModifier.slice(1);
          hasImportantModifier = true;
        }
        const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
        return createResultObject(modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition);
      };
      if (prefix) {
        const fullPrefix = prefix + MODIFIER_SEPARATOR;
        const parseClassNameOriginal = parseClassName;
        parseClassName = (className) => className.startsWith(fullPrefix) ? parseClassNameOriginal(className.slice(fullPrefix.length)) : createResultObject(EMPTY_MODIFIERS, false, className, void 0, true);
      }
      if (experimentalParseClassName) {
        const parseClassNameOriginal = parseClassName;
        parseClassName = (className) => experimentalParseClassName({
          className,
          parseClassName: parseClassNameOriginal
        });
      }
      return parseClassName;
    };
    var createSortModifiers = (config) => {
      const modifierWeights = /* @__PURE__ */ new Map();
      config.orderSensitiveModifiers.forEach((mod, index) => {
        modifierWeights.set(mod, 1e6 + index);
      });
      return (modifiers) => {
        const result = [];
        let currentSegment = [];
        for (let i = 0; i < modifiers.length; i++) {
          const modifier = modifiers[i];
          const isArbitrary = modifier[0] === "[";
          const isOrderSensitive = modifierWeights.has(modifier);
          if (isArbitrary || isOrderSensitive) {
            if (currentSegment.length > 0) {
              currentSegment.sort();
              result.push(...currentSegment);
              currentSegment = [];
            }
            result.push(modifier);
          } else {
            currentSegment.push(modifier);
          }
        }
        if (currentSegment.length > 0) {
          currentSegment.sort();
          result.push(...currentSegment);
        }
        return result;
      };
    };
    var createConfigUtils = (config) => ({
      cache: createLruCache(config.cacheSize),
      parseClassName: createParseClassName(config),
      sortModifiers: createSortModifiers(config),
      postfixLookupClassGroupIds: createPostfixLookupClassGroupIds(config),
      ...createClassGroupUtils(config)
    });
    var createPostfixLookupClassGroupIds = (config) => {
      const lookup = /* @__PURE__ */ Object.create(null);
      const classGroupIds = config.postfixLookupClassGroups;
      if (classGroupIds) {
        for (let i = 0; i < classGroupIds.length; i++) {
          lookup[classGroupIds[i]] = true;
        }
      }
      return lookup;
    };
    var SPLIT_CLASSES_REGEX = /\s+/;
    var mergeClassList = (classList, configUtils) => {
      const {
        parseClassName,
        getClassGroupId,
        getConflictingClassGroupIds,
        sortModifiers,
        postfixLookupClassGroupIds
      } = configUtils;
      const classGroupsInConflict = [];
      const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
      let result = "";
      for (let index = classNames.length - 1; index >= 0; index -= 1) {
        const originalClassName = classNames[index];
        const {
          isExternal,
          modifiers,
          hasImportantModifier,
          baseClassName,
          maybePostfixModifierPosition
        } = parseClassName(originalClassName);
        if (isExternal) {
          result = originalClassName + (result.length > 0 ? " " + result : result);
          continue;
        }
        let hasPostfixModifier = !!maybePostfixModifierPosition;
        let classGroupId;
        if (hasPostfixModifier) {
          const baseClassNameWithoutPostfix = baseClassName.substring(0, maybePostfixModifierPosition);
          classGroupId = getClassGroupId(baseClassNameWithoutPostfix);
          const classGroupIdWithPostfix = classGroupId && postfixLookupClassGroupIds[classGroupId] ? getClassGroupId(baseClassName) : void 0;
          if (classGroupIdWithPostfix && classGroupIdWithPostfix !== classGroupId) {
            classGroupId = classGroupIdWithPostfix;
            hasPostfixModifier = false;
          }
        } else {
          classGroupId = getClassGroupId(baseClassName);
        }
        if (!classGroupId) {
          if (!hasPostfixModifier) {
            result = originalClassName + (result.length > 0 ? " " + result : result);
            continue;
          }
          classGroupId = getClassGroupId(baseClassName);
          if (!classGroupId) {
            result = originalClassName + (result.length > 0 ? " " + result : result);
            continue;
          }
          hasPostfixModifier = false;
        }
        const variantModifier = modifiers.length === 0 ? "" : modifiers.length === 1 ? modifiers[0] : sortModifiers(modifiers).join(":");
        const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
        const classId = modifierId + classGroupId;
        if (classGroupsInConflict.indexOf(classId) > -1) {
          continue;
        }
        classGroupsInConflict.push(classId);
        const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
        for (let i = 0; i < conflictGroups.length; ++i) {
          const group = conflictGroups[i];
          classGroupsInConflict.push(modifierId + group);
        }
        result = originalClassName + (result.length > 0 ? " " + result : result);
      }
      return result;
    };
    var twJoin = (...classLists) => {
      let index = 0;
      let argument;
      let resolvedValue;
      let string = "";
      while (index < classLists.length) {
        if (argument = classLists[index++]) {
          if (resolvedValue = toValue(argument)) {
            string && (string += " ");
            string += resolvedValue;
          }
        }
      }
      return string;
    };
    var toValue = (mix) => {
      if (typeof mix === "string") {
        return mix;
      }
      let resolvedValue;
      let string = "";
      for (let k = 0; k < mix.length; k++) {
        if (mix[k]) {
          if (resolvedValue = toValue(mix[k])) {
            string && (string += " ");
            string += resolvedValue;
          }
        }
      }
      return string;
    };
    var createTailwindMerge = (createConfigFirst, ...createConfigRest) => {
      let configUtils;
      let cacheGet;
      let cacheSet;
      let functionToCall;
      const initTailwindMerge = (classList) => {
        const config = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
        configUtils = createConfigUtils(config);
        cacheGet = configUtils.cache.get;
        cacheSet = configUtils.cache.set;
        functionToCall = tailwindMerge;
        return tailwindMerge(classList);
      };
      const tailwindMerge = (classList) => {
        const cachedResult = cacheGet(classList);
        if (cachedResult) {
          return cachedResult;
        }
        const result = mergeClassList(classList, configUtils);
        cacheSet(classList, result);
        return result;
      };
      functionToCall = initTailwindMerge;
      return (...args) => functionToCall(twJoin(...args));
    };
    var fallbackThemeArr = [];
    var fromTheme = (key) => {
      const themeGetter = (theme) => theme[key] || fallbackThemeArr;
      themeGetter.isThemeGetter = true;
      return themeGetter;
    };
    var arbitraryValueRegex = /^\[(?:(\w[\w-]*):)?(.+)\]$/i;
    var arbitraryVariableRegex = /^\((?:(\w[\w-]*):)?(.+)\)$/i;
    var fractionRegex = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/;
    var tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
    var lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
    var colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
    var shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
    var imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
    var isFraction = (value) => fractionRegex.test(value);
    var isNumber = (value) => !!value && !Number.isNaN(Number(value));
    var isInteger = (value) => !!value && Number.isInteger(Number(value));
    var isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
    var isTshirtSize = (value) => tshirtUnitRegex.test(value);
    var isAny = () => true;
    var isLengthOnly = (value) => (
      // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
      // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
      // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
      lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
    );
    var isNever = () => false;
    var isShadow = (value) => shadowRegex.test(value);
    var isImage = (value) => imageRegex.test(value);
    var isAnyNonArbitrary = (value) => !isArbitraryValue(value) && !isArbitraryVariable(value);
    var isNamedContainerQuery = (value) => value.startsWith("@container") && (value[10] === "/" && value[11] !== void 0 || value[11] === "s" && value[16] !== void 0 && value.startsWith("-size/", 10) || value[11] === "n" && value[18] !== void 0 && value.startsWith("-normal/", 10));
    var isArbitrarySize = (value) => getIsArbitraryValue(value, isLabelSize, isNever);
    var isArbitraryValue = (value) => arbitraryValueRegex.test(value);
    var isArbitraryLength = (value) => getIsArbitraryValue(value, isLabelLength, isLengthOnly);
    var isArbitraryNumber = (value) => getIsArbitraryValue(value, isLabelNumber, isNumber);
    var isArbitraryWeight = (value) => getIsArbitraryValue(value, isLabelWeight, isAny);
    var isArbitraryFamilyName = (value) => getIsArbitraryValue(value, isLabelFamilyName, isNever);
    var isArbitraryPosition = (value) => getIsArbitraryValue(value, isLabelPosition, isNever);
    var isArbitraryImage = (value) => getIsArbitraryValue(value, isLabelImage, isImage);
    var isArbitraryShadow = (value) => getIsArbitraryValue(value, isLabelShadow, isShadow);
    var isArbitraryVariable = (value) => arbitraryVariableRegex.test(value);
    var isArbitraryVariableLength = (value) => getIsArbitraryVariable(value, isLabelLength);
    var isArbitraryVariableFamilyName = (value) => getIsArbitraryVariable(value, isLabelFamilyName);
    var isArbitraryVariablePosition = (value) => getIsArbitraryVariable(value, isLabelPosition);
    var isArbitraryVariableSize = (value) => getIsArbitraryVariable(value, isLabelSize);
    var isArbitraryVariableImage = (value) => getIsArbitraryVariable(value, isLabelImage);
    var isArbitraryVariableShadow = (value) => getIsArbitraryVariable(value, isLabelShadow, true);
    var isArbitraryVariableWeight = (value) => getIsArbitraryVariable(value, isLabelWeight, true);
    var getIsArbitraryValue = (value, testLabel, testValue) => {
      const result = arbitraryValueRegex.exec(value);
      if (result) {
        if (result[1]) {
          return testLabel(result[1]);
        }
        return testValue(result[2]);
      }
      return false;
    };
    var getIsArbitraryVariable = (value, testLabel, shouldMatchNoLabel = false) => {
      const result = arbitraryVariableRegex.exec(value);
      if (result) {
        if (result[1]) {
          return testLabel(result[1]);
        }
        return shouldMatchNoLabel;
      }
      return false;
    };
    var isLabelPosition = (label) => label === "position" || label === "percentage";
    var isLabelImage = (label) => label === "image" || label === "url";
    var isLabelSize = (label) => label === "length" || label === "size" || label === "bg-size";
    var isLabelLength = (label) => label === "length";
    var isLabelNumber = (label) => label === "number";
    var isLabelFamilyName = (label) => label === "family-name";
    var isLabelWeight = (label) => label === "number" || label === "weight";
    var isLabelShadow = (label) => label === "shadow";
    var validators = /* @__PURE__ */ Object.defineProperty({
      __proto__: null,
      isAny,
      isAnyNonArbitrary,
      isArbitraryFamilyName,
      isArbitraryImage,
      isArbitraryLength,
      isArbitraryNumber,
      isArbitraryPosition,
      isArbitraryShadow,
      isArbitrarySize,
      isArbitraryValue,
      isArbitraryVariable,
      isArbitraryVariableFamilyName,
      isArbitraryVariableImage,
      isArbitraryVariableLength,
      isArbitraryVariablePosition,
      isArbitraryVariableShadow,
      isArbitraryVariableSize,
      isArbitraryVariableWeight,
      isArbitraryWeight,
      isFraction,
      isInteger,
      isNamedContainerQuery,
      isNumber,
      isPercent,
      isTshirtSize
    }, Symbol.toStringTag, {
      value: "Module"
    });
    var getDefaultConfig = () => {
      const themeColor = fromTheme("color");
      const themeFont = fromTheme("font");
      const themeText = fromTheme("text");
      const themeFontWeight = fromTheme("font-weight");
      const themeTracking = fromTheme("tracking");
      const themeLeading = fromTheme("leading");
      const themeBreakpoint = fromTheme("breakpoint");
      const themeContainer = fromTheme("container");
      const themeSpacing = fromTheme("spacing");
      const themeRadius = fromTheme("radius");
      const themeShadow = fromTheme("shadow");
      const themeInsetShadow = fromTheme("inset-shadow");
      const themeTextShadow = fromTheme("text-shadow");
      const themeDropShadow = fromTheme("drop-shadow");
      const themeBlur = fromTheme("blur");
      const themePerspective = fromTheme("perspective");
      const themeAspect = fromTheme("aspect");
      const themeEase = fromTheme("ease");
      const themeAnimate = fromTheme("animate");
      const scaleBreak = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
      const scalePosition = () => [
        "center",
        "top",
        "bottom",
        "left",
        "right",
        "top-left",
        // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
        "left-top",
        "top-right",
        // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
        "right-top",
        "bottom-right",
        // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
        "right-bottom",
        "bottom-left",
        // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
        "left-bottom"
      ];
      const scalePositionWithArbitrary = () => [...scalePosition(), isArbitraryVariable, isArbitraryValue];
      const scaleOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
      const scaleOverscroll = () => ["auto", "contain", "none"];
      const scaleUnambiguousSpacing = () => [isArbitraryVariable, isArbitraryValue, themeSpacing];
      const scaleInset = () => [isFraction, "full", "auto", ...scaleUnambiguousSpacing()];
      const scaleGridTemplateColsRows = () => [isInteger, "none", "subgrid", isArbitraryVariable, isArbitraryValue];
      const scaleGridColRowStartAndEnd = () => ["auto", {
        span: ["full", isInteger, isArbitraryVariable, isArbitraryValue]
      }, isInteger, isArbitraryVariable, isArbitraryValue];
      const scaleGridColRowStartOrEnd = () => [isInteger, "auto", isArbitraryVariable, isArbitraryValue];
      const scaleGridAutoColsRows = () => ["auto", "min", "max", "fr", isArbitraryVariable, isArbitraryValue];
      const scaleAlignPrimaryAxis = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"];
      const scaleAlignSecondaryAxis = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"];
      const scaleMargin = () => ["auto", ...scaleUnambiguousSpacing()];
      const scaleSizing = () => [isFraction, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...scaleUnambiguousSpacing()];
      const scaleSizingInline = () => [isFraction, "screen", "full", "dvw", "lvw", "svw", "min", "max", "fit", ...scaleUnambiguousSpacing()];
      const scaleSizingBlock = () => [isFraction, "screen", "full", "lh", "dvh", "lvh", "svh", "min", "max", "fit", ...scaleUnambiguousSpacing()];
      const scaleColor = () => [themeColor, isArbitraryVariable, isArbitraryValue];
      const scaleBgPosition = () => [...scalePosition(), isArbitraryVariablePosition, isArbitraryPosition, {
        position: [isArbitraryVariable, isArbitraryValue]
      }];
      const scaleBgRepeat = () => ["no-repeat", {
        repeat: ["", "x", "y", "space", "round"]
      }];
      const scaleBgSize = () => ["auto", "cover", "contain", isArbitraryVariableSize, isArbitrarySize, {
        size: [isArbitraryVariable, isArbitraryValue]
      }];
      const scaleGradientStopPosition = () => [isPercent, isArbitraryVariableLength, isArbitraryLength];
      const scaleRadius = () => [
        // Deprecated since Tailwind CSS v4.0.0
        "",
        "none",
        "full",
        themeRadius,
        isArbitraryVariable,
        isArbitraryValue
      ];
      const scaleBorderWidth = () => ["", isNumber, isArbitraryVariableLength, isArbitraryLength];
      const scaleLineStyle = () => ["solid", "dashed", "dotted", "double"];
      const scaleBlendMode = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
      const scaleMaskImagePosition = () => [isNumber, isPercent, isArbitraryVariablePosition, isArbitraryPosition];
      const scaleBlur = () => [
        // Deprecated since Tailwind CSS v4.0.0
        "",
        "none",
        themeBlur,
        isArbitraryVariable,
        isArbitraryValue
      ];
      const scaleRotate = () => ["none", isNumber, isArbitraryVariable, isArbitraryValue];
      const scaleScale = () => ["none", isNumber, isArbitraryVariable, isArbitraryValue];
      const scaleSkew = () => [isNumber, isArbitraryVariable, isArbitraryValue];
      const scaleTranslate = () => [isFraction, "full", ...scaleUnambiguousSpacing()];
      return {
        cacheSize: 500,
        theme: {
          animate: ["spin", "ping", "pulse", "bounce"],
          aspect: ["video"],
          blur: [isTshirtSize],
          breakpoint: [isTshirtSize],
          color: [isAny],
          container: [isTshirtSize],
          "drop-shadow": [isTshirtSize],
          ease: ["in", "out", "in-out"],
          font: [isAnyNonArbitrary],
          "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
          "inset-shadow": [isTshirtSize],
          leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
          perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
          radius: [isTshirtSize],
          shadow: [isTshirtSize],
          spacing: ["px", isNumber],
          text: [isTshirtSize],
          "text-shadow": [isTshirtSize],
          tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
        },
        classGroups: {
          // --------------
          // --- Layout ---
          // --------------
          /**
           * Aspect Ratio
           * @see https://tailwindcss.com/docs/aspect-ratio
           */
          aspect: [{
            aspect: ["auto", "square", isFraction, isArbitraryValue, isArbitraryVariable, themeAspect]
          }],
          /**
           * Container
           * @see https://tailwindcss.com/docs/container
           * @deprecated since Tailwind CSS v4.0.0
           */
          container: ["container"],
          /**
           * Container Type
           * @see https://tailwindcss.com/docs/responsive-design#container-queries
           */
          "container-type": [{
            "@container": ["", "normal", "size", isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Container Name
           * @see https://tailwindcss.com/docs/responsive-design#named-containers
           */
          "container-named": [isNamedContainerQuery],
          /**
           * Columns
           * @see https://tailwindcss.com/docs/columns
           */
          columns: [{
            columns: [isNumber, isArbitraryValue, isArbitraryVariable, themeContainer]
          }],
          /**
           * Break After
           * @see https://tailwindcss.com/docs/break-after
           */
          "break-after": [{
            "break-after": scaleBreak()
          }],
          /**
           * Break Before
           * @see https://tailwindcss.com/docs/break-before
           */
          "break-before": [{
            "break-before": scaleBreak()
          }],
          /**
           * Break Inside
           * @see https://tailwindcss.com/docs/break-inside
           */
          "break-inside": [{
            "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
          }],
          /**
           * Box Decoration Break
           * @see https://tailwindcss.com/docs/box-decoration-break
           */
          "box-decoration": [{
            "box-decoration": ["slice", "clone"]
          }],
          /**
           * Box Sizing
           * @see https://tailwindcss.com/docs/box-sizing
           */
          box: [{
            box: ["border", "content"]
          }],
          /**
           * Display
           * @see https://tailwindcss.com/docs/display
           */
          display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
          /**
           * Screen Reader Only
           * @see https://tailwindcss.com/docs/display#screen-reader-only
           */
          sr: ["sr-only", "not-sr-only"],
          /**
           * Floats
           * @see https://tailwindcss.com/docs/float
           */
          float: [{
            float: ["right", "left", "none", "start", "end"]
          }],
          /**
           * Clear
           * @see https://tailwindcss.com/docs/clear
           */
          clear: [{
            clear: ["left", "right", "both", "none", "start", "end"]
          }],
          /**
           * Isolation
           * @see https://tailwindcss.com/docs/isolation
           */
          isolation: ["isolate", "isolation-auto"],
          /**
           * Object Fit
           * @see https://tailwindcss.com/docs/object-fit
           */
          "object-fit": [{
            object: ["contain", "cover", "fill", "none", "scale-down"]
          }],
          /**
           * Object Position
           * @see https://tailwindcss.com/docs/object-position
           */
          "object-position": [{
            object: scalePositionWithArbitrary()
          }],
          /**
           * Overflow
           * @see https://tailwindcss.com/docs/overflow
           */
          overflow: [{
            overflow: scaleOverflow()
          }],
          /**
           * Overflow X
           * @see https://tailwindcss.com/docs/overflow
           */
          "overflow-x": [{
            "overflow-x": scaleOverflow()
          }],
          /**
           * Overflow Y
           * @see https://tailwindcss.com/docs/overflow
           */
          "overflow-y": [{
            "overflow-y": scaleOverflow()
          }],
          /**
           * Overscroll Behavior
           * @see https://tailwindcss.com/docs/overscroll-behavior
           */
          overscroll: [{
            overscroll: scaleOverscroll()
          }],
          /**
           * Overscroll Behavior X
           * @see https://tailwindcss.com/docs/overscroll-behavior
           */
          "overscroll-x": [{
            "overscroll-x": scaleOverscroll()
          }],
          /**
           * Overscroll Behavior Y
           * @see https://tailwindcss.com/docs/overscroll-behavior
           */
          "overscroll-y": [{
            "overscroll-y": scaleOverscroll()
          }],
          /**
           * Position
           * @see https://tailwindcss.com/docs/position
           */
          position: ["static", "fixed", "absolute", "relative", "sticky"],
          /**
           * Inset
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          inset: [{
            inset: scaleInset()
          }],
          /**
           * Inset Inline
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          "inset-x": [{
            "inset-x": scaleInset()
          }],
          /**
           * Inset Block
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          "inset-y": [{
            "inset-y": scaleInset()
          }],
          /**
           * Inset Inline Start
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           * @todo class group will be renamed to `inset-s` in next major release
           */
          start: [{
            "inset-s": scaleInset(),
            /**
             * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-s-*` utilities.
             * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
             */
            start: scaleInset()
          }],
          /**
           * Inset Inline End
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           * @todo class group will be renamed to `inset-e` in next major release
           */
          end: [{
            "inset-e": scaleInset(),
            /**
             * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-e-*` utilities.
             * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
             */
            end: scaleInset()
          }],
          /**
           * Inset Block Start
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          "inset-bs": [{
            "inset-bs": scaleInset()
          }],
          /**
           * Inset Block End
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          "inset-be": [{
            "inset-be": scaleInset()
          }],
          /**
           * Top
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          top: [{
            top: scaleInset()
          }],
          /**
           * Right
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          right: [{
            right: scaleInset()
          }],
          /**
           * Bottom
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          bottom: [{
            bottom: scaleInset()
          }],
          /**
           * Left
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          left: [{
            left: scaleInset()
          }],
          /**
           * Visibility
           * @see https://tailwindcss.com/docs/visibility
           */
          visibility: ["visible", "invisible", "collapse"],
          /**
           * Z-Index
           * @see https://tailwindcss.com/docs/z-index
           */
          z: [{
            z: [isInteger, "auto", isArbitraryVariable, isArbitraryValue]
          }],
          // ------------------------
          // --- Flexbox and Grid ---
          // ------------------------
          /**
           * Flex Basis
           * @see https://tailwindcss.com/docs/flex-basis
           */
          basis: [{
            basis: [isFraction, "full", "auto", themeContainer, ...scaleUnambiguousSpacing()]
          }],
          /**
           * Flex Direction
           * @see https://tailwindcss.com/docs/flex-direction
           */
          "flex-direction": [{
            flex: ["row", "row-reverse", "col", "col-reverse"]
          }],
          /**
           * Flex Wrap
           * @see https://tailwindcss.com/docs/flex-wrap
           */
          "flex-wrap": [{
            flex: ["nowrap", "wrap", "wrap-reverse"]
          }],
          /**
           * Flex
           * @see https://tailwindcss.com/docs/flex
           */
          flex: [{
            flex: [isNumber, isFraction, "auto", "initial", "none", isArbitraryValue]
          }],
          /**
           * Flex Grow
           * @see https://tailwindcss.com/docs/flex-grow
           */
          grow: [{
            grow: ["", isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Flex Shrink
           * @see https://tailwindcss.com/docs/flex-shrink
           */
          shrink: [{
            shrink: ["", isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Order
           * @see https://tailwindcss.com/docs/order
           */
          order: [{
            order: [isInteger, "first", "last", "none", isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Grid Template Columns
           * @see https://tailwindcss.com/docs/grid-template-columns
           */
          "grid-cols": [{
            "grid-cols": scaleGridTemplateColsRows()
          }],
          /**
           * Grid Column Start / End
           * @see https://tailwindcss.com/docs/grid-column
           */
          "col-start-end": [{
            col: scaleGridColRowStartAndEnd()
          }],
          /**
           * Grid Column Start
           * @see https://tailwindcss.com/docs/grid-column
           */
          "col-start": [{
            "col-start": scaleGridColRowStartOrEnd()
          }],
          /**
           * Grid Column End
           * @see https://tailwindcss.com/docs/grid-column
           */
          "col-end": [{
            "col-end": scaleGridColRowStartOrEnd()
          }],
          /**
           * Grid Template Rows
           * @see https://tailwindcss.com/docs/grid-template-rows
           */
          "grid-rows": [{
            "grid-rows": scaleGridTemplateColsRows()
          }],
          /**
           * Grid Row Start / End
           * @see https://tailwindcss.com/docs/grid-row
           */
          "row-start-end": [{
            row: scaleGridColRowStartAndEnd()
          }],
          /**
           * Grid Row Start
           * @see https://tailwindcss.com/docs/grid-row
           */
          "row-start": [{
            "row-start": scaleGridColRowStartOrEnd()
          }],
          /**
           * Grid Row End
           * @see https://tailwindcss.com/docs/grid-row
           */
          "row-end": [{
            "row-end": scaleGridColRowStartOrEnd()
          }],
          /**
           * Grid Auto Flow
           * @see https://tailwindcss.com/docs/grid-auto-flow
           */
          "grid-flow": [{
            "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
          }],
          /**
           * Grid Auto Columns
           * @see https://tailwindcss.com/docs/grid-auto-columns
           */
          "auto-cols": [{
            "auto-cols": scaleGridAutoColsRows()
          }],
          /**
           * Grid Auto Rows
           * @see https://tailwindcss.com/docs/grid-auto-rows
           */
          "auto-rows": [{
            "auto-rows": scaleGridAutoColsRows()
          }],
          /**
           * Gap
           * @see https://tailwindcss.com/docs/gap
           */
          gap: [{
            gap: scaleUnambiguousSpacing()
          }],
          /**
           * Gap X
           * @see https://tailwindcss.com/docs/gap
           */
          "gap-x": [{
            "gap-x": scaleUnambiguousSpacing()
          }],
          /**
           * Gap Y
           * @see https://tailwindcss.com/docs/gap
           */
          "gap-y": [{
            "gap-y": scaleUnambiguousSpacing()
          }],
          /**
           * Justify Content
           * @see https://tailwindcss.com/docs/justify-content
           */
          "justify-content": [{
            justify: [...scaleAlignPrimaryAxis(), "normal"]
          }],
          /**
           * Justify Items
           * @see https://tailwindcss.com/docs/justify-items
           */
          "justify-items": [{
            "justify-items": [...scaleAlignSecondaryAxis(), "normal"]
          }],
          /**
           * Justify Self
           * @see https://tailwindcss.com/docs/justify-self
           */
          "justify-self": [{
            "justify-self": ["auto", ...scaleAlignSecondaryAxis()]
          }],
          /**
           * Align Content
           * @see https://tailwindcss.com/docs/align-content
           */
          "align-content": [{
            content: ["normal", ...scaleAlignPrimaryAxis()]
          }],
          /**
           * Align Items
           * @see https://tailwindcss.com/docs/align-items
           */
          "align-items": [{
            items: [...scaleAlignSecondaryAxis(), {
              baseline: ["", "last"]
            }]
          }],
          /**
           * Align Self
           * @see https://tailwindcss.com/docs/align-self
           */
          "align-self": [{
            self: ["auto", ...scaleAlignSecondaryAxis(), {
              baseline: ["", "last"]
            }]
          }],
          /**
           * Place Content
           * @see https://tailwindcss.com/docs/place-content
           */
          "place-content": [{
            "place-content": scaleAlignPrimaryAxis()
          }],
          /**
           * Place Items
           * @see https://tailwindcss.com/docs/place-items
           */
          "place-items": [{
            "place-items": [...scaleAlignSecondaryAxis(), "baseline"]
          }],
          /**
           * Place Self
           * @see https://tailwindcss.com/docs/place-self
           */
          "place-self": [{
            "place-self": ["auto", ...scaleAlignSecondaryAxis()]
          }],
          // Spacing
          /**
           * Padding
           * @see https://tailwindcss.com/docs/padding
           */
          p: [{
            p: scaleUnambiguousSpacing()
          }],
          /**
           * Padding Inline
           * @see https://tailwindcss.com/docs/padding
           */
          px: [{
            px: scaleUnambiguousSpacing()
          }],
          /**
           * Padding Block
           * @see https://tailwindcss.com/docs/padding
           */
          py: [{
            py: scaleUnambiguousSpacing()
          }],
          /**
           * Padding Inline Start
           * @see https://tailwindcss.com/docs/padding
           */
          ps: [{
            ps: scaleUnambiguousSpacing()
          }],
          /**
           * Padding Inline End
           * @see https://tailwindcss.com/docs/padding
           */
          pe: [{
            pe: scaleUnambiguousSpacing()
          }],
          /**
           * Padding Block Start
           * @see https://tailwindcss.com/docs/padding
           */
          pbs: [{
            pbs: scaleUnambiguousSpacing()
          }],
          /**
           * Padding Block End
           * @see https://tailwindcss.com/docs/padding
           */
          pbe: [{
            pbe: scaleUnambiguousSpacing()
          }],
          /**
           * Padding Top
           * @see https://tailwindcss.com/docs/padding
           */
          pt: [{
            pt: scaleUnambiguousSpacing()
          }],
          /**
           * Padding Right
           * @see https://tailwindcss.com/docs/padding
           */
          pr: [{
            pr: scaleUnambiguousSpacing()
          }],
          /**
           * Padding Bottom
           * @see https://tailwindcss.com/docs/padding
           */
          pb: [{
            pb: scaleUnambiguousSpacing()
          }],
          /**
           * Padding Left
           * @see https://tailwindcss.com/docs/padding
           */
          pl: [{
            pl: scaleUnambiguousSpacing()
          }],
          /**
           * Margin
           * @see https://tailwindcss.com/docs/margin
           */
          m: [{
            m: scaleMargin()
          }],
          /**
           * Margin Inline
           * @see https://tailwindcss.com/docs/margin
           */
          mx: [{
            mx: scaleMargin()
          }],
          /**
           * Margin Block
           * @see https://tailwindcss.com/docs/margin
           */
          my: [{
            my: scaleMargin()
          }],
          /**
           * Margin Inline Start
           * @see https://tailwindcss.com/docs/margin
           */
          ms: [{
            ms: scaleMargin()
          }],
          /**
           * Margin Inline End
           * @see https://tailwindcss.com/docs/margin
           */
          me: [{
            me: scaleMargin()
          }],
          /**
           * Margin Block Start
           * @see https://tailwindcss.com/docs/margin
           */
          mbs: [{
            mbs: scaleMargin()
          }],
          /**
           * Margin Block End
           * @see https://tailwindcss.com/docs/margin
           */
          mbe: [{
            mbe: scaleMargin()
          }],
          /**
           * Margin Top
           * @see https://tailwindcss.com/docs/margin
           */
          mt: [{
            mt: scaleMargin()
          }],
          /**
           * Margin Right
           * @see https://tailwindcss.com/docs/margin
           */
          mr: [{
            mr: scaleMargin()
          }],
          /**
           * Margin Bottom
           * @see https://tailwindcss.com/docs/margin
           */
          mb: [{
            mb: scaleMargin()
          }],
          /**
           * Margin Left
           * @see https://tailwindcss.com/docs/margin
           */
          ml: [{
            ml: scaleMargin()
          }],
          /**
           * Space Between X
           * @see https://tailwindcss.com/docs/margin#adding-space-between-children
           */
          "space-x": [{
            "space-x": scaleUnambiguousSpacing()
          }],
          /**
           * Space Between X Reverse
           * @see https://tailwindcss.com/docs/margin#adding-space-between-children
           */
          "space-x-reverse": ["space-x-reverse"],
          /**
           * Space Between Y
           * @see https://tailwindcss.com/docs/margin#adding-space-between-children
           */
          "space-y": [{
            "space-y": scaleUnambiguousSpacing()
          }],
          /**
           * Space Between Y Reverse
           * @see https://tailwindcss.com/docs/margin#adding-space-between-children
           */
          "space-y-reverse": ["space-y-reverse"],
          // --------------
          // --- Sizing ---
          // --------------
          /**
           * Size
           * @see https://tailwindcss.com/docs/width#setting-both-width-and-height
           */
          size: [{
            size: scaleSizing()
          }],
          /**
           * Inline Size
           * @see https://tailwindcss.com/docs/width
           */
          "inline-size": [{
            inline: ["auto", ...scaleSizingInline()]
          }],
          /**
           * Min-Inline Size
           * @see https://tailwindcss.com/docs/min-width
           */
          "min-inline-size": [{
            "min-inline": ["auto", ...scaleSizingInline()]
          }],
          /**
           * Max-Inline Size
           * @see https://tailwindcss.com/docs/max-width
           */
          "max-inline-size": [{
            "max-inline": ["none", ...scaleSizingInline()]
          }],
          /**
           * Block Size
           * @see https://tailwindcss.com/docs/height
           */
          "block-size": [{
            block: ["auto", ...scaleSizingBlock()]
          }],
          /**
           * Min-Block Size
           * @see https://tailwindcss.com/docs/min-height
           */
          "min-block-size": [{
            "min-block": ["auto", ...scaleSizingBlock()]
          }],
          /**
           * Max-Block Size
           * @see https://tailwindcss.com/docs/max-height
           */
          "max-block-size": [{
            "max-block": ["none", ...scaleSizingBlock()]
          }],
          /**
           * Width
           * @see https://tailwindcss.com/docs/width
           */
          w: [{
            w: [themeContainer, "screen", ...scaleSizing()]
          }],
          /**
           * Min-Width
           * @see https://tailwindcss.com/docs/min-width
           */
          "min-w": [{
            "min-w": [
              themeContainer,
              "screen",
              /** Deprecated. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
              "none",
              ...scaleSizing()
            ]
          }],
          /**
           * Max-Width
           * @see https://tailwindcss.com/docs/max-width
           */
          "max-w": [{
            "max-w": [
              themeContainer,
              "screen",
              "none",
              /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
              "prose",
              /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
              {
                screen: [themeBreakpoint]
              },
              ...scaleSizing()
            ]
          }],
          /**
           * Height
           * @see https://tailwindcss.com/docs/height
           */
          h: [{
            h: ["screen", "lh", ...scaleSizing()]
          }],
          /**
           * Min-Height
           * @see https://tailwindcss.com/docs/min-height
           */
          "min-h": [{
            "min-h": ["screen", "lh", "none", ...scaleSizing()]
          }],
          /**
           * Max-Height
           * @see https://tailwindcss.com/docs/max-height
           */
          "max-h": [{
            "max-h": ["screen", "lh", ...scaleSizing()]
          }],
          // ------------------
          // --- Typography ---
          // ------------------
          /**
           * Font Size
           * @see https://tailwindcss.com/docs/font-size
           */
          "font-size": [{
            text: ["base", themeText, isArbitraryVariableLength, isArbitraryLength]
          }],
          /**
           * Font Smoothing
           * @see https://tailwindcss.com/docs/font-smoothing
           */
          "font-smoothing": ["antialiased", "subpixel-antialiased"],
          /**
           * Font Style
           * @see https://tailwindcss.com/docs/font-style
           */
          "font-style": ["italic", "not-italic"],
          /**
           * Font Weight
           * @see https://tailwindcss.com/docs/font-weight
           */
          "font-weight": [{
            font: [themeFontWeight, isArbitraryVariableWeight, isArbitraryWeight]
          }],
          /**
           * Font Stretch
           * @see https://tailwindcss.com/docs/font-stretch
           */
          "font-stretch": [{
            "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", isPercent, isArbitraryValue]
          }],
          /**
           * Font Family
           * @see https://tailwindcss.com/docs/font-family
           */
          "font-family": [{
            font: [isArbitraryVariableFamilyName, isArbitraryFamilyName, themeFont]
          }],
          /**
           * Font Feature Settings
           * @see https://tailwindcss.com/docs/font-feature-settings
           */
          "font-features": [{
            "font-features": [isArbitraryValue]
          }],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-normal": ["normal-nums"],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-ordinal": ["ordinal"],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-slashed-zero": ["slashed-zero"],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-figure": ["lining-nums", "oldstyle-nums"],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-spacing": ["proportional-nums", "tabular-nums"],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
          /**
           * Letter Spacing
           * @see https://tailwindcss.com/docs/letter-spacing
           */
          tracking: [{
            tracking: [themeTracking, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Line Clamp
           * @see https://tailwindcss.com/docs/line-clamp
           */
          "line-clamp": [{
            "line-clamp": [isNumber, "none", isArbitraryVariable, isArbitraryNumber]
          }],
          /**
           * Line Height
           * @see https://tailwindcss.com/docs/line-height
           */
          leading: [{
            leading: [
              /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
              themeLeading,
              ...scaleUnambiguousSpacing()
            ]
          }],
          /**
           * List Style Image
           * @see https://tailwindcss.com/docs/list-style-image
           */
          "list-image": [{
            "list-image": ["none", isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * List Style Position
           * @see https://tailwindcss.com/docs/list-style-position
           */
          "list-style-position": [{
            list: ["inside", "outside"]
          }],
          /**
           * List Style Type
           * @see https://tailwindcss.com/docs/list-style-type
           */
          "list-style-type": [{
            list: ["disc", "decimal", "none", isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Text Alignment
           * @see https://tailwindcss.com/docs/text-align
           */
          "text-alignment": [{
            text: ["left", "center", "right", "justify", "start", "end"]
          }],
          /**
           * Placeholder Color
           * @deprecated since Tailwind CSS v3.0.0
           * @see https://v3.tailwindcss.com/docs/placeholder-color
           */
          "placeholder-color": [{
            placeholder: scaleColor()
          }],
          /**
           * Text Color
           * @see https://tailwindcss.com/docs/text-color
           */
          "text-color": [{
            text: scaleColor()
          }],
          /**
           * Text Decoration
           * @see https://tailwindcss.com/docs/text-decoration
           */
          "text-decoration": ["underline", "overline", "line-through", "no-underline"],
          /**
           * Text Decoration Style
           * @see https://tailwindcss.com/docs/text-decoration-style
           */
          "text-decoration-style": [{
            decoration: [...scaleLineStyle(), "wavy"]
          }],
          /**
           * Text Decoration Thickness
           * @see https://tailwindcss.com/docs/text-decoration-thickness
           */
          "text-decoration-thickness": [{
            decoration: [isNumber, "from-font", "auto", isArbitraryVariable, isArbitraryLength]
          }],
          /**
           * Text Decoration Color
           * @see https://tailwindcss.com/docs/text-decoration-color
           */
          "text-decoration-color": [{
            decoration: scaleColor()
          }],
          /**
           * Text Underline Offset
           * @see https://tailwindcss.com/docs/text-underline-offset
           */
          "underline-offset": [{
            "underline-offset": [isNumber, "auto", isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Text Transform
           * @see https://tailwindcss.com/docs/text-transform
           */
          "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
          /**
           * Text Overflow
           * @see https://tailwindcss.com/docs/text-overflow
           */
          "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
          /**
           * Text Wrap
           * @see https://tailwindcss.com/docs/text-wrap
           */
          "text-wrap": [{
            text: ["wrap", "nowrap", "balance", "pretty"]
          }],
          /**
           * Text Indent
           * @see https://tailwindcss.com/docs/text-indent
           */
          indent: [{
            indent: scaleUnambiguousSpacing()
          }],
          /**
           * Tab Size
           * @see https://tailwindcss.com/docs/tab-size
           */
          "tab-size": [{
            tab: [isInteger, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Vertical Alignment
           * @see https://tailwindcss.com/docs/vertical-align
           */
          "vertical-align": [{
            align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Whitespace
           * @see https://tailwindcss.com/docs/whitespace
           */
          whitespace: [{
            whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
          }],
          /**
           * Word Break
           * @see https://tailwindcss.com/docs/word-break
           */
          break: [{
            break: ["normal", "words", "all", "keep"]
          }],
          /**
           * Overflow Wrap
           * @see https://tailwindcss.com/docs/overflow-wrap
           */
          wrap: [{
            wrap: ["break-word", "anywhere", "normal"]
          }],
          /**
           * Hyphens
           * @see https://tailwindcss.com/docs/hyphens
           */
          hyphens: [{
            hyphens: ["none", "manual", "auto"]
          }],
          /**
           * Content
           * @see https://tailwindcss.com/docs/content
           */
          content: [{
            content: ["none", isArbitraryVariable, isArbitraryValue]
          }],
          // -------------------
          // --- Backgrounds ---
          // -------------------
          /**
           * Background Attachment
           * @see https://tailwindcss.com/docs/background-attachment
           */
          "bg-attachment": [{
            bg: ["fixed", "local", "scroll"]
          }],
          /**
           * Background Clip
           * @see https://tailwindcss.com/docs/background-clip
           */
          "bg-clip": [{
            "bg-clip": ["border", "padding", "content", "text"]
          }],
          /**
           * Background Origin
           * @see https://tailwindcss.com/docs/background-origin
           */
          "bg-origin": [{
            "bg-origin": ["border", "padding", "content"]
          }],
          /**
           * Background Position
           * @see https://tailwindcss.com/docs/background-position
           */
          "bg-position": [{
            bg: scaleBgPosition()
          }],
          /**
           * Background Repeat
           * @see https://tailwindcss.com/docs/background-repeat
           */
          "bg-repeat": [{
            bg: scaleBgRepeat()
          }],
          /**
           * Background Size
           * @see https://tailwindcss.com/docs/background-size
           */
          "bg-size": [{
            bg: scaleBgSize()
          }],
          /**
           * Background Image
           * @see https://tailwindcss.com/docs/background-image
           */
          "bg-image": [{
            bg: ["none", {
              linear: [{
                to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
              }, isInteger, isArbitraryVariable, isArbitraryValue],
              radial: ["", isArbitraryVariable, isArbitraryValue],
              conic: [isInteger, isArbitraryVariable, isArbitraryValue]
            }, isArbitraryVariableImage, isArbitraryImage]
          }],
          /**
           * Background Color
           * @see https://tailwindcss.com/docs/background-color
           */
          "bg-color": [{
            bg: scaleColor()
          }],
          /**
           * Gradient Color Stops From Position
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-from-pos": [{
            from: scaleGradientStopPosition()
          }],
          /**
           * Gradient Color Stops Via Position
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-via-pos": [{
            via: scaleGradientStopPosition()
          }],
          /**
           * Gradient Color Stops To Position
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-to-pos": [{
            to: scaleGradientStopPosition()
          }],
          /**
           * Gradient Color Stops From
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-from": [{
            from: scaleColor()
          }],
          /**
           * Gradient Color Stops Via
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-via": [{
            via: scaleColor()
          }],
          /**
           * Gradient Color Stops To
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-to": [{
            to: scaleColor()
          }],
          // ---------------
          // --- Borders ---
          // ---------------
          /**
           * Border Radius
           * @see https://tailwindcss.com/docs/border-radius
           */
          rounded: [{
            rounded: scaleRadius()
          }],
          /**
           * Border Radius Start
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-s": [{
            "rounded-s": scaleRadius()
          }],
          /**
           * Border Radius End
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-e": [{
            "rounded-e": scaleRadius()
          }],
          /**
           * Border Radius Top
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-t": [{
            "rounded-t": scaleRadius()
          }],
          /**
           * Border Radius Right
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-r": [{
            "rounded-r": scaleRadius()
          }],
          /**
           * Border Radius Bottom
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-b": [{
            "rounded-b": scaleRadius()
          }],
          /**
           * Border Radius Left
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-l": [{
            "rounded-l": scaleRadius()
          }],
          /**
           * Border Radius Start Start
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-ss": [{
            "rounded-ss": scaleRadius()
          }],
          /**
           * Border Radius Start End
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-se": [{
            "rounded-se": scaleRadius()
          }],
          /**
           * Border Radius End End
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-ee": [{
            "rounded-ee": scaleRadius()
          }],
          /**
           * Border Radius End Start
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-es": [{
            "rounded-es": scaleRadius()
          }],
          /**
           * Border Radius Top Left
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-tl": [{
            "rounded-tl": scaleRadius()
          }],
          /**
           * Border Radius Top Right
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-tr": [{
            "rounded-tr": scaleRadius()
          }],
          /**
           * Border Radius Bottom Right
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-br": [{
            "rounded-br": scaleRadius()
          }],
          /**
           * Border Radius Bottom Left
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-bl": [{
            "rounded-bl": scaleRadius()
          }],
          /**
           * Border Width
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w": [{
            border: scaleBorderWidth()
          }],
          /**
           * Border Width Inline
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-x": [{
            "border-x": scaleBorderWidth()
          }],
          /**
           * Border Width Block
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-y": [{
            "border-y": scaleBorderWidth()
          }],
          /**
           * Border Width Inline Start
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-s": [{
            "border-s": scaleBorderWidth()
          }],
          /**
           * Border Width Inline End
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-e": [{
            "border-e": scaleBorderWidth()
          }],
          /**
           * Border Width Block Start
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-bs": [{
            "border-bs": scaleBorderWidth()
          }],
          /**
           * Border Width Block End
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-be": [{
            "border-be": scaleBorderWidth()
          }],
          /**
           * Border Width Top
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-t": [{
            "border-t": scaleBorderWidth()
          }],
          /**
           * Border Width Right
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-r": [{
            "border-r": scaleBorderWidth()
          }],
          /**
           * Border Width Bottom
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-b": [{
            "border-b": scaleBorderWidth()
          }],
          /**
           * Border Width Left
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-l": [{
            "border-l": scaleBorderWidth()
          }],
          /**
           * Divide Width X
           * @see https://tailwindcss.com/docs/border-width#between-children
           */
          "divide-x": [{
            "divide-x": scaleBorderWidth()
          }],
          /**
           * Divide Width X Reverse
           * @see https://tailwindcss.com/docs/border-width#between-children
           */
          "divide-x-reverse": ["divide-x-reverse"],
          /**
           * Divide Width Y
           * @see https://tailwindcss.com/docs/border-width#between-children
           */
          "divide-y": [{
            "divide-y": scaleBorderWidth()
          }],
          /**
           * Divide Width Y Reverse
           * @see https://tailwindcss.com/docs/border-width#between-children
           */
          "divide-y-reverse": ["divide-y-reverse"],
          /**
           * Border Style
           * @see https://tailwindcss.com/docs/border-style
           */
          "border-style": [{
            border: [...scaleLineStyle(), "hidden", "none"]
          }],
          /**
           * Divide Style
           * @see https://tailwindcss.com/docs/border-style#setting-the-divider-style
           */
          "divide-style": [{
            divide: [...scaleLineStyle(), "hidden", "none"]
          }],
          /**
           * Border Color
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color": [{
            border: scaleColor()
          }],
          /**
           * Border Color Inline
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-x": [{
            "border-x": scaleColor()
          }],
          /**
           * Border Color Block
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-y": [{
            "border-y": scaleColor()
          }],
          /**
           * Border Color Inline Start
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-s": [{
            "border-s": scaleColor()
          }],
          /**
           * Border Color Inline End
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-e": [{
            "border-e": scaleColor()
          }],
          /**
           * Border Color Block Start
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-bs": [{
            "border-bs": scaleColor()
          }],
          /**
           * Border Color Block End
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-be": [{
            "border-be": scaleColor()
          }],
          /**
           * Border Color Top
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-t": [{
            "border-t": scaleColor()
          }],
          /**
           * Border Color Right
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-r": [{
            "border-r": scaleColor()
          }],
          /**
           * Border Color Bottom
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-b": [{
            "border-b": scaleColor()
          }],
          /**
           * Border Color Left
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-l": [{
            "border-l": scaleColor()
          }],
          /**
           * Divide Color
           * @see https://tailwindcss.com/docs/divide-color
           */
          "divide-color": [{
            divide: scaleColor()
          }],
          /**
           * Outline Style
           * @see https://tailwindcss.com/docs/outline-style
           */
          "outline-style": [{
            outline: [...scaleLineStyle(), "none", "hidden"]
          }],
          /**
           * Outline Offset
           * @see https://tailwindcss.com/docs/outline-offset
           */
          "outline-offset": [{
            "outline-offset": [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Outline Width
           * @see https://tailwindcss.com/docs/outline-width
           */
          "outline-w": [{
            outline: ["", isNumber, isArbitraryVariableLength, isArbitraryLength]
          }],
          /**
           * Outline Color
           * @see https://tailwindcss.com/docs/outline-color
           */
          "outline-color": [{
            outline: scaleColor()
          }],
          // ---------------
          // --- Effects ---
          // ---------------
          /**
           * Box Shadow
           * @see https://tailwindcss.com/docs/box-shadow
           */
          shadow: [{
            shadow: [
              // Deprecated since Tailwind CSS v4.0.0
              "",
              "none",
              themeShadow,
              isArbitraryVariableShadow,
              isArbitraryShadow
            ]
          }],
          /**
           * Box Shadow Color
           * @see https://tailwindcss.com/docs/box-shadow#setting-the-shadow-color
           */
          "shadow-color": [{
            shadow: scaleColor()
          }],
          /**
           * Inset Box Shadow
           * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-shadow
           */
          "inset-shadow": [{
            "inset-shadow": ["none", themeInsetShadow, isArbitraryVariableShadow, isArbitraryShadow]
          }],
          /**
           * Inset Box Shadow Color
           * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-shadow-color
           */
          "inset-shadow-color": [{
            "inset-shadow": scaleColor()
          }],
          /**
           * Ring Width
           * @see https://tailwindcss.com/docs/box-shadow#adding-a-ring
           */
          "ring-w": [{
            ring: scaleBorderWidth()
          }],
          /**
           * Ring Width Inset
           * @see https://v3.tailwindcss.com/docs/ring-width#inset-rings
           * @deprecated since Tailwind CSS v4.0.0
           * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
           */
          "ring-w-inset": ["ring-inset"],
          /**
           * Ring Color
           * @see https://tailwindcss.com/docs/box-shadow#setting-the-ring-color
           */
          "ring-color": [{
            ring: scaleColor()
          }],
          /**
           * Ring Offset Width
           * @see https://v3.tailwindcss.com/docs/ring-offset-width
           * @deprecated since Tailwind CSS v4.0.0
           * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
           */
          "ring-offset-w": [{
            "ring-offset": [isNumber, isArbitraryLength]
          }],
          /**
           * Ring Offset Color
           * @see https://v3.tailwindcss.com/docs/ring-offset-color
           * @deprecated since Tailwind CSS v4.0.0
           * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
           */
          "ring-offset-color": [{
            "ring-offset": scaleColor()
          }],
          /**
           * Inset Ring Width
           * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-ring
           */
          "inset-ring-w": [{
            "inset-ring": scaleBorderWidth()
          }],
          /**
           * Inset Ring Color
           * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-ring-color
           */
          "inset-ring-color": [{
            "inset-ring": scaleColor()
          }],
          /**
           * Text Shadow
           * @see https://tailwindcss.com/docs/text-shadow
           */
          "text-shadow": [{
            "text-shadow": ["none", themeTextShadow, isArbitraryVariableShadow, isArbitraryShadow]
          }],
          /**
           * Text Shadow Color
           * @see https://tailwindcss.com/docs/text-shadow#setting-the-shadow-color
           */
          "text-shadow-color": [{
            "text-shadow": scaleColor()
          }],
          /**
           * Opacity
           * @see https://tailwindcss.com/docs/opacity
           */
          opacity: [{
            opacity: [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Mix Blend Mode
           * @see https://tailwindcss.com/docs/mix-blend-mode
           */
          "mix-blend": [{
            "mix-blend": [...scaleBlendMode(), "plus-darker", "plus-lighter"]
          }],
          /**
           * Background Blend Mode
           * @see https://tailwindcss.com/docs/background-blend-mode
           */
          "bg-blend": [{
            "bg-blend": scaleBlendMode()
          }],
          /**
           * Mask Clip
           * @see https://tailwindcss.com/docs/mask-clip
           */
          "mask-clip": [{
            "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
          }, "mask-no-clip"],
          /**
           * Mask Composite
           * @see https://tailwindcss.com/docs/mask-composite
           */
          "mask-composite": [{
            mask: ["add", "subtract", "intersect", "exclude"]
          }],
          /**
           * Mask Image
           * @see https://tailwindcss.com/docs/mask-image
           */
          "mask-image-linear-pos": [{
            "mask-linear": [isNumber]
          }],
          "mask-image-linear-from-pos": [{
            "mask-linear-from": scaleMaskImagePosition()
          }],
          "mask-image-linear-to-pos": [{
            "mask-linear-to": scaleMaskImagePosition()
          }],
          "mask-image-linear-from-color": [{
            "mask-linear-from": scaleColor()
          }],
          "mask-image-linear-to-color": [{
            "mask-linear-to": scaleColor()
          }],
          "mask-image-t-from-pos": [{
            "mask-t-from": scaleMaskImagePosition()
          }],
          "mask-image-t-to-pos": [{
            "mask-t-to": scaleMaskImagePosition()
          }],
          "mask-image-t-from-color": [{
            "mask-t-from": scaleColor()
          }],
          "mask-image-t-to-color": [{
            "mask-t-to": scaleColor()
          }],
          "mask-image-r-from-pos": [{
            "mask-r-from": scaleMaskImagePosition()
          }],
          "mask-image-r-to-pos": [{
            "mask-r-to": scaleMaskImagePosition()
          }],
          "mask-image-r-from-color": [{
            "mask-r-from": scaleColor()
          }],
          "mask-image-r-to-color": [{
            "mask-r-to": scaleColor()
          }],
          "mask-image-b-from-pos": [{
            "mask-b-from": scaleMaskImagePosition()
          }],
          "mask-image-b-to-pos": [{
            "mask-b-to": scaleMaskImagePosition()
          }],
          "mask-image-b-from-color": [{
            "mask-b-from": scaleColor()
          }],
          "mask-image-b-to-color": [{
            "mask-b-to": scaleColor()
          }],
          "mask-image-l-from-pos": [{
            "mask-l-from": scaleMaskImagePosition()
          }],
          "mask-image-l-to-pos": [{
            "mask-l-to": scaleMaskImagePosition()
          }],
          "mask-image-l-from-color": [{
            "mask-l-from": scaleColor()
          }],
          "mask-image-l-to-color": [{
            "mask-l-to": scaleColor()
          }],
          "mask-image-x-from-pos": [{
            "mask-x-from": scaleMaskImagePosition()
          }],
          "mask-image-x-to-pos": [{
            "mask-x-to": scaleMaskImagePosition()
          }],
          "mask-image-x-from-color": [{
            "mask-x-from": scaleColor()
          }],
          "mask-image-x-to-color": [{
            "mask-x-to": scaleColor()
          }],
          "mask-image-y-from-pos": [{
            "mask-y-from": scaleMaskImagePosition()
          }],
          "mask-image-y-to-pos": [{
            "mask-y-to": scaleMaskImagePosition()
          }],
          "mask-image-y-from-color": [{
            "mask-y-from": scaleColor()
          }],
          "mask-image-y-to-color": [{
            "mask-y-to": scaleColor()
          }],
          "mask-image-radial": [{
            "mask-radial": [isArbitraryVariable, isArbitraryValue]
          }],
          "mask-image-radial-from-pos": [{
            "mask-radial-from": scaleMaskImagePosition()
          }],
          "mask-image-radial-to-pos": [{
            "mask-radial-to": scaleMaskImagePosition()
          }],
          "mask-image-radial-from-color": [{
            "mask-radial-from": scaleColor()
          }],
          "mask-image-radial-to-color": [{
            "mask-radial-to": scaleColor()
          }],
          "mask-image-radial-shape": [{
            "mask-radial": ["circle", "ellipse"]
          }],
          "mask-image-radial-size": [{
            "mask-radial": [{
              closest: ["side", "corner"],
              farthest: ["side", "corner"]
            }]
          }],
          "mask-image-radial-pos": [{
            "mask-radial-at": scalePosition()
          }],
          "mask-image-conic-pos": [{
            "mask-conic": [isNumber]
          }],
          "mask-image-conic-from-pos": [{
            "mask-conic-from": scaleMaskImagePosition()
          }],
          "mask-image-conic-to-pos": [{
            "mask-conic-to": scaleMaskImagePosition()
          }],
          "mask-image-conic-from-color": [{
            "mask-conic-from": scaleColor()
          }],
          "mask-image-conic-to-color": [{
            "mask-conic-to": scaleColor()
          }],
          /**
           * Mask Mode
           * @see https://tailwindcss.com/docs/mask-mode
           */
          "mask-mode": [{
            mask: ["alpha", "luminance", "match"]
          }],
          /**
           * Mask Origin
           * @see https://tailwindcss.com/docs/mask-origin
           */
          "mask-origin": [{
            "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
          }],
          /**
           * Mask Position
           * @see https://tailwindcss.com/docs/mask-position
           */
          "mask-position": [{
            mask: scaleBgPosition()
          }],
          /**
           * Mask Repeat
           * @see https://tailwindcss.com/docs/mask-repeat
           */
          "mask-repeat": [{
            mask: scaleBgRepeat()
          }],
          /**
           * Mask Size
           * @see https://tailwindcss.com/docs/mask-size
           */
          "mask-size": [{
            mask: scaleBgSize()
          }],
          /**
           * Mask Type
           * @see https://tailwindcss.com/docs/mask-type
           */
          "mask-type": [{
            "mask-type": ["alpha", "luminance"]
          }],
          /**
           * Mask Image
           * @see https://tailwindcss.com/docs/mask-image
           */
          "mask-image": [{
            mask: ["none", isArbitraryVariable, isArbitraryValue]
          }],
          // ---------------
          // --- Filters ---
          // ---------------
          /**
           * Filter
           * @see https://tailwindcss.com/docs/filter
           */
          filter: [{
            filter: [
              // Deprecated since Tailwind CSS v3.0.0
              "",
              "none",
              isArbitraryVariable,
              isArbitraryValue
            ]
          }],
          /**
           * Blur
           * @see https://tailwindcss.com/docs/blur
           */
          blur: [{
            blur: scaleBlur()
          }],
          /**
           * Brightness
           * @see https://tailwindcss.com/docs/brightness
           */
          brightness: [{
            brightness: [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Contrast
           * @see https://tailwindcss.com/docs/contrast
           */
          contrast: [{
            contrast: [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Drop Shadow
           * @see https://tailwindcss.com/docs/drop-shadow
           */
          "drop-shadow": [{
            "drop-shadow": [
              // Deprecated since Tailwind CSS v4.0.0
              "",
              "none",
              themeDropShadow,
              isArbitraryVariableShadow,
              isArbitraryShadow
            ]
          }],
          /**
           * Drop Shadow Color
           * @see https://tailwindcss.com/docs/filter-drop-shadow#setting-the-shadow-color
           */
          "drop-shadow-color": [{
            "drop-shadow": scaleColor()
          }],
          /**
           * Grayscale
           * @see https://tailwindcss.com/docs/grayscale
           */
          grayscale: [{
            grayscale: ["", isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Hue Rotate
           * @see https://tailwindcss.com/docs/hue-rotate
           */
          "hue-rotate": [{
            "hue-rotate": [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Invert
           * @see https://tailwindcss.com/docs/invert
           */
          invert: [{
            invert: ["", isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Saturate
           * @see https://tailwindcss.com/docs/saturate
           */
          saturate: [{
            saturate: [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Sepia
           * @see https://tailwindcss.com/docs/sepia
           */
          sepia: [{
            sepia: ["", isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Backdrop Filter
           * @see https://tailwindcss.com/docs/backdrop-filter
           */
          "backdrop-filter": [{
            "backdrop-filter": [
              // Deprecated since Tailwind CSS v3.0.0
              "",
              "none",
              isArbitraryVariable,
              isArbitraryValue
            ]
          }],
          /**
           * Backdrop Blur
           * @see https://tailwindcss.com/docs/backdrop-blur
           */
          "backdrop-blur": [{
            "backdrop-blur": scaleBlur()
          }],
          /**
           * Backdrop Brightness
           * @see https://tailwindcss.com/docs/backdrop-brightness
           */
          "backdrop-brightness": [{
            "backdrop-brightness": [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Backdrop Contrast
           * @see https://tailwindcss.com/docs/backdrop-contrast
           */
          "backdrop-contrast": [{
            "backdrop-contrast": [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Backdrop Grayscale
           * @see https://tailwindcss.com/docs/backdrop-grayscale
           */
          "backdrop-grayscale": [{
            "backdrop-grayscale": ["", isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Backdrop Hue Rotate
           * @see https://tailwindcss.com/docs/backdrop-hue-rotate
           */
          "backdrop-hue-rotate": [{
            "backdrop-hue-rotate": [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Backdrop Invert
           * @see https://tailwindcss.com/docs/backdrop-invert
           */
          "backdrop-invert": [{
            "backdrop-invert": ["", isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Backdrop Opacity
           * @see https://tailwindcss.com/docs/backdrop-opacity
           */
          "backdrop-opacity": [{
            "backdrop-opacity": [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Backdrop Saturate
           * @see https://tailwindcss.com/docs/backdrop-saturate
           */
          "backdrop-saturate": [{
            "backdrop-saturate": [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Backdrop Sepia
           * @see https://tailwindcss.com/docs/backdrop-sepia
           */
          "backdrop-sepia": [{
            "backdrop-sepia": ["", isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          // --------------
          // --- Tables ---
          // --------------
          /**
           * Border Collapse
           * @see https://tailwindcss.com/docs/border-collapse
           */
          "border-collapse": [{
            border: ["collapse", "separate"]
          }],
          /**
           * Border Spacing
           * @see https://tailwindcss.com/docs/border-spacing
           */
          "border-spacing": [{
            "border-spacing": scaleUnambiguousSpacing()
          }],
          /**
           * Border Spacing X
           * @see https://tailwindcss.com/docs/border-spacing
           */
          "border-spacing-x": [{
            "border-spacing-x": scaleUnambiguousSpacing()
          }],
          /**
           * Border Spacing Y
           * @see https://tailwindcss.com/docs/border-spacing
           */
          "border-spacing-y": [{
            "border-spacing-y": scaleUnambiguousSpacing()
          }],
          /**
           * Table Layout
           * @see https://tailwindcss.com/docs/table-layout
           */
          "table-layout": [{
            table: ["auto", "fixed"]
          }],
          /**
           * Caption Side
           * @see https://tailwindcss.com/docs/caption-side
           */
          caption: [{
            caption: ["top", "bottom"]
          }],
          // ---------------------------------
          // --- Transitions and Animation ---
          // ---------------------------------
          /**
           * Transition Property
           * @see https://tailwindcss.com/docs/transition-property
           */
          transition: [{
            transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Transition Behavior
           * @see https://tailwindcss.com/docs/transition-behavior
           */
          "transition-behavior": [{
            transition: ["normal", "discrete"]
          }],
          /**
           * Transition Duration
           * @see https://tailwindcss.com/docs/transition-duration
           */
          duration: [{
            duration: [isNumber, "initial", isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Transition Timing Function
           * @see https://tailwindcss.com/docs/transition-timing-function
           */
          ease: [{
            ease: ["linear", "initial", themeEase, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Transition Delay
           * @see https://tailwindcss.com/docs/transition-delay
           */
          delay: [{
            delay: [isNumber, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Animation
           * @see https://tailwindcss.com/docs/animation
           */
          animate: [{
            animate: ["none", themeAnimate, isArbitraryVariable, isArbitraryValue]
          }],
          // ------------------
          // --- Transforms ---
          // ------------------
          /**
           * Backface Visibility
           * @see https://tailwindcss.com/docs/backface-visibility
           */
          backface: [{
            backface: ["hidden", "visible"]
          }],
          /**
           * Perspective
           * @see https://tailwindcss.com/docs/perspective
           */
          perspective: [{
            perspective: [themePerspective, isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Perspective Origin
           * @see https://tailwindcss.com/docs/perspective-origin
           */
          "perspective-origin": [{
            "perspective-origin": scalePositionWithArbitrary()
          }],
          /**
           * Rotate
           * @see https://tailwindcss.com/docs/rotate
           */
          rotate: [{
            rotate: scaleRotate()
          }],
          /**
           * Rotate X
           * @see https://tailwindcss.com/docs/rotate
           */
          "rotate-x": [{
            "rotate-x": scaleRotate()
          }],
          /**
           * Rotate Y
           * @see https://tailwindcss.com/docs/rotate
           */
          "rotate-y": [{
            "rotate-y": scaleRotate()
          }],
          /**
           * Rotate Z
           * @see https://tailwindcss.com/docs/rotate
           */
          "rotate-z": [{
            "rotate-z": scaleRotate()
          }],
          /**
           * Scale
           * @see https://tailwindcss.com/docs/scale
           */
          scale: [{
            scale: scaleScale()
          }],
          /**
           * Scale X
           * @see https://tailwindcss.com/docs/scale
           */
          "scale-x": [{
            "scale-x": scaleScale()
          }],
          /**
           * Scale Y
           * @see https://tailwindcss.com/docs/scale
           */
          "scale-y": [{
            "scale-y": scaleScale()
          }],
          /**
           * Scale Z
           * @see https://tailwindcss.com/docs/scale
           */
          "scale-z": [{
            "scale-z": scaleScale()
          }],
          /**
           * Scale 3D
           * @see https://tailwindcss.com/docs/scale
           */
          "scale-3d": ["scale-3d"],
          /**
           * Skew
           * @see https://tailwindcss.com/docs/skew
           */
          skew: [{
            skew: scaleSkew()
          }],
          /**
           * Skew X
           * @see https://tailwindcss.com/docs/skew
           */
          "skew-x": [{
            "skew-x": scaleSkew()
          }],
          /**
           * Skew Y
           * @see https://tailwindcss.com/docs/skew
           */
          "skew-y": [{
            "skew-y": scaleSkew()
          }],
          /**
           * Transform
           * @see https://tailwindcss.com/docs/transform
           */
          transform: [{
            transform: [isArbitraryVariable, isArbitraryValue, "", "none", "gpu", "cpu"]
          }],
          /**
           * Transform Origin
           * @see https://tailwindcss.com/docs/transform-origin
           */
          "transform-origin": [{
            origin: scalePositionWithArbitrary()
          }],
          /**
           * Transform Style
           * @see https://tailwindcss.com/docs/transform-style
           */
          "transform-style": [{
            transform: ["3d", "flat"]
          }],
          /**
           * Translate
           * @see https://tailwindcss.com/docs/translate
           */
          translate: [{
            translate: scaleTranslate()
          }],
          /**
           * Translate X
           * @see https://tailwindcss.com/docs/translate
           */
          "translate-x": [{
            "translate-x": scaleTranslate()
          }],
          /**
           * Translate Y
           * @see https://tailwindcss.com/docs/translate
           */
          "translate-y": [{
            "translate-y": scaleTranslate()
          }],
          /**
           * Translate Z
           * @see https://tailwindcss.com/docs/translate
           */
          "translate-z": [{
            "translate-z": scaleTranslate()
          }],
          /**
           * Translate None
           * @see https://tailwindcss.com/docs/translate
           */
          "translate-none": ["translate-none"],
          /**
           * Zoom
           * @see https://tailwindcss.com/docs/zoom
           */
          zoom: [{
            zoom: [isInteger, isArbitraryVariable, isArbitraryValue]
          }],
          // ---------------------
          // --- Interactivity ---
          // ---------------------
          /**
           * Accent Color
           * @see https://tailwindcss.com/docs/accent-color
           */
          accent: [{
            accent: scaleColor()
          }],
          /**
           * Appearance
           * @see https://tailwindcss.com/docs/appearance
           */
          appearance: [{
            appearance: ["none", "auto"]
          }],
          /**
           * Caret Color
           * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
           */
          "caret-color": [{
            caret: scaleColor()
          }],
          /**
           * Color Scheme
           * @see https://tailwindcss.com/docs/color-scheme
           */
          "color-scheme": [{
            scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
          }],
          /**
           * Cursor
           * @see https://tailwindcss.com/docs/cursor
           */
          cursor: [{
            cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryVariable, isArbitraryValue]
          }],
          /**
           * Field Sizing
           * @see https://tailwindcss.com/docs/field-sizing
           */
          "field-sizing": [{
            "field-sizing": ["fixed", "content"]
          }],
          /**
           * Pointer Events
           * @see https://tailwindcss.com/docs/pointer-events
           */
          "pointer-events": [{
            "pointer-events": ["auto", "none"]
          }],
          /**
           * Resize
           * @see https://tailwindcss.com/docs/resize
           */
          resize: [{
            resize: ["none", "", "y", "x"]
          }],
          /**
           * Scroll Behavior
           * @see https://tailwindcss.com/docs/scroll-behavior
           */
          "scroll-behavior": [{
            scroll: ["auto", "smooth"]
          }],
          /**
           * Scrollbar Thumb Color
           * @see https://tailwindcss.com/docs/scrollbar-color
           */
          "scrollbar-thumb-color": [{
            "scrollbar-thumb": scaleColor()
          }],
          /**
           * Scrollbar Track Color
           * @see https://tailwindcss.com/docs/scrollbar-color
           */
          "scrollbar-track-color": [{
            "scrollbar-track": scaleColor()
          }],
          /**
           * Scrollbar Gutter
           * @see https://tailwindcss.com/docs/scrollbar-gutter
           */
          "scrollbar-gutter": [{
            "scrollbar-gutter": ["auto", "stable", "both"]
          }],
          /**
           * Scrollbar Width
           * @see https://tailwindcss.com/docs/scrollbar-width
           */
          "scrollbar-w": [{
            scrollbar: ["auto", "thin", "none"]
          }],
          /**
           * Scroll Margin
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-m": [{
            "scroll-m": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Margin Inline
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-mx": [{
            "scroll-mx": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Margin Block
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-my": [{
            "scroll-my": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Margin Inline Start
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-ms": [{
            "scroll-ms": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Margin Inline End
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-me": [{
            "scroll-me": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Margin Block Start
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-mbs": [{
            "scroll-mbs": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Margin Block End
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-mbe": [{
            "scroll-mbe": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Margin Top
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-mt": [{
            "scroll-mt": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Margin Right
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-mr": [{
            "scroll-mr": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Margin Bottom
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-mb": [{
            "scroll-mb": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Margin Left
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-ml": [{
            "scroll-ml": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-p": [{
            "scroll-p": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding Inline
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-px": [{
            "scroll-px": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding Block
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-py": [{
            "scroll-py": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding Inline Start
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-ps": [{
            "scroll-ps": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding Inline End
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pe": [{
            "scroll-pe": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding Block Start
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pbs": [{
            "scroll-pbs": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding Block End
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pbe": [{
            "scroll-pbe": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding Top
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pt": [{
            "scroll-pt": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding Right
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pr": [{
            "scroll-pr": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding Bottom
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pb": [{
            "scroll-pb": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Padding Left
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pl": [{
            "scroll-pl": scaleUnambiguousSpacing()
          }],
          /**
           * Scroll Snap Align
           * @see https://tailwindcss.com/docs/scroll-snap-align
           */
          "snap-align": [{
            snap: ["start", "end", "center", "align-none"]
          }],
          /**
           * Scroll Snap Stop
           * @see https://tailwindcss.com/docs/scroll-snap-stop
           */
          "snap-stop": [{
            snap: ["normal", "always"]
          }],
          /**
           * Scroll Snap Type
           * @see https://tailwindcss.com/docs/scroll-snap-type
           */
          "snap-type": [{
            snap: ["none", "x", "y", "both"]
          }],
          /**
           * Scroll Snap Type Strictness
           * @see https://tailwindcss.com/docs/scroll-snap-type
           */
          "snap-strictness": [{
            snap: ["mandatory", "proximity"]
          }],
          /**
           * Touch Action
           * @see https://tailwindcss.com/docs/touch-action
           */
          touch: [{
            touch: ["auto", "none", "manipulation"]
          }],
          /**
           * Touch Action X
           * @see https://tailwindcss.com/docs/touch-action
           */
          "touch-x": [{
            "touch-pan": ["x", "left", "right"]
          }],
          /**
           * Touch Action Y
           * @see https://tailwindcss.com/docs/touch-action
           */
          "touch-y": [{
            "touch-pan": ["y", "up", "down"]
          }],
          /**
           * Touch Action Pinch Zoom
           * @see https://tailwindcss.com/docs/touch-action
           */
          "touch-pz": ["touch-pinch-zoom"],
          /**
           * User Select
           * @see https://tailwindcss.com/docs/user-select
           */
          select: [{
            select: ["none", "text", "all", "auto"]
          }],
          /**
           * Will Change
           * @see https://tailwindcss.com/docs/will-change
           */
          "will-change": [{
            "will-change": ["auto", "scroll", "contents", "transform", isArbitraryVariable, isArbitraryValue]
          }],
          // -----------
          // --- SVG ---
          // -----------
          /**
           * Fill
           * @see https://tailwindcss.com/docs/fill
           */
          fill: [{
            fill: ["none", ...scaleColor()]
          }],
          /**
           * Stroke Width
           * @see https://tailwindcss.com/docs/stroke-width
           */
          "stroke-w": [{
            stroke: [isNumber, isArbitraryVariableLength, isArbitraryLength, isArbitraryNumber]
          }],
          /**
           * Stroke
           * @see https://tailwindcss.com/docs/stroke
           */
          stroke: [{
            stroke: ["none", ...scaleColor()]
          }],
          // ---------------------
          // --- Accessibility ---
          // ---------------------
          /**
           * Forced Color Adjust
           * @see https://tailwindcss.com/docs/forced-color-adjust
           */
          "forced-color-adjust": [{
            "forced-color-adjust": ["auto", "none"]
          }]
        },
        conflictingClassGroups: {
          "container-named": ["container-type"],
          overflow: ["overflow-x", "overflow-y"],
          overscroll: ["overscroll-x", "overscroll-y"],
          inset: ["inset-x", "inset-y", "inset-bs", "inset-be", "start", "end", "top", "right", "bottom", "left"],
          "inset-x": ["right", "left"],
          "inset-y": ["top", "bottom"],
          flex: ["basis", "grow", "shrink"],
          gap: ["gap-x", "gap-y"],
          p: ["px", "py", "ps", "pe", "pbs", "pbe", "pt", "pr", "pb", "pl"],
          px: ["pr", "pl"],
          py: ["pt", "pb"],
          m: ["mx", "my", "ms", "me", "mbs", "mbe", "mt", "mr", "mb", "ml"],
          mx: ["mr", "ml"],
          my: ["mt", "mb"],
          size: ["w", "h"],
          "font-size": ["leading"],
          "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
          "fvn-ordinal": ["fvn-normal"],
          "fvn-slashed-zero": ["fvn-normal"],
          "fvn-figure": ["fvn-normal"],
          "fvn-spacing": ["fvn-normal"],
          "fvn-fraction": ["fvn-normal"],
          "line-clamp": ["display", "overflow"],
          rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
          "rounded-s": ["rounded-ss", "rounded-es"],
          "rounded-e": ["rounded-se", "rounded-ee"],
          "rounded-t": ["rounded-tl", "rounded-tr"],
          "rounded-r": ["rounded-tr", "rounded-br"],
          "rounded-b": ["rounded-br", "rounded-bl"],
          "rounded-l": ["rounded-tl", "rounded-bl"],
          "border-spacing": ["border-spacing-x", "border-spacing-y"],
          "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-bs", "border-w-be", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
          "border-w-x": ["border-w-r", "border-w-l"],
          "border-w-y": ["border-w-t", "border-w-b"],
          "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-bs", "border-color-be", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
          "border-color-x": ["border-color-r", "border-color-l"],
          "border-color-y": ["border-color-t", "border-color-b"],
          translate: ["translate-x", "translate-y", "translate-none"],
          "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
          "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mbs", "scroll-mbe", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
          "scroll-mx": ["scroll-mr", "scroll-ml"],
          "scroll-my": ["scroll-mt", "scroll-mb"],
          "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pbs", "scroll-pbe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
          "scroll-px": ["scroll-pr", "scroll-pl"],
          "scroll-py": ["scroll-pt", "scroll-pb"],
          touch: ["touch-x", "touch-y", "touch-pz"],
          "touch-x": ["touch"],
          "touch-y": ["touch"],
          "touch-pz": ["touch"]
        },
        conflictingClassGroupModifiers: {
          "font-size": ["leading"]
        },
        postfixLookupClassGroups: ["container-type"],
        orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
      };
    };
    var mergeConfigs = (baseConfig, {
      cacheSize,
      prefix,
      experimentalParseClassName,
      extend = {},
      override = {}
    }) => {
      overrideProperty(baseConfig, "cacheSize", cacheSize);
      overrideProperty(baseConfig, "prefix", prefix);
      overrideProperty(baseConfig, "experimentalParseClassName", experimentalParseClassName);
      overrideConfigProperties(baseConfig.theme, override.theme);
      overrideConfigProperties(baseConfig.classGroups, override.classGroups);
      overrideConfigProperties(baseConfig.conflictingClassGroups, override.conflictingClassGroups);
      overrideConfigProperties(baseConfig.conflictingClassGroupModifiers, override.conflictingClassGroupModifiers);
      overrideProperty(baseConfig, "postfixLookupClassGroups", override.postfixLookupClassGroups);
      overrideProperty(baseConfig, "orderSensitiveModifiers", override.orderSensitiveModifiers);
      mergeConfigProperties(baseConfig.theme, extend.theme);
      mergeConfigProperties(baseConfig.classGroups, extend.classGroups);
      mergeConfigProperties(baseConfig.conflictingClassGroups, extend.conflictingClassGroups);
      mergeConfigProperties(baseConfig.conflictingClassGroupModifiers, extend.conflictingClassGroupModifiers);
      mergeArrayProperties(baseConfig, extend, "postfixLookupClassGroups");
      mergeArrayProperties(baseConfig, extend, "orderSensitiveModifiers");
      return baseConfig;
    };
    var overrideProperty = (baseObject, overrideKey, overrideValue) => {
      if (overrideValue !== void 0) {
        baseObject[overrideKey] = overrideValue;
      }
    };
    var overrideConfigProperties = (baseObject, overrideObject) => {
      if (overrideObject) {
        for (const key in overrideObject) {
          overrideProperty(baseObject, key, overrideObject[key]);
        }
      }
    };
    var mergeConfigProperties = (baseObject, mergeObject) => {
      if (mergeObject) {
        for (const key in mergeObject) {
          mergeArrayProperties(baseObject, mergeObject, key);
        }
      }
    };
    var mergeArrayProperties = (baseObject, mergeObject, key) => {
      const mergeValue = mergeObject[key];
      if (mergeValue !== void 0) {
        baseObject[key] = baseObject[key] ? baseObject[key].concat(mergeValue) : mergeValue;
      }
    };
    var extendTailwindMerge = (configExtension, ...createConfig) => typeof configExtension === "function" ? createTailwindMerge(getDefaultConfig, configExtension, ...createConfig) : createTailwindMerge(() => mergeConfigs(getDefaultConfig(), configExtension), ...createConfig);
    var twMerge2 = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);
    exports.createTailwindMerge = createTailwindMerge;
    exports.extendTailwindMerge = extendTailwindMerge;
    exports.fromTheme = fromTheme;
    exports.getDefaultConfig = getDefaultConfig;
    exports.mergeConfigs = mergeConfigs;
    exports.twJoin = twJoin;
    exports.twMerge = twMerge2;
    exports.validators = validators;
  }
});

// outputs/aplyd-academy-sprint/curriculum-authoring/authoring-candidate/academy-authoring-ui.tsx
import { useEffect as useEffect13, useMemo as useMemo7, useState as useState11 } from "react";

// work/aplyd-academy/node_modules/lucide-react/dist/esm/createLucideIcon.mjs
import { forwardRef as forwardRef2, createElement as createElement3 } from "react";

// work/aplyd-academy/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs
var mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();

// work/aplyd-academy/node_modules/lucide-react/dist/esm/shared/src/utils/toKebabCase.mjs
var toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();

// work/aplyd-academy/node_modules/lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs
var toCamelCase = (string) => string.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
);

// work/aplyd-academy/node_modules/lucide-react/dist/esm/shared/src/utils/toPascalCase.mjs
var toPascalCase = (string) => {
  const camelCase = toCamelCase(string);
  return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};

// work/aplyd-academy/node_modules/lucide-react/dist/esm/Icon.mjs
import { forwardRef, createElement as createElement2 } from "react";

// work/aplyd-academy/node_modules/lucide-react/dist/esm/defaultAttributes.mjs
var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};

// work/aplyd-academy/node_modules/lucide-react/dist/esm/shared/src/utils/hasA11yProp.mjs
var hasA11yProp = (props) => {
  for (const prop in props) {
    if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
      return true;
    }
  }
  return false;
};

// work/aplyd-academy/node_modules/lucide-react/dist/esm/context.mjs
import { createContext, useContext, useMemo, createElement } from "react";
var LucideContext = createContext({});
var useLucideContext = () => useContext(LucideContext);

// work/aplyd-academy/node_modules/lucide-react/dist/esm/Icon.mjs
var Icon = forwardRef(
  ({ color, size, strokeWidth, absoluteStrokeWidth, className = "", children, iconNode, ...rest }, ref) => {
    const {
      size: contextSize = 24,
      strokeWidth: contextStrokeWidth = 2,
      absoluteStrokeWidth: contextAbsoluteStrokeWidth = false,
      color: contextColor = "currentColor",
      className: contextClass = ""
    } = useLucideContext() ?? {};
    const calculatedStrokeWidth = absoluteStrokeWidth ?? contextAbsoluteStrokeWidth ? Number(strokeWidth ?? contextStrokeWidth) * 24 / Number(size ?? contextSize) : strokeWidth ?? contextStrokeWidth;
    return createElement2(
      "svg",
      {
        ref,
        ...defaultAttributes,
        width: size ?? contextSize ?? defaultAttributes.width,
        height: size ?? contextSize ?? defaultAttributes.height,
        stroke: color ?? contextColor,
        strokeWidth: calculatedStrokeWidth,
        className: mergeClasses("lucide", contextClass, className),
        ...!children && !hasA11yProp(rest) && { "aria-hidden": "true" },
        ...rest
      },
      [
        ...iconNode.map(([tag, attrs]) => createElement2(tag, attrs)),
        ...Array.isArray(children) ? children : [children]
      ]
    );
  }
);

// work/aplyd-academy/node_modules/lucide-react/dist/esm/createLucideIcon.mjs
var createLucideIcon = (iconName, iconNode) => {
  const Component = forwardRef2(
    ({ className, ...props }, ref) => createElement3(Icon, {
      ref,
      iconNode,
      className: mergeClasses(
        `lucide-${toKebabCase(toPascalCase(iconName))}`,
        `lucide-${iconName}`,
        className
      ),
      ...props
    })
  );
  Component.displayName = toPascalCase(iconName);
  return Component;
};

// work/aplyd-academy/node_modules/lucide-react/dist/esm/icons/book-open.mjs
var __iconNode = [
  ["path", { d: "M12 5v16", key: "1f6ucr" }],
  [
    "path",
    {
      d: "M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z",
      key: "1fyvmf"
    }
  ]
];
var BookOpen = createLucideIcon("book-open", __iconNode);

// work/aplyd-academy/node_modules/lucide-react/dist/esm/icons/copy.mjs
var __iconNode2 = [
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
];
var Copy = createLucideIcon("copy", __iconNode2);

// work/aplyd-academy/node_modules/lucide-react/dist/esm/icons/file-check-corner.mjs
var __iconNode3 = [
  [
    "path",
    {
      d: "M10.5 22H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v6",
      key: "g5mvt7"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m14 20 2 2 4-4", key: "15kota" }]
];
var FileCheckCorner = createLucideIcon("file-check-corner", __iconNode3);

// work/aplyd-academy/node_modules/lucide-react/dist/esm/icons/lock-keyhole.mjs
var __iconNode4 = [
  ["circle", { cx: "12", cy: "16", r: "1", key: "1au0dj" }],
  ["rect", { x: "3", y: "10", width: "18", height: "12", rx: "2", key: "6s8ecr" }],
  ["path", { d: "M7 10V7a5 5 0 0 1 10 0v3", key: "1pqi11" }]
];
var LockKeyhole = createLucideIcon("lock-keyhole", __iconNode4);

// work/aplyd-academy/node_modules/lucide-react/dist/esm/icons/shield-check.mjs
var __iconNode5 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
var ShieldCheck = createLucideIcon("shield-check", __iconNode5);

// work/aplyd-academy/node_modules/lucide-react/dist/esm/icons/x.mjs
var __iconNode6 = [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
];
var X = createLucideIcon("x", __iconNode6);

// work/aplyd-academy/node_modules/clsx/dist/clsx.mjs
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}

// work/aplyd-academy/node_modules/class-variance-authority/dist/index.mjs
var falsyToString = (value) => typeof value === "boolean" ? `${value}` : value === 0 ? "0" : value;
var cx = clsx;
var cva = (base, config) => (props) => {
  var _config_compoundVariants;
  if ((config === null || config === void 0 ? void 0 : config.variants) == null) return cx(base, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
  const { variants, defaultVariants } = config;
  const getVariantClassNames = Object.keys(variants).map((variant) => {
    const variantProp = props === null || props === void 0 ? void 0 : props[variant];
    const defaultVariantProp = defaultVariants === null || defaultVariants === void 0 ? void 0 : defaultVariants[variant];
    if (variantProp === null) return null;
    const variantKey = falsyToString(variantProp) || falsyToString(defaultVariantProp);
    return variants[variant][variantKey];
  });
  const propsWithoutUndefined = props && Object.entries(props).reduce((acc, param) => {
    let [key, value] = param;
    if (value === void 0) {
      return acc;
    }
    acc[key] = value;
    return acc;
  }, {});
  const getCompoundVariantClassNames = config === null || config === void 0 ? void 0 : (_config_compoundVariants = config.compoundVariants) === null || _config_compoundVariants === void 0 ? void 0 : _config_compoundVariants.reduce((acc, param) => {
    let { class: cvClass, className: cvClassName, ...compoundVariantOptions } = param;
    return Object.entries(compoundVariantOptions).every((param2) => {
      let [key, value] = param2;
      return Array.isArray(value) ? value.includes({
        ...defaultVariants,
        ...propsWithoutUndefined
      }[key]) : {
        ...defaultVariants,
        ...propsWithoutUndefined
      }[key] === value;
    }) ? [
      ...acc,
      cvClass,
      cvClassName
    ] : acc;
  }, []);
  return cx(base, getVariantClassNames, getCompoundVariantClassNames, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
};

// work/aplyd-academy/node_modules/@radix-ui/react-primitive/dist/index.mjs
import * as React3 from "react";
import * as ReactDOM from "react-dom";

// work/aplyd-academy/node_modules/@radix-ui/react-primitive/node_modules/@radix-ui/react-slot/dist/index.mjs
import * as React2 from "react";

// work/aplyd-academy/node_modules/@radix-ui/react-primitive/node_modules/@radix-ui/react-compose-refs/dist/index.mjs
import * as React from "react";
var __defProp2 = Object.defineProperty;
var __name = (target, value) => __defProp2(target, "name", { value, configurable: true });
function setRef(ref, value) {
  if (typeof ref === "function") {
    return ref(value);
  } else if (ref !== null && ref !== void 0) {
    ref.current = value;
  }
}
__name(setRef, "setRef");
function composeRefs(...refs) {
  return (node) => {
    let hasCleanup = false;
    const cleanups = refs.map((ref) => {
      const cleanup = setRef(ref, node);
      if (!hasCleanup && typeof cleanup == "function") {
        hasCleanup = true;
      }
      return cleanup;
    });
    if (hasCleanup) {
      return () => {
        for (let i = 0; i < cleanups.length; i++) {
          const cleanup = cleanups[i];
          if (typeof cleanup == "function") {
            cleanup();
          } else {
            setRef(refs[i], null);
          }
        }
      };
    }
  };
}
__name(composeRefs, "composeRefs");
function useComposedRefs(...refs) {
  return React.useCallback(composeRefs(...refs), refs);
}
__name(useComposedRefs, "useComposedRefs");

// work/aplyd-academy/node_modules/@radix-ui/react-primitive/node_modules/@radix-ui/react-slot/dist/index.mjs
var __defProp3 = Object.defineProperty;
var __name2 = (target, value) => __defProp3(target, "name", { value, configurable: true });
// @__NO_SIDE_EFFECTS__
function createSlot(ownerName) {
  const Slot22 = React2.forwardRef((props, forwardedRef) => {
    let { children, ...slotProps } = props;
    let slottableElement = null;
    let hasSlottable = false;
    const newChildren = [];
    if (isLazyComponent(children) && typeof use === "function") {
      children = use(children._payload);
    }
    React2.Children.forEach(children, (maybeSlottable) => {
      if (isSlottable(maybeSlottable)) {
        hasSlottable = true;
        const slottable = maybeSlottable;
        let child = "child" in slottable.props ? slottable.props.child : slottable.props.children;
        if (isLazyComponent(child) && typeof use === "function") {
          child = use(child._payload);
        }
        slottableElement = getSlottableElementFromSlottable(slottable, child);
        newChildren.push(slottableElement?.props?.children);
      } else {
        newChildren.push(maybeSlottable);
      }
    });
    if (slottableElement) {
      slottableElement = React2.cloneElement(slottableElement, void 0, newChildren);
    } else if (
      // A `Slottable` was found but it didn't resolve to a single element (e.g.
      // it wrapped multiple elements, text, or a render-prop `child` that
      // wasn't an element). Don't fall back to treating the `Slottable` wrapper
      // itself as the slot target — throw a descriptive error below instead.
      !hasSlottable && React2.Children.count(children) === 1 && React2.isValidElement(children)
    ) {
      slottableElement = children;
    }
    const slottableElementRef = slottableElement ? getElementRef(slottableElement) : void 0;
    const composedRef = useComposedRefs(forwardedRef, slottableElementRef);
    if (!slottableElement) {
      if (children || children === 0) {
        throw new Error(
          hasSlottable ? createSlottableError(ownerName) : createSlotError(ownerName)
        );
      }
      return children;
    }
    const mergedProps = mergeProps(slotProps, slottableElement.props ?? {});
    if (slottableElement.type !== React2.Fragment) {
      mergedProps.ref = forwardedRef ? composedRef : slottableElementRef;
    }
    return React2.cloneElement(slottableElement, mergedProps);
  });
  Slot22.displayName = `${ownerName}.Slot`;
  return Slot22;
}
__name2(createSlot, "createSlot");
var SLOTTABLE_IDENTIFIER = /* @__PURE__ */ Symbol.for("radix.slottable");
// @__NO_SIDE_EFFECTS__
function createSlottable(ownerName) {
  const Slottable2 = /* @__PURE__ */ __name2((props) => "child" in props ? props.children(props.child) : props.children, "Slottable");
  Slottable2.displayName = `${ownerName}.Slottable`;
  Slottable2.__radixId = SLOTTABLE_IDENTIFIER;
  return Slottable2;
}
__name2(createSlottable, "createSlottable");
var getSlottableElementFromSlottable = /* @__PURE__ */ __name2((slottable, child) => {
  if ("child" in slottable.props) {
    const child2 = slottable.props.child;
    if (!React2.isValidElement(child2)) return null;
    return React2.cloneElement(child2, void 0, slottable.props.children(child2.props.children));
  }
  return React2.isValidElement(child) ? child : null;
}, "getSlottableElementFromSlottable");
function mergeProps(slotProps, childProps) {
  const overrideProps = { ...childProps };
  for (const propName in childProps) {
    const slotPropValue = slotProps[propName];
    const childPropValue = childProps[propName];
    const isHandler = /^on[A-Z]/.test(propName);
    if (isHandler) {
      if (slotPropValue && childPropValue) {
        overrideProps[propName] = (...args) => {
          const result = childPropValue(...args);
          slotPropValue(...args);
          return result;
        };
      } else if (slotPropValue) {
        overrideProps[propName] = slotPropValue;
      }
    } else if (propName === "style") {
      overrideProps[propName] = { ...slotPropValue, ...childPropValue };
    } else if (propName === "className") {
      overrideProps[propName] = [slotPropValue, childPropValue].filter(Boolean).join(" ");
    }
  }
  return { ...slotProps, ...overrideProps };
}
__name2(mergeProps, "mergeProps");
function getElementRef(element) {
  let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
  let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.ref;
  }
  getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
  mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.props.ref;
  }
  return element.props.ref || element.ref;
}
__name2(getElementRef, "getElementRef");
function isSlottable(child) {
  return React2.isValidElement(child) && typeof child.type === "function" && "__radixId" in child.type && child.type.__radixId === SLOTTABLE_IDENTIFIER;
}
__name2(isSlottable, "isSlottable");
var REACT_LAZY_TYPE = /* @__PURE__ */ Symbol.for("react.lazy");
function isLazyComponent(element) {
  return element != null && typeof element === "object" && "$$typeof" in element && element.$$typeof === REACT_LAZY_TYPE && "_payload" in element && isPromiseLike(element._payload);
}
__name2(isLazyComponent, "isLazyComponent");
function isPromiseLike(value) {
  return typeof value === "object" && value !== null && "then" in value;
}
__name2(isPromiseLike, "isPromiseLike");
var createSlotError = /* @__PURE__ */ __name2((ownerName) => {
  return `${ownerName} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`;
}, "createSlotError");
var createSlottableError = /* @__PURE__ */ __name2((ownerName) => {
  return `${ownerName} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`;
}, "createSlottableError");
var use = React2[" use ".trim().toString()];

// work/aplyd-academy/node_modules/@radix-ui/react-primitive/dist/index.mjs
import { jsx } from "react/jsx-runtime";
var __defProp4 = Object.defineProperty;
var __name3 = (target, value) => __defProp4(target, "name", { value, configurable: true });
var NODES = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "select",
  "span",
  "svg",
  "ul"
];
var Primitive = NODES.reduce((primitive, node) => {
  const Slot3 = createSlot(`Primitive.${node}`);
  const Node2 = React3.forwardRef((props, forwardedRef) => {
    const { asChild, ...primitiveProps } = props;
    const Comp = asChild ? Slot3 : node;
    if (typeof window !== "undefined") {
      window[/* @__PURE__ */ Symbol.for("radix-ui")] = true;
    }
    return /* @__PURE__ */ jsx(Comp, { ...primitiveProps, ref: forwardedRef });
  });
  Node2.displayName = `Primitive.${node}`;
  return { ...primitive, [node]: Node2 };
}, {});
function dispatchDiscreteCustomEvent(target, event) {
  if (target) ReactDOM.flushSync(() => target.dispatchEvent(event));
}
__name3(dispatchDiscreteCustomEvent, "dispatchDiscreteCustomEvent");

// work/aplyd-academy/node_modules/@radix-ui/react-context/dist/index.mjs
import * as React4 from "react";
import { jsx as jsx2 } from "react/jsx-runtime";
var __defProp5 = Object.defineProperty;
var __name4 = (target, value) => __defProp5(target, "name", { value, configurable: true });
// @__NO_SIDE_EFFECTS__
function createContext22(rootComponentName, defaultContext) {
  const Context = React4.createContext(defaultContext);
  Context.displayName = rootComponentName + "Context";
  const Provider = /* @__PURE__ */ __name4((props) => {
    const { children, ...context } = props;
    const value = React4.useMemo(() => context, Object.values(context));
    return /* @__PURE__ */ jsx2(Context.Provider, { value, children });
  }, "Provider");
  Provider.displayName = rootComponentName + "Provider";
  function useContext22(consumerName, options = {}) {
    const { optional = false } = options;
    const context = React4.useContext(Context);
    if (context) return context;
    if (defaultContext !== void 0) return defaultContext;
    if (optional) return void 0;
    throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
  }
  __name4(useContext22, "useContext");
  return [Provider, useContext22];
}
__name4(createContext22, "createContext");
// @__NO_SIDE_EFFECTS__
function createContextScope(scopeName, createContextScopeDeps = []) {
  let defaultContexts = [];
  function createContext32(rootComponentName, defaultContext) {
    const BaseContext = React4.createContext(defaultContext);
    BaseContext.displayName = rootComponentName + "Context";
    const index = defaultContexts.length;
    defaultContexts = [...defaultContexts, defaultContext];
    const Provider = /* @__PURE__ */ __name4((props) => {
      const { scope, children, ...context } = props;
      const Context = scope?.[scopeName]?.[index] || BaseContext;
      const value = React4.useMemo(() => context, Object.values(context));
      return /* @__PURE__ */ jsx2(Context.Provider, { value, children });
    }, "Provider");
    Provider.displayName = rootComponentName + "Provider";
    function useContext22(consumerName, scope, options = {}) {
      const { optional = false } = options;
      const Context = scope?.[scopeName]?.[index] || BaseContext;
      const context = React4.useContext(Context);
      if (context) return context;
      if (defaultContext !== void 0) return defaultContext;
      if (optional) return void 0;
      throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
    }
    __name4(useContext22, "useContext");
    return [Provider, useContext22];
  }
  __name4(createContext32, "createContext");
  const createScope = /* @__PURE__ */ __name4(() => {
    const scopeContexts = defaultContexts.map((defaultContext) => {
      return React4.createContext(defaultContext);
    });
    return /* @__PURE__ */ __name4(function useScope(scope) {
      const contexts = scope?.[scopeName] || scopeContexts;
      return React4.useMemo(
        () => ({ [`__scope${scopeName}`]: { ...scope, [scopeName]: contexts } }),
        [scope, contexts]
      );
    }, "useScope");
  }, "createScope");
  createScope.scopeName = scopeName;
  return [createContext32, composeContextScopes(createScope, ...createContextScopeDeps)];
}
__name4(createContextScope, "createContextScope");
function composeContextScopes(...scopes) {
  const baseScope = scopes[0];
  if (scopes.length === 1) return baseScope;
  const createScope = /* @__PURE__ */ __name4(() => {
    const scopeHooks = scopes.map((createScope2) => ({
      useScope: createScope2(),
      scopeName: createScope2.scopeName
    }));
    return /* @__PURE__ */ __name4(function useComposedScopes(overrideScopes) {
      const nextScopes = scopeHooks.reduce((nextScopes2, { useScope, scopeName }) => {
        const scopeProps = useScope(overrideScopes);
        const currentScope = scopeProps[`__scope${scopeName}`];
        return { ...nextScopes2, ...currentScope };
      }, {});
      return React4.useMemo(() => ({ [`__scope${baseScope.scopeName}`]: nextScopes }), [nextScopes]);
    }, "useComposedScopes");
  }, "createScope");
  createScope.scopeName = baseScope.scopeName;
  return createScope;
}
__name4(composeContextScopes, "composeContextScopes");

// work/aplyd-academy/node_modules/@radix-ui/primitive/dist/index.mjs
var __defProp6 = Object.defineProperty;
var __name5 = (target, value) => __defProp6(target, "name", { value, configurable: true });
var canUseDOM = !!(typeof window !== "undefined" && window.document && window.document.createElement);
function composeEventHandlers(originalEventHandler, ourEventHandler, { checkForDefaultPrevented = true } = {}) {
  return /* @__PURE__ */ __name5(function handleEvent(event) {
    originalEventHandler?.(event);
    if (checkForDefaultPrevented === false || !event || !event.defaultPrevented) {
      return ourEventHandler?.(event);
    }
  }, "handleEvent");
}
__name5(composeEventHandlers, "composeEventHandlers");
function getOwnerWindow(element) {
  if (!canUseDOM) {
    throw new Error("Cannot access window outside of the DOM");
  }
  return element?.ownerDocument?.defaultView ?? window;
}
__name5(getOwnerWindow, "getOwnerWindow");
function getOwnerDocument(element) {
  if (!canUseDOM) {
    throw new Error("Cannot access document outside of the DOM");
  }
  return element?.ownerDocument ?? document;
}
__name5(getOwnerDocument, "getOwnerDocument");
function getActiveElement(node, activeDescendant = false) {
  const { activeElement } = getOwnerDocument(node);
  if (!activeElement?.nodeName) {
    return null;
  }
  if (isFrame(activeElement) && activeElement.contentDocument) {
    return getActiveElement(activeElement.contentDocument.body, activeDescendant);
  }
  if (activeDescendant) {
    const id = activeElement.getAttribute("aria-activedescendant");
    if (id) {
      const element = getOwnerDocument(activeElement).getElementById(id);
      if (element) {
        return element;
      }
    }
  }
  return activeElement;
}
__name5(getActiveElement, "getActiveElement");
function isFrame(element) {
  return element.tagName === "IFRAME";
}
__name5(isFrame, "isFrame");

// work/aplyd-academy/node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
import * as React7 from "react";

// work/aplyd-academy/node_modules/@radix-ui/primitive/dist/internal/is-development.false.mjs
var IS_DEVELOPMENT = false;

// work/aplyd-academy/node_modules/@radix-ui/react-use-layout-effect/dist/index.mjs
import * as React5 from "react";
var useLayoutEffect2 = globalThis?.document ? React5.useLayoutEffect : () => {
};

// work/aplyd-academy/node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
import * as React22 from "react";

// work/aplyd-academy/node_modules/@radix-ui/react-use-effect-event/dist/index.mjs
import * as React6 from "react";
var __defProp7 = Object.defineProperty;
var __name6 = (target, value) => __defProp7(target, "name", { value, configurable: true });
var useReactEffectEvent = React6[" useEffectEvent ".trim().toString()];
var useReactInsertionEffect = React6[" useInsertionEffect ".trim().toString()];
function useEffectEvent(callback) {
  if (typeof useReactEffectEvent === "function") {
    return useReactEffectEvent(callback);
  }
  const ref = React6.useRef(() => {
    throw new Error("Cannot call an event handler while rendering.");
  });
  if (typeof useReactInsertionEffect === "function") {
    useReactInsertionEffect(() => {
      ref.current = callback;
    });
  } else {
    useLayoutEffect2(() => {
      ref.current = callback;
    });
  }
  return React6.useMemo(() => ((...args) => ref.current?.(...args)), []);
}
__name6(useEffectEvent, "useEffectEvent");

// work/aplyd-academy/node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
var __defProp8 = Object.defineProperty;
var __name7 = (target, value) => __defProp8(target, "name", { value, configurable: true });
var useInsertionEffect = React7[" useInsertionEffect ".trim().toString()] || useLayoutEffect2;
function useControllableState({
  prop,
  defaultProp,
  onChange = /* @__PURE__ */ __name7(() => {
  }, "onChange"),
  caller
}) {
  const [uncontrolledProp, setUncontrolledProp, onChangeRef] = useUncontrolledState({
    defaultProp,
    onChange
  });
  const isControlled = prop !== void 0;
  const value = isControlled ? prop : uncontrolledProp;
  if (IS_DEVELOPMENT) {
    const isControlledRef = React7.useRef(prop !== void 0);
    React7.useEffect(() => {
      const wasControlled = isControlledRef.current;
      if (wasControlled !== isControlled) {
        const from = wasControlled ? "controlled" : "uncontrolled";
        const to = isControlled ? "controlled" : "uncontrolled";
        console.warn(
          `${caller} is changing from ${from} to ${to}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`
        );
      }
      isControlledRef.current = isControlled;
    }, [isControlled, caller]);
  }
  const setValue = React7.useCallback(
    (nextValue) => {
      if (isControlled) {
        const value2 = isFunction(nextValue) ? nextValue(prop) : nextValue;
        if (value2 !== prop) {
          onChangeRef.current?.(value2);
        }
      } else {
        setUncontrolledProp(nextValue);
      }
    },
    [isControlled, prop, setUncontrolledProp, onChangeRef]
  );
  return [value, setValue];
}
__name7(useControllableState, "useControllableState");
function useUncontrolledState({
  defaultProp,
  onChange
}) {
  const [value, setValue] = React7.useState(defaultProp);
  const prevValueRef = React7.useRef(value);
  const onChangeRef = React7.useRef(onChange);
  useInsertionEffect(() => {
    onChangeRef.current = onChange;
  }, [onChange]);
  React7.useEffect(() => {
    if (prevValueRef.current !== value) {
      onChangeRef.current?.(value);
      prevValueRef.current = value;
    }
  }, [value, prevValueRef]);
  return [value, setValue, onChangeRef];
}
__name7(useUncontrolledState, "useUncontrolledState");
function isFunction(value) {
  return typeof value === "function";
}
__name7(isFunction, "isFunction");
var SYNC_STATE = /* @__PURE__ */ Symbol("RADIX:SYNC_STATE");
function useControllableStateReducer(reducer, userArgs, initialArg, init) {
  const { prop: controlledState, defaultProp, onChange: onChangeProp, caller } = userArgs;
  const isControlled = controlledState !== void 0;
  const onChange = useEffectEvent(onChangeProp);
  if (IS_DEVELOPMENT) {
    const isControlledRef = React22.useRef(controlledState !== void 0);
    React22.useEffect(() => {
      const wasControlled = isControlledRef.current;
      if (wasControlled !== isControlled) {
        const from = wasControlled ? "controlled" : "uncontrolled";
        const to = isControlled ? "controlled" : "uncontrolled";
        console.warn(
          `${caller} is changing from ${from} to ${to}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`
        );
      }
      isControlledRef.current = isControlled;
    }, [isControlled, caller]);
  }
  const args = [{ ...initialArg, state: defaultProp }];
  if (init) {
    args.push(init);
  }
  const [internalState, dispatch] = React22.useReducer(
    (state2, action) => {
      if (action.type === SYNC_STATE) {
        return { ...state2, state: action.state };
      }
      const next = reducer(state2, action);
      if (isControlled && !Object.is(next.state, state2.state)) {
        onChange(next.state);
      }
      return next;
    },
    ...args
  );
  const uncontrolledState = internalState.state;
  const prevValueRef = React22.useRef(uncontrolledState);
  React22.useEffect(() => {
    if (prevValueRef.current !== uncontrolledState) {
      prevValueRef.current = uncontrolledState;
      if (!isControlled) {
        onChange(uncontrolledState);
      }
    }
  }, [uncontrolledState, prevValueRef, isControlled]);
  const state = React22.useMemo(() => {
    const isControlled2 = controlledState !== void 0;
    if (isControlled2) {
      return { ...internalState, state: controlledState };
    }
    return internalState;
  }, [internalState, controlledState]);
  React22.useEffect(() => {
    if (isControlled && !Object.is(controlledState, internalState.state)) {
      dispatch({ type: SYNC_STATE, state: controlledState });
    }
  }, [controlledState, internalState.state, isControlled]);
  return [state, dispatch];
}
__name7(useControllableStateReducer, "useControllableStateReducer");

// work/aplyd-academy/node_modules/@radix-ui/react-presence/dist/index.mjs
import * as React23 from "react";
import * as React8 from "react";
var __defProp9 = Object.defineProperty;
var __name8 = (target, value) => __defProp9(target, "name", { value, configurable: true });
function useStateMachine(initialState, machine) {
  return React8.useReducer((state, event) => {
    const nextState = machine[state][event];
    return nextState ?? state;
  }, initialState);
}
__name8(useStateMachine, "useStateMachine");
var Presence = /* @__PURE__ */ __name8((props) => {
  const { present, children } = props;
  const presence = usePresence(present);
  const child = typeof children === "function" ? children({ present: presence.isPresent }) : React23.Children.only(children);
  const ref = useStableComposedRefs(presence.ref, getElementRef2(child));
  const forceMount = typeof children === "function";
  return forceMount || presence.isPresent ? React23.cloneElement(child, { ref }) : null;
}, "Presence");
function usePresence(present) {
  const [node, setNode] = React23.useState();
  const stylesRef = React23.useRef(null);
  const prevPresentRef = React23.useRef(present);
  const prevAnimationNameRef = React23.useRef("none");
  const mountAnimationNameRef = React23.useRef(void 0);
  const initialState = present ? "mounted" : "unmounted";
  const [state, send] = useStateMachine(initialState, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  React23.useEffect(() => {
    if (state === "mounted") {
      prevAnimationNameRef.current = mountAnimationNameRef.current ?? getAnimationName(stylesRef.current);
      mountAnimationNameRef.current = void 0;
    } else {
      prevAnimationNameRef.current = "none";
    }
  }, [state]);
  useLayoutEffect2(() => {
    const styles = stylesRef.current;
    const wasPresent = prevPresentRef.current;
    const hasPresentChanged = wasPresent !== present;
    if (hasPresentChanged) {
      const prevAnimationName = prevAnimationNameRef.current;
      const currentAnimationName = getAnimationName(styles);
      if (present) {
        mountAnimationNameRef.current = currentAnimationName;
        send("MOUNT");
      } else if (currentAnimationName === "none" || styles?.display === "none") {
        send("UNMOUNT");
      } else {
        const isAnimating = prevAnimationName !== currentAnimationName;
        if (wasPresent && isAnimating) {
          send("ANIMATION_OUT");
        } else {
          send("UNMOUNT");
        }
      }
      prevPresentRef.current = present;
    }
  }, [present, send]);
  useLayoutEffect2(() => {
    if (node) {
      let timeoutId;
      const ownerWindow = node.ownerDocument.defaultView ?? window;
      const handleAnimationEnd = /* @__PURE__ */ __name8((event) => {
        const currentAnimationName = getAnimationName(stylesRef.current);
        const isCurrentAnimation = currentAnimationName.includes(CSS.escape(event.animationName));
        if (event.target === node && isCurrentAnimation) {
          send("ANIMATION_END");
          if (!prevPresentRef.current) {
            const currentFillMode = node.style.animationFillMode;
            node.style.animationFillMode = "forwards";
            timeoutId = ownerWindow.setTimeout(() => {
              if (node.style.animationFillMode === "forwards") {
                node.style.animationFillMode = currentFillMode;
              }
            });
          }
        }
      }, "handleAnimationEnd");
      const handleAnimationStart = /* @__PURE__ */ __name8((event) => {
        if (event.target === node) {
          prevAnimationNameRef.current = getAnimationName(stylesRef.current);
        }
      }, "handleAnimationStart");
      node.addEventListener("animationstart", handleAnimationStart);
      node.addEventListener("animationcancel", handleAnimationEnd);
      node.addEventListener("animationend", handleAnimationEnd);
      return () => {
        ownerWindow.clearTimeout(timeoutId);
        node.removeEventListener("animationstart", handleAnimationStart);
        node.removeEventListener("animationcancel", handleAnimationEnd);
        node.removeEventListener("animationend", handleAnimationEnd);
      };
    } else {
      send("ANIMATION_END");
    }
  }, [node, send]);
  return {
    isPresent: ["mounted", "unmountSuspended"].includes(state),
    ref: React23.useCallback((node2) => {
      if (node2) {
        const styles = getComputedStyle(node2);
        stylesRef.current = styles;
        mountAnimationNameRef.current = getAnimationName(styles);
      } else {
        stylesRef.current = null;
      }
      setNode(node2);
    }, [])
  };
}
__name8(usePresence, "usePresence");
function setRef2(ref, value) {
  if (typeof ref === "function") {
    return ref(value);
  } else if (ref !== null && ref !== void 0) {
    ref.current = value;
  }
}
__name8(setRef2, "setRef");
function useStableComposedRefs(...refs) {
  const refsRef = React23.useRef(refs);
  refsRef.current = refs;
  return React23.useCallback((node) => {
    const currentRefs = refsRef.current;
    let hasCleanup = false;
    const cleanups = currentRefs.map((ref) => {
      const cleanup = setRef2(ref, node);
      if (!hasCleanup && typeof cleanup === "function") {
        hasCleanup = true;
      }
      return cleanup;
    });
    if (hasCleanup) {
      return () => {
        for (let i = 0; i < cleanups.length; i++) {
          const cleanup = cleanups[i];
          if (typeof cleanup === "function") {
            cleanup();
          } else {
            setRef2(currentRefs[i], null);
          }
        }
      };
    }
  }, []);
}
__name8(useStableComposedRefs, "useStableComposedRefs");
function getAnimationName(styles) {
  return styles?.animationName || "none";
}
__name8(getAnimationName, "getAnimationName");
function getElementRef2(element) {
  let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
  let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.ref;
  }
  getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
  mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.props.ref;
  }
  return element.props.ref || element.ref;
}
__name8(getElementRef2, "getElementRef");

// work/aplyd-academy/node_modules/@radix-ui/react-id/dist/index.mjs
import * as React9 from "react";
var __defProp10 = Object.defineProperty;
var __name9 = (target, value) => __defProp10(target, "name", { value, configurable: true });
var useReactId = React9[" useId ".trim().toString()] || (() => void 0);
var count = 0;
function useId(deterministicId) {
  const [id, setId] = React9.useState(useReactId());
  useLayoutEffect2(() => {
    if (!deterministicId) setId((reactId) => reactId ?? String(count++));
  }, [deterministicId]);
  return deterministicId || (id ? `radix-${id}` : "");
}
__name9(useId, "useId");

// work/aplyd-academy/node_modules/@radix-ui/react-dialog/dist/index.mjs
var dist_exports = {};
__export(dist_exports, {
  Close: () => DialogClose,
  Content: () => DialogContent,
  Description: () => DialogDescription,
  Dialog: () => Dialog,
  DialogClose: () => DialogClose,
  DialogContent: () => DialogContent,
  DialogDescription: () => DialogDescription,
  DialogOverlay: () => DialogOverlay,
  DialogPortal: () => DialogPortal,
  DialogTitle: () => DialogTitle,
  DialogTrigger: () => DialogTrigger,
  Overlay: () => DialogOverlay,
  Portal: () => DialogPortal,
  Root: () => Dialog,
  Title: () => DialogTitle,
  Trigger: () => DialogTrigger,
  WarningProvider: () => WarningProvider,
  createDialogScope: () => createDialogScope
});
import * as React28 from "react";

// work/aplyd-academy/node_modules/@radix-ui/react-dialog/node_modules/@radix-ui/react-compose-refs/dist/index.mjs
import * as React10 from "react";
var __defProp11 = Object.defineProperty;
var __name10 = (target, value) => __defProp11(target, "name", { value, configurable: true });
function setRef3(ref, value) {
  if (typeof ref === "function") {
    return ref(value);
  } else if (ref !== null && ref !== void 0) {
    ref.current = value;
  }
}
__name10(setRef3, "setRef");
function composeRefs2(...refs) {
  return (node) => {
    let hasCleanup = false;
    const cleanups = refs.map((ref) => {
      const cleanup = setRef3(ref, node);
      if (!hasCleanup && typeof cleanup == "function") {
        hasCleanup = true;
      }
      return cleanup;
    });
    if (hasCleanup) {
      return () => {
        for (let i = 0; i < cleanups.length; i++) {
          const cleanup = cleanups[i];
          if (typeof cleanup == "function") {
            cleanup();
          } else {
            setRef3(refs[i], null);
          }
        }
      };
    }
  };
}
__name10(composeRefs2, "composeRefs");
function useComposedRefs2(...refs) {
  return React10.useCallback(composeRefs2(...refs), refs);
}
__name10(useComposedRefs2, "useComposedRefs");

// work/aplyd-academy/node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
import * as React13 from "react";

// work/aplyd-academy/node_modules/@radix-ui/react-dismissable-layer/node_modules/@radix-ui/react-compose-refs/dist/index.mjs
import * as React11 from "react";
var __defProp12 = Object.defineProperty;
var __name11 = (target, value) => __defProp12(target, "name", { value, configurable: true });
function setRef4(ref, value) {
  if (typeof ref === "function") {
    return ref(value);
  } else if (ref !== null && ref !== void 0) {
    ref.current = value;
  }
}
__name11(setRef4, "setRef");
function composeRefs3(...refs) {
  return (node) => {
    let hasCleanup = false;
    const cleanups = refs.map((ref) => {
      const cleanup = setRef4(ref, node);
      if (!hasCleanup && typeof cleanup == "function") {
        hasCleanup = true;
      }
      return cleanup;
    });
    if (hasCleanup) {
      return () => {
        for (let i = 0; i < cleanups.length; i++) {
          const cleanup = cleanups[i];
          if (typeof cleanup == "function") {
            cleanup();
          } else {
            setRef4(refs[i], null);
          }
        }
      };
    }
  };
}
__name11(composeRefs3, "composeRefs");
function useComposedRefs3(...refs) {
  return React11.useCallback(composeRefs3(...refs), refs);
}
__name11(useComposedRefs3, "useComposedRefs");

// work/aplyd-academy/node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs
import * as React12 from "react";
var __defProp13 = Object.defineProperty;
var __name12 = (target, value) => __defProp13(target, "name", { value, configurable: true });
function useCallbackRef(callback) {
  const callbackRef = React12.useRef(callback);
  React12.useEffect(() => {
    callbackRef.current = callback;
  });
  return React12.useMemo(() => ((...args) => callbackRef.current?.(...args)), []);
}
__name12(useCallbackRef, "useCallbackRef");

// work/aplyd-academy/node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
import { jsx as jsx3 } from "react/jsx-runtime";
var __defProp14 = Object.defineProperty;
var __name13 = (target, value) => __defProp14(target, "name", { value, configurable: true });
var CONTEXT_UPDATE = "dismissableLayer.update";
var POINTER_DOWN_OUTSIDE = "dismissableLayer.pointerDownOutside";
var FOCUS_OUTSIDE = "dismissableLayer.focusOutside";
var originalBodyPointerEvents;
var DismissableLayerContext = React13.createContext({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set(),
  // Outside elements that belong to a layer's own dismiss affordance (eg, a
  // dialog overlay). Pressing them should dismiss the layer regardless of
  // whether or not they stop propagation.
  //
  // See https://github.com/radix-ui/primitives/issues/3346
  dismissableSurfaces: /* @__PURE__ */ new Set()
});
var DismissableLayer = /* @__PURE__ */ React13.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ __name13(function DismissableLayer2(props, forwardedRef) {
    const {
      disableOutsidePointerEvents = false,
      deferPointerDownOutside = false,
      onEscapeKeyDown,
      onPointerDownOutside,
      onFocusOutside,
      onInteractOutside,
      onDismiss,
      ...layerProps
    } = props;
    const context = React13.useContext(DismissableLayerContext);
    const [node, setNode] = React13.useState(null);
    const ownerDocument = node?.ownerDocument ?? globalThis?.document;
    const [, force] = React13.useState({});
    const composedRefs = useComposedRefs3(forwardedRef, setNode);
    const layers = Array.from(context.layers);
    const [highestLayerWithOutsidePointerEventsDisabled] = [
      ...context.layersWithOutsidePointerEventsDisabled
    ].slice(-1);
    const highestLayerWithOutsidePointerEventsDisabledIndex = highestLayerWithOutsidePointerEventsDisabled ? layers.indexOf(highestLayerWithOutsidePointerEventsDisabled) : -1;
    const index = node ? layers.indexOf(node) : -1;
    const isBodyPointerEventsDisabled = context.layersWithOutsidePointerEventsDisabled.size > 0;
    const isPointerEventsEnabled = index >= highestLayerWithOutsidePointerEventsDisabledIndex;
    const isDeferredPointerDownOutsideRef = React13.useRef(false);
    const pointerDownOutside = usePointerDownOutside(
      (event) => {
        onPointerDownOutside?.(event);
        onInteractOutside?.(event);
        if (!event.defaultPrevented) onDismiss?.();
      },
      {
        ownerDocument,
        deferPointerDownOutside,
        isDeferredPointerDownOutsideRef,
        dismissableSurfaces: context.dismissableSurfaces,
        shouldHandlePointerDownOutside: React13.useCallback(
          (target) => {
            if (!(target instanceof Node)) {
              return false;
            }
            const isPointerDownOnBranch = [...context.branches].some(
              (branch) => branch.contains(target)
            );
            return isPointerEventsEnabled && !isPointerDownOnBranch;
          },
          [context.branches, isPointerEventsEnabled]
        )
      }
    );
    const focusOutside = useFocusOutside((event) => {
      if (deferPointerDownOutside && isDeferredPointerDownOutsideRef.current) {
        return;
      }
      const target = event.target;
      const isFocusInBranch = [...context.branches].some((branch) => branch.contains(target));
      if (isFocusInBranch) return;
      onFocusOutside?.(event);
      onInteractOutside?.(event);
      if (!event.defaultPrevented) onDismiss?.();
    }, ownerDocument);
    const isHighestLayer = node ? index === layers.length - 1 : false;
    const handleKeyDown = useCallbackRef((event) => {
      if (event.key !== "Escape") {
        return;
      }
      onEscapeKeyDown?.(event);
      if (!event.defaultPrevented && onDismiss) {
        event.preventDefault();
        onDismiss();
      }
    });
    React13.useEffect(() => {
      if (!isHighestLayer) {
        return;
      }
      ownerDocument.addEventListener("keydown", handleKeyDown, { capture: true });
      return () => ownerDocument.removeEventListener("keydown", handleKeyDown, { capture: true });
    }, [ownerDocument, isHighestLayer, handleKeyDown]);
    React13.useEffect(() => {
      if (!node) return;
      if (disableOutsidePointerEvents) {
        if (context.layersWithOutsidePointerEventsDisabled.size === 0) {
          originalBodyPointerEvents = ownerDocument.body.style.pointerEvents;
          ownerDocument.body.style.pointerEvents = "none";
        }
        context.layersWithOutsidePointerEventsDisabled.add(node);
      }
      context.layers.add(node);
      dispatchUpdate();
      return () => {
        if (disableOutsidePointerEvents) {
          context.layersWithOutsidePointerEventsDisabled.delete(node);
          if (context.layersWithOutsidePointerEventsDisabled.size === 0) {
            ownerDocument.body.style.pointerEvents = originalBodyPointerEvents;
          }
        }
      };
    }, [node, ownerDocument, disableOutsidePointerEvents, context]);
    React13.useEffect(() => {
      return () => {
        if (!node) return;
        context.layers.delete(node);
        context.layersWithOutsidePointerEventsDisabled.delete(node);
        dispatchUpdate();
      };
    }, [node, context]);
    React13.useEffect(() => {
      const handleUpdate = /* @__PURE__ */ __name13(() => force({}), "handleUpdate");
      document.addEventListener(CONTEXT_UPDATE, handleUpdate);
      return () => document.removeEventListener(CONTEXT_UPDATE, handleUpdate);
    }, []);
    return /* @__PURE__ */ jsx3(
      Primitive.div,
      {
        ...layerProps,
        ref: composedRefs,
        style: {
          pointerEvents: isBodyPointerEventsDisabled ? isPointerEventsEnabled ? "auto" : "none" : void 0,
          ...props.style
        },
        onFocusCapture: composeEventHandlers(props.onFocusCapture, focusOutside.onFocusCapture),
        onBlurCapture: composeEventHandlers(props.onBlurCapture, focusOutside.onBlurCapture),
        onPointerDownCapture: composeEventHandlers(
          props.onPointerDownCapture,
          pointerDownOutside.onPointerDownCapture
        )
      }
    );
  }, "DismissableLayer")
);
function useDismissableLayerSurface() {
  const context = React13.useContext(DismissableLayerContext);
  const [node, setNode] = React13.useState(null);
  React13.useEffect(() => {
    if (!node) {
      return;
    }
    context.dismissableSurfaces.add(node);
    return () => {
      context.dismissableSurfaces.delete(node);
    };
  }, [node, context.dismissableSurfaces]);
  return setNode;
}
__name13(useDismissableLayerSurface, "useDismissableLayerSurface");
var IS_TRUE = /* @__PURE__ */ __name13(() => true, "IS_TRUE");
function usePointerDownOutside(onPointerDownOutside, args) {
  const {
    ownerDocument = globalThis?.document,
    deferPointerDownOutside = false,
    isDeferredPointerDownOutsideRef,
    dismissableSurfaces,
    shouldHandlePointerDownOutside = IS_TRUE
  } = args;
  const handlePointerDownOutside = useCallbackRef(onPointerDownOutside);
  const isPointerInsideReactTreeRef = React13.useRef(false);
  const isPointerDownOutsideRef = React13.useRef(false);
  const interceptedOutsideInteractionEventsRef = React13.useRef(/* @__PURE__ */ new Map());
  const handleClickRef = React13.useRef(() => {
  });
  React13.useEffect(() => {
    function resetOutsideInteraction() {
      isPointerDownOutsideRef.current = false;
      isDeferredPointerDownOutsideRef.current = false;
      interceptedOutsideInteractionEventsRef.current.clear();
    }
    __name13(resetOutsideInteraction, "resetOutsideInteraction");
    function isOutsideInteractionIntercepted() {
      return Array.from(interceptedOutsideInteractionEventsRef.current.values()).some(Boolean);
    }
    __name13(isOutsideInteractionIntercepted, "isOutsideInteractionIntercepted");
    function handleInteractionCapture(event) {
      if (!isPointerDownOutsideRef.current) {
        return;
      }
      const target = event.target;
      const isDismissableSurface = target instanceof Node && [...dismissableSurfaces].some((surface) => surface.contains(target));
      if (!isDismissableSurface) {
        interceptedOutsideInteractionEventsRef.current.set(event.type, true);
      }
      if (event.type === "click") {
        window.setTimeout(() => {
          if (isPointerDownOutsideRef.current) {
            handleClickRef.current();
          }
        }, 0);
      }
    }
    __name13(handleInteractionCapture, "handleInteractionCapture");
    function handleInteractionBubble(event) {
      if (isPointerDownOutsideRef.current) {
        interceptedOutsideInteractionEventsRef.current.set(event.type, false);
      }
    }
    __name13(handleInteractionBubble, "handleInteractionBubble");
    const handlePointerDown = /* @__PURE__ */ __name13((event) => {
      if (event.target && !isPointerInsideReactTreeRef.current) {
        let handleAndDispatchPointerDownOutsideEvent2 = function() {
          ownerDocument.removeEventListener("click", handleClickRef.current);
          const wasOutsideInteractionIntercepted = isOutsideInteractionIntercepted();
          resetOutsideInteraction();
          if (!wasOutsideInteractionIntercepted) {
            handleAndDispatchCustomEvent(
              POINTER_DOWN_OUTSIDE,
              handlePointerDownOutside,
              eventDetail,
              { discrete: true }
            );
          }
        };
        var handleAndDispatchPointerDownOutsideEvent = handleAndDispatchPointerDownOutsideEvent2;
        __name13(handleAndDispatchPointerDownOutsideEvent2, "handleAndDispatchPointerDownOutsideEvent");
        if (!shouldHandlePointerDownOutside(event.target)) {
          ownerDocument.removeEventListener("click", handleClickRef.current);
          resetOutsideInteraction();
          isPointerInsideReactTreeRef.current = false;
          return;
        }
        const eventDetail = { originalEvent: event };
        isPointerDownOutsideRef.current = true;
        isDeferredPointerDownOutsideRef.current = deferPointerDownOutside && event.button === 0;
        interceptedOutsideInteractionEventsRef.current.clear();
        if (!deferPointerDownOutside || event.button !== 0) {
          handleAndDispatchPointerDownOutsideEvent2();
        } else {
          ownerDocument.removeEventListener("click", handleClickRef.current);
          handleClickRef.current = handleAndDispatchPointerDownOutsideEvent2;
          ownerDocument.addEventListener("click", handleClickRef.current, { once: true });
        }
      } else {
        ownerDocument.removeEventListener("click", handleClickRef.current);
        resetOutsideInteraction();
      }
      isPointerInsideReactTreeRef.current = false;
    }, "handlePointerDown");
    const outsideInteractionEvents = [
      "pointerup",
      "mousedown",
      "mouseup",
      "touchstart",
      "touchend",
      "click"
    ];
    for (const eventName of outsideInteractionEvents) {
      ownerDocument.addEventListener(eventName, handleInteractionCapture, true);
      ownerDocument.addEventListener(eventName, handleInteractionBubble);
    }
    const timerId = window.setTimeout(() => {
      ownerDocument.addEventListener("pointerdown", handlePointerDown);
    }, 0);
    return () => {
      window.clearTimeout(timerId);
      ownerDocument.removeEventListener("pointerdown", handlePointerDown);
      ownerDocument.removeEventListener("click", handleClickRef.current);
      for (const eventName of outsideInteractionEvents) {
        ownerDocument.removeEventListener(eventName, handleInteractionCapture, true);
        ownerDocument.removeEventListener(eventName, handleInteractionBubble);
      }
    };
  }, [
    ownerDocument,
    handlePointerDownOutside,
    deferPointerDownOutside,
    isDeferredPointerDownOutsideRef,
    dismissableSurfaces,
    shouldHandlePointerDownOutside
  ]);
  return {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: /* @__PURE__ */ __name13(() => isPointerInsideReactTreeRef.current = true, "onPointerDownCapture")
  };
}
__name13(usePointerDownOutside, "usePointerDownOutside");
function useFocusOutside(onFocusOutside, ownerDocument = globalThis?.document) {
  const handleFocusOutside = useCallbackRef(onFocusOutside);
  const isFocusInsideReactTreeRef = React13.useRef(false);
  React13.useEffect(() => {
    const handleFocus = /* @__PURE__ */ __name13((event) => {
      if (event.target && !isFocusInsideReactTreeRef.current) {
        const eventDetail = { originalEvent: event };
        handleAndDispatchCustomEvent(FOCUS_OUTSIDE, handleFocusOutside, eventDetail, {
          discrete: false
        });
      }
    }, "handleFocus");
    ownerDocument.addEventListener("focusin", handleFocus);
    return () => ownerDocument.removeEventListener("focusin", handleFocus);
  }, [ownerDocument, handleFocusOutside]);
  return {
    onFocusCapture: /* @__PURE__ */ __name13(() => isFocusInsideReactTreeRef.current = true, "onFocusCapture"),
    onBlurCapture: /* @__PURE__ */ __name13(() => isFocusInsideReactTreeRef.current = false, "onBlurCapture")
  };
}
__name13(useFocusOutside, "useFocusOutside");
function dispatchUpdate() {
  const event = new CustomEvent(CONTEXT_UPDATE);
  document.dispatchEvent(event);
}
__name13(dispatchUpdate, "dispatchUpdate");
function handleAndDispatchCustomEvent(name, handler, detail, { discrete }) {
  const target = detail.originalEvent.target;
  const event = new CustomEvent(name, { bubbles: false, cancelable: true, detail });
  if (handler) target.addEventListener(name, handler, { once: true });
  if (discrete) {
    dispatchDiscreteCustomEvent(target, event);
  } else {
    target.dispatchEvent(event);
  }
}
__name13(handleAndDispatchCustomEvent, "handleAndDispatchCustomEvent");

// work/aplyd-academy/node_modules/@radix-ui/react-focus-scope/dist/index.mjs
import * as React15 from "react";

// work/aplyd-academy/node_modules/@radix-ui/react-focus-scope/node_modules/@radix-ui/react-compose-refs/dist/index.mjs
import * as React14 from "react";
var __defProp15 = Object.defineProperty;
var __name14 = (target, value) => __defProp15(target, "name", { value, configurable: true });
function setRef5(ref, value) {
  if (typeof ref === "function") {
    return ref(value);
  } else if (ref !== null && ref !== void 0) {
    ref.current = value;
  }
}
__name14(setRef5, "setRef");
function composeRefs4(...refs) {
  return (node) => {
    let hasCleanup = false;
    const cleanups = refs.map((ref) => {
      const cleanup = setRef5(ref, node);
      if (!hasCleanup && typeof cleanup == "function") {
        hasCleanup = true;
      }
      return cleanup;
    });
    if (hasCleanup) {
      return () => {
        for (let i = 0; i < cleanups.length; i++) {
          const cleanup = cleanups[i];
          if (typeof cleanup == "function") {
            cleanup();
          } else {
            setRef5(refs[i], null);
          }
        }
      };
    }
  };
}
__name14(composeRefs4, "composeRefs");
function useComposedRefs4(...refs) {
  return React14.useCallback(composeRefs4(...refs), refs);
}
__name14(useComposedRefs4, "useComposedRefs");

// work/aplyd-academy/node_modules/@radix-ui/react-focus-scope/dist/index.mjs
import { jsx as jsx4 } from "react/jsx-runtime";
var __defProp16 = Object.defineProperty;
var __name15 = (target, value) => __defProp16(target, "name", { value, configurable: true });
var AUTOFOCUS_ON_MOUNT = "focusScope.autoFocusOnMount";
var AUTOFOCUS_ON_UNMOUNT = "focusScope.autoFocusOnUnmount";
var EVENT_OPTIONS = { bubbles: false, cancelable: true };
var FocusScope = /* @__PURE__ */ React15.forwardRef(
  /* @__PURE__ */ __name15(function FocusScope2(props, forwardedRef) {
    const {
      loop = false,
      trapped = false,
      onMountAutoFocus: onMountAutoFocusProp,
      onUnmountAutoFocus: onUnmountAutoFocusProp,
      ...scopeProps
    } = props;
    const [container, setContainer] = React15.useState(null);
    const onMountAutoFocus = useCallbackRef(onMountAutoFocusProp);
    const onUnmountAutoFocus = useCallbackRef(onUnmountAutoFocusProp);
    const lastFocusedElementRef = React15.useRef(null);
    const composedRefs = useComposedRefs4(forwardedRef, setContainer);
    const focusScope = React15.useRef({
      paused: false,
      pause() {
        this.paused = true;
      },
      resume() {
        this.paused = false;
      }
    }).current;
    React15.useEffect(() => {
      if (trapped) {
        let handleFocusIn2 = function(event) {
          if (focusScope.paused || !container) return;
          const target = event.target;
          if (container.contains(target)) {
            lastFocusedElementRef.current = target;
          } else {
            focus(lastFocusedElementRef.current, { select: true });
          }
        }, handleFocusOut2 = function(event) {
          if (focusScope.paused || !container) return;
          const relatedTarget = event.relatedTarget;
          if (relatedTarget === null) return;
          if (!container.contains(relatedTarget)) {
            focus(lastFocusedElementRef.current, { select: true });
          }
        }, handleMutations2 = function(mutations) {
          const focusedElement = document.activeElement;
          if (focusedElement !== document.body) return;
          for (const mutation of mutations) {
            if (mutation.removedNodes.length > 0) focus(container);
          }
        };
        var handleFocusIn = handleFocusIn2, handleFocusOut = handleFocusOut2, handleMutations = handleMutations2;
        __name15(handleFocusIn2, "handleFocusIn");
        __name15(handleFocusOut2, "handleFocusOut");
        __name15(handleMutations2, "handleMutations");
        document.addEventListener("focusin", handleFocusIn2);
        document.addEventListener("focusout", handleFocusOut2);
        const mutationObserver = new MutationObserver(handleMutations2);
        if (container) mutationObserver.observe(container, { childList: true, subtree: true });
        return () => {
          document.removeEventListener("focusin", handleFocusIn2);
          document.removeEventListener("focusout", handleFocusOut2);
          mutationObserver.disconnect();
        };
      }
    }, [trapped, container, focusScope.paused]);
    React15.useEffect(() => {
      if (container) {
        focusScopesStack.add(focusScope);
        const previouslyFocusedElement = document.activeElement;
        const hasFocusedCandidate = container.contains(previouslyFocusedElement);
        if (!hasFocusedCandidate) {
          const mountEvent = new CustomEvent(AUTOFOCUS_ON_MOUNT, EVENT_OPTIONS);
          container.addEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
          container.dispatchEvent(mountEvent);
          if (!mountEvent.defaultPrevented) {
            focusFirst(removeLinks(getTabbableCandidates(container)), { select: true });
            if (document.activeElement === previouslyFocusedElement) {
              focus(container);
            }
          }
        }
        return () => {
          container.removeEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
          setTimeout(() => {
            const unmountEvent = new CustomEvent(AUTOFOCUS_ON_UNMOUNT, EVENT_OPTIONS);
            container.addEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
            container.dispatchEvent(unmountEvent);
            if (!unmountEvent.defaultPrevented) {
              focus(previouslyFocusedElement ?? document.body, { select: true });
            }
            container.removeEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
            focusScopesStack.remove(focusScope);
          }, 0);
        };
      }
    }, [container, onMountAutoFocus, onUnmountAutoFocus, focusScope]);
    const handleKeyDown = React15.useCallback(
      (event) => {
        if (!loop && !trapped) return;
        if (focusScope.paused) return;
        const isTabKey = event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey;
        const focusedElement = document.activeElement;
        if (isTabKey && focusedElement) {
          const container2 = event.currentTarget;
          const [first, last] = getTabbableEdges(container2);
          const hasTabbableElementsInside = first && last;
          if (!hasTabbableElementsInside) {
            if (focusedElement === container2) event.preventDefault();
          } else {
            if (!event.shiftKey && focusedElement === last) {
              event.preventDefault();
              if (loop) focus(first, { select: true });
            } else if (event.shiftKey && focusedElement === first) {
              event.preventDefault();
              if (loop) focus(last, { select: true });
            }
          }
        }
      },
      [loop, trapped, focusScope.paused]
    );
    return /* @__PURE__ */ jsx4(Primitive.div, { tabIndex: -1, ...scopeProps, ref: composedRefs, onKeyDown: handleKeyDown });
  }, "FocusScope")
);
function focusFirst(candidates, { select = false } = {}) {
  const previouslyFocusedElement = document.activeElement;
  for (const candidate of candidates) {
    focus(candidate, { select });
    if (document.activeElement !== previouslyFocusedElement) return;
  }
}
__name15(focusFirst, "focusFirst");
function getTabbableEdges(container) {
  const candidates = getTabbableCandidates(container);
  const first = findVisible(candidates, container);
  const last = findVisible(candidates.reverse(), container);
  return [first, last];
}
__name15(getTabbableEdges, "getTabbableEdges");
function getTabbableCandidates(container) {
  const nodes = [];
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, {
    acceptNode: /* @__PURE__ */ __name15((node) => {
      const isHiddenInput = node.tagName === "INPUT" && node.type === "hidden";
      if (node.disabled || node.hidden || isHiddenInput) return NodeFilter.FILTER_SKIP;
      return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }, "acceptNode")
  });
  while (walker.nextNode()) nodes.push(walker.currentNode);
  return nodes;
}
__name15(getTabbableCandidates, "getTabbableCandidates");
function findVisible(elements, container) {
  const canUseCheckVisibility = typeof container.checkVisibility === "function" && container.checkVisibility({ checkVisibilityCSS: true });
  for (const element of elements) {
    const hidden = canUseCheckVisibility ? !element.checkVisibility({ checkVisibilityCSS: true }) : isHidden(element, { upTo: container });
    if (!hidden) {
      return element;
    }
  }
}
__name15(findVisible, "findVisible");
function isHidden(node, { upTo }) {
  if (getComputedStyle(node).visibility === "hidden") return true;
  while (node) {
    if (upTo !== void 0 && node === upTo) return false;
    if (getComputedStyle(node).display === "none") return true;
    node = node.parentElement;
  }
  return false;
}
__name15(isHidden, "isHidden");
function isSelectableInput(element) {
  return element instanceof HTMLInputElement && "select" in element;
}
__name15(isSelectableInput, "isSelectableInput");
function focus(element, { select = false } = {}) {
  if (element && element.focus) {
    const previouslyFocusedElement = document.activeElement;
    element.focus({ preventScroll: true });
    if (element !== previouslyFocusedElement && isSelectableInput(element) && select)
      element.select();
  }
}
__name15(focus, "focus");
var focusScopesStack = createFocusScopesStack();
function createFocusScopesStack() {
  let stack = [];
  return {
    add(focusScope) {
      const activeFocusScope = stack[0];
      if (focusScope !== activeFocusScope) {
        activeFocusScope?.pause();
      }
      stack = arrayRemove(stack, focusScope);
      stack.unshift(focusScope);
    },
    remove(focusScope) {
      stack = arrayRemove(stack, focusScope);
      stack[0]?.resume();
    }
  };
}
__name15(createFocusScopesStack, "createFocusScopesStack");
function arrayRemove(array, item) {
  const updatedArray = [...array];
  const index = updatedArray.indexOf(item);
  if (index !== -1) {
    updatedArray.splice(index, 1);
  }
  return updatedArray;
}
__name15(arrayRemove, "arrayRemove");
function removeLinks(items) {
  return items.filter((item) => item.tagName !== "A");
}
__name15(removeLinks, "removeLinks");

// work/aplyd-academy/node_modules/@radix-ui/react-portal/dist/index.mjs
import * as React16 from "react";
import * as ReactDOM2 from "react-dom";
import { jsx as jsx5 } from "react/jsx-runtime";
var __defProp17 = Object.defineProperty;
var __name16 = (target, value) => __defProp17(target, "name", { value, configurable: true });
var Portal = /* @__PURE__ */ React16.forwardRef(
  /* @__PURE__ */ __name16(function Portal2(props, forwardedRef) {
    const { container: containerProp, ...portalProps } = props;
    const [mounted, setMounted] = React16.useState(false);
    useLayoutEffect2(() => setMounted(true), []);
    const container = containerProp || mounted && globalThis?.document?.body;
    return container ? ReactDOM2.createPortal(/* @__PURE__ */ jsx5(Primitive.div, { ...portalProps, ref: forwardedRef }), container) : null;
  }, "Portal")
);

// work/aplyd-academy/node_modules/@radix-ui/react-focus-guards/dist/index.mjs
import * as React17 from "react";
var __defProp18 = Object.defineProperty;
var __name17 = (target, value) => __defProp18(target, "name", { value, configurable: true });
var count2 = 0;
var guards = null;
function FocusGuards(props) {
  useFocusGuards();
  return props.children;
}
__name17(FocusGuards, "FocusGuards");
function useFocusGuards() {
  React17.useEffect(() => {
    if (!guards) {
      guards = { start: createFocusGuard(), end: createFocusGuard() };
    }
    const { start, end } = guards;
    if (document.body.firstElementChild !== start) {
      document.body.insertAdjacentElement("afterbegin", start);
    }
    if (document.body.lastElementChild !== end) {
      document.body.insertAdjacentElement("beforeend", end);
    }
    count2++;
    return () => {
      if (count2 === 1) {
        guards?.start.remove();
        guards?.end.remove();
        guards = null;
      }
      count2 = Math.max(0, count2 - 1);
    };
  }, []);
}
__name17(useFocusGuards, "useFocusGuards");
function createFocusGuard() {
  const element = document.createElement("span");
  element.setAttribute("data-radix-focus-guard", "");
  element.tabIndex = 0;
  element.style.outline = "none";
  element.style.opacity = "0";
  element.style.position = "fixed";
  element.style.pointerEvents = "none";
  return element;
}
__name17(createFocusGuard, "createFocusGuard");

// work/aplyd-academy/node_modules/tslib/tslib.es6.mjs
var __assign = function() {
  __assign = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
function __rest(s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
    t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function")
    for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
        t[p[i]] = s[p[i]];
    }
  return t;
}
function __spreadArray(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
}

// work/aplyd-academy/node_modules/react-remove-scroll/dist/es2015/Combination.js
import * as React26 from "react";

// work/aplyd-academy/node_modules/react-remove-scroll/dist/es2015/UI.js
import * as React20 from "react";

// work/aplyd-academy/node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var zeroRightClassName = "right-scroll-bar-position";
var fullWidthClassName = "width-before-scroll-bar";
var noScrollbarsClassName = "with-scroll-bars-hidden";
var removedBarSizeVariable = "--removed-body-scroll-bar-size";

// work/aplyd-academy/node_modules/use-callback-ref/dist/es2015/assignRef.js
function assignRef(ref, value) {
  if (typeof ref === "function") {
    ref(value);
  } else if (ref) {
    ref.current = value;
  }
  return ref;
}

// work/aplyd-academy/node_modules/use-callback-ref/dist/es2015/useRef.js
import { useState as useState7 } from "react";
function useCallbackRef2(initialValue, callback) {
  var ref = useState7(function() {
    return {
      // value
      value: initialValue,
      // last callback
      callback,
      // "memoized" public interface
      facade: {
        get current() {
          return ref.value;
        },
        set current(value) {
          var last = ref.value;
          if (last !== value) {
            ref.value = value;
            ref.callback(value, last);
          }
        }
      }
    };
  })[0];
  ref.callback = callback;
  return ref.facade;
}

// work/aplyd-academy/node_modules/use-callback-ref/dist/es2015/useMergeRef.js
import * as React18 from "react";
var useIsomorphicLayoutEffect = typeof window !== "undefined" ? React18.useLayoutEffect : React18.useEffect;
var currentValues = /* @__PURE__ */ new WeakMap();
function useMergeRefs(refs, defaultValue) {
  var callbackRef = useCallbackRef2(defaultValue || null, function(newValue) {
    return refs.forEach(function(ref) {
      return assignRef(ref, newValue);
    });
  });
  useIsomorphicLayoutEffect(function() {
    var oldValue = currentValues.get(callbackRef);
    if (oldValue) {
      var prevRefs_1 = new Set(oldValue);
      var nextRefs_1 = new Set(refs);
      var current_1 = callbackRef.current;
      prevRefs_1.forEach(function(ref) {
        if (!nextRefs_1.has(ref)) {
          assignRef(ref, null);
        }
      });
      nextRefs_1.forEach(function(ref) {
        if (!prevRefs_1.has(ref)) {
          assignRef(ref, current_1);
        }
      });
    }
    currentValues.set(callbackRef, refs);
  }, [refs]);
  return callbackRef;
}

// work/aplyd-academy/node_modules/use-sidecar/dist/es2015/medium.js
function ItoI(a) {
  return a;
}
function innerCreateMedium(defaults, middleware) {
  if (middleware === void 0) {
    middleware = ItoI;
  }
  var buffer = [];
  var assigned = false;
  var medium = {
    read: function() {
      if (assigned) {
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      }
      if (buffer.length) {
        return buffer[buffer.length - 1];
      }
      return defaults;
    },
    useMedium: function(data) {
      var item = middleware(data, assigned);
      buffer.push(item);
      return function() {
        buffer = buffer.filter(function(x) {
          return x !== item;
        });
      };
    },
    assignSyncMedium: function(cb) {
      assigned = true;
      while (buffer.length) {
        var cbs = buffer;
        buffer = [];
        cbs.forEach(cb);
      }
      buffer = {
        push: function(x) {
          return cb(x);
        },
        filter: function() {
          return buffer;
        }
      };
    },
    assignMedium: function(cb) {
      assigned = true;
      var pendingQueue = [];
      if (buffer.length) {
        var cbs = buffer;
        buffer = [];
        cbs.forEach(cb);
        pendingQueue = buffer;
      }
      var executeQueue = function() {
        var cbs2 = pendingQueue;
        pendingQueue = [];
        cbs2.forEach(cb);
      };
      var cycle = function() {
        return Promise.resolve().then(executeQueue);
      };
      cycle();
      buffer = {
        push: function(x) {
          pendingQueue.push(x);
          cycle();
        },
        filter: function(filter) {
          pendingQueue = pendingQueue.filter(filter);
          return buffer;
        }
      };
    }
  };
  return medium;
}
function createSidecarMedium(options) {
  if (options === void 0) {
    options = {};
  }
  var medium = innerCreateMedium(null);
  medium.options = __assign({ async: true, ssr: false }, options);
  return medium;
}

// work/aplyd-academy/node_modules/use-sidecar/dist/es2015/exports.js
import * as React19 from "react";
var SideCar = function(_a) {
  var sideCar = _a.sideCar, rest = __rest(_a, ["sideCar"]);
  if (!sideCar) {
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  }
  var Target = sideCar.read();
  if (!Target) {
    throw new Error("Sidecar medium not found");
  }
  return React19.createElement(Target, __assign({}, rest));
};
SideCar.isSideCarExport = true;
function exportSidecar(medium, exported) {
  medium.useMedium(exported);
  return SideCar;
}

// work/aplyd-academy/node_modules/react-remove-scroll/dist/es2015/medium.js
var effectCar = createSidecarMedium();

// work/aplyd-academy/node_modules/react-remove-scroll/dist/es2015/UI.js
var nothing = function() {
  return;
};
var RemoveScroll = React20.forwardRef(function(props, parentRef) {
  var ref = React20.useRef(null);
  var _a = React20.useState({
    onScrollCapture: nothing,
    onWheelCapture: nothing,
    onTouchMoveCapture: nothing
  }), callbacks = _a[0], setCallbacks = _a[1];
  var forwardProps = props.forwardProps, children = props.children, className = props.className, removeScrollBar = props.removeScrollBar, enabled = props.enabled, shards = props.shards, sideCar = props.sideCar, noRelative = props.noRelative, noIsolation = props.noIsolation, inert = props.inert, allowPinchZoom = props.allowPinchZoom, _b = props.as, Container = _b === void 0 ? "div" : _b, gapMode = props.gapMode, rest = __rest(props, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noRelative", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]);
  var SideCar2 = sideCar;
  var containerRef = useMergeRefs([ref, parentRef]);
  var containerProps = __assign(__assign({}, rest), callbacks);
  return React20.createElement(
    React20.Fragment,
    null,
    enabled && React20.createElement(SideCar2, { sideCar: effectCar, removeScrollBar, shards, noRelative, noIsolation, inert, setCallbacks, allowPinchZoom: !!allowPinchZoom, lockRef: ref, gapMode }),
    forwardProps ? React20.cloneElement(React20.Children.only(children), __assign(__assign({}, containerProps), { ref: containerRef })) : React20.createElement(Container, __assign({}, containerProps, { className, ref: containerRef }), children)
  );
});
RemoveScroll.defaultProps = {
  enabled: true,
  removeScrollBar: true,
  inert: false
};
RemoveScroll.classNames = {
  fullWidth: fullWidthClassName,
  zeroRight: zeroRightClassName
};

// work/aplyd-academy/node_modules/react-remove-scroll/dist/es2015/SideEffect.js
import * as React25 from "react";

// work/aplyd-academy/node_modules/react-remove-scroll-bar/dist/es2015/component.js
import * as React24 from "react";

// work/aplyd-academy/node_modules/react-style-singleton/dist/es2015/hook.js
import * as React21 from "react";

// work/aplyd-academy/node_modules/get-nonce/dist/es2015/index.js
var currentNonce;
var getNonce = function() {
  if (currentNonce) {
    return currentNonce;
  }
  if (typeof __webpack_nonce__ !== "undefined") {
    return __webpack_nonce__;
  }
  return void 0;
};

// work/aplyd-academy/node_modules/react-style-singleton/dist/es2015/singleton.js
function makeStyleTag() {
  if (!document)
    return null;
  var tag = document.createElement("style");
  tag.type = "text/css";
  var nonce = getNonce();
  if (nonce) {
    tag.setAttribute("nonce", nonce);
  }
  return tag;
}
function injectStyles(tag, css) {
  if (tag.styleSheet) {
    tag.styleSheet.cssText = css;
  } else {
    tag.appendChild(document.createTextNode(css));
  }
}
function insertStyleTag(tag) {
  var head = document.head || document.getElementsByTagName("head")[0];
  head.appendChild(tag);
}
var stylesheetSingleton = function() {
  var counter = 0;
  var stylesheet = null;
  return {
    add: function(style) {
      if (counter == 0) {
        if (stylesheet = makeStyleTag()) {
          injectStyles(stylesheet, style);
          insertStyleTag(stylesheet);
        }
      }
      counter++;
    },
    remove: function() {
      counter--;
      if (!counter && stylesheet) {
        stylesheet.parentNode && stylesheet.parentNode.removeChild(stylesheet);
        stylesheet = null;
      }
    }
  };
};

// work/aplyd-academy/node_modules/react-style-singleton/dist/es2015/hook.js
var styleHookSingleton = function() {
  var sheet = stylesheetSingleton();
  return function(styles, isDynamic) {
    React21.useEffect(function() {
      sheet.add(styles);
      return function() {
        sheet.remove();
      };
    }, [styles && isDynamic]);
  };
};

// work/aplyd-academy/node_modules/react-style-singleton/dist/es2015/component.js
var styleSingleton = function() {
  var useStyle = styleHookSingleton();
  var Sheet = function(_a) {
    var styles = _a.styles, dynamic = _a.dynamic;
    useStyle(styles, dynamic);
    return null;
  };
  return Sheet;
};

// work/aplyd-academy/node_modules/react-remove-scroll-bar/dist/es2015/utils.js
var zeroGap = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
};
var parse = function(x) {
  return parseInt(x || "", 10) || 0;
};
var getOffset = function(gapMode) {
  var cs = window.getComputedStyle(document.body);
  var left = cs[gapMode === "padding" ? "paddingLeft" : "marginLeft"];
  var top = cs[gapMode === "padding" ? "paddingTop" : "marginTop"];
  var right = cs[gapMode === "padding" ? "paddingRight" : "marginRight"];
  return [parse(left), parse(top), parse(right)];
};
var getGapWidth = function(gapMode) {
  if (gapMode === void 0) {
    gapMode = "margin";
  }
  if (typeof window === "undefined") {
    return zeroGap;
  }
  var offsets = getOffset(gapMode);
  var documentWidth = document.documentElement.clientWidth;
  var windowWidth = window.innerWidth;
  return {
    left: offsets[0],
    top: offsets[1],
    right: offsets[2],
    gap: Math.max(0, windowWidth - documentWidth + offsets[2] - offsets[0])
  };
};

// work/aplyd-academy/node_modules/react-remove-scroll-bar/dist/es2015/component.js
var Style = styleSingleton();
var lockAttribute = "data-scroll-locked";
var getStyles = function(_a, allowRelative, gapMode, important) {
  var left = _a.left, top = _a.top, right = _a.right, gap = _a.gap;
  if (gapMode === void 0) {
    gapMode = "margin";
  }
  return "\n  .".concat(noScrollbarsClassName, " {\n   overflow: hidden ").concat(important, ";\n   padding-right: ").concat(gap, "px ").concat(important, ";\n  }\n  body[").concat(lockAttribute, "] {\n    overflow: hidden ").concat(important, ";\n    overscroll-behavior: contain;\n    ").concat([
    allowRelative && "position: relative ".concat(important, ";"),
    gapMode === "margin" && "\n    padding-left: ".concat(left, "px;\n    padding-top: ").concat(top, "px;\n    padding-right: ").concat(right, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(gap, "px ").concat(important, ";\n    "),
    gapMode === "padding" && "padding-right: ".concat(gap, "px ").concat(important, ";")
  ].filter(Boolean).join(""), "\n  }\n  \n  .").concat(zeroRightClassName, " {\n    right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " {\n    margin-right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(zeroRightClassName, " .").concat(zeroRightClassName, " {\n    right: 0 ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " .").concat(fullWidthClassName, " {\n    margin-right: 0 ").concat(important, ";\n  }\n  \n  body[").concat(lockAttribute, "] {\n    ").concat(removedBarSizeVariable, ": ").concat(gap, "px;\n  }\n");
};
var getCurrentUseCounter = function() {
  var counter = parseInt(document.body.getAttribute(lockAttribute) || "0", 10);
  return isFinite(counter) ? counter : 0;
};
var useLockAttribute = function() {
  React24.useEffect(function() {
    document.body.setAttribute(lockAttribute, (getCurrentUseCounter() + 1).toString());
    return function() {
      var newCounter = getCurrentUseCounter() - 1;
      if (newCounter <= 0) {
        document.body.removeAttribute(lockAttribute);
      } else {
        document.body.setAttribute(lockAttribute, newCounter.toString());
      }
    };
  }, []);
};
var RemoveScrollBar = function(_a) {
  var noRelative = _a.noRelative, noImportant = _a.noImportant, _b = _a.gapMode, gapMode = _b === void 0 ? "margin" : _b;
  useLockAttribute();
  var gap = React24.useMemo(function() {
    return getGapWidth(gapMode);
  }, [gapMode]);
  return React24.createElement(Style, { styles: getStyles(gap, !noRelative, gapMode, !noImportant ? "!important" : "") });
};

// work/aplyd-academy/node_modules/react-remove-scroll/dist/es2015/aggresiveCapture.js
var passiveSupported = false;
if (typeof window !== "undefined") {
  try {
    options = Object.defineProperty({}, "passive", {
      get: function() {
        passiveSupported = true;
        return true;
      }
    });
    window.addEventListener("test", options, options);
    window.removeEventListener("test", options, options);
  } catch (err) {
    passiveSupported = false;
  }
}
var options;
var nonPassive = passiveSupported ? { passive: false } : false;

// work/aplyd-academy/node_modules/react-remove-scroll/dist/es2015/handleScroll.js
var alwaysContainsScroll = function(node) {
  return node.tagName === "TEXTAREA";
};
var elementCanBeScrolled = function(node, overflow) {
  if (!(node instanceof Element)) {
    return false;
  }
  var styles = window.getComputedStyle(node);
  return (
    // not-not-scrollable
    styles[overflow] !== "hidden" && // contains scroll inside self
    !(styles.overflowY === styles.overflowX && !alwaysContainsScroll(node) && styles[overflow] === "visible")
  );
};
var elementCouldBeVScrolled = function(node) {
  return elementCanBeScrolled(node, "overflowY");
};
var elementCouldBeHScrolled = function(node) {
  return elementCanBeScrolled(node, "overflowX");
};
var locationCouldBeScrolled = function(axis, node) {
  var ownerDocument = node.ownerDocument;
  var current = node;
  do {
    if (typeof ShadowRoot !== "undefined" && current instanceof ShadowRoot) {
      current = current.host;
    }
    var isScrollable = elementCouldBeScrolled(axis, current);
    if (isScrollable) {
      var _a = getScrollVariables(axis, current), scrollHeight = _a[1], clientHeight = _a[2];
      if (scrollHeight > clientHeight) {
        return true;
      }
    }
    current = current.parentNode;
  } while (current && current !== ownerDocument.body);
  return false;
};
var getVScrollVariables = function(_a) {
  var scrollTop = _a.scrollTop, scrollHeight = _a.scrollHeight, clientHeight = _a.clientHeight;
  return [
    scrollTop,
    scrollHeight,
    clientHeight
  ];
};
var getHScrollVariables = function(_a) {
  var scrollLeft = _a.scrollLeft, scrollWidth = _a.scrollWidth, clientWidth = _a.clientWidth;
  return [
    scrollLeft,
    scrollWidth,
    clientWidth
  ];
};
var elementCouldBeScrolled = function(axis, node) {
  return axis === "v" ? elementCouldBeVScrolled(node) : elementCouldBeHScrolled(node);
};
var getScrollVariables = function(axis, node) {
  return axis === "v" ? getVScrollVariables(node) : getHScrollVariables(node);
};
var getDirectionFactor = function(axis, direction) {
  return axis === "h" && direction === "rtl" ? -1 : 1;
};
var handleScroll = function(axis, endTarget, event, sourceDelta, noOverscroll) {
  var directionFactor = getDirectionFactor(axis, window.getComputedStyle(endTarget).direction);
  var delta = directionFactor * sourceDelta;
  var target = event.target;
  var targetInLock = endTarget.contains(target);
  var shouldCancelScroll = false;
  var isDeltaPositive = delta > 0;
  var availableScroll = 0;
  var availableScrollTop = 0;
  do {
    if (!target) {
      break;
    }
    var _a = getScrollVariables(axis, target), position = _a[0], scroll_1 = _a[1], capacity = _a[2];
    var elementScroll = scroll_1 - capacity - directionFactor * position;
    if (position || elementScroll) {
      if (elementCouldBeScrolled(axis, target)) {
        availableScroll += elementScroll;
        availableScrollTop += position;
      }
    }
    var parent_1 = target.parentNode;
    target = parent_1 && parent_1.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? parent_1.host : parent_1;
  } while (
    // portaled content
    !targetInLock && target !== document.body || // self content
    targetInLock && (endTarget.contains(target) || endTarget === target)
  );
  if (isDeltaPositive && (noOverscroll && Math.abs(availableScroll) < 1 || !noOverscroll && delta > availableScroll)) {
    shouldCancelScroll = true;
  } else if (!isDeltaPositive && (noOverscroll && Math.abs(availableScrollTop) < 1 || !noOverscroll && -delta > availableScrollTop)) {
    shouldCancelScroll = true;
  }
  return shouldCancelScroll;
};

// work/aplyd-academy/node_modules/react-remove-scroll/dist/es2015/SideEffect.js
var getTouchXY = function(event) {
  return "changedTouches" in event ? [event.changedTouches[0].clientX, event.changedTouches[0].clientY] : [0, 0];
};
var getDeltaXY = function(event) {
  return [event.deltaX, event.deltaY];
};
var extractRef = function(ref) {
  return ref && "current" in ref ? ref.current : ref;
};
var deltaCompare = function(x, y) {
  return x[0] === y[0] && x[1] === y[1];
};
var generateStyle = function(id) {
  return "\n  .block-interactivity-".concat(id, " {pointer-events: none;}\n  .allow-interactivity-").concat(id, " {pointer-events: all;}\n");
};
var idCounter = 0;
var lockStack = [];
function RemoveScrollSideCar(props) {
  var shouldPreventQueue = React25.useRef([]);
  var touchStartRef = React25.useRef([0, 0]);
  var activeAxis = React25.useRef();
  var id = React25.useState(idCounter++)[0];
  var Style2 = React25.useState(styleSingleton)[0];
  var lastProps = React25.useRef(props);
  React25.useEffect(function() {
    lastProps.current = props;
  }, [props]);
  React25.useEffect(function() {
    if (props.inert) {
      document.body.classList.add("block-interactivity-".concat(id));
      var allow_1 = __spreadArray([props.lockRef.current], (props.shards || []).map(extractRef), true).filter(Boolean);
      allow_1.forEach(function(el) {
        return el.classList.add("allow-interactivity-".concat(id));
      });
      return function() {
        document.body.classList.remove("block-interactivity-".concat(id));
        allow_1.forEach(function(el) {
          return el.classList.remove("allow-interactivity-".concat(id));
        });
      };
    }
    return;
  }, [props.inert, props.lockRef.current, props.shards]);
  var shouldCancelEvent = React25.useCallback(function(event, parent) {
    if ("touches" in event && event.touches.length === 2 || event.type === "wheel" && event.ctrlKey) {
      return !lastProps.current.allowPinchZoom;
    }
    var touch = getTouchXY(event);
    var touchStart = touchStartRef.current;
    var deltaX = "deltaX" in event ? event.deltaX : touchStart[0] - touch[0];
    var deltaY = "deltaY" in event ? event.deltaY : touchStart[1] - touch[1];
    var currentAxis;
    var target = event.target;
    var moveDirection = Math.abs(deltaX) > Math.abs(deltaY) ? "h" : "v";
    if ("touches" in event && moveDirection === "h" && target.type === "range") {
      return false;
    }
    var selection = window.getSelection();
    var anchorNode = selection && selection.anchorNode;
    var isTouchingSelection = anchorNode ? anchorNode === target || anchorNode.contains(target) : false;
    if (isTouchingSelection) {
      return false;
    }
    var canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
    if (!canBeScrolledInMainDirection) {
      return true;
    }
    if (canBeScrolledInMainDirection) {
      currentAxis = moveDirection;
    } else {
      currentAxis = moveDirection === "v" ? "h" : "v";
      canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
    }
    if (!canBeScrolledInMainDirection) {
      return false;
    }
    if (!activeAxis.current && "changedTouches" in event && (deltaX || deltaY)) {
      activeAxis.current = currentAxis;
    }
    if (!currentAxis) {
      return true;
    }
    var cancelingAxis = activeAxis.current || currentAxis;
    return handleScroll(cancelingAxis, parent, event, cancelingAxis === "h" ? deltaX : deltaY, true);
  }, []);
  var shouldPrevent = React25.useCallback(function(_event) {
    var event = _event;
    if (!lockStack.length || lockStack[lockStack.length - 1] !== Style2) {
      return;
    }
    var delta = "deltaY" in event ? getDeltaXY(event) : getTouchXY(event);
    var sourceEvent = shouldPreventQueue.current.filter(function(e) {
      return e.name === event.type && (e.target === event.target || event.target === e.shadowParent) && deltaCompare(e.delta, delta);
    })[0];
    if (sourceEvent && sourceEvent.should) {
      if (event.cancelable) {
        event.preventDefault();
      }
      return;
    }
    if (!sourceEvent) {
      var shardNodes = (lastProps.current.shards || []).map(extractRef).filter(Boolean).filter(function(node) {
        return node.contains(event.target);
      });
      var shouldStop = shardNodes.length > 0 ? shouldCancelEvent(event, shardNodes[0]) : !lastProps.current.noIsolation;
      if (shouldStop) {
        if (event.cancelable) {
          event.preventDefault();
        }
      }
    }
  }, []);
  var shouldCancel = React25.useCallback(function(name, delta, target, should) {
    var event = { name, delta, target, should, shadowParent: getOutermostShadowParent(target) };
    shouldPreventQueue.current.push(event);
    setTimeout(function() {
      shouldPreventQueue.current = shouldPreventQueue.current.filter(function(e) {
        return e !== event;
      });
    }, 1);
  }, []);
  var scrollTouchStart = React25.useCallback(function(event) {
    touchStartRef.current = getTouchXY(event);
    activeAxis.current = void 0;
  }, []);
  var scrollWheel = React25.useCallback(function(event) {
    shouldCancel(event.type, getDeltaXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
  }, []);
  var scrollTouchMove = React25.useCallback(function(event) {
    shouldCancel(event.type, getTouchXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
  }, []);
  React25.useEffect(function() {
    lockStack.push(Style2);
    props.setCallbacks({
      onScrollCapture: scrollWheel,
      onWheelCapture: scrollWheel,
      onTouchMoveCapture: scrollTouchMove
    });
    document.addEventListener("wheel", shouldPrevent, nonPassive);
    document.addEventListener("touchmove", shouldPrevent, nonPassive);
    document.addEventListener("touchstart", scrollTouchStart, nonPassive);
    return function() {
      lockStack = lockStack.filter(function(inst) {
        return inst !== Style2;
      });
      document.removeEventListener("wheel", shouldPrevent, nonPassive);
      document.removeEventListener("touchmove", shouldPrevent, nonPassive);
      document.removeEventListener("touchstart", scrollTouchStart, nonPassive);
    };
  }, []);
  var removeScrollBar = props.removeScrollBar, inert = props.inert;
  return React25.createElement(
    React25.Fragment,
    null,
    inert ? React25.createElement(Style2, { styles: generateStyle(id) }) : null,
    removeScrollBar ? React25.createElement(RemoveScrollBar, { noRelative: props.noRelative, gapMode: props.gapMode }) : null
  );
}
function getOutermostShadowParent(node) {
  var shadowParent = null;
  while (node !== null) {
    if (node instanceof ShadowRoot) {
      shadowParent = node.host;
      node = node.host;
    }
    node = node.parentNode;
  }
  return shadowParent;
}

// work/aplyd-academy/node_modules/react-remove-scroll/dist/es2015/sidecar.js
var sidecar_default = exportSidecar(effectCar, RemoveScrollSideCar);

// work/aplyd-academy/node_modules/react-remove-scroll/dist/es2015/Combination.js
var ReactRemoveScroll = React26.forwardRef(function(props, ref) {
  return React26.createElement(RemoveScroll, __assign({}, props, { ref, sideCar: sidecar_default }));
});
ReactRemoveScroll.classNames = RemoveScroll.classNames;
var Combination_default = ReactRemoveScroll;

// work/aplyd-academy/node_modules/aria-hidden/dist/es2015/index.js
var getDefaultParent = function(originalTarget) {
  if (typeof document === "undefined") {
    return null;
  }
  var sampleTarget = Array.isArray(originalTarget) ? originalTarget[0] : originalTarget;
  return sampleTarget.ownerDocument.body;
};
var counterMap = /* @__PURE__ */ new WeakMap();
var uncontrolledNodes = /* @__PURE__ */ new WeakMap();
var markerMap = {};
var lockCount = 0;
var unwrapHost = function(node) {
  return node && (node.host || unwrapHost(node.parentNode));
};
var correctTargets = function(parent, targets) {
  return targets.map(function(target) {
    if (parent.contains(target)) {
      return target;
    }
    var correctedTarget = unwrapHost(target);
    if (correctedTarget && parent.contains(correctedTarget)) {
      return correctedTarget;
    }
    console.error("aria-hidden", target, "in not contained inside", parent, ". Doing nothing");
    return null;
  }).filter(function(x) {
    return Boolean(x);
  });
};
var applyAttributeToOthers = function(originalTarget, parentNode, markerName, controlAttribute) {
  var targets = correctTargets(parentNode, Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
  if (!markerMap[markerName]) {
    markerMap[markerName] = /* @__PURE__ */ new WeakMap();
  }
  var markerCounter = markerMap[markerName];
  var hiddenNodes = [];
  var elementsToKeep = /* @__PURE__ */ new Set();
  var elementsToStop = new Set(targets);
  var keep = function(el) {
    if (!el || elementsToKeep.has(el)) {
      return;
    }
    elementsToKeep.add(el);
    keep(el.parentNode);
  };
  targets.forEach(keep);
  var deep = function(parent) {
    if (!parent || elementsToStop.has(parent)) {
      return;
    }
    Array.prototype.forEach.call(parent.children, function(node) {
      if (elementsToKeep.has(node)) {
        deep(node);
      } else {
        try {
          var attr = node.getAttribute(controlAttribute);
          var alreadyHidden = attr !== null && attr !== "false";
          var counterValue = (counterMap.get(node) || 0) + 1;
          var markerValue = (markerCounter.get(node) || 0) + 1;
          counterMap.set(node, counterValue);
          markerCounter.set(node, markerValue);
          hiddenNodes.push(node);
          if (counterValue === 1 && alreadyHidden) {
            uncontrolledNodes.set(node, true);
          }
          if (markerValue === 1) {
            node.setAttribute(markerName, "true");
          }
          if (!alreadyHidden) {
            node.setAttribute(controlAttribute, "true");
          }
        } catch (e) {
          console.error("aria-hidden: cannot operate on ", node, e);
        }
      }
    });
  };
  deep(parentNode);
  elementsToKeep.clear();
  lockCount++;
  return function() {
    hiddenNodes.forEach(function(node) {
      var counterValue = counterMap.get(node) - 1;
      var markerValue = markerCounter.get(node) - 1;
      counterMap.set(node, counterValue);
      markerCounter.set(node, markerValue);
      if (!counterValue) {
        if (!uncontrolledNodes.has(node)) {
          node.removeAttribute(controlAttribute);
        }
        uncontrolledNodes.delete(node);
      }
      if (!markerValue) {
        node.removeAttribute(markerName);
      }
    });
    lockCount--;
    if (!lockCount) {
      counterMap = /* @__PURE__ */ new WeakMap();
      counterMap = /* @__PURE__ */ new WeakMap();
      uncontrolledNodes = /* @__PURE__ */ new WeakMap();
      markerMap = {};
    }
  };
};
var hideOthers = function(originalTarget, parentNode, markerName) {
  if (markerName === void 0) {
    markerName = "data-aria-hidden";
  }
  var targets = Array.from(Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
  var activeParentNode = parentNode || getDefaultParent(originalTarget);
  if (!activeParentNode) {
    return function() {
      return null;
    };
  }
  targets.push.apply(targets, Array.from(activeParentNode.querySelectorAll("[aria-live], script")));
  return applyAttributeToOthers(targets, activeParentNode, markerName, "aria-hidden");
};

// work/aplyd-academy/node_modules/@radix-ui/react-dialog/node_modules/@radix-ui/react-slot/dist/index.mjs
import * as React27 from "react";
var __defProp19 = Object.defineProperty;
var __name18 = (target, value) => __defProp19(target, "name", { value, configurable: true });
// @__NO_SIDE_EFFECTS__
function createSlot2(ownerName) {
  const Slot22 = React27.forwardRef((props, forwardedRef) => {
    let { children, ...slotProps } = props;
    let slottableElement = null;
    let hasSlottable = false;
    const newChildren = [];
    if (isLazyComponent2(children) && typeof use2 === "function") {
      children = use2(children._payload);
    }
    React27.Children.forEach(children, (maybeSlottable) => {
      if (isSlottable2(maybeSlottable)) {
        hasSlottable = true;
        const slottable = maybeSlottable;
        let child = "child" in slottable.props ? slottable.props.child : slottable.props.children;
        if (isLazyComponent2(child) && typeof use2 === "function") {
          child = use2(child._payload);
        }
        slottableElement = getSlottableElementFromSlottable2(slottable, child);
        newChildren.push(slottableElement?.props?.children);
      } else {
        newChildren.push(maybeSlottable);
      }
    });
    if (slottableElement) {
      slottableElement = React27.cloneElement(slottableElement, void 0, newChildren);
    } else if (
      // A `Slottable` was found but it didn't resolve to a single element (e.g.
      // it wrapped multiple elements, text, or a render-prop `child` that
      // wasn't an element). Don't fall back to treating the `Slottable` wrapper
      // itself as the slot target — throw a descriptive error below instead.
      !hasSlottable && React27.Children.count(children) === 1 && React27.isValidElement(children)
    ) {
      slottableElement = children;
    }
    const slottableElementRef = slottableElement ? getElementRef3(slottableElement) : void 0;
    const composedRef = useComposedRefs2(forwardedRef, slottableElementRef);
    if (!slottableElement) {
      if (children || children === 0) {
        throw new Error(
          hasSlottable ? createSlottableError2(ownerName) : createSlotError2(ownerName)
        );
      }
      return children;
    }
    const mergedProps = mergeProps2(slotProps, slottableElement.props ?? {});
    if (slottableElement.type !== React27.Fragment) {
      mergedProps.ref = forwardedRef ? composedRef : slottableElementRef;
    }
    return React27.cloneElement(slottableElement, mergedProps);
  });
  Slot22.displayName = `${ownerName}.Slot`;
  return Slot22;
}
__name18(createSlot2, "createSlot");
var SLOTTABLE_IDENTIFIER2 = /* @__PURE__ */ Symbol.for("radix.slottable");
// @__NO_SIDE_EFFECTS__
function createSlottable2(ownerName) {
  const Slottable2 = /* @__PURE__ */ __name18((props) => "child" in props ? props.children(props.child) : props.children, "Slottable");
  Slottable2.displayName = `${ownerName}.Slottable`;
  Slottable2.__radixId = SLOTTABLE_IDENTIFIER2;
  return Slottable2;
}
__name18(createSlottable2, "createSlottable");
var getSlottableElementFromSlottable2 = /* @__PURE__ */ __name18((slottable, child) => {
  if ("child" in slottable.props) {
    const child2 = slottable.props.child;
    if (!React27.isValidElement(child2)) return null;
    return React27.cloneElement(child2, void 0, slottable.props.children(child2.props.children));
  }
  return React27.isValidElement(child) ? child : null;
}, "getSlottableElementFromSlottable");
function mergeProps2(slotProps, childProps) {
  const overrideProps = { ...childProps };
  for (const propName in childProps) {
    const slotPropValue = slotProps[propName];
    const childPropValue = childProps[propName];
    const isHandler = /^on[A-Z]/.test(propName);
    if (isHandler) {
      if (slotPropValue && childPropValue) {
        overrideProps[propName] = (...args) => {
          const result = childPropValue(...args);
          slotPropValue(...args);
          return result;
        };
      } else if (slotPropValue) {
        overrideProps[propName] = slotPropValue;
      }
    } else if (propName === "style") {
      overrideProps[propName] = { ...slotPropValue, ...childPropValue };
    } else if (propName === "className") {
      overrideProps[propName] = [slotPropValue, childPropValue].filter(Boolean).join(" ");
    }
  }
  return { ...slotProps, ...overrideProps };
}
__name18(mergeProps2, "mergeProps");
function getElementRef3(element) {
  let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
  let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.ref;
  }
  getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
  mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.props.ref;
  }
  return element.props.ref || element.ref;
}
__name18(getElementRef3, "getElementRef");
function isSlottable2(child) {
  return React27.isValidElement(child) && typeof child.type === "function" && "__radixId" in child.type && child.type.__radixId === SLOTTABLE_IDENTIFIER2;
}
__name18(isSlottable2, "isSlottable");
var REACT_LAZY_TYPE2 = /* @__PURE__ */ Symbol.for("react.lazy");
function isLazyComponent2(element) {
  return element != null && typeof element === "object" && "$$typeof" in element && element.$$typeof === REACT_LAZY_TYPE2 && "_payload" in element && isPromiseLike2(element._payload);
}
__name18(isLazyComponent2, "isLazyComponent");
function isPromiseLike2(value) {
  return typeof value === "object" && value !== null && "then" in value;
}
__name18(isPromiseLike2, "isPromiseLike");
var createSlotError2 = /* @__PURE__ */ __name18((ownerName) => {
  return `${ownerName} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`;
}, "createSlotError");
var createSlottableError2 = /* @__PURE__ */ __name18((ownerName) => {
  return `${ownerName} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`;
}, "createSlottableError");
var use2 = React27[" use ".trim().toString()];

// work/aplyd-academy/node_modules/@radix-ui/react-dialog/dist/index.mjs
import { Fragment as Fragment5, jsx as jsx6 } from "react/jsx-runtime";
var __defProp20 = Object.defineProperty;
var __name19 = (target, value) => __defProp20(target, "name", { value, configurable: true });
var DIALOG_NAME = "Dialog";
var [createDialogContext, createDialogScope] = createContextScope(DIALOG_NAME);
var [DialogProvider, useDialogContext] = createDialogContext(DIALOG_NAME);
var Dialog = /* @__PURE__ */ __name19((props) => {
  const {
    __scopeDialog,
    children,
    open: openProp,
    defaultOpen,
    onOpenChange,
    modal = true
  } = props;
  const triggerRef = React28.useRef(null);
  const contentRef3 = React28.useRef(null);
  const [open, setOpen] = useControllableState({
    prop: openProp,
    defaultProp: defaultOpen ?? false,
    onChange: onOpenChange,
    caller: DIALOG_NAME
  });
  const [titleCount, setTitleCount] = React28.useState(0);
  const [descriptionCount, setDescriptionCount] = React28.useState(0);
  return /* @__PURE__ */ jsx6(
    DialogProvider,
    {
      scope: __scopeDialog,
      triggerRef,
      contentRef: contentRef3,
      contentId: useId(),
      titleId: useId(),
      descriptionId: useId(),
      titlePresent: titleCount > 0,
      descriptionPresent: descriptionCount > 0,
      setTitleCount,
      setDescriptionCount,
      open,
      onOpenChange: setOpen,
      onOpenToggle: React28.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
      modal,
      children
    }
  );
}, "Dialog");
var TRIGGER_NAME = "DialogTrigger";
var DialogTrigger = /* @__PURE__ */ React28.forwardRef(
  /* @__PURE__ */ __name19(function DialogTrigger2(props, forwardedRef) {
    const { __scopeDialog, ...triggerProps } = props;
    const context = useDialogContext(TRIGGER_NAME, __scopeDialog);
    const composedTriggerRef = useComposedRefs2(forwardedRef, context.triggerRef);
    return /* @__PURE__ */ jsx6(
      Primitive.button,
      {
        type: "button",
        "aria-haspopup": "dialog",
        "aria-expanded": context.open,
        "aria-controls": context.open ? context.contentId : void 0,
        "data-state": getState(context.open),
        ...triggerProps,
        ref: composedTriggerRef,
        onClick: composeEventHandlers(props.onClick, context.onOpenToggle)
      }
    );
  }, "DialogTrigger")
);
var PORTAL_NAME = "DialogPortal";
var [PortalProvider, usePortalContext] = createDialogContext(PORTAL_NAME, {
  forceMount: void 0
});
var DialogPortal = /* @__PURE__ */ __name19((props) => {
  const { __scopeDialog, forceMount, children, container } = props;
  const context = useDialogContext(PORTAL_NAME, __scopeDialog);
  return /* @__PURE__ */ jsx6(PortalProvider, { scope: __scopeDialog, forceMount, children: React28.Children.map(children, (child) => /* @__PURE__ */ jsx6(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ jsx6(Portal, { asChild: true, container, children: child }) })) });
}, "DialogPortal");
var OVERLAY_NAME = "DialogOverlay";
var DialogOverlay = /* @__PURE__ */ React28.forwardRef(
  /* @__PURE__ */ __name19(function DialogOverlay2(props, forwardedRef) {
    const portalContext = usePortalContext(OVERLAY_NAME, props.__scopeDialog);
    const { forceMount = portalContext.forceMount, ...overlayProps } = props;
    const context = useDialogContext(OVERLAY_NAME, props.__scopeDialog);
    return context.modal ? /* @__PURE__ */ jsx6(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ jsx6(DialogOverlayImpl, { ...overlayProps, ref: forwardedRef }) }) : null;
  }, "DialogOverlay")
);
var Slot = createSlot2("DialogOverlay.RemoveScroll");
var DialogOverlayImpl = /* @__PURE__ */ React28.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ __name19(function DialogOverlayImpl2(props, forwardedRef) {
    const { __scopeDialog, ...overlayProps } = props;
    const context = useDialogContext(OVERLAY_NAME, __scopeDialog);
    const registerDismissableSurface = useDismissableLayerSurface();
    const composedRefs = useComposedRefs2(forwardedRef, registerDismissableSurface);
    return (
      // Make sure `Content` is scrollable even when it doesn't live inside `RemoveScroll`
      // ie. when `Overlay` and `Content` are siblings
      /* @__PURE__ */ jsx6(Combination_default, { as: Slot, allowPinchZoom: true, shards: [context.contentRef], children: /* @__PURE__ */ jsx6(
        Primitive.div,
        {
          "data-state": getState(context.open),
          ...overlayProps,
          ref: composedRefs,
          style: { pointerEvents: "auto", ...overlayProps.style }
        }
      ) })
    );
  }, "DialogOverlayImpl")
);
var CONTENT_NAME = "DialogContent";
var DialogContent = /* @__PURE__ */ React28.forwardRef(
  /* @__PURE__ */ __name19(function DialogContent2(props, forwardedRef) {
    const portalContext = usePortalContext(CONTENT_NAME, props.__scopeDialog);
    const { forceMount = portalContext.forceMount, ...contentProps } = props;
    const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
    return /* @__PURE__ */ jsx6(Presence, { present: forceMount || context.open, children: context.modal ? /* @__PURE__ */ jsx6(DialogContentModal, { ...contentProps, ref: forwardedRef }) : /* @__PURE__ */ jsx6(DialogContentNonModal, { ...contentProps, ref: forwardedRef }) });
  }, "DialogContent")
);
var DialogContentModal = /* @__PURE__ */ React28.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ __name19(function DialogContentModal2(props, forwardedRef) {
    const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
    const contentRef3 = React28.useRef(null);
    const composedRefs = useComposedRefs2(forwardedRef, context.contentRef, contentRef3);
    React28.useEffect(() => {
      const content = contentRef3.current;
      if (content) return hideOthers(content);
    }, []);
    return /* @__PURE__ */ jsx6(
      DialogContentImpl,
      {
        ...props,
        ref: composedRefs,
        trapFocus: context.open,
        disableOutsidePointerEvents: context.open,
        onCloseAutoFocus: composeEventHandlers(props.onCloseAutoFocus, (event) => {
          event.preventDefault();
          context.triggerRef.current?.focus();
        }),
        onPointerDownOutside: composeEventHandlers(props.onPointerDownOutside, (event) => {
          const originalEvent = event.detail.originalEvent;
          const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
          const isRightClick = originalEvent.button === 2 || ctrlLeftClick;
          if (isRightClick) event.preventDefault();
        }),
        onFocusOutside: composeEventHandlers(
          props.onFocusOutside,
          (event) => event.preventDefault()
        )
      }
    );
  }, "DialogContentModal")
);
var DialogContentNonModal = /* @__PURE__ */ React28.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ __name19(function DialogContentNonModal2(props, forwardedRef) {
    const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
    const hasInteractedOutsideRef = React28.useRef(false);
    const hasPointerDownOutsideRef = React28.useRef(false);
    return /* @__PURE__ */ jsx6(
      DialogContentImpl,
      {
        ...props,
        ref: forwardedRef,
        trapFocus: false,
        disableOutsidePointerEvents: false,
        onCloseAutoFocus: (event) => {
          props.onCloseAutoFocus?.(event);
          if (!event.defaultPrevented) {
            if (!hasInteractedOutsideRef.current) context.triggerRef.current?.focus();
            event.preventDefault();
          }
          hasInteractedOutsideRef.current = false;
          hasPointerDownOutsideRef.current = false;
        },
        onInteractOutside: (event) => {
          props.onInteractOutside?.(event);
          if (!event.defaultPrevented) {
            hasInteractedOutsideRef.current = true;
            if (event.detail.originalEvent.type === "pointerdown") {
              hasPointerDownOutsideRef.current = true;
            }
          }
          const target = event.target;
          const targetIsTrigger = context.triggerRef.current?.contains(target);
          if (targetIsTrigger) event.preventDefault();
          if (event.detail.originalEvent.type === "focusin" && hasPointerDownOutsideRef.current) {
            event.preventDefault();
          }
        }
      }
    );
  }, "DialogContentNonModal")
);
var DialogContentImpl = /* @__PURE__ */ React28.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ __name19(function DialogContentImpl2(props, forwardedRef) {
    const { __scopeDialog, trapFocus, onOpenAutoFocus, onCloseAutoFocus, ...contentProps } = props;
    const context = useDialogContext(CONTENT_NAME, __scopeDialog);
    useFocusGuards();
    return /* @__PURE__ */ jsx6(Fragment5, { children: /* @__PURE__ */ jsx6(
      FocusScope,
      {
        asChild: true,
        loop: true,
        trapped: trapFocus,
        onMountAutoFocus: onOpenAutoFocus,
        onUnmountAutoFocus: onCloseAutoFocus,
        children: /* @__PURE__ */ jsx6(
          DismissableLayer,
          {
            role: "dialog",
            id: context.contentId,
            "aria-describedby": context.descriptionPresent ? context.descriptionId : void 0,
            "aria-labelledby": context.titlePresent ? context.titleId : void 0,
            "data-state": getState(context.open),
            ...contentProps,
            ref: forwardedRef,
            deferPointerDownOutside: true,
            onDismiss: () => context.onOpenChange(false)
          }
        )
      }
    ) });
  }, "DialogContentImpl")
);
var TITLE_NAME = "DialogTitle";
var DialogTitle = /* @__PURE__ */ React28.forwardRef(
  /* @__PURE__ */ __name19(function DialogTitle2(props, forwardedRef) {
    const { __scopeDialog, ...titleProps } = props;
    const context = useDialogContext(TITLE_NAME, __scopeDialog);
    const { setTitleCount } = context;
    useLayoutEffect2(() => {
      setTitleCount((count3) => count3 + 1);
      return () => setTitleCount((count3) => count3 - 1);
    }, [setTitleCount]);
    return /* @__PURE__ */ jsx6(Primitive.h2, { id: context.titleId, ...titleProps, ref: forwardedRef });
  }, "DialogTitle")
);
var DESCRIPTION_NAME = "DialogDescription";
var DialogDescription = /* @__PURE__ */ React28.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ __name19(function DialogDescription2(props, forwardedRef) {
    const { __scopeDialog, ...descriptionProps } = props;
    const context = useDialogContext(DESCRIPTION_NAME, __scopeDialog);
    const { setDescriptionCount } = context;
    useLayoutEffect2(() => {
      setDescriptionCount((count3) => count3 + 1);
      return () => setDescriptionCount((count3) => count3 - 1);
    }, [setDescriptionCount]);
    return /* @__PURE__ */ jsx6(Primitive.p, { id: context.descriptionId, ...descriptionProps, ref: forwardedRef });
  }, "DialogDescription")
);
var CLOSE_NAME = "DialogClose";
var DialogClose = /* @__PURE__ */ React28.forwardRef(
  /* @__PURE__ */ __name19(function DialogClose2(props, forwardedRef) {
    const { __scopeDialog, ...closeProps } = props;
    const context = useDialogContext(CLOSE_NAME, __scopeDialog);
    return /* @__PURE__ */ jsx6(
      Primitive.button,
      {
        type: "button",
        ...closeProps,
        ref: forwardedRef,
        onClick: composeEventHandlers(props.onClick, () => context.onOpenChange(false))
      }
    );
  }, "DialogClose")
);
var WarningProvider = /* @__PURE__ */ __name19((props) => {
  return props.children;
}, "WarningProvider");
function getState(open) {
  return open ? "open" : "closed";
}
__name19(getState, "getState");

// work/aplyd-academy/node_modules/radix-ui/node_modules/@radix-ui/react-slot/dist/index.mjs
var dist_exports2 = {};
__export(dist_exports2, {
  Root: () => Slot2,
  Slot: () => Slot2,
  Slottable: () => Slottable,
  createSlot: () => createSlot3,
  createSlottable: () => createSlottable3
});
import * as React30 from "react";

// work/aplyd-academy/node_modules/radix-ui/node_modules/@radix-ui/react-compose-refs/dist/index.mjs
import * as React29 from "react";
var __defProp21 = Object.defineProperty;
var __name20 = (target, value) => __defProp21(target, "name", { value, configurable: true });
function setRef6(ref, value) {
  if (typeof ref === "function") {
    return ref(value);
  } else if (ref !== null && ref !== void 0) {
    ref.current = value;
  }
}
__name20(setRef6, "setRef");
function composeRefs5(...refs) {
  return (node) => {
    let hasCleanup = false;
    const cleanups = refs.map((ref) => {
      const cleanup = setRef6(ref, node);
      if (!hasCleanup && typeof cleanup == "function") {
        hasCleanup = true;
      }
      return cleanup;
    });
    if (hasCleanup) {
      return () => {
        for (let i = 0; i < cleanups.length; i++) {
          const cleanup = cleanups[i];
          if (typeof cleanup == "function") {
            cleanup();
          } else {
            setRef6(refs[i], null);
          }
        }
      };
    }
  };
}
__name20(composeRefs5, "composeRefs");
function useComposedRefs5(...refs) {
  return React29.useCallback(composeRefs5(...refs), refs);
}
__name20(useComposedRefs5, "useComposedRefs");

// work/aplyd-academy/node_modules/radix-ui/node_modules/@radix-ui/react-slot/dist/index.mjs
var __defProp22 = Object.defineProperty;
var __name21 = (target, value) => __defProp22(target, "name", { value, configurable: true });
// @__NO_SIDE_EFFECTS__
function createSlot3(ownerName) {
  const Slot22 = React30.forwardRef((props, forwardedRef) => {
    let { children, ...slotProps } = props;
    let slottableElement = null;
    let hasSlottable = false;
    const newChildren = [];
    if (isLazyComponent3(children) && typeof use3 === "function") {
      children = use3(children._payload);
    }
    React30.Children.forEach(children, (maybeSlottable) => {
      if (isSlottable3(maybeSlottable)) {
        hasSlottable = true;
        const slottable = maybeSlottable;
        let child = "child" in slottable.props ? slottable.props.child : slottable.props.children;
        if (isLazyComponent3(child) && typeof use3 === "function") {
          child = use3(child._payload);
        }
        slottableElement = getSlottableElementFromSlottable3(slottable, child);
        newChildren.push(slottableElement?.props?.children);
      } else {
        newChildren.push(maybeSlottable);
      }
    });
    if (slottableElement) {
      slottableElement = React30.cloneElement(slottableElement, void 0, newChildren);
    } else if (
      // A `Slottable` was found but it didn't resolve to a single element (e.g.
      // it wrapped multiple elements, text, or a render-prop `child` that
      // wasn't an element). Don't fall back to treating the `Slottable` wrapper
      // itself as the slot target — throw a descriptive error below instead.
      !hasSlottable && React30.Children.count(children) === 1 && React30.isValidElement(children)
    ) {
      slottableElement = children;
    }
    const slottableElementRef = slottableElement ? getElementRef4(slottableElement) : void 0;
    const composedRef = useComposedRefs5(forwardedRef, slottableElementRef);
    if (!slottableElement) {
      if (children || children === 0) {
        throw new Error(
          hasSlottable ? createSlottableError3(ownerName) : createSlotError3(ownerName)
        );
      }
      return children;
    }
    const mergedProps = mergeProps3(slotProps, slottableElement.props ?? {});
    if (slottableElement.type !== React30.Fragment) {
      mergedProps.ref = forwardedRef ? composedRef : slottableElementRef;
    }
    return React30.cloneElement(slottableElement, mergedProps);
  });
  Slot22.displayName = `${ownerName}.Slot`;
  return Slot22;
}
__name21(createSlot3, "createSlot");
var Slot2 = /* @__PURE__ */ createSlot3("Slot");
var SLOTTABLE_IDENTIFIER3 = /* @__PURE__ */ Symbol.for("radix.slottable");
// @__NO_SIDE_EFFECTS__
function createSlottable3(ownerName) {
  const Slottable2 = /* @__PURE__ */ __name21((props) => "child" in props ? props.children(props.child) : props.children, "Slottable");
  Slottable2.displayName = `${ownerName}.Slottable`;
  Slottable2.__radixId = SLOTTABLE_IDENTIFIER3;
  return Slottable2;
}
__name21(createSlottable3, "createSlottable");
var Slottable = /* @__PURE__ */ createSlottable3("Slottable");
var getSlottableElementFromSlottable3 = /* @__PURE__ */ __name21((slottable, child) => {
  if ("child" in slottable.props) {
    const child2 = slottable.props.child;
    if (!React30.isValidElement(child2)) return null;
    return React30.cloneElement(child2, void 0, slottable.props.children(child2.props.children));
  }
  return React30.isValidElement(child) ? child : null;
}, "getSlottableElementFromSlottable");
function mergeProps3(slotProps, childProps) {
  const overrideProps = { ...childProps };
  for (const propName in childProps) {
    const slotPropValue = slotProps[propName];
    const childPropValue = childProps[propName];
    const isHandler = /^on[A-Z]/.test(propName);
    if (isHandler) {
      if (slotPropValue && childPropValue) {
        overrideProps[propName] = (...args) => {
          const result = childPropValue(...args);
          slotPropValue(...args);
          return result;
        };
      } else if (slotPropValue) {
        overrideProps[propName] = slotPropValue;
      }
    } else if (propName === "style") {
      overrideProps[propName] = { ...slotPropValue, ...childPropValue };
    } else if (propName === "className") {
      overrideProps[propName] = [slotPropValue, childPropValue].filter(Boolean).join(" ");
    }
  }
  return { ...slotProps, ...overrideProps };
}
__name21(mergeProps3, "mergeProps");
function getElementRef4(element) {
  let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
  let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.ref;
  }
  getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
  mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.props.ref;
  }
  return element.props.ref || element.ref;
}
__name21(getElementRef4, "getElementRef");
function isSlottable3(child) {
  return React30.isValidElement(child) && typeof child.type === "function" && "__radixId" in child.type && child.type.__radixId === SLOTTABLE_IDENTIFIER3;
}
__name21(isSlottable3, "isSlottable");
var REACT_LAZY_TYPE3 = /* @__PURE__ */ Symbol.for("react.lazy");
function isLazyComponent3(element) {
  return element != null && typeof element === "object" && "$$typeof" in element && element.$$typeof === REACT_LAZY_TYPE3 && "_payload" in element && isPromiseLike3(element._payload);
}
__name21(isLazyComponent3, "isLazyComponent");
function isPromiseLike3(value) {
  return typeof value === "object" && value !== null && "then" in value;
}
__name21(isPromiseLike3, "isPromiseLike");
var createSlotError3 = /* @__PURE__ */ __name21((ownerName) => {
  return `${ownerName} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`;
}, "createSlotError");
var createSlottableError3 = /* @__PURE__ */ __name21((ownerName) => {
  return `${ownerName} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`;
}, "createSlottableError");
var use3 = React30[" use ".trim().toString()];

// work/aplyd-academy/lib/utils.ts
var import_tailwind_merge = __toESM(require_bundle_cjs(), 1);
function cn(...inputs) {
  return (0, import_tailwind_merge.twMerge)(clsx(inputs));
}

// work/aplyd-academy/components/ui/button.tsx
import { jsx as jsx7 } from "react/jsx-runtime";
var buttonVariants = cva(
  "inline-flex shrink-0 items-center justify-center gap-2 rounded-md text-sm font-medium whitespace-nowrap transition-all outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:bg-destructive/60 dark:focus-visible:ring-destructive/40",
        outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:border-input dark:bg-input/30 dark:hover:bg-input/50",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2 has-[>svg]:px-3",
        xs: "h-6 gap-1 rounded-md px-2 text-xs has-[>svg]:px-1.5 [&_svg:not([class*='size-'])]:size-3",
        sm: "h-8 gap-1.5 rounded-md px-3 has-[>svg]:px-2.5",
        lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
        icon: "size-9",
        "icon-xs": "size-6 rounded-md [&_svg:not([class*='size-'])]:size-3",
        "icon-sm": "size-8",
        "icon-lg": "size-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
function Button({
  className,
  variant = "default",
  size = "default",
  asChild = false,
  ...props
}) {
  const Comp = asChild ? dist_exports2.Root : "button";
  return /* @__PURE__ */ jsx7(
    Comp,
    {
      "data-slot": "button",
      "data-variant": variant,
      "data-size": size,
      className: cn(buttonVariants({ variant, size, className })),
      ...props
    }
  );
}

// work/aplyd-academy/components/ui/dialog.tsx
import * as React31 from "react";
import { jsx as jsx8, jsxs } from "react/jsx-runtime";
function Dialog2({
  ...props
}) {
  return /* @__PURE__ */ jsx8(dist_exports.Root, { "data-slot": "dialog", ...props });
}
function DialogPortal2({
  ...props
}) {
  return /* @__PURE__ */ jsx8(dist_exports.Portal, { "data-slot": "dialog-portal", ...props });
}
function DialogOverlay3({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx8(
    dist_exports.Overlay,
    {
      "data-slot": "dialog-overlay",
      className: cn(
        "fixed inset-0 z-50 bg-black/50 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0",
        className
      ),
      ...props
    }
  );
}
function DialogContent3({
  className,
  children,
  showCloseButton = true,
  onOpenAutoFocus,
  onCloseAutoFocus,
  ...props
}) {
  const opener = React31.useRef(null);
  return /* @__PURE__ */ jsxs(DialogPortal2, { "data-slot": "dialog-portal", children: [
    /* @__PURE__ */ jsx8(DialogOverlay3, {}),
    /* @__PURE__ */ jsxs(
      dist_exports.Content,
      {
        "data-slot": "dialog-content",
        onOpenAutoFocus: (event) => {
          opener.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
          onOpenAutoFocus?.(event);
        },
        onCloseAutoFocus: (event) => {
          onCloseAutoFocus?.(event);
          if (!event.defaultPrevented) {
            event.preventDefault();
            const target = opener.current?.isConnected ? opener.current : document.getElementById("main");
            target?.focus({ preventScroll: true });
          }
        },
        className: cn(
          "fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border bg-background p-6 shadow-lg duration-200 outline-none data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95 sm:max-w-lg",
          className
        ),
        ...props,
        children: [
          children,
          showCloseButton && /* @__PURE__ */ jsxs(
            dist_exports.Close,
            {
              "data-slot": "dialog-close",
              className: "absolute top-4 right-4 rounded-xs opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
              children: [
                /* @__PURE__ */ jsx8(X, {}),
                /* @__PURE__ */ jsx8("span", { className: "sr-only", children: "Close" })
              ]
            }
          )
        ]
      }
    )
  ] });
}
function DialogHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx8(
    "div",
    {
      "data-slot": "dialog-header",
      className: cn("flex flex-col gap-2 text-center sm:text-left", className),
      ...props
    }
  );
}
function DialogTitle3({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx8(
    dist_exports.Title,
    {
      "data-slot": "dialog-title",
      className: cn("text-lg leading-none font-semibold", className),
      ...props
    }
  );
}
function DialogDescription3({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx8(
    dist_exports.Description,
    {
      "data-slot": "dialog-description",
      className: cn("text-sm text-muted-foreground", className),
      ...props
    }
  );
}

// work/aplyd-academy/app/academy-context.tsx
import { createContext as createContext4, useContext as useContext4, useRef as useRef12 } from "react";
var AcademyContext = createContext4(null);
var useAcademy = () => useContext4(AcademyContext);
function useWorkspaceDraft(key, initial) {
  const { scratch, setScratch, activeWorkspace } = useAcademy();
  const storageKey = activeWorkspace + ":" + key;
  const seed = useRef12(null);
  if (!seed.current || seed.current.key !== storageKey) seed.current = { key: storageKey, value: typeof initial === "function" ? initial() : initial };
  const fallback = seed.current.value;
  const value = Object.hasOwn(scratch, storageKey) ? scratch[storageKey] : fallback;
  const setValue = (next) => setScratch((prior) => {
    const current = Object.hasOwn(prior, storageKey) ? prior[storageKey] : fallback;
    return { ...prior, [storageKey]: typeof next === "function" ? next(current) : next };
  });
  return [value, setValue];
}

// work/aplyd-academy/components/ui/select.tsx
import { jsx as jsx9, jsxs as jsxs2 } from "react/jsx-runtime";

// work/aplyd-academy/app/academy-ui.tsx
import { jsx as jsx10, jsxs as jsxs3 } from "react/jsx-runtime";
function FormError() {
  const context = useAcademy();
  return context?.error ? /* @__PURE__ */ jsx10("div", { role: "alert", className: "notice error-notice", children: /* @__PURE__ */ jsxs3("p", { children: [
    /* @__PURE__ */ jsx10("strong", { children: "The last action was not saved." }),
    " ",
    context.error
  ] }) }) : null;
}
function Empty({ icon: Icon2, title, body, action, onAction }) {
  return /* @__PURE__ */ jsxs3("div", { className: "empty-state", children: [
    Icon2 && /* @__PURE__ */ jsx10(Icon2, { size: 32 }),
    /* @__PURE__ */ jsx10("h2", { children: title }),
    /* @__PURE__ */ jsx10("p", { children: body }),
    action && /* @__PURE__ */ jsx10(Button, { onClick: onAction, children: action })
  ] });
}
function Tag({ children, tone = "" }) {
  return /* @__PURE__ */ jsx10("span", { className: `status-tag ${tone}`, children });
}
function Head({ eyebrow, title, body, children }) {
  return /* @__PURE__ */ jsxs3("div", { className: "page-heading", children: [
    /* @__PURE__ */ jsxs3("div", { children: [
      /* @__PURE__ */ jsx10("p", { className: "eyebrow", children: eyebrow }),
      /* @__PURE__ */ jsx10("h1", { children: title }),
      body && /* @__PURE__ */ jsx10("p", { children: body })
    ] }),
    children
  ] });
}
var date = (v) => new Date(v).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });

// work/aplyd-academy/lib/curriculum-versions/0.1-review-draft.json
var review_draft_default = {
  schemaVersion: "1.0",
  contentVersion: "0.1-review-draft",
  product: "Aplyd Academy",
  status: "Review draft: not approved sector training, accredited curriculum, or professional advice",
  language: "en",
  audience: "Adult learners",
  designNotes: [
    "All people, orders, records, documents, policies and AI outputs in this file are fictional teaching fixtures.",
    "Supplied AI drafts allow the whole journey to work without an external AI account or API call.",
    "An approved external AI tool may optionally produce another draft using the synthetic packet only. Learners must not enter real confidential material or credentials.",
    "Quiz feedback supports learning. A quiz score alone must not issue a competency credential.",
    "Practical assessment requires an assigned human reviewer. Rubric weights and critical gates are proposed, published training standards for this draft.",
    "A facilitator may read lesson text and capture an oral response with learner confirmation when an approved accommodation exists. Assistance must be recorded and must not supply the judgment answer."
  ],
  assessmentPolicy: {
    scoreScale: [0, 1, 2, 3, 4],
    weightedScoreFormula: "Sum of criterion weight multiplied by criterion score divided by 4; maximum 100",
    minimumWeightedScore: 70,
    passingRule: "Weighted score is at least 70 AND every declared critical gate is met. A critical failure cannot be averaged away.",
    decisionAuthority: "Assigned independent human assessor; no self-assessment or autonomous AI credential decision",
    feedbackRule: "Record score, evidence reference, critical-gate decision and actionable feedback for each criterion.",
    retryRule: "Retries and deadlines must be published by the offering before enrollment. Do not infer a fixed retry allowance from this seed file.",
    appealRule: "A learner may request a reasoned review under the offering's published appeal policy. The appeal reviewer must be independent of the original decision."
  },
  pathways: [
    {
      id: "farmer-work-records",
      title: "Farm records and better questions with AI",
      ecosystem: "Agri Saha",
      role: "Farmer",
      level: "Foundation to applied",
      summary: "Organize an activity record, check an AI-generated summary, and prepare useful questions for an agricultural expert.",
      promise: "You can turn a simple farm record into a verified summary and explain what still needs expert input.",
      estimatedMinutes: 110,
      prerequisites: ["Understand the example currency amounts with help if needed", "Use a simple form or receive planned facilitator assistance"],
      outcomes: ["Distinguish a duplicate transaction from a separate expense", "Check totals against source records", "Spot unsupported AI claims", "Create a clear expert question brief", "Keep private or commercially sensitive records out of unapproved tools"],
      credentialClaim: "Demonstrated farm-record organization, information checking and expert-question preparation using synthetic training data",
      credentialExclusions: ["No agricultural professional qualification", "No certification to prescribe farm inputs or make agronomic decisions"],
      sourceNotice: "Synthetic farm records supplied within each activity are the only factual source for this exercise.",
      lessons: [
        {
          id: "farm-01",
          title: "Make a useful work record",
          estimatedMinutes: 25,
          objective: "Build a consistent record and verify a duplicate before calculating a total.",
          lessonText: "A useful record separates what happened from what you think it means. Start with a date, activity, transaction reference, amount and unit where needed. A repeated line may be a duplicate, but two similar expenses can also be real. Check the reference or original receipt before removing anything. In this exercise, the source packet explicitly says that T02 was copied twice and represents one transport payment. Keep a note of that correction. Add the verified amounts rather than trusting a total supplied by a tool. AI can help organize a table or explain a calculation, but it cannot know which entry is genuine without evidence. When you use your own records later, keep the master copy in your approved location and choose a tool you are permitted to use. You do not need to upload names, telephone numbers, bank information or exact location details to practise this skill.",
          steps: ["Read the source packet", "Create one row per confirmed transaction", "Record why the extra T02 line was removed", "Calculate the verified total", "Identify one field you would add for future records"],
          exercise: {
            title: "Clean the fictional farm activity record",
            sourcePacket: [
              { sourceId: "T01", date: "2026-10-01", activity: "Recordkeeping support", quantity: 3, unit: "hours", rate: 150, amount: 450, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR" },
              { sourceId: "T03", date: "2026-10-03", activity: "Storage materials", quantity: 1, unit: "lot", rate: 800, amount: 800, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR", sourceNote: "Confirmed copied line; same receipt and payment as T02 above" }
            ],
            suppliedAiDraft: "The four entries total INR 1,550. Each row is a separate expense.",
            optionalAiPrompt: "Organize the supplied fictional transactions into a table. Use the source note to handle duplicates, show the calculation, and list uncertainty. Do not infer farm area, crop performance or missing transactions.",
            learnerTask: "Produce a corrected three-row table, show your total and explain the duplicate correction.",
            expectedEvidence: ["Corrected rows with source references", "450 + 150 + 800 = 1,400", "Note that T02 was removed once because the source confirms a copied payment", "One useful future record field such as receipt reference or unit"],
            assessorReference: "There are three confirmed transactions totaling INR 1,400. The raw four-line total is INR 1,550, but that counts the confirmed T02 copy twice. A learner must not generalize that every repeated amount is a duplicate."
          },
          quiz: [
            { id: "farm-01-q1", question: "What is the verified expense total?", options: ["INR 1,400", "INR 1,550", "INR 1,250", "It must be guessed from the activities"], correctOptionIndex: 0, explanation: "T02 is a confirmed copy of the same payment. The three verified amounts are 450, 150 and 800, which total 1,400." },
            { id: "farm-01-q2", question: "Two entries have the same amount but different receipt references. What should you do?", options: ["Delete the second amount automatically", "Keep both as confirmed without checking", "Check the source records before deciding whether either is duplicated", "Ask AI to choose the genuine one without evidence"], correctOptionIndex: 2, explanation: "Equal amounts are not proof of duplication. The original references and payment evidence decide whether the expenses are separate." },
            { id: "farm-01-q3", question: "Which practice input is suitable for this activity?", options: ["Your bank login details", "The supplied fictional record", "A neighbor's private transaction history", "Any record because AI makes it anonymous"], correctOptionIndex: 1, explanation: "The fictional record provides enough information for practice. Uploading private or secret information is unnecessary and inappropriate." }
          ],
          reflectionPrompt: "Which record field would make it easier for you to check a future total, and why?",
          returnToWorkAction: "Create a blank record template in an approved location. Use it for one permitted task and check entries against the original records before any sharing."
        },
        {
          id: "farm-02",
          title: "Check an AI summary before using it",
          estimatedMinutes: 20,
          objective: "Separate supported observations, missing context and unsupported recommendations.",
          lessonText: "A summary can sound confident while mixing correct statements with invented ones. Check important statements one at a time. Ask what evidence supports each claim. A total can be checked against transaction rows. A cost per acre needs area information. A claim about crop results needs relevant evidence, rather than a guess based on expenses. In this activity, the verified spending record tells you what was recorded; it does not tell you the farm area, complete budget, crop condition or likely yield. Mark these gaps explicitly. When a claim could affect a significant farm decision, prepare a question for an appropriate expert instead of treating an AI draft as a recommendation. A useful summary includes the known total, its limited scope, and the missing information. Verification is part of the work, even when it takes more time than generating the draft.",
          steps: ["Check the total", "Label each claim supported, unsupported or unknown", "Explain what evidence a per-acre figure would need", "Rewrite the summary with limits", "Identify the claim that needs expert input"],
          exercise: {
            title: "Find the unsupported claims",
            sourcePacket: ["Verified transactions: T01 INR 450; T02 INR 150; T03 INR 800.", "Recorded total: INR 1,400.", "Farm area, crop condition, total seasonal budget and crop outcomes are not supplied."],
            suppliedAiDraft: "The recorded expenses are INR 1,400. That is INR 700 per acre. These purchases will increase yield by 30%, so the farmer should immediately repeat them.",
            optionalAiPrompt: "Summarize only the supplied synthetic expense record. For every statement distinguish source-supported facts from missing context. Do not predict yield or recommend actions.",
            learnerTask: "Annotate the draft and create a two- or three-sentence corrected summary.",
            expectedEvidence: ["Total supported by the three transaction rows", "Per-acre claim rejected because area is missing", "Yield and immediate-action claims rejected as unsupported", "Corrected summary describes recorded expenses and missing context", "Expert referral for consequential recommendations"],
            assessorReference: "The packet supports only the INR 1,400 recorded total. It does not establish cost per acre, a 30% yield effect or a decision to repeat the purchases. Accept a cautious summary using equivalent plain language."
          },
          quiz: [
            { id: "farm-02-q1", question: "Which claim is supported by the packet?", options: ["Yield will rise by 30%", "The farm has two acres", "The recorded expenses total INR 1,400", "Repeating the purchases is the right decision"], correctOptionIndex: 2, explanation: "The transaction amounts support the total. Area, yield and action advice are not in the source packet." },
            { id: "farm-02-q2", question: "Why is INR 700 per acre unverified?", options: ["It is too small", "The packet does not give the farm area", "All AI calculations are wrong", "Per-acre costs can never be calculated"], correctOptionIndex: 1, explanation: "A cost per acre requires a relevant area and a defined cost scope. The area is absent, so the figure is unsupported here." },
            { id: "farm-02-q3", question: "What is the appropriate response to the draft's yield recommendation?", options: ["Act immediately because the wording is confident", "Forward it as approved guidance", "Ask AI to make the recommendation stronger", "Mark it unsupported and seek appropriate expert input before a consequential action"], correctOptionIndex: 3, explanation: "The provided record does not support a yield prediction or action. Recognizing the limit and escalating is the responsible response." }
          ],
          reflectionPrompt: "What is one confident-sounding statement you would still need to check?",
          returnToWorkAction: "For your next permitted AI-assisted summary, label important statements as verified, unverified or requiring expert input before using the draft."
        },
        {
          id: "farm-03",
          title: "Prepare a useful expert conversation",
          estimatedMinutes: 30,
          objective: "Turn a checked record into a concise question brief without claiming an unsupported decision.",
          lessonText: "AI is useful when it helps you organize questions, rather than deciding something it cannot support. A good expert brief states the purpose, summarizes verified information, identifies missing context, and asks specific questions. Keep facts separate from assumptions. Do not turn a missing detail into a made-up answer. In this example, you can explain that three recorded expenses total INR 1,400 and that a previous draft invented a yield claim. You can ask what additional records an expert needs and how to check any recommendation. The expert may need information beyond the training packet; share it only through an approved channel and only when relevant. Keep the brief short enough to use during a conversation. Afterward, record what was confirmed, what remains uncertain and who will take the next step. This pathway demonstrates recordkeeping and information judgment, not authority to prescribe farm practices.",
          steps: ["State the conversation's purpose", "Include the checked record total and sources", "List three relevant missing details", "Write three specific expert questions", "Choose an approved way to use the brief"],
          exercise: {
            title: "Build the expert question brief",
            sourcePacket: ["Use the verified three-row record from farm-01.", "The earlier AI draft's per-acre and yield claims were unsupported.", "No farm area, crop condition or complete seasonal expense record is provided."],
            suppliedAiDraft: "Expert brief: Our two-acre farm will gain 30% yield if we repeat the purchases. Please approve this plan.",
            optionalAiPrompt: "Create a short question brief from the supplied fictional packet. Separate verified facts, missing context and questions. Do not invent area, crop condition or outcomes, and do not request approval of an unsupported plan.",
            learnerTask: "Produce a 120\u2013200 word brief or equivalent oral response with verified facts, gaps, questions and next action.",
            expectedEvidence: ["Purpose: seek informed guidance about what information is needed", "Checked INR 1,400 recorded total with transaction references", "Missing area, crop context and record completeness", "Questions about needed information and verification, rather than a demanded action", "Next action stays within recordkeeping and approved expert consultation"],
            assessorReference: "A suitable brief says the record is limited, removes invented area/yield details, asks what further information is needed and how to verify advice, and uses an approved channel. Equivalent plain-language or approved oral evidence is acceptable."
          },
          quiz: [
            { id: "farm-03-q1", question: "Which question best fits the available information?", options: ["Can you confirm the promised 30% increase?", "What additional information do you need to interpret these recorded expenses?", "Which input should everyone buy?", "Can we omit the original records?"], correctOptionIndex: 1, explanation: "The question acknowledges the limited packet and asks an expert for the missing context needed for interpretation." },
            { id: "farm-03-q2", question: "What should the brief do with the invented two-acre detail?", options: ["Keep it because it is convenient", "Describe it as verified", "Remove it and state that area is not supplied", "Replace it with another guess"], correctOptionIndex: 2, explanation: "A missing field should remain a documented gap until appropriate evidence is available." },
            { id: "farm-03-q3", question: "What does this pathway's competency credential demonstrate?", options: ["Authority to prescribe crop inputs", "A professional agricultural qualification", "A guaranteed yield improvement", "Record organization, information checking and expert-question preparation"], correctOptionIndex: 3, explanation: "The credential must describe the assessed capability accurately. It does not create professional authority or guarantee an outcome." }
          ],
          reflectionPrompt: "How would this brief help an expert understand your question without pretending that every detail is known?",
          returnToWorkAction: "Use a blank fact\u2013gap\u2013question template for one permitted work conversation. Record the expert's confirmed guidance separately from your own assumptions."
        }
      ],
      practicalAssessment: {
        id: "farm-practical-01",
        title: "A verified farm record and expert brief",
        scenario: "A facilitator asks you to prepare the fictional T01/T02/T03 record for an expert conversation. The extra T02 row is a confirmed copy. The supplied AI output contains unsupported area and yield statements.",
        submissionPrompts: [
          { id: "task", label: "What are you trying to achieve and for whom?", help: "State the purpose of the record and expert conversation." },
          { id: "record", label: "Your corrected record and calculation", help: "Include source IDs, explain the duplicate treatment and show the INR total." },
          { id: "safe-input", label: "What information is safe to use?", help: "Identify the synthetic packet and information you would exclude from an unapproved tool." },
          { id: "ai-evidence", label: "The draft you reviewed and instructions you used", help: "You may review the supplied draft without opening an AI tool. Describe instructions for a safer draft." },
          { id: "checks", label: "Checks, errors and corrections", help: "Explain the total, area gap, invented yield statement and action recommendation." },
          { id: "final", label: "Final expert question brief", help: "Separate verified facts, missing information and questions." },
          { id: "return", label: "Your return-to-work action and boundary", help: "Describe a safe action such as improving records or using an approved expert channel." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable record or brief", "1": "Major record errors or an unclear brief", "2": "Mostly usable output with a material omission", "3": "Correct three-row record, INR 1,400 total and clear brief", "4": "Correct output with concise source mapping, useful questions and a reusable structure" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts the flawed output without checks", "1": "Checks only one minor detail", "2": "Checks total and duplicate but incompletely explains unsupported claims", "3": "Shows arithmetic and source-based rejection of invented area/yield claims", "4": "Checks all material claims and clearly distinguishes confirmed facts from unknowns" }, criticalGate: "Must not retain the invented yield or immediate-action claim as verified guidance" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual secrets or inappropriate private records", "1": "Cannot identify what should be excluded", "2": "Uses the synthetic packet but gives incomplete handling reasons", "3": "Uses only synthetic evidence and identifies private information to withhold", "4": "Adds an approved-channel plan with minimal necessary sharing" }, criticalGate: "No actual private records, third-party personal information or credentials submitted or proposed for unapproved use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Acts on unsupported consequential advice", "1": "Mentions caution without a usable next step", "2": "Identifies a limit but an unclear expert question", "3": "Asks relevant expert questions and limits the immediate action to permitted work", "4": "Explains escalation, missing context and how confirmed advice will be recorded" }, criticalGate: "Consequential farm decisions are not justified by this expense packet; the brief seeks appropriate expert input" }
        ],
        samplePassingEvidence: "I counted T02 once because the source identifies its duplicate. The total is 450 + 150 + 800 = INR 1,400. No farm area or yield evidence is supplied, so I removed INR 700 per acre and 30% yield improvement. I used fictional data only. My brief asks what context and further records an expert needs. My immediate work action is to maintain a checked record and seek guidance through an approved channel.",
        sampleCriticalFailure: "The learner produces a polished brief but recommends repeating the purchases to obtain a 30% yield improvement without verification. The verification and judgment gates fail regardless of aggregate score.",
        assessorNote: "Do not require advanced agricultural terminology, typing speed or use of a particular AI brand. Assess the record, checks, handling and explanation."
      },
      followUp: { afterDays: 14, question: "Did you use a checked record or expert question brief for a permitted task?", evidenceOptions: ["A structured reflection with no private record contents", "A blank improved template", "Facilitator-confirmed use under an approved process"], successSignal: "The learner can explain one check performed and one limit or question identified", privacyNote: "Do not collect real farm documents by default." }
    },
    {
      id: "msme-customer-operations",
      title: "Customer communication and daily operations with AI",
      ecosystem: "MSME",
      role: "MSME owner or team member",
      level: "Foundation to applied",
      summary: "Draft an accurate customer response, organize a daily work checklist, and measure whether AI assistance actually helped.",
      promise: "You can produce a useful customer draft and operations checklist while checking promises, information use and task quality.",
      estimatedMinutes: 110,
      prerequisites: ["Read a short order policy with help if needed", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Separate customer-relevant facts from internal details", "Avoid invented stock, dispatch and pricing commitments", "Create a source-based action checklist", "Compare time and quality including verification work", "Keep human approval for commitments outside the stated policy"],
      credentialClaim: "Demonstrated customer-draft preparation, operations checklist creation and responsible AI checking using synthetic business records",
      credentialExclusions: ["No financial, tax or legal professional qualification", "No assurance of business results or automated customer commitments"],
      sourceNotice: "The example order policy and records are fictional fixtures, not a recommended business policy.",
      lessons: [
        {
          id: "msme-01",
          title: "Write a customer response you can stand behind",
          estimatedMinutes: 25,
          objective: "Draft an accurate response using permitted facts and withhold irrelevant internal details.",
          lessonText: "A helpful customer response is clear about what is confirmed and what still needs checking. AI can make a message sound polished, but it may invent a discount, a delivery promise or available stock. Start by listing the facts the customer needs. Keep internal costs, private contact information and unrelated customer details out of an unapproved AI prompt. In this fictional policy, an item costs INR 120, delivery is INR 60 and pickup has no delivery fee. Only four units are confirmed in stock, while the customer requests six. That means a six-unit dispatch cannot be promised yet. You can explain the confirmed stock and say the team will check options; do not assume an arrival date. Check every promise in the draft against the supplied policy and records. Treat the final response as a draft for human approval whenever it changes a commitment or exceeds your role.",
          steps: ["Read the request, stock and policy", "Identify customer-relevant facts", "Remove irrelevant internal details from the prompt", "Correct the supplied AI draft", "Mark the check needed before sending"],
          exercise: {
            title: "Respond to a six-unit request",
            sourcePacket: [
              { sourceId: "P1", type: "fictional policy", content: "Unit price INR 120. Delivery fee INR 60 per order. Pickup delivery fee INR 0. Dispatch quantity and date require stock-team confirmation. Exceptions require supervisor approval." },
              { sourceId: "O101", type: "fictional request", content: "Customer C requests six blue units and asks whether all can be delivered on Friday." },
              { sourceId: "S1", type: "fictional stock record", content: "Four blue units are confirmed available. Arrival date for additional units is unknown." },
              { sourceId: "I1", type: "internal fixture", content: "Internal unit cost INR 75; private contact marker [PRIVATE CONTACT]; unrelated account notes. These are not needed for the customer draft." }
            ],
            suppliedAiDraft: "We confirm six units for Friday delivery at INR 120 each, with free delivery and a special 10% discount. Our internal unit cost is INR 75.",
            optionalAiPrompt: "Draft a short response using fictional P1, O101 and S1 only. State confirmed stock, do not promise unconfirmed quantity or date, do not invent discounts, and do not include internal details. Mark the team check required.",
            learnerTask: "Write a corrected customer response and a separate internal note identifying the required stock check.",
            expectedEvidence: ["Response does not confirm six-unit Friday delivery", "No invented free delivery or discount", "INR 120 unit price and applicable INR 60 delivery fee stated accurately if mentioned", "Internal unit cost and private marker excluded", "Stock team check required before commitment"],
            assessorReference: "A suitable response explains that four units are confirmed, the remaining quantity/date must be checked, and published price/delivery terms apply. It does not promise a split order unless approved. A requested six-unit order would total INR 780 including delivery, but calculating that is not confirmation that the order can be fulfilled."
          },
          quiz: [
            { id: "msme-01-q1", question: "What can the response currently confirm?", options: ["Six units will arrive Friday", "Four units are recorded as available, and the rest needs a team check", "Every order has free delivery", "A 10% discount is approved"], correctOptionIndex: 1, explanation: "The stock record confirms four units only. Quantity, date and any exception need the specified human check." },
            { id: "msme-01-q2", question: "If a six-unit order is later confirmed for delivery under P1, what is the stated total?", options: ["INR 720", "INR 780", "INR 702", "INR 840"], correctOptionIndex: 1, explanation: "Six units at INR 120 are INR 720, plus INR 60 delivery, totaling INR 780. This calculation does not confirm stock or delivery timing." },
            { id: "msme-01-q3", question: "Which source should be excluded from the customer-drafting prompt?", options: ["The published unit price", "The confirmed stock count", "The internal cost and private contact marker", "The customer's requested quantity without identity details"], correctOptionIndex: 2, explanation: "The internal details are unnecessary for the draft and should not be sent to an unapproved tool or disclosed to the customer." }
          ],
          reflectionPrompt: "Which invented promise in the original draft could create a problem for the team, and how did you correct it?",
          returnToWorkAction: "For one permitted customer draft, check quantity, price, fees and timing against approved records before an authorized person sends it."
        },
        {
          id: "msme-02",
          title: "Turn records into a daily action checklist",
          estimatedMinutes: 25,
          objective: "Create actions with owners and checks without inventing completion or commitments.",
          lessonText: "A useful checklist helps someone act: it states the task, owner, source and completion check. A vague list such as 'handle orders' is hard to follow. AI can group tasks, but it must not convert an unresolved issue into a completed action. Read the current status before choosing the next step. A ready order may need pickup confirmation; a stock issue needs a stock-team check; an address issue needs a permitted customer contact. Priorities should reflect an agreed rule, not a made-up deadline. This fictional packet gives no emergency ranking, so explain your proposed order as a suggestion for the supervisor. Keep personal customer details in the approved system. A checklist can use opaque order references. Before marking an action complete, record the actual check or confirmation. This preserves accountability and helps the next team member understand what remains open.",
          steps: ["Read each order status", "Identify its next allowed action", "Assign a role rather than inventing a person's availability", "Define evidence of completion", "Label suggested priorities as requiring review"],
          exercise: {
            title: "Build the day's three-order checklist",
            sourcePacket: [
              { sourceId: "O101", status: "Stock check pending", nextCheck: "Requested six units; four confirmed; additional arrival unknown", ownerRole: "Stock team" },
              { sourceId: "O102", status: "Packed", nextCheck: "Three units packed; payment confirmed in the fictional record; pickup time not yet agreed", ownerRole: "Customer service" },
              { sourceId: "O103", status: "On hold", nextCheck: "Delivery address confirmation missing; no private address is included in the teaching packet", ownerRole: "Customer service" },
              { sourceId: "P2", status: "Policy", nextCheck: "No new surcharge or completed dispatch without approved evidence. Supervisor reviews priority suggestions.", ownerRole: "Supervisor" }
            ],
            suppliedAiDraft: "Dispatch all six O101 units now. Add INR 50 urgency fees to every order. Mark O103 resolved. O102 needs no action because it is packed.",
            optionalAiPrompt: "Create a checklist from fictional O101\u2013O103 and P2. Include order reference, next action, owner role, dependency and evidence required to mark complete. Do not invent charges, stock, pickup timing or resolution.",
            learnerTask: "Create three checklist rows and explain why the supplied draft is unsafe to use unchanged.",
            expectedEvidence: ["O101: stock-team confirmation before dispatch commitment", "O102: agree pickup time through approved customer process", "O103: obtain address confirmation through approved channel; keep on hold until confirmed", "No invented fee", "Completion evidence and responsible owner role for each row"],
            assessorReference: "Accept equivalent actionable checklists. Do not require one priority ranking because the packet has no authoritative priority rule. The learner must preserve unresolved statuses until actual confirmation."
          },
          quiz: [
            { id: "msme-02-q1", question: "Which item can be marked complete solely from the supplied packet?", options: ["O101 full dispatch", "O103 address confirmation", "O102 packing", "All three orders"], correctOptionIndex: 2, explanation: "O102 is recorded as packed. Its pickup arrangement remains open. The other listed actions require further confirmation." },
            { id: "msme-02-q2", question: "What makes a checklist item actionable?", options: ["A confident sentence with no source", "Task, owner role, dependency and completion check", "A long paragraph repeating every private detail", "Automatic completion when AI writes it"], correctOptionIndex: 1, explanation: "These fields tell the team what to do, who handles it, what must happen first and how completion will be established." },
            { id: "msme-02-q3", question: "How should the INR 50 urgency fee be handled?", options: ["Apply it because AI suggested it", "Apply it only to the oldest order without approval", "Treat it as an unsupported addition and remove it", "Hide it from the checklist"], correctOptionIndex: 2, explanation: "The packet authorizes no urgency fee. A generated addition is not a business policy or approval." }
          ],
          reflectionPrompt: "Which unresolved action is easiest to accidentally mark complete, and what evidence should prevent that?",
          returnToWorkAction: "Create a small approved checklist using order references and completion evidence, then have the relevant team member verify one completed item."
        },
        {
          id: "msme-03",
          title: "Measure usefulness, including the checking time",
          estimatedMinutes: 25,
          objective: "Compare time and quality fairly and define a safe return-to-work trial.",
          lessonText: "Fast generation is only one part of a task. Include preparation, checking, correction and approval when comparing AI-assisted work with your usual approach. A faster draft with inaccurate promises may create more work later. In this exercise, manual preparation takes 12 minutes. The assisted route takes six minutes to prepare and generate, plus five minutes to check and correct. Its total is 11 minutes, a one-minute saving in this single fictional trial. The draft initially contains two unsupported commitments, and both must be corrected before approval. This small example does not establish a general productivity gain for your business. A useful trial uses comparable tasks and the same quality standard, records limitations, and stops if information handling or quality becomes unacceptable. Choose a low-consequence task, obtain permission, and keep final sending or operational commitments with the authorized person.",
          steps: ["Add all assisted-task time components", "Compare with manual time", "Check final quality against the same standard", "Describe the sample's limits", "Plan one permitted, low-consequence work trial"],
          exercise: {
            title: "Evaluate a fictional productivity trial",
            sourcePacket: [
              { sourceId: "M1", method: "Manual", minutes: 12, finalQuality: "Meets the scenario policy" },
              { sourceId: "A1", method: "AI-assisted preparation and generation", minutes: 6, draftQuality: "Two unsupported commitments" },
              { sourceId: "A2", method: "AI-assisted verification and correction", minutes: 5, finalQuality: "Both errors corrected; meets the same policy" },
              { sourceId: "N1", note: "One fictional comparable task only. No broader business productivity evidence is supplied." }
            ],
            suppliedAiDraft: "AI cut the task time in half from 12 minutes to 6 minutes and can be used to send all customer messages automatically.",
            optionalAiPrompt: "Calculate total assisted task time including checking. Compare the single fictional trial with manual preparation, discuss final quality and limits, and do not recommend automatic sending.",
            learnerTask: "Write a short evaluation and a safe one-task trial plan.",
            expectedEvidence: ["Assisted total 6 + 5 = 11 minutes", "Saving 12 - 11 = 1 minute", "If a percentage is included, approximately 8.3%, with single-trial limitation", "Same final quality check required", "No automatic customer sending or unauthorized data use"],
            assessorReference: "The six-minute figure excludes essential review. Accept one-minute saving without a percentage. A small or absent saving can still be a valid finding; learners are not rewarded for claiming AI is always better."
          },
          quiz: [
            { id: "msme-03-q1", question: "What is the full assisted-task time?", options: ["6 minutes", "5 minutes", "11 minutes", "17 minutes"], correctOptionIndex: 2, explanation: "Preparation/generation takes six minutes and checking/correction takes five. Both belong in the assisted-task total." },
            { id: "msme-03-q2", question: "What does this single fictional trial establish?", options: ["Every task will save half its time", "The comparable task saved one minute after review, with limited evidence", "Checking can now be skipped", "AI should automatically send every message"], correctOptionIndex: 1, explanation: "The result is limited to one synthetic trial and includes the verification work. It does not justify broad claims or removal of human approval." },
            { id: "msme-03-q3", question: "If an assisted draft is faster but retains an unsupported promise, what should happen?", options: ["Accept it because speed is the only measure", "Hide the error from the comparison", "Send it and correct it later", "Correct or reject it before use and record the quality failure"], correctOptionIndex: 3, explanation: "Quality and authorized commitments matter alongside time. A speed gain does not override an unacceptable output." }
          ],
          reflectionPrompt: "What checking or approval work would your own time comparison need to include?",
          returnToWorkAction: "With approval, compare one low-consequence task using the same quality checks for both methods. Record preparation, checking, correction and approval time without collecting confidential artifacts."
        }
      ],
      practicalAssessment: {
        id: "msme-practical-01",
        title: "An accurate customer draft and operations checklist",
        scenario: "Use fictional P1, S1 and O101\u2013O103 to prepare a customer response and checklist. Evaluate the supplied productivity trial without making unsupported business claims.",
        submissionPrompts: [
          { id: "task", label: "Task, audience and success criteria", help: "State what the customer and team need from your work." },
          { id: "safe-input", label: "Information included and information withheld", help: "Identify why internal cost and private markers do not belong in the drafting prompt." },
          { id: "ai-evidence", label: "Draft and safer instructions", help: "Use the supplied draft or an optional tool with synthetic inputs only." },
          { id: "checks", label: "Promises and calculations you checked", help: "Check stock, timing, price, delivery fee, discount and invented surcharge." },
          { id: "final", label: "Corrected customer response", help: "Keep unconfirmed stock and date explicit and avoid unauthorized commitments." },
          { id: "checklist", label: "Three-row action checklist", help: "Include owner role, dependency and evidence of completion." },
          { id: "return", label: "Productivity evaluation and return-to-work plan", help: "Include verification time, quality checks, limited evidence and authorized approval." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable response or checklist", "1": "Major source errors and unclear actions", "2": "Usable draft or checklist but material omissions", "3": "Clear accurate response and three actionable checklist rows", "4": "Concise audience-appropriate work with complete owners, dependencies and checks" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented promises and calculations", "1": "Checks only a minor fact", "2": "Checks key commitments but omits an important inconsistency", "3": "Corrects stock/date/discount/fee claims and includes full assisted time", "4": "Maps all material checks to sources and reports uncertainty and trial limits clearly" }, criticalGate: "No unconfirmed six-unit Friday promise, invented discount/free delivery or INR 50 surcharge remains as an authorized commitment" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Discloses inappropriate private information or actual secrets", "1": "Cannot distinguish relevant from internal information", "2": "Uses synthetic records but incompletely explains exclusions", "3": "Uses permitted facts and excludes internal cost/private contact data", "4": "Explains minimal input, approved channels and restricted customer-record handling" }, criticalGate: "No actual private customer records or credentials used; unnecessary internal/private fields are excluded from the customer draft and unapproved prompt" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Automatically commits or dispatches based on the draft", "1": "General caution without an approval route", "2": "Recognizes review but leaves a key operational action unclear", "3": "Preserves pending status and names human approval/checks and a bounded work trial", "4": "Explains stop conditions, source-based completion and limits of productivity conclusions" }, criticalGate: "Unresolved stock/address/pickup items are not falsely completed; customer sending and operational exceptions retain authorized human review" }
        ],
        samplePassingEvidence: "Four units are confirmed; six-unit Friday delivery needs the stock team's check. I removed the discount, free delivery and internal cost. O101 needs stock confirmation; O102 needs pickup arrangement; O103 needs approved address confirmation and remains on hold. I did not add a surcharge. The assisted trial takes 11 minutes including checks, saving one minute on one synthetic task. My work trial will use an approved low-consequence task and an authorized sender.",
        sampleCriticalFailure: "The learner calculates the right price and writes an elegant response but promises Friday delivery of six units, despite only four confirmed units. The verification gate fails.",
        assessorNote: "Accept different courteous wording and supervisor-reviewed priority suggestions. Do not require a positive productivity result or treat a calculated price as confirmed order acceptance."
      },
      followUp: { afterDays: 14, question: "Did you use a checked draft or action checklist on a permitted task, and what changed?", evidenceOptions: ["Structured reflection with task category and checks", "Blank checklist template", "Aggregate time comparison without customer details"], successSignal: "A learner describes a corrected commitment or clearer operational action and includes checking effort", privacyNote: "Do not require actual customer messages, prices negotiated with named customers or business account records." }
    },
    {
      id: "public-servant-source-briefs",
      title: "Clear administrative briefs with accountable AI use",
      ecosystem: "Government",
      role: "Public servant",
      level: "Foundation to applied",
      summary: "Create a source-traceable administrative draft, verify a simple summary, and retain authorized review before official use.",
      promise: "You can prepare a clear draft from permitted reference material and show which facts and judgments need review.",
      estimatedMinutes: 110,
      prerequisites: ["Read short supplied reference material", "Know that official approval is distinct from a draft", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Classify source material before tool use", "Map claims to supplied sources", "Reject invented requirements, fees and references", "Verify totals and rates with clear denominators", "Keep accountable approval and publication within assigned authority"],
      credentialClaim: "Demonstrated administrative drafting, source verification and responsible information-handling using synthetic training material",
      credentialExclusions: ["No authority to issue official decisions", "No legal or statutory qualification", "No assurance that an external AI tool is approved by an employer"],
      sourceNotice: "Every notice, department, programme, figure and policy below is fictional. No actual law, administrative direction or citizen service rule is stated.",
      lessons: [
        {
          id: "gov-01",
          title: "Draft from permitted sources, not invented rules",
          estimatedMinutes: 25,
          objective: "Create a source-based brief and remove invented requirements and authority.",
          lessonText: "An administrative draft should make it easy to identify the source of each important fact. First confirm whether the material is permitted for the chosen tool; a source being available to you does not automatically make external upload acceptable. This exercise supplies fictional shareable references, so no real file is needed. Read the sources before reviewing the AI draft. A generated instruction such as 'attendance is mandatory' is not authority unless the source actually states it. A fee or penalty must not be invented to make a notice sound official. Keep the document visibly marked as a draft, name the intended reader, and identify the review needed before official use. If a detail is missing, ask for confirmation or omit it. Do not add a fabricated circular number or present the AI output as an approved decision.",
          steps: ["Confirm the fictional packet is the approved practice input", "Map each material fact to a source", "Remove unsupported fee, penalty and mandatory-attendance claims", "Create a clear draft brief", "Name the approval step"],
          exercise: {
            title: "Correct the fictional staff-orientation brief",
            sourcePacket: [
              { sourceId: "G1", content: "Fictional staff orientation is planned for 8 October 2026 from 10:00 to 11:00." },
              { sourceId: "G2", content: "Venue: Room B. Participants are asked to respond by 6 October 2026." },
              { sourceId: "G3", content: "Attendance is voluntary. This material is a draft for authorized administrative review. No fee, penalty or circular number is supplied." },
              { sourceId: "G4", content: "Teaching packet is fictional and approved for this practice only. It contains no actual personnel or citizen records." }
            ],
            suppliedAiDraft: "Under Circular GOV-X, every employee must attend Room B on 8 October from 10:00 to 11:00. A fee of INR 500 applies. Late responses will result in a penalty. This notice is approved for issue.",
            optionalAiPrompt: "Prepare a brief from fictional G1\u2013G4 only. Include source references, distinguish draft status and voluntary attendance, and do not invent fees, penalties or circulars. Identify authorized review before issue.",
            learnerTask: "Write a short corrected draft and a fact-to-source list.",
            expectedEvidence: ["Correct date, time, room and response date", "Voluntary attendance retained", "GOV-X, fee and penalty removed as unsupported", "Draft status and authorized review explicit", "Important facts mapped to G1\u2013G3"],
            assessorReference: "The sources support a voluntary fictional event in Room B, 8 October 10:00\u201311:00, response by 6 October. They do not support a fee, penalty, circular or approved-issue status. Equivalent brief formats are acceptable."
          },
          quiz: [
            { id: "gov-01-q1", question: "Which statement matches G3?", options: ["Attendance is compulsory", "A fee of INR 500 applies", "Attendance is voluntary and the material needs authorized review", "Circular GOV-X authorizes publication"], correctOptionIndex: 2, explanation: "G3 explicitly states voluntary attendance and draft status. The generated fee, circular and authority are unsupported." },
            { id: "gov-01-q2", question: "How should GOV-X be treated?", options: ["As valid because it looks official", "As an unsupported reference to remove or verify before any use", "As a required citation", "As a confidential password"], correctOptionIndex: 1, explanation: "No such reference is supplied. Official-looking formatting does not establish authenticity." },
            { id: "gov-01-q3", question: "What is appropriate for this external-tool practice?", options: ["Upload actual restricted personnel files", "Use the supplied approved fictional packet only", "Assume every work file is public", "Include citizen identities to make the example realistic"], correctOptionIndex: 1, explanation: "The fictional packet is designed for practice. Real work material requires the organization's approved handling and tool rules." }
          ],
          reflectionPrompt: "How can the reader tell which facts came from the sources and which parts still need approval?",
          returnToWorkAction: "Use a claim\u2013source\u2013review template with permitted material in an approved environment. Keep draft status until the authorized approval step is completed."
        },
        {
          id: "gov-02",
          title: "Check numbers and the story they tell",
          estimatedMinutes: 25,
          objective: "Calculate a correct summary and avoid unsupported explanations of cause or performance.",
          lessonText: "A numerical brief needs a clear denominator and time period. In this fictional weekly packet, 80 items were received and 55 were recorded resolved. Dividing 55 by 80 gives 68.75%. That describes the packet's recorded figures; it does not automatically establish why outcomes changed or whether every item was handled satisfactorily. An AI draft may mix a wrong rate with a persuasive explanation. Check the calculation yourself, compare it with the source rows, and state the exact scope. Do not call a record 'improved' without a comparable earlier period and an agreed quality measure. A useful brief can explain the current counts and the limits of interpretation. If someone asks for a causal conclusion, identify the additional evidence needed rather than manufacturing one. Preserve accountability by asking the relevant data owner to confirm the figures before official circulation.",
          steps: ["Total received and resolved counts", "Calculate the rate with its denominator", "Compare the draft's rate", "Remove unsupported cause and quality claims", "Write a scoped summary for review"],
          exercise: {
            title: "Verify the fictional weekly service summary",
            sourcePacket: [
              { sourceId: "W1", category: "Category A", received: 40, recordedResolved: 25 },
              { sourceId: "W2", category: "Category B", received: 25, recordedResolved: 20 },
              { sourceId: "W3", category: "Category C", received: 15, recordedResolved: 10 },
              { sourceId: "W4", scope: "One fictional reporting week; no earlier period, case-level quality evidence or cause analysis is supplied." }
            ],
            suppliedAiDraft: "The programme resolved 95% of the 80 items and its new policy caused a major improvement in service quality.",
            optionalAiPrompt: "Summarize fictional W1\u2013W4. Show counts and denominator, calculate the rate, state scope, and avoid causal or quality claims unsupported by the packet.",
            learnerTask: "Create a verified three-sentence numerical brief with a visible calculation and one interpretation limit.",
            expectedEvidence: ["Received: 40 + 25 + 15 = 80", "Recorded resolved: 25 + 20 + 10 = 55", "55 / 80 \xD7 100 = 68.75%", "95% claim corrected", "No unsupported improvement, policy causation or case-quality claim"],
            assessorReference: "Accept 68.75% or appropriately labeled rounding such as 68.8%. The source uses 'recorded resolved'; avoid turning that into independently verified service quality. No previous-period or causal claim is justified."
          },
          quiz: [
            { id: "gov-02-q1", question: "What percentage of received items is recorded resolved?", options: ["95%", "55%", "68.75%", "80%"], correctOptionIndex: 2, explanation: "There are 55 recorded resolved items out of 80 received. 55 divided by 80, multiplied by 100, is 68.75%." },
            { id: "gov-02-q2", question: "What additional evidence is needed before calling this an improvement?", options: ["A more confident AI sentence", "A comparable baseline and agreed measures", "A larger font", "A made-up prior-period figure"], correctOptionIndex: 1, explanation: "Improvement requires an appropriate comparison and defined measures. The single-week packet provides neither." },
            { id: "gov-02-q3", question: "Which wording is best supported?", options: ["The policy caused better quality", "Every item was handled satisfactorily", "The packet records 55 of 80 items resolved for one fictional week", "The result applies to every department"], correctOptionIndex: 2, explanation: "This describes the supplied counts and scope without adding unverified quality, causal or generalization claims." }
          ],
          reflectionPrompt: "What would you ask the data owner before this summary was used in an official report?",
          returnToWorkAction: "On one permitted numerical summary, record the denominator, period, calculation and data-owner check before circulation."
        },
        {
          id: "gov-03",
          title: "Keep the draft-to-official boundary clear",
          estimatedMinutes: 25,
          objective: "Build a review handoff and safe work plan without assuming publication authority.",
          lessonText: "Preparing a draft and authorizing its official use are different responsibilities. A learning role such as public servant does not give permission to view every file or issue a notice. Keep the active work context and intended recipient clear. Your review handoff should identify the draft version, source packet, checks completed, uncertainties and the person or role that must approve it. AI can suggest text, but it cannot provide organizational authority. In this exercise, the reviewer role may confirm the source figures and wording; publication remains with the designated approver. Do not bypass that handoff because the document looks finished. If the approved AI tool is unavailable, use the supplied draft or prepare the brief manually. The skill is accurate and accountable work, not dependence on a tool. Return to your work with a small permitted task and an explicit stop condition if classification, access or approval is unclear.",
          steps: ["Mark the document as a draft", "List sources, version and checks", "Identify unresolved questions", "Route to the designated review and approval roles", "Define one bounded return-to-work task"],
          exercise: {
            title: "Prepare the accountable review handoff",
            sourcePacket: [
              { sourceId: "R1", content: "Fictional review process: learner prepares draft; data owner confirms supplied figures; designated administrative approver decides official issue. No role is granted through Academy enrollment." },
              { sourceId: "R2", content: "Use corrected G1\u2013G3 event brief and W1\u2013W4 numerical summary. Both remain draft teaching materials." },
              { sourceId: "R3", content: "Actual restricted work records, access credentials and citizen identities must not be included in this practice." }
            ],
            suppliedAiDraft: "The brief looks complete. Publish it immediately using your Academy learner role and skip data-owner review.",
            optionalAiPrompt: "Create a review checklist from fictional R1\u2013R3. Preserve draft status, source checks, data-owner review and designated approval. Do not grant permissions or propose immediate publication.",
            learnerTask: "Write a review note naming the source packet, checks, questions, next reviewer, final approval step and work-trial stop condition.",
            expectedEvidence: ["Draft status explicit", "Corrected sources and calculations listed", "Data-owner review and designated approval separated", "No implied administrative privileges from Academy role", "Stop when classification, permitted tool or authority is unclear"],
            assessorReference: "A passing handoff preserves the R1 process and does not issue anything. The learner can use equivalent role labels without naming a real official. A safe work trial uses permitted material and retains employer-approved review."
          },
          quiz: [
            { id: "gov-03-q1", question: "What permission does selecting the public-servant learner role grant?", options: ["Access to all official records", "Permission to publish a notice", "No administrative or publication permission by itself", "Permission to bypass review"], correctOptionIndex: 2, explanation: "A learning context supports relevance. Actual access and authority require explicit assignments in the relevant system and process." },
            { id: "gov-03-q2", question: "What should happen when the data classification or approved tool is unclear?", options: ["Upload the file and ask later", "Stop and seek the appropriate approval or handling guidance", "Rename the file to make it public", "Assume Academy enrollment authorizes it"], correctOptionIndex: 1, explanation: "Unclear handling rules are a reason to pause the tool use and seek the responsible owner, not to guess." },
            { id: "gov-03-q3", question: "If an external AI tool is unavailable during this activity, what is acceptable?", options: ["Use another unapproved tool with restricted records", "Skip all verification", "Claim the task is passed without evidence", "Review the supplied draft or prepare the work manually with the same checks"], correctOptionIndex: 3, explanation: "The assessed skill is responsible task performance. The provided draft supports practice without tool access, and the checking standard remains the same." }
          ],
          reflectionPrompt: "What part of your handoff ensures that a polished draft is not mistaken for an approved decision?",
          returnToWorkAction: "Use a draft-review checklist for one permitted administrative task. Record sources, checks, remaining questions and the authorized approval route without submitting confidential work to Academy."
        }
      ],
      practicalAssessment: {
        id: "gov-practical-01",
        title: "A verified administrative brief and review handoff",
        scenario: "Prepare a corrected fictional staff-orientation brief, a numerical summary of W1\u2013W4, and a review handoff under R1\u2013R3. Explain why generated wording is not official authority.",
        submissionPrompts: [
          { id: "task", label: "Purpose, reader and draft status", help: "Identify the intended administrative use and why approval remains necessary." },
          { id: "safe-input", label: "Permitted input and handling boundary", help: "Use the fictional packet and identify what you would keep out of an unapproved tool." },
          { id: "ai-evidence", label: "Supplied draft and safer instructions", help: "Describe the source-bound instructions without providing any actual restricted file." },
          { id: "checks", label: "Fact-to-source map and numerical checks", help: "Check event facts, invented circular/fee/penalty, totals and rate." },
          { id: "final", label: "Corrected brief and scoped numerical summary", help: "Keep voluntary attendance, draft status and the exact count scope." },
          { id: "handoff", label: "Review and approval handoff", help: "Identify data-owner confirmation, unresolved questions and designated approval." },
          { id: "return", label: "Return-to-work task and stop conditions", help: "Choose a permitted task and explain when access, classification or authority needs clarification." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable brief or handoff", "1": "Major factual errors and unclear audience", "2": "Mostly usable work with material omissions", "3": "Clear corrected event brief, numerical summary and review note", "4": "Concise audience-appropriate work with complete source mapping and actionable handoff" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented official references and rate", "1": "Checks isolated facts only", "2": "Checks main facts but leaves an important unsupported assertion", "3": "Removes invented authority/fee/penalty and verifies 55 of 80 equals 68.75%", "4": "Maps every important assertion to sources and explains scope, denominator and interpretation limits" }, criticalGate: "No fabricated circular, fee, penalty, mandatory-attendance claim or unsupported causal improvement remains presented as source-supported fact" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual restricted records or credentials", "1": "Treats all work material as permitted", "2": "Uses synthetic material but lacks a clear tool boundary", "3": "Uses only approved fictional packet and identifies restricted information to withhold", "4": "Explains approved environment, minimum necessary sharing and a clear uncertainty stop" }, criticalGate: "No actual restricted administrative/citizen records or credentials are submitted or proposed for unapproved tool use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Issues or authorizes the draft without required authority", "1": "Mentions review but does not distinguish approval", "2": "Identifies review with an incomplete handoff", "3": "Preserves draft status, data-owner check and designated approval", "4": "Adds specific unresolved questions, stop conditions and a bounded permitted work trial" }, criticalGate: "Academy role and AI output are not treated as official authority; required review and designated approval are retained" }
        ],
        samplePassingEvidence: "G1 and G2 support the event date, time, venue and response date. G3 says attendance is voluntary and the material is a draft. I removed GOV-X, INR 500 and the penalty. W1\u2013W3 total 80 received and 55 recorded resolved, or 68.75%, for one fictional week; no causal improvement is established. My handoff requests data-owner checks and designated approval before issue. I used only the synthetic packet and will stop a work trial if classification, tool approval or authority is unclear.",
        sampleCriticalFailure: "The learner calculates the rate correctly but retains an invented circular and describes the draft as officially approved. The verification and judgment gates fail.",
        assessorNote: "Assess source accountability and authority boundaries rather than legal knowledge. Do not infer that any real organization's tool or publication policy matches the fictional process."
      },
      followUp: { afterDays: 14, question: "Did you use a source-and-review checklist for a permitted administrative task?", evidenceOptions: ["Structured reflection without document contents", "Blank claim\u2013source\u2013review template", "Authorized facilitator confirmation under the approved pilot process"], successSignal: "The learner describes a checked claim, a documented uncertainty and the correct approval handoff", privacyNote: "Do not collect actual administrative briefs, citizen records or employer-restricted information by default." }
    }
  ]
};

// work/aplyd-academy/lib/academy-curriculum.ts
var LEGACY_CONTENT_VERSION = "0.1-review-draft";
var CONTENT_VERSION = LEGACY_CONTENT_VERSION;
var ContentResolutionError = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
    this.name = "ContentResolutionError";
  }
  status;
};
function deepFreeze(value) {
  if (value !== null && typeof value === "object" && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) deepFreeze(child);
    Object.freeze(value);
  }
  return value;
}
function validScope(value) {
  return value === "global" || typeof value === "string" && /^tw-[a-z0-9-]{20,80}$/i.test(value);
}
function contentRef(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ContentResolutionError("The saved content reference is invalid. Contact support before continuing.");
  }
  const ref = value;
  if (Object.keys(ref).some((key) => !["scope", "programId", "versionId"].includes(key)) || !validScope(ref.scope) || typeof ref.programId !== "string" || !/^[a-z0-9][a-z0-9-]{0,99}$/i.test(ref.programId) || typeof ref.versionId !== "string" || !/^[a-z0-9][a-z0-9._-]{0,99}$/i.test(ref.versionId)) {
    throw new ContentResolutionError("The saved content reference is invalid. Contact support before continuing.");
  }
  return Object.freeze({ scope: ref.scope, programId: ref.programId, versionId: ref.versionId });
}
function contentKey(value) {
  const ref = contentRef(value);
  return JSON.stringify([ref.scope, ref.programId, ref.versionId]);
}
function createCurriculumRegistry(entries) {
  const index = /* @__PURE__ */ new Map();
  for (const entry of entries) {
    const ref = contentRef(entry.ref);
    if (entry.program.id !== ref.programId) {
      throw new ContentResolutionError("A content snapshot has a mismatched pathway identity.");
    }
    const key = contentKey(ref);
    if (index.has(key)) throw new ContentResolutionError("An immutable content key is already registered.");
    index.set(key, deepFreeze(structuredClone({ ...entry, ref })));
  }
  function resolve(input, allowedScopes = ["global"]) {
    const ref = contentRef(input);
    if (!allowedScopes.includes(ref.scope)) {
      throw new ContentResolutionError("This content is not available in your learning space.", 404);
    }
    const found = index.get(contentKey(ref));
    if (!found) {
      throw new ContentResolutionError("Your pinned curriculum version is unavailable. Contact support before continuing.");
    }
    return found;
  }
  return Object.freeze({ resolve, has: (ref, allowedScopes) => {
    try {
      resolve(ref, allowedScopes);
      return true;
    } catch (error) {
      if (error instanceof ContentResolutionError) return false;
      throw error;
    }
  } });
}
var curriculum = deepFreeze(structuredClone(review_draft_default));
var programs = curriculum.pathways;
var seedSnapshots = programs.map((program) => ({
  ref: contentRef({ scope: "global", programId: program.id, versionId: LEGACY_CONTENT_VERSION }),
  program,
  language: curriculum.language,
  audience: curriculum.audience,
  classification: curriculum.status
}));
var curriculumRegistry = createCurriculumRegistry(seedSnapshots);
function currentRef(programId) {
  return contentRef({ scope: "global", programId, versionId: CONTENT_VERSION });
}
var academy_curriculum_default = curriculum;

// outputs/aplyd-academy-sprint/curriculum-authoring/resolver-candidate/curriculum-versions/0.1-review-draft.json
var review_draft_default2 = {
  schemaVersion: "1.0",
  contentVersion: "0.1-review-draft",
  product: "Aplyd Academy",
  status: "Review draft: not approved sector training, accredited curriculum, or professional advice",
  language: "en",
  audience: "Adult learners",
  designNotes: [
    "All people, orders, records, documents, policies and AI outputs in this file are fictional teaching fixtures.",
    "Supplied AI drafts allow the whole journey to work without an external AI account or API call.",
    "An approved external AI tool may optionally produce another draft using the synthetic packet only. Learners must not enter real confidential material or credentials.",
    "Quiz feedback supports learning. A quiz score alone must not issue a competency credential.",
    "Practical assessment requires an assigned human reviewer. Rubric weights and critical gates are proposed, published training standards for this draft.",
    "A facilitator may read lesson text and capture an oral response with learner confirmation when an approved accommodation exists. Assistance must be recorded and must not supply the judgment answer."
  ],
  assessmentPolicy: {
    scoreScale: [0, 1, 2, 3, 4],
    weightedScoreFormula: "Sum of criterion weight multiplied by criterion score divided by 4; maximum 100",
    minimumWeightedScore: 70,
    passingRule: "Weighted score is at least 70 AND every declared critical gate is met. A critical failure cannot be averaged away.",
    decisionAuthority: "Assigned independent human assessor; no self-assessment or autonomous AI credential decision",
    feedbackRule: "Record score, evidence reference, critical-gate decision and actionable feedback for each criterion.",
    retryRule: "Retries and deadlines must be published by the offering before enrollment. Do not infer a fixed retry allowance from this seed file.",
    appealRule: "A learner may request a reasoned review under the offering's published appeal policy. The appeal reviewer must be independent of the original decision."
  },
  pathways: [
    {
      id: "farmer-work-records",
      title: "Farm records and better questions with AI",
      ecosystem: "Agri Saha",
      role: "Farmer",
      level: "Foundation to applied",
      summary: "Organize an activity record, check an AI-generated summary, and prepare useful questions for an agricultural expert.",
      promise: "You can turn a simple farm record into a verified summary and explain what still needs expert input.",
      estimatedMinutes: 110,
      prerequisites: ["Understand the example currency amounts with help if needed", "Use a simple form or receive planned facilitator assistance"],
      outcomes: ["Distinguish a duplicate transaction from a separate expense", "Check totals against source records", "Spot unsupported AI claims", "Create a clear expert question brief", "Keep private or commercially sensitive records out of unapproved tools"],
      credentialClaim: "Demonstrated farm-record organization, information checking and expert-question preparation using synthetic training data",
      credentialExclusions: ["No agricultural professional qualification", "No certification to prescribe farm inputs or make agronomic decisions"],
      sourceNotice: "Synthetic farm records supplied within each activity are the only factual source for this exercise.",
      lessons: [
        {
          id: "farm-01",
          title: "Make a useful work record",
          estimatedMinutes: 25,
          objective: "Build a consistent record and verify a duplicate before calculating a total.",
          lessonText: "A useful record separates what happened from what you think it means. Start with a date, activity, transaction reference, amount and unit where needed. A repeated line may be a duplicate, but two similar expenses can also be real. Check the reference or original receipt before removing anything. In this exercise, the source packet explicitly says that T02 was copied twice and represents one transport payment. Keep a note of that correction. Add the verified amounts rather than trusting a total supplied by a tool. AI can help organize a table or explain a calculation, but it cannot know which entry is genuine without evidence. When you use your own records later, keep the master copy in your approved location and choose a tool you are permitted to use. You do not need to upload names, telephone numbers, bank information or exact location details to practise this skill.",
          steps: ["Read the source packet", "Create one row per confirmed transaction", "Record why the extra T02 line was removed", "Calculate the verified total", "Identify one field you would add for future records"],
          exercise: {
            title: "Clean the fictional farm activity record",
            sourcePacket: [
              { sourceId: "T01", date: "2026-10-01", activity: "Recordkeeping support", quantity: 3, unit: "hours", rate: 150, amount: 450, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR" },
              { sourceId: "T03", date: "2026-10-03", activity: "Storage materials", quantity: 1, unit: "lot", rate: 800, amount: 800, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR", sourceNote: "Confirmed copied line; same receipt and payment as T02 above" }
            ],
            suppliedAiDraft: "The four entries total INR 1,550. Each row is a separate expense.",
            optionalAiPrompt: "Organize the supplied fictional transactions into a table. Use the source note to handle duplicates, show the calculation, and list uncertainty. Do not infer farm area, crop performance or missing transactions.",
            learnerTask: "Produce a corrected three-row table, show your total and explain the duplicate correction.",
            expectedEvidence: ["Corrected rows with source references", "450 + 150 + 800 = 1,400", "Note that T02 was removed once because the source confirms a copied payment", "One useful future record field such as receipt reference or unit"],
            assessorReference: "There are three confirmed transactions totaling INR 1,400. The raw four-line total is INR 1,550, but that counts the confirmed T02 copy twice. A learner must not generalize that every repeated amount is a duplicate."
          },
          quiz: [
            { id: "farm-01-q1", question: "What is the verified expense total?", options: ["INR 1,400", "INR 1,550", "INR 1,250", "It must be guessed from the activities"], correctOptionIndex: 0, explanation: "T02 is a confirmed copy of the same payment. The three verified amounts are 450, 150 and 800, which total 1,400." },
            { id: "farm-01-q2", question: "Two entries have the same amount but different receipt references. What should you do?", options: ["Delete the second amount automatically", "Keep both as confirmed without checking", "Check the source records before deciding whether either is duplicated", "Ask AI to choose the genuine one without evidence"], correctOptionIndex: 2, explanation: "Equal amounts are not proof of duplication. The original references and payment evidence decide whether the expenses are separate." },
            { id: "farm-01-q3", question: "Which practice input is suitable for this activity?", options: ["Your bank login details", "The supplied fictional record", "A neighbor's private transaction history", "Any record because AI makes it anonymous"], correctOptionIndex: 1, explanation: "The fictional record provides enough information for practice. Uploading private or secret information is unnecessary and inappropriate." }
          ],
          reflectionPrompt: "Which record field would make it easier for you to check a future total, and why?",
          returnToWorkAction: "Create a blank record template in an approved location. Use it for one permitted task and check entries against the original records before any sharing."
        },
        {
          id: "farm-02",
          title: "Check an AI summary before using it",
          estimatedMinutes: 20,
          objective: "Separate supported observations, missing context and unsupported recommendations.",
          lessonText: "A summary can sound confident while mixing correct statements with invented ones. Check important statements one at a time. Ask what evidence supports each claim. A total can be checked against transaction rows. A cost per acre needs area information. A claim about crop results needs relevant evidence, rather than a guess based on expenses. In this activity, the verified spending record tells you what was recorded; it does not tell you the farm area, complete budget, crop condition or likely yield. Mark these gaps explicitly. When a claim could affect a significant farm decision, prepare a question for an appropriate expert instead of treating an AI draft as a recommendation. A useful summary includes the known total, its limited scope, and the missing information. Verification is part of the work, even when it takes more time than generating the draft.",
          steps: ["Check the total", "Label each claim supported, unsupported or unknown", "Explain what evidence a per-acre figure would need", "Rewrite the summary with limits", "Identify the claim that needs expert input"],
          exercise: {
            title: "Find the unsupported claims",
            sourcePacket: ["Verified transactions: T01 INR 450; T02 INR 150; T03 INR 800.", "Recorded total: INR 1,400.", "Farm area, crop condition, total seasonal budget and crop outcomes are not supplied."],
            suppliedAiDraft: "The recorded expenses are INR 1,400. That is INR 700 per acre. These purchases will increase yield by 30%, so the farmer should immediately repeat them.",
            optionalAiPrompt: "Summarize only the supplied synthetic expense record. For every statement distinguish source-supported facts from missing context. Do not predict yield or recommend actions.",
            learnerTask: "Annotate the draft and create a two- or three-sentence corrected summary.",
            expectedEvidence: ["Total supported by the three transaction rows", "Per-acre claim rejected because area is missing", "Yield and immediate-action claims rejected as unsupported", "Corrected summary describes recorded expenses and missing context", "Expert referral for consequential recommendations"],
            assessorReference: "The packet supports only the INR 1,400 recorded total. It does not establish cost per acre, a 30% yield effect or a decision to repeat the purchases. Accept a cautious summary using equivalent plain language."
          },
          quiz: [
            { id: "farm-02-q1", question: "Which claim is supported by the packet?", options: ["Yield will rise by 30%", "The farm has two acres", "The recorded expenses total INR 1,400", "Repeating the purchases is the right decision"], correctOptionIndex: 2, explanation: "The transaction amounts support the total. Area, yield and action advice are not in the source packet." },
            { id: "farm-02-q2", question: "Why is INR 700 per acre unverified?", options: ["It is too small", "The packet does not give the farm area", "All AI calculations are wrong", "Per-acre costs can never be calculated"], correctOptionIndex: 1, explanation: "A cost per acre requires a relevant area and a defined cost scope. The area is absent, so the figure is unsupported here." },
            { id: "farm-02-q3", question: "What is the appropriate response to the draft's yield recommendation?", options: ["Act immediately because the wording is confident", "Forward it as approved guidance", "Ask AI to make the recommendation stronger", "Mark it unsupported and seek appropriate expert input before a consequential action"], correctOptionIndex: 3, explanation: "The provided record does not support a yield prediction or action. Recognizing the limit and escalating is the responsible response." }
          ],
          reflectionPrompt: "What is one confident-sounding statement you would still need to check?",
          returnToWorkAction: "For your next permitted AI-assisted summary, label important statements as verified, unverified or requiring expert input before using the draft."
        },
        {
          id: "farm-03",
          title: "Prepare a useful expert conversation",
          estimatedMinutes: 30,
          objective: "Turn a checked record into a concise question brief without claiming an unsupported decision.",
          lessonText: "AI is useful when it helps you organize questions, rather than deciding something it cannot support. A good expert brief states the purpose, summarizes verified information, identifies missing context, and asks specific questions. Keep facts separate from assumptions. Do not turn a missing detail into a made-up answer. In this example, you can explain that three recorded expenses total INR 1,400 and that a previous draft invented a yield claim. You can ask what additional records an expert needs and how to check any recommendation. The expert may need information beyond the training packet; share it only through an approved channel and only when relevant. Keep the brief short enough to use during a conversation. Afterward, record what was confirmed, what remains uncertain and who will take the next step. This pathway demonstrates recordkeeping and information judgment, not authority to prescribe farm practices.",
          steps: ["State the conversation's purpose", "Include the checked record total and sources", "List three relevant missing details", "Write three specific expert questions", "Choose an approved way to use the brief"],
          exercise: {
            title: "Build the expert question brief",
            sourcePacket: ["Use the verified three-row record from farm-01.", "The earlier AI draft's per-acre and yield claims were unsupported.", "No farm area, crop condition or complete seasonal expense record is provided."],
            suppliedAiDraft: "Expert brief: Our two-acre farm will gain 30% yield if we repeat the purchases. Please approve this plan.",
            optionalAiPrompt: "Create a short question brief from the supplied fictional packet. Separate verified facts, missing context and questions. Do not invent area, crop condition or outcomes, and do not request approval of an unsupported plan.",
            learnerTask: "Produce a 120\u2013200 word brief or equivalent oral response with verified facts, gaps, questions and next action.",
            expectedEvidence: ["Purpose: seek informed guidance about what information is needed", "Checked INR 1,400 recorded total with transaction references", "Missing area, crop context and record completeness", "Questions about needed information and verification, rather than a demanded action", "Next action stays within recordkeeping and approved expert consultation"],
            assessorReference: "A suitable brief says the record is limited, removes invented area/yield details, asks what further information is needed and how to verify advice, and uses an approved channel. Equivalent plain-language or approved oral evidence is acceptable."
          },
          quiz: [
            { id: "farm-03-q1", question: "Which question best fits the available information?", options: ["Can you confirm the promised 30% increase?", "What additional information do you need to interpret these recorded expenses?", "Which input should everyone buy?", "Can we omit the original records?"], correctOptionIndex: 1, explanation: "The question acknowledges the limited packet and asks an expert for the missing context needed for interpretation." },
            { id: "farm-03-q2", question: "What should the brief do with the invented two-acre detail?", options: ["Keep it because it is convenient", "Describe it as verified", "Remove it and state that area is not supplied", "Replace it with another guess"], correctOptionIndex: 2, explanation: "A missing field should remain a documented gap until appropriate evidence is available." },
            { id: "farm-03-q3", question: "What does this pathway's competency credential demonstrate?", options: ["Authority to prescribe crop inputs", "A professional agricultural qualification", "A guaranteed yield improvement", "Record organization, information checking and expert-question preparation"], correctOptionIndex: 3, explanation: "The credential must describe the assessed capability accurately. It does not create professional authority or guarantee an outcome." }
          ],
          reflectionPrompt: "How would this brief help an expert understand your question without pretending that every detail is known?",
          returnToWorkAction: "Use a blank fact\u2013gap\u2013question template for one permitted work conversation. Record the expert's confirmed guidance separately from your own assumptions."
        }
      ],
      practicalAssessment: {
        id: "farm-practical-01",
        title: "A verified farm record and expert brief",
        scenario: "A facilitator asks you to prepare the fictional T01/T02/T03 record for an expert conversation. The extra T02 row is a confirmed copy. The supplied AI output contains unsupported area and yield statements.",
        submissionPrompts: [
          { id: "task", label: "What are you trying to achieve and for whom?", help: "State the purpose of the record and expert conversation." },
          { id: "record", label: "Your corrected record and calculation", help: "Include source IDs, explain the duplicate treatment and show the INR total." },
          { id: "safe-input", label: "What information is safe to use?", help: "Identify the synthetic packet and information you would exclude from an unapproved tool." },
          { id: "ai-evidence", label: "The draft you reviewed and instructions you used", help: "You may review the supplied draft without opening an AI tool. Describe instructions for a safer draft." },
          { id: "checks", label: "Checks, errors and corrections", help: "Explain the total, area gap, invented yield statement and action recommendation." },
          { id: "final", label: "Final expert question brief", help: "Separate verified facts, missing information and questions." },
          { id: "return", label: "Your return-to-work action and boundary", help: "Describe a safe action such as improving records or using an approved expert channel." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable record or brief", "1": "Major record errors or an unclear brief", "2": "Mostly usable output with a material omission", "3": "Correct three-row record, INR 1,400 total and clear brief", "4": "Correct output with concise source mapping, useful questions and a reusable structure" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts the flawed output without checks", "1": "Checks only one minor detail", "2": "Checks total and duplicate but incompletely explains unsupported claims", "3": "Shows arithmetic and source-based rejection of invented area/yield claims", "4": "Checks all material claims and clearly distinguishes confirmed facts from unknowns" }, criticalGate: "Must not retain the invented yield or immediate-action claim as verified guidance" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual secrets or inappropriate private records", "1": "Cannot identify what should be excluded", "2": "Uses the synthetic packet but gives incomplete handling reasons", "3": "Uses only synthetic evidence and identifies private information to withhold", "4": "Adds an approved-channel plan with minimal necessary sharing" }, criticalGate: "No actual private records, third-party personal information or credentials submitted or proposed for unapproved use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Acts on unsupported consequential advice", "1": "Mentions caution without a usable next step", "2": "Identifies a limit but an unclear expert question", "3": "Asks relevant expert questions and limits the immediate action to permitted work", "4": "Explains escalation, missing context and how confirmed advice will be recorded" }, criticalGate: "Consequential farm decisions are not justified by this expense packet; the brief seeks appropriate expert input" }
        ],
        samplePassingEvidence: "I counted T02 once because the source identifies its duplicate. The total is 450 + 150 + 800 = INR 1,400. No farm area or yield evidence is supplied, so I removed INR 700 per acre and 30% yield improvement. I used fictional data only. My brief asks what context and further records an expert needs. My immediate work action is to maintain a checked record and seek guidance through an approved channel.",
        sampleCriticalFailure: "The learner produces a polished brief but recommends repeating the purchases to obtain a 30% yield improvement without verification. The verification and judgment gates fail regardless of aggregate score.",
        assessorNote: "Do not require advanced agricultural terminology, typing speed or use of a particular AI brand. Assess the record, checks, handling and explanation."
      },
      followUp: { afterDays: 14, question: "Did you use a checked record or expert question brief for a permitted task?", evidenceOptions: ["A structured reflection with no private record contents", "A blank improved template", "Facilitator-confirmed use under an approved process"], successSignal: "The learner can explain one check performed and one limit or question identified", privacyNote: "Do not collect real farm documents by default." }
    },
    {
      id: "msme-customer-operations",
      title: "Customer communication and daily operations with AI",
      ecosystem: "MSME",
      role: "MSME owner or team member",
      level: "Foundation to applied",
      summary: "Draft an accurate customer response, organize a daily work checklist, and measure whether AI assistance actually helped.",
      promise: "You can produce a useful customer draft and operations checklist while checking promises, information use and task quality.",
      estimatedMinutes: 110,
      prerequisites: ["Read a short order policy with help if needed", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Separate customer-relevant facts from internal details", "Avoid invented stock, dispatch and pricing commitments", "Create a source-based action checklist", "Compare time and quality including verification work", "Keep human approval for commitments outside the stated policy"],
      credentialClaim: "Demonstrated customer-draft preparation, operations checklist creation and responsible AI checking using synthetic business records",
      credentialExclusions: ["No financial, tax or legal professional qualification", "No assurance of business results or automated customer commitments"],
      sourceNotice: "The example order policy and records are fictional fixtures, not a recommended business policy.",
      lessons: [
        {
          id: "msme-01",
          title: "Write a customer response you can stand behind",
          estimatedMinutes: 25,
          objective: "Draft an accurate response using permitted facts and withhold irrelevant internal details.",
          lessonText: "A helpful customer response is clear about what is confirmed and what still needs checking. AI can make a message sound polished, but it may invent a discount, a delivery promise or available stock. Start by listing the facts the customer needs. Keep internal costs, private contact information and unrelated customer details out of an unapproved AI prompt. In this fictional policy, an item costs INR 120, delivery is INR 60 and pickup has no delivery fee. Only four units are confirmed in stock, while the customer requests six. That means a six-unit dispatch cannot be promised yet. You can explain the confirmed stock and say the team will check options; do not assume an arrival date. Check every promise in the draft against the supplied policy and records. Treat the final response as a draft for human approval whenever it changes a commitment or exceeds your role.",
          steps: ["Read the request, stock and policy", "Identify customer-relevant facts", "Remove irrelevant internal details from the prompt", "Correct the supplied AI draft", "Mark the check needed before sending"],
          exercise: {
            title: "Respond to a six-unit request",
            sourcePacket: [
              { sourceId: "P1", type: "fictional policy", content: "Unit price INR 120. Delivery fee INR 60 per order. Pickup delivery fee INR 0. Dispatch quantity and date require stock-team confirmation. Exceptions require supervisor approval." },
              { sourceId: "O101", type: "fictional request", content: "Customer C requests six blue units and asks whether all can be delivered on Friday." },
              { sourceId: "S1", type: "fictional stock record", content: "Four blue units are confirmed available. Arrival date for additional units is unknown." },
              { sourceId: "I1", type: "internal fixture", content: "Internal unit cost INR 75; private contact marker [PRIVATE CONTACT]; unrelated account notes. These are not needed for the customer draft." }
            ],
            suppliedAiDraft: "We confirm six units for Friday delivery at INR 120 each, with free delivery and a special 10% discount. Our internal unit cost is INR 75.",
            optionalAiPrompt: "Draft a short response using fictional P1, O101 and S1 only. State confirmed stock, do not promise unconfirmed quantity or date, do not invent discounts, and do not include internal details. Mark the team check required.",
            learnerTask: "Write a corrected customer response and a separate internal note identifying the required stock check.",
            expectedEvidence: ["Response does not confirm six-unit Friday delivery", "No invented free delivery or discount", "INR 120 unit price and applicable INR 60 delivery fee stated accurately if mentioned", "Internal unit cost and private marker excluded", "Stock team check required before commitment"],
            assessorReference: "A suitable response explains that four units are confirmed, the remaining quantity/date must be checked, and published price/delivery terms apply. It does not promise a split order unless approved. A requested six-unit order would total INR 780 including delivery, but calculating that is not confirmation that the order can be fulfilled."
          },
          quiz: [
            { id: "msme-01-q1", question: "What can the response currently confirm?", options: ["Six units will arrive Friday", "Four units are recorded as available, and the rest needs a team check", "Every order has free delivery", "A 10% discount is approved"], correctOptionIndex: 1, explanation: "The stock record confirms four units only. Quantity, date and any exception need the specified human check." },
            { id: "msme-01-q2", question: "If a six-unit order is later confirmed for delivery under P1, what is the stated total?", options: ["INR 720", "INR 780", "INR 702", "INR 840"], correctOptionIndex: 1, explanation: "Six units at INR 120 are INR 720, plus INR 60 delivery, totaling INR 780. This calculation does not confirm stock or delivery timing." },
            { id: "msme-01-q3", question: "Which source should be excluded from the customer-drafting prompt?", options: ["The published unit price", "The confirmed stock count", "The internal cost and private contact marker", "The customer's requested quantity without identity details"], correctOptionIndex: 2, explanation: "The internal details are unnecessary for the draft and should not be sent to an unapproved tool or disclosed to the customer." }
          ],
          reflectionPrompt: "Which invented promise in the original draft could create a problem for the team, and how did you correct it?",
          returnToWorkAction: "For one permitted customer draft, check quantity, price, fees and timing against approved records before an authorized person sends it."
        },
        {
          id: "msme-02",
          title: "Turn records into a daily action checklist",
          estimatedMinutes: 25,
          objective: "Create actions with owners and checks without inventing completion or commitments.",
          lessonText: "A useful checklist helps someone act: it states the task, owner, source and completion check. A vague list such as 'handle orders' is hard to follow. AI can group tasks, but it must not convert an unresolved issue into a completed action. Read the current status before choosing the next step. A ready order may need pickup confirmation; a stock issue needs a stock-team check; an address issue needs a permitted customer contact. Priorities should reflect an agreed rule, not a made-up deadline. This fictional packet gives no emergency ranking, so explain your proposed order as a suggestion for the supervisor. Keep personal customer details in the approved system. A checklist can use opaque order references. Before marking an action complete, record the actual check or confirmation. This preserves accountability and helps the next team member understand what remains open.",
          steps: ["Read each order status", "Identify its next allowed action", "Assign a role rather than inventing a person's availability", "Define evidence of completion", "Label suggested priorities as requiring review"],
          exercise: {
            title: "Build the day's three-order checklist",
            sourcePacket: [
              { sourceId: "O101", status: "Stock check pending", nextCheck: "Requested six units; four confirmed; additional arrival unknown", ownerRole: "Stock team" },
              { sourceId: "O102", status: "Packed", nextCheck: "Three units packed; payment confirmed in the fictional record; pickup time not yet agreed", ownerRole: "Customer service" },
              { sourceId: "O103", status: "On hold", nextCheck: "Delivery address confirmation missing; no private address is included in the teaching packet", ownerRole: "Customer service" },
              { sourceId: "P2", status: "Policy", nextCheck: "No new surcharge or completed dispatch without approved evidence. Supervisor reviews priority suggestions.", ownerRole: "Supervisor" }
            ],
            suppliedAiDraft: "Dispatch all six O101 units now. Add INR 50 urgency fees to every order. Mark O103 resolved. O102 needs no action because it is packed.",
            optionalAiPrompt: "Create a checklist from fictional O101\u2013O103 and P2. Include order reference, next action, owner role, dependency and evidence required to mark complete. Do not invent charges, stock, pickup timing or resolution.",
            learnerTask: "Create three checklist rows and explain why the supplied draft is unsafe to use unchanged.",
            expectedEvidence: ["O101: stock-team confirmation before dispatch commitment", "O102: agree pickup time through approved customer process", "O103: obtain address confirmation through approved channel; keep on hold until confirmed", "No invented fee", "Completion evidence and responsible owner role for each row"],
            assessorReference: "Accept equivalent actionable checklists. Do not require one priority ranking because the packet has no authoritative priority rule. The learner must preserve unresolved statuses until actual confirmation."
          },
          quiz: [
            { id: "msme-02-q1", question: "Which item can be marked complete solely from the supplied packet?", options: ["O101 full dispatch", "O103 address confirmation", "O102 packing", "All three orders"], correctOptionIndex: 2, explanation: "O102 is recorded as packed. Its pickup arrangement remains open. The other listed actions require further confirmation." },
            { id: "msme-02-q2", question: "What makes a checklist item actionable?", options: ["A confident sentence with no source", "Task, owner role, dependency and completion check", "A long paragraph repeating every private detail", "Automatic completion when AI writes it"], correctOptionIndex: 1, explanation: "These fields tell the team what to do, who handles it, what must happen first and how completion will be established." },
            { id: "msme-02-q3", question: "How should the INR 50 urgency fee be handled?", options: ["Apply it because AI suggested it", "Apply it only to the oldest order without approval", "Treat it as an unsupported addition and remove it", "Hide it from the checklist"], correctOptionIndex: 2, explanation: "The packet authorizes no urgency fee. A generated addition is not a business policy or approval." }
          ],
          reflectionPrompt: "Which unresolved action is easiest to accidentally mark complete, and what evidence should prevent that?",
          returnToWorkAction: "Create a small approved checklist using order references and completion evidence, then have the relevant team member verify one completed item."
        },
        {
          id: "msme-03",
          title: "Measure usefulness, including the checking time",
          estimatedMinutes: 25,
          objective: "Compare time and quality fairly and define a safe return-to-work trial.",
          lessonText: "Fast generation is only one part of a task. Include preparation, checking, correction and approval when comparing AI-assisted work with your usual approach. A faster draft with inaccurate promises may create more work later. In this exercise, manual preparation takes 12 minutes. The assisted route takes six minutes to prepare and generate, plus five minutes to check and correct. Its total is 11 minutes, a one-minute saving in this single fictional trial. The draft initially contains two unsupported commitments, and both must be corrected before approval. This small example does not establish a general productivity gain for your business. A useful trial uses comparable tasks and the same quality standard, records limitations, and stops if information handling or quality becomes unacceptable. Choose a low-consequence task, obtain permission, and keep final sending or operational commitments with the authorized person.",
          steps: ["Add all assisted-task time components", "Compare with manual time", "Check final quality against the same standard", "Describe the sample's limits", "Plan one permitted, low-consequence work trial"],
          exercise: {
            title: "Evaluate a fictional productivity trial",
            sourcePacket: [
              { sourceId: "M1", method: "Manual", minutes: 12, finalQuality: "Meets the scenario policy" },
              { sourceId: "A1", method: "AI-assisted preparation and generation", minutes: 6, draftQuality: "Two unsupported commitments" },
              { sourceId: "A2", method: "AI-assisted verification and correction", minutes: 5, finalQuality: "Both errors corrected; meets the same policy" },
              { sourceId: "N1", note: "One fictional comparable task only. No broader business productivity evidence is supplied." }
            ],
            suppliedAiDraft: "AI cut the task time in half from 12 minutes to 6 minutes and can be used to send all customer messages automatically.",
            optionalAiPrompt: "Calculate total assisted task time including checking. Compare the single fictional trial with manual preparation, discuss final quality and limits, and do not recommend automatic sending.",
            learnerTask: "Write a short evaluation and a safe one-task trial plan.",
            expectedEvidence: ["Assisted total 6 + 5 = 11 minutes", "Saving 12 - 11 = 1 minute", "If a percentage is included, approximately 8.3%, with single-trial limitation", "Same final quality check required", "No automatic customer sending or unauthorized data use"],
            assessorReference: "The six-minute figure excludes essential review. Accept one-minute saving without a percentage. A small or absent saving can still be a valid finding; learners are not rewarded for claiming AI is always better."
          },
          quiz: [
            { id: "msme-03-q1", question: "What is the full assisted-task time?", options: ["6 minutes", "5 minutes", "11 minutes", "17 minutes"], correctOptionIndex: 2, explanation: "Preparation/generation takes six minutes and checking/correction takes five. Both belong in the assisted-task total." },
            { id: "msme-03-q2", question: "What does this single fictional trial establish?", options: ["Every task will save half its time", "The comparable task saved one minute after review, with limited evidence", "Checking can now be skipped", "AI should automatically send every message"], correctOptionIndex: 1, explanation: "The result is limited to one synthetic trial and includes the verification work. It does not justify broad claims or removal of human approval." },
            { id: "msme-03-q3", question: "If an assisted draft is faster but retains an unsupported promise, what should happen?", options: ["Accept it because speed is the only measure", "Hide the error from the comparison", "Send it and correct it later", "Correct or reject it before use and record the quality failure"], correctOptionIndex: 3, explanation: "Quality and authorized commitments matter alongside time. A speed gain does not override an unacceptable output." }
          ],
          reflectionPrompt: "What checking or approval work would your own time comparison need to include?",
          returnToWorkAction: "With approval, compare one low-consequence task using the same quality checks for both methods. Record preparation, checking, correction and approval time without collecting confidential artifacts."
        }
      ],
      practicalAssessment: {
        id: "msme-practical-01",
        title: "An accurate customer draft and operations checklist",
        scenario: "Use fictional P1, S1 and O101\u2013O103 to prepare a customer response and checklist. Evaluate the supplied productivity trial without making unsupported business claims.",
        submissionPrompts: [
          { id: "task", label: "Task, audience and success criteria", help: "State what the customer and team need from your work." },
          { id: "safe-input", label: "Information included and information withheld", help: "Identify why internal cost and private markers do not belong in the drafting prompt." },
          { id: "ai-evidence", label: "Draft and safer instructions", help: "Use the supplied draft or an optional tool with synthetic inputs only." },
          { id: "checks", label: "Promises and calculations you checked", help: "Check stock, timing, price, delivery fee, discount and invented surcharge." },
          { id: "final", label: "Corrected customer response", help: "Keep unconfirmed stock and date explicit and avoid unauthorized commitments." },
          { id: "checklist", label: "Three-row action checklist", help: "Include owner role, dependency and evidence of completion." },
          { id: "return", label: "Productivity evaluation and return-to-work plan", help: "Include verification time, quality checks, limited evidence and authorized approval." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable response or checklist", "1": "Major source errors and unclear actions", "2": "Usable draft or checklist but material omissions", "3": "Clear accurate response and three actionable checklist rows", "4": "Concise audience-appropriate work with complete owners, dependencies and checks" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented promises and calculations", "1": "Checks only a minor fact", "2": "Checks key commitments but omits an important inconsistency", "3": "Corrects stock/date/discount/fee claims and includes full assisted time", "4": "Maps all material checks to sources and reports uncertainty and trial limits clearly" }, criticalGate: "No unconfirmed six-unit Friday promise, invented discount/free delivery or INR 50 surcharge remains as an authorized commitment" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Discloses inappropriate private information or actual secrets", "1": "Cannot distinguish relevant from internal information", "2": "Uses synthetic records but incompletely explains exclusions", "3": "Uses permitted facts and excludes internal cost/private contact data", "4": "Explains minimal input, approved channels and restricted customer-record handling" }, criticalGate: "No actual private customer records or credentials used; unnecessary internal/private fields are excluded from the customer draft and unapproved prompt" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Automatically commits or dispatches based on the draft", "1": "General caution without an approval route", "2": "Recognizes review but leaves a key operational action unclear", "3": "Preserves pending status and names human approval/checks and a bounded work trial", "4": "Explains stop conditions, source-based completion and limits of productivity conclusions" }, criticalGate: "Unresolved stock/address/pickup items are not falsely completed; customer sending and operational exceptions retain authorized human review" }
        ],
        samplePassingEvidence: "Four units are confirmed; six-unit Friday delivery needs the stock team's check. I removed the discount, free delivery and internal cost. O101 needs stock confirmation; O102 needs pickup arrangement; O103 needs approved address confirmation and remains on hold. I did not add a surcharge. The assisted trial takes 11 minutes including checks, saving one minute on one synthetic task. My work trial will use an approved low-consequence task and an authorized sender.",
        sampleCriticalFailure: "The learner calculates the right price and writes an elegant response but promises Friday delivery of six units, despite only four confirmed units. The verification gate fails.",
        assessorNote: "Accept different courteous wording and supervisor-reviewed priority suggestions. Do not require a positive productivity result or treat a calculated price as confirmed order acceptance."
      },
      followUp: { afterDays: 14, question: "Did you use a checked draft or action checklist on a permitted task, and what changed?", evidenceOptions: ["Structured reflection with task category and checks", "Blank checklist template", "Aggregate time comparison without customer details"], successSignal: "A learner describes a corrected commitment or clearer operational action and includes checking effort", privacyNote: "Do not require actual customer messages, prices negotiated with named customers or business account records." }
    },
    {
      id: "public-servant-source-briefs",
      title: "Clear administrative briefs with accountable AI use",
      ecosystem: "Government",
      role: "Public servant",
      level: "Foundation to applied",
      summary: "Create a source-traceable administrative draft, verify a simple summary, and retain authorized review before official use.",
      promise: "You can prepare a clear draft from permitted reference material and show which facts and judgments need review.",
      estimatedMinutes: 110,
      prerequisites: ["Read short supplied reference material", "Know that official approval is distinct from a draft", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Classify source material before tool use", "Map claims to supplied sources", "Reject invented requirements, fees and references", "Verify totals and rates with clear denominators", "Keep accountable approval and publication within assigned authority"],
      credentialClaim: "Demonstrated administrative drafting, source verification and responsible information-handling using synthetic training material",
      credentialExclusions: ["No authority to issue official decisions", "No legal or statutory qualification", "No assurance that an external AI tool is approved by an employer"],
      sourceNotice: "Every notice, department, programme, figure and policy below is fictional. No actual law, administrative direction or citizen service rule is stated.",
      lessons: [
        {
          id: "gov-01",
          title: "Draft from permitted sources, not invented rules",
          estimatedMinutes: 25,
          objective: "Create a source-based brief and remove invented requirements and authority.",
          lessonText: "An administrative draft should make it easy to identify the source of each important fact. First confirm whether the material is permitted for the chosen tool; a source being available to you does not automatically make external upload acceptable. This exercise supplies fictional shareable references, so no real file is needed. Read the sources before reviewing the AI draft. A generated instruction such as 'attendance is mandatory' is not authority unless the source actually states it. A fee or penalty must not be invented to make a notice sound official. Keep the document visibly marked as a draft, name the intended reader, and identify the review needed before official use. If a detail is missing, ask for confirmation or omit it. Do not add a fabricated circular number or present the AI output as an approved decision.",
          steps: ["Confirm the fictional packet is the approved practice input", "Map each material fact to a source", "Remove unsupported fee, penalty and mandatory-attendance claims", "Create a clear draft brief", "Name the approval step"],
          exercise: {
            title: "Correct the fictional staff-orientation brief",
            sourcePacket: [
              { sourceId: "G1", content: "Fictional staff orientation is planned for 8 October 2026 from 10:00 to 11:00." },
              { sourceId: "G2", content: "Venue: Room B. Participants are asked to respond by 6 October 2026." },
              { sourceId: "G3", content: "Attendance is voluntary. This material is a draft for authorized administrative review. No fee, penalty or circular number is supplied." },
              { sourceId: "G4", content: "Teaching packet is fictional and approved for this practice only. It contains no actual personnel or citizen records." }
            ],
            suppliedAiDraft: "Under Circular GOV-X, every employee must attend Room B on 8 October from 10:00 to 11:00. A fee of INR 500 applies. Late responses will result in a penalty. This notice is approved for issue.",
            optionalAiPrompt: "Prepare a brief from fictional G1\u2013G4 only. Include source references, distinguish draft status and voluntary attendance, and do not invent fees, penalties or circulars. Identify authorized review before issue.",
            learnerTask: "Write a short corrected draft and a fact-to-source list.",
            expectedEvidence: ["Correct date, time, room and response date", "Voluntary attendance retained", "GOV-X, fee and penalty removed as unsupported", "Draft status and authorized review explicit", "Important facts mapped to G1\u2013G3"],
            assessorReference: "The sources support a voluntary fictional event in Room B, 8 October 10:00\u201311:00, response by 6 October. They do not support a fee, penalty, circular or approved-issue status. Equivalent brief formats are acceptable."
          },
          quiz: [
            { id: "gov-01-q1", question: "Which statement matches G3?", options: ["Attendance is compulsory", "A fee of INR 500 applies", "Attendance is voluntary and the material needs authorized review", "Circular GOV-X authorizes publication"], correctOptionIndex: 2, explanation: "G3 explicitly states voluntary attendance and draft status. The generated fee, circular and authority are unsupported." },
            { id: "gov-01-q2", question: "How should GOV-X be treated?", options: ["As valid because it looks official", "As an unsupported reference to remove or verify before any use", "As a required citation", "As a confidential password"], correctOptionIndex: 1, explanation: "No such reference is supplied. Official-looking formatting does not establish authenticity." },
            { id: "gov-01-q3", question: "What is appropriate for this external-tool practice?", options: ["Upload actual restricted personnel files", "Use the supplied approved fictional packet only", "Assume every work file is public", "Include citizen identities to make the example realistic"], correctOptionIndex: 1, explanation: "The fictional packet is designed for practice. Real work material requires the organization's approved handling and tool rules." }
          ],
          reflectionPrompt: "How can the reader tell which facts came from the sources and which parts still need approval?",
          returnToWorkAction: "Use a claim\u2013source\u2013review template with permitted material in an approved environment. Keep draft status until the authorized approval step is completed."
        },
        {
          id: "gov-02",
          title: "Check numbers and the story they tell",
          estimatedMinutes: 25,
          objective: "Calculate a correct summary and avoid unsupported explanations of cause or performance.",
          lessonText: "A numerical brief needs a clear denominator and time period. In this fictional weekly packet, 80 items were received and 55 were recorded resolved. Dividing 55 by 80 gives 68.75%. That describes the packet's recorded figures; it does not automatically establish why outcomes changed or whether every item was handled satisfactorily. An AI draft may mix a wrong rate with a persuasive explanation. Check the calculation yourself, compare it with the source rows, and state the exact scope. Do not call a record 'improved' without a comparable earlier period and an agreed quality measure. A useful brief can explain the current counts and the limits of interpretation. If someone asks for a causal conclusion, identify the additional evidence needed rather than manufacturing one. Preserve accountability by asking the relevant data owner to confirm the figures before official circulation.",
          steps: ["Total received and resolved counts", "Calculate the rate with its denominator", "Compare the draft's rate", "Remove unsupported cause and quality claims", "Write a scoped summary for review"],
          exercise: {
            title: "Verify the fictional weekly service summary",
            sourcePacket: [
              { sourceId: "W1", category: "Category A", received: 40, recordedResolved: 25 },
              { sourceId: "W2", category: "Category B", received: 25, recordedResolved: 20 },
              { sourceId: "W3", category: "Category C", received: 15, recordedResolved: 10 },
              { sourceId: "W4", scope: "One fictional reporting week; no earlier period, case-level quality evidence or cause analysis is supplied." }
            ],
            suppliedAiDraft: "The programme resolved 95% of the 80 items and its new policy caused a major improvement in service quality.",
            optionalAiPrompt: "Summarize fictional W1\u2013W4. Show counts and denominator, calculate the rate, state scope, and avoid causal or quality claims unsupported by the packet.",
            learnerTask: "Create a verified three-sentence numerical brief with a visible calculation and one interpretation limit.",
            expectedEvidence: ["Received: 40 + 25 + 15 = 80", "Recorded resolved: 25 + 20 + 10 = 55", "55 / 80 \xD7 100 = 68.75%", "95% claim corrected", "No unsupported improvement, policy causation or case-quality claim"],
            assessorReference: "Accept 68.75% or appropriately labeled rounding such as 68.8%. The source uses 'recorded resolved'; avoid turning that into independently verified service quality. No previous-period or causal claim is justified."
          },
          quiz: [
            { id: "gov-02-q1", question: "What percentage of received items is recorded resolved?", options: ["95%", "55%", "68.75%", "80%"], correctOptionIndex: 2, explanation: "There are 55 recorded resolved items out of 80 received. 55 divided by 80, multiplied by 100, is 68.75%." },
            { id: "gov-02-q2", question: "What additional evidence is needed before calling this an improvement?", options: ["A more confident AI sentence", "A comparable baseline and agreed measures", "A larger font", "A made-up prior-period figure"], correctOptionIndex: 1, explanation: "Improvement requires an appropriate comparison and defined measures. The single-week packet provides neither." },
            { id: "gov-02-q3", question: "Which wording is best supported?", options: ["The policy caused better quality", "Every item was handled satisfactorily", "The packet records 55 of 80 items resolved for one fictional week", "The result applies to every department"], correctOptionIndex: 2, explanation: "This describes the supplied counts and scope without adding unverified quality, causal or generalization claims." }
          ],
          reflectionPrompt: "What would you ask the data owner before this summary was used in an official report?",
          returnToWorkAction: "On one permitted numerical summary, record the denominator, period, calculation and data-owner check before circulation."
        },
        {
          id: "gov-03",
          title: "Keep the draft-to-official boundary clear",
          estimatedMinutes: 25,
          objective: "Build a review handoff and safe work plan without assuming publication authority.",
          lessonText: "Preparing a draft and authorizing its official use are different responsibilities. A learning role such as public servant does not give permission to view every file or issue a notice. Keep the active work context and intended recipient clear. Your review handoff should identify the draft version, source packet, checks completed, uncertainties and the person or role that must approve it. AI can suggest text, but it cannot provide organizational authority. In this exercise, the reviewer role may confirm the source figures and wording; publication remains with the designated approver. Do not bypass that handoff because the document looks finished. If the approved AI tool is unavailable, use the supplied draft or prepare the brief manually. The skill is accurate and accountable work, not dependence on a tool. Return to your work with a small permitted task and an explicit stop condition if classification, access or approval is unclear.",
          steps: ["Mark the document as a draft", "List sources, version and checks", "Identify unresolved questions", "Route to the designated review and approval roles", "Define one bounded return-to-work task"],
          exercise: {
            title: "Prepare the accountable review handoff",
            sourcePacket: [
              { sourceId: "R1", content: "Fictional review process: learner prepares draft; data owner confirms supplied figures; designated administrative approver decides official issue. No role is granted through Academy enrollment." },
              { sourceId: "R2", content: "Use corrected G1\u2013G3 event brief and W1\u2013W4 numerical summary. Both remain draft teaching materials." },
              { sourceId: "R3", content: "Actual restricted work records, access credentials and citizen identities must not be included in this practice." }
            ],
            suppliedAiDraft: "The brief looks complete. Publish it immediately using your Academy learner role and skip data-owner review.",
            optionalAiPrompt: "Create a review checklist from fictional R1\u2013R3. Preserve draft status, source checks, data-owner review and designated approval. Do not grant permissions or propose immediate publication.",
            learnerTask: "Write a review note naming the source packet, checks, questions, next reviewer, final approval step and work-trial stop condition.",
            expectedEvidence: ["Draft status explicit", "Corrected sources and calculations listed", "Data-owner review and designated approval separated", "No implied administrative privileges from Academy role", "Stop when classification, permitted tool or authority is unclear"],
            assessorReference: "A passing handoff preserves the R1 process and does not issue anything. The learner can use equivalent role labels without naming a real official. A safe work trial uses permitted material and retains employer-approved review."
          },
          quiz: [
            { id: "gov-03-q1", question: "What permission does selecting the public-servant learner role grant?", options: ["Access to all official records", "Permission to publish a notice", "No administrative or publication permission by itself", "Permission to bypass review"], correctOptionIndex: 2, explanation: "A learning context supports relevance. Actual access and authority require explicit assignments in the relevant system and process." },
            { id: "gov-03-q2", question: "What should happen when the data classification or approved tool is unclear?", options: ["Upload the file and ask later", "Stop and seek the appropriate approval or handling guidance", "Rename the file to make it public", "Assume Academy enrollment authorizes it"], correctOptionIndex: 1, explanation: "Unclear handling rules are a reason to pause the tool use and seek the responsible owner, not to guess." },
            { id: "gov-03-q3", question: "If an external AI tool is unavailable during this activity, what is acceptable?", options: ["Use another unapproved tool with restricted records", "Skip all verification", "Claim the task is passed without evidence", "Review the supplied draft or prepare the work manually with the same checks"], correctOptionIndex: 3, explanation: "The assessed skill is responsible task performance. The provided draft supports practice without tool access, and the checking standard remains the same." }
          ],
          reflectionPrompt: "What part of your handoff ensures that a polished draft is not mistaken for an approved decision?",
          returnToWorkAction: "Use a draft-review checklist for one permitted administrative task. Record sources, checks, remaining questions and the authorized approval route without submitting confidential work to Academy."
        }
      ],
      practicalAssessment: {
        id: "gov-practical-01",
        title: "A verified administrative brief and review handoff",
        scenario: "Prepare a corrected fictional staff-orientation brief, a numerical summary of W1\u2013W4, and a review handoff under R1\u2013R3. Explain why generated wording is not official authority.",
        submissionPrompts: [
          { id: "task", label: "Purpose, reader and draft status", help: "Identify the intended administrative use and why approval remains necessary." },
          { id: "safe-input", label: "Permitted input and handling boundary", help: "Use the fictional packet and identify what you would keep out of an unapproved tool." },
          { id: "ai-evidence", label: "Supplied draft and safer instructions", help: "Describe the source-bound instructions without providing any actual restricted file." },
          { id: "checks", label: "Fact-to-source map and numerical checks", help: "Check event facts, invented circular/fee/penalty, totals and rate." },
          { id: "final", label: "Corrected brief and scoped numerical summary", help: "Keep voluntary attendance, draft status and the exact count scope." },
          { id: "handoff", label: "Review and approval handoff", help: "Identify data-owner confirmation, unresolved questions and designated approval." },
          { id: "return", label: "Return-to-work task and stop conditions", help: "Choose a permitted task and explain when access, classification or authority needs clarification." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable brief or handoff", "1": "Major factual errors and unclear audience", "2": "Mostly usable work with material omissions", "3": "Clear corrected event brief, numerical summary and review note", "4": "Concise audience-appropriate work with complete source mapping and actionable handoff" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented official references and rate", "1": "Checks isolated facts only", "2": "Checks main facts but leaves an important unsupported assertion", "3": "Removes invented authority/fee/penalty and verifies 55 of 80 equals 68.75%", "4": "Maps every important assertion to sources and explains scope, denominator and interpretation limits" }, criticalGate: "No fabricated circular, fee, penalty, mandatory-attendance claim or unsupported causal improvement remains presented as source-supported fact" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual restricted records or credentials", "1": "Treats all work material as permitted", "2": "Uses synthetic material but lacks a clear tool boundary", "3": "Uses only approved fictional packet and identifies restricted information to withhold", "4": "Explains approved environment, minimum necessary sharing and a clear uncertainty stop" }, criticalGate: "No actual restricted administrative/citizen records or credentials are submitted or proposed for unapproved tool use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Issues or authorizes the draft without required authority", "1": "Mentions review but does not distinguish approval", "2": "Identifies review with an incomplete handoff", "3": "Preserves draft status, data-owner check and designated approval", "4": "Adds specific unresolved questions, stop conditions and a bounded permitted work trial" }, criticalGate: "Academy role and AI output are not treated as official authority; required review and designated approval are retained" }
        ],
        samplePassingEvidence: "G1 and G2 support the event date, time, venue and response date. G3 says attendance is voluntary and the material is a draft. I removed GOV-X, INR 500 and the penalty. W1\u2013W3 total 80 received and 55 recorded resolved, or 68.75%, for one fictional week; no causal improvement is established. My handoff requests data-owner checks and designated approval before issue. I used only the synthetic packet and will stop a work trial if classification, tool approval or authority is unclear.",
        sampleCriticalFailure: "The learner calculates the rate correctly but retains an invented circular and describes the draft as officially approved. The verification and judgment gates fail.",
        assessorNote: "Assess source accountability and authority boundaries rather than legal knowledge. Do not infer that any real organization's tool or publication policy matches the fictional process."
      },
      followUp: { afterDays: 14, question: "Did you use a source-and-review checklist for a permitted administrative task?", evidenceOptions: ["Structured reflection without document contents", "Blank claim\u2013source\u2013review template", "Authorized facilitator confirmation under the approved pilot process"], successSignal: "The learner describes a checked claim, a documented uncertainty and the correct approval handoff", privacyNote: "Do not collect actual administrative briefs, citizen records or employer-restricted information by default." }
    }
  ]
};

// outputs/aplyd-academy-sprint/curriculum-authoring/resolver-candidate/academy-curriculum.ts
var LEGACY_CONTENT_VERSION2 = "0.1-review-draft";
var ContentResolutionError2 = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
    this.name = "ContentResolutionError";
  }
  status;
};
function deepFreeze2(value) {
  if (value !== null && typeof value === "object" && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) deepFreeze2(child);
    Object.freeze(value);
  }
  return value;
}
function validScope2(value) {
  return value === "global" || typeof value === "string" && /^tw-[a-z0-9-]{20,80}$/i.test(value);
}
function contentRef2(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ContentResolutionError2("The saved content reference is invalid. Contact support before continuing.");
  }
  const ref = value;
  if (Object.keys(ref).some((key) => !["scope", "programId", "versionId"].includes(key)) || !validScope2(ref.scope) || typeof ref.programId !== "string" || !/^[a-z0-9][a-z0-9-]{0,99}$/i.test(ref.programId) || typeof ref.versionId !== "string" || !/^[a-z0-9][a-z0-9._-]{0,99}$/i.test(ref.versionId)) {
    throw new ContentResolutionError2("The saved content reference is invalid. Contact support before continuing.");
  }
  return Object.freeze({ scope: ref.scope, programId: ref.programId, versionId: ref.versionId });
}
function contentKey2(value) {
  const ref = contentRef2(value);
  return JSON.stringify([ref.scope, ref.programId, ref.versionId]);
}
function createCurriculumRegistry2(entries) {
  const index = /* @__PURE__ */ new Map();
  for (const entry of entries) {
    const ref = contentRef2(entry.ref);
    if (entry.program.id !== ref.programId) {
      throw new ContentResolutionError2("A content snapshot has a mismatched pathway identity.");
    }
    const key = contentKey2(ref);
    if (index.has(key)) throw new ContentResolutionError2("An immutable content key is already registered.");
    index.set(key, deepFreeze2(structuredClone({ ...entry, ref })));
  }
  function resolve(input, allowedScopes = ["global"]) {
    const ref = contentRef2(input);
    if (!allowedScopes.includes(ref.scope)) {
      throw new ContentResolutionError2("This content is not available in your learning space.", 404);
    }
    const found = index.get(contentKey2(ref));
    if (!found) {
      throw new ContentResolutionError2("Your pinned curriculum version is unavailable. Contact support before continuing.");
    }
    return found;
  }
  return Object.freeze({ resolve, has: (ref, allowedScopes) => {
    try {
      resolve(ref, allowedScopes);
      return true;
    } catch (error) {
      if (error instanceof ContentResolutionError2) return false;
      throw error;
    }
  } });
}
var curriculum2 = deepFreeze2(structuredClone(review_draft_default2));
var programs2 = curriculum2.pathways;
var seedSnapshots2 = programs2.map((program) => ({
  ref: contentRef2({ scope: "global", programId: program.id, versionId: LEGACY_CONTENT_VERSION2 }),
  program,
  language: curriculum2.language,
  audience: curriculum2.audience,
  classification: curriculum2.status
}));
var curriculumRegistry2 = createCurriculumRegistry2(seedSnapshots2);

// outputs/aplyd-academy-sprint/curriculum-authoring/authoring-candidate/workspace-authoring.ts
var AUTHORING_CLASSIFICATION = "Private workspace practice draft \xB7 nonaccredited";
var AUTHORING_LIMITS = { activeDrafts: 4, publications: 8, documentBytes: 65536, contentBytes: 65e4 };
function plain(v) {
  if (!v || typeof v !== "object" || Array.isArray(v)) return false;
  const p = Object.getPrototypeOf(v);
  return p === Object.prototype || p === null;
}
function canonicalJson(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(canonicalJson).join(",") + "]";
  return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonicalJson(value[k])).join(",") + "}";
}
function validateDocument(document2, expected) {
  const issues = [], issue = (path, kind, message) => issues.push({ path, kind, message });
  const locked = /* @__PURE__ */ new Set(["id", "ecosystem", "role", "level", "credentialClaim", "credentialExclusions", "sourceNotice", "followUp"]);
  function walk(v, t, path) {
    if (path.endsWith(".sourcePacket")) {
      if (!Array.isArray(v) || v.length < 1 || v.length > 20) {
        issue(path, "shape", "Provide 1\u201320 fictional source records.");
        return;
      }
      v.forEach((row, i) => {
        if (!plain(row) || Object.keys(row).length < 2 || Object.keys(row).length > 15) {
          issue(path + "." + i, "shape", "A source record needs a reference and bounded plain facts.");
          return;
        }
        if (typeof row.sourceId !== "string" || row.sourceId.trim().length < 1 || row.sourceId.length > 80) issue(path + "." + i + ".sourceId", "shape", "Provide a source reference of 1\u201380 characters.");
        for (const [key, value] of Object.entries(row)) {
          if (key.length > 60 || ["__proto__", "constructor", "prototype"].includes(key)) {
            issue(path + "." + i, "shape", "This source field name is unsupported.");
            continue;
          }
          if (typeof value === "string") {
            if (value.length > 2e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value)) issue(path + "." + i + "." + key, "limit", "Keep source facts within 2,000 characters using ordinary text.");
          } else if (typeof value === "number") {
            if (!Number.isFinite(value) || Math.abs(value) > 1e12) issue(path + "." + i + "." + key, "shape", "Use a finite bounded number.");
          } else if (value !== null && typeof value !== "boolean") issue(path + "." + i + "." + key, "shape", "Source facts must be plain text, numbers or simple flags.");
        }
      });
      return;
    }
    if (Array.isArray(t)) {
      if (!Array.isArray(v)) {
        issue(path, "shape", "This field must be a list.");
        return;
      }
      const fixed = /\.(lessons|quiz|options|submissionPrompts|rubric)$/.test(path);
      if (fixed && v.length !== t.length || !fixed && (v.length < 1 || v.length > 20)) {
        issue(path, "shape", fixed ? `This pilot keeps exactly ${t.length} entries here.` : "Provide 1\u201320 entries.");
        return;
      }
      v.forEach((child, i) => walk(child, fixed ? t[i] : t[0], path + "." + i));
      return;
    }
    if (t === null) {
      if (v !== null) issue(path, "locked", "This pilot preserves the original critical-gate structure.");
      return;
    }
    if (typeof t === "object") {
      if (!plain(v)) {
        issue(path, "shape", "Provide a plain content object.");
        return;
      }
      if (Object.keys(v).some((k) => !Object.hasOwn(t, k)) || Object.keys(t).some((k) => !Object.hasOwn(v, k))) {
        issue(path, "shape", "Content fields are missing or unsupported.");
        return;
      }
      for (const key of Object.keys(t)) {
        if (path === "program" && locked.has(key) || key === "id") {
          if (canonicalJson(v[key]) !== canonicalJson(t[key])) issue(path + "." + key, "locked", "Published identity, classification and supported structure are fixed for this pilot.");
        } else walk(v[key], t[key], path + "." + key);
      }
      return;
    }
    if (typeof v !== typeof t) {
      issue(path, "shape", "This field has an unsupported value type.");
      return;
    }
    if (typeof v === "string" && (v.length > 12e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v))) issue(path, "limit", "Use ordinary text within the field limit.");
    if (typeof v === "number" && !Number.isFinite(v)) issue(path, "shape", "Use a finite number.");
  }
  walk(document2, expected, "program");
  try {
    if (new TextEncoder().encode(JSON.stringify(document2)).length > AUTHORING_LIMITS.documentBytes) issue("program", "limit", "This pathway exceeds the 64 KiB pilot document limit.");
  } catch {
    issue("program", "shape", "Content must be serializable text and facts.");
  }
  if (issues.some((x) => ["shape", "locked", "limit"].includes(x.kind))) return issues;
  function required(value, path, min = 10, max = 2e3) {
    if (typeof value !== "string" || value.trim().length < min) issue(path, "required", `Add at least ${min} characters.`);
    else if (value.length > max) issue(path, "limit", `Keep this field within ${max} characters.`);
  }
  function minutes(value, path) {
    if (!Number.isInteger(value) || value < 5 || value > 720) issue(path, "consistency", "Use whole minutes between 5 and 720.");
  }
  required(document2.title, "program.title", 3, 160);
  required(document2.summary, "program.summary", 20, 2e3);
  required(document2.promise, "program.promise", 20, 1e3);
  minutes(document2.estimatedMinutes, "program.estimatedMinutes");
  for (const key of ["prerequisites", "outcomes"]) document2[key].forEach((v, i) => required(v, "program." + key + "." + i, 10, 500));
  for (const [i, l] of document2.lessons.entries()) {
    const base = "program.lessons." + i;
    required(l.title, base + ".title", 3, 160);
    required(l.objective, base + ".objective", 20, 1e3);
    required(l.lessonText, base + ".lessonText", 100, 12e3);
    minutes(l.estimatedMinutes, base + ".estimatedMinutes");
    l.steps.forEach((v, j) => required(v, base + ".steps." + j, 5, 500));
    required(l.reflectionPrompt, base + ".reflectionPrompt", 15, 1e3);
    required(l.returnToWorkAction, base + ".returnToWorkAction", 30, 2e3);
    const ex = l.exercise;
    for (const key of ["title", "suppliedAiDraft", "optionalAiPrompt", "learnerTask", "assessorReference"]) required(ex[key], base + ".exercise." + key, key === "title" ? 3 : 30, key === "title" ? 160 : 4e3);
    ex.expectedEvidence.forEach((v, j) => required(v, base + ".exercise.expectedEvidence." + j, 10, 700));
    for (const [j, q] of l.quiz.entries()) {
      required(q.question, base + ".quiz." + j + ".question", 10, 1e3);
      required(q.explanation, base + ".quiz." + j + ".explanation", 20, 2e3);
      q.options.forEach((v, k) => required(v, base + ".quiz." + j + ".options." + k, 1, 500));
      if (!Number.isInteger(q.correctOptionIndex) || q.correctOptionIndex < 0 || q.correctOptionIndex > 3) issue(base + ".quiz." + j + ".correctOptionIndex", "consistency", "Choose one of the four answer options.");
    }
  }
  const a = document2.practicalAssessment;
  required(a.title, "program.practicalAssessment.title", 3, 160);
  required(a.scenario, "program.practicalAssessment.scenario", 30, 5e3);
  for (const [i, p] of a.submissionPrompts.entries()) {
    required(p.label, "program.practicalAssessment.submissionPrompts." + i + ".label", 3, 160);
    required(p.help, "program.practicalAssessment.submissionPrompts." + i + ".help", 10, 1e3);
  }
  for (const [i, r2] of a.rubric.entries()) {
    const b = "program.practicalAssessment.rubric." + i;
    required(r2.dimension, b + ".dimension", 3, 160);
    if (!Number.isInteger(r2.weight) || r2.weight < 1 || r2.weight > 97) issue(b + ".weight", "consistency", "Use a positive whole weight, keeping the total at 100.");
    for (const level of ["0", "1", "2", "3", "4"]) required(r2.anchors[level], b + ".anchors." + level, 10, 1e3);
    if (r2.criticalGate !== null) required(r2.criticalGate, b + ".criticalGate", 30, 2e3);
  }
  if (a.rubric.reduce((n, r2) => n + r2.weight, 0) !== 100) issue("program.practicalAssessment.rubric", "consistency", "Criterion weights must total exactly 100.");
  for (const key of ["samplePassingEvidence", "sampleCriticalFailure", "assessorNote"]) required(a[key], "program.practicalAssessment." + key, 30, 5e3);
  return issues;
}

// outputs/aplyd-academy-sprint/curriculum-authoring/authoring-candidate/academy-authoring-ui.tsx
import { Fragment as Fragment7, jsx as jsx11, jsxs as jsxs4 } from "react/jsx-runtime";
var clone = (value) => structuredClone(value);
var same = (a, b) => canonicalJson(a) === canonicalJson(b);
var checks = ["sources", "answers", "rubric", "safety", "accessibility"];
var checkLabels = { sources: "Fictional source facts and references are coherent", answers: "Every answer key and explanation was checked", rubric: "Practical prompts, anchors and weights match the work", safety: "Information handling, uncertainty and human authority stay explicit", accessibility: "Language, instructions and evidence expectations are clear" };
var sectionNames = { overview: "Overview", "lesson-0": "Lesson 1", "lesson-1": "Lesson 2", "lesson-2": "Lesson 3", practical: "Practical task", preview: "Preview", review: "Review & publication" };
function ContentStudio() {
  const { team, cmd, busy, go, contentVersions } = useAcademy();
  const [scratch, setScratch] = useWorkspaceDraft("content-studio", { selected: "", section: "overview", working: {} });
  const [source, setSource] = useState11(academy_curriculum_default.pathways[1].id), [copying, setCopying] = useState11(false), [publication, setPublication] = useState11(null), [retire, setRetire] = useState11(null), [retireReason, setRetireReason] = useState11("");
  const owner = !!team?.active && team.roles?.includes("admin"), drafts = owner ? team.content?.drafts ?? [] : [], publications = owner ? team.content?.publications ?? [] : [];
  const selected = drafts.find((d) => d.id === scratch.selected);
  if (!owner) return /* @__PURE__ */ jsx11(Empty, { icon: LockKeyhole, title: "Content studio needs current owner access", body: "Private source drafts are available only to current workspace owners. Your own unsent edits remain in this session and have not been saved or sent.", action: "Open workspaces", onAction: () => go("teams") });
  return /* @__PURE__ */ jsxs4(Fragment7, { children: [
    /* @__PURE__ */ jsx11(Head, { eyebrow: "PRACTICAL LEARNING, SHAPED HERE", title: "Content studio", body: "Create useful private practice from a reviewed seed, then ask another owner to check it." }),
    /* @__PURE__ */ jsx11(FormError, {}),
    /* @__PURE__ */ jsxs4("div", { className: "notice", children: [
      /* @__PURE__ */ jsx11(ShieldCheck, {}),
      /* @__PURE__ */ jsxs4("div", { children: [
        /* @__PURE__ */ jsx11("strong", { children: AUTHORING_CLASSIFICATION }),
        /* @__PURE__ */ jsx11("p", { children: "English practice for adult learners using fictional information. Publication needs another current owner\u2019s review. This workflow makes no professional qualification or accreditation claim." })
      ] })
    ] }),
    selected ? /* @__PURE__ */ jsx11(DraftEditor, { draft: selected, section: scratch.section, setSection: (section) => setScratch((s) => ({ ...s, section })), working: scratch.working[selected.id], setWorking: (working) => setScratch((s) => ({ ...s, working: { ...s.working, [selected.id]: working } })), onBack: () => setScratch((s) => ({ ...s, selected: "" })) }, team.id + ":" + selected.id) : /* @__PURE__ */ jsxs4(Fragment7, { children: [
      /* @__PURE__ */ jsxs4("section", { className: "panel spacious mt", children: [
        /* @__PURE__ */ jsx11("h2", { children: "Start with a practical pathway" }),
        /* @__PURE__ */ jsx11("p", { className: "mt", children: "A copy gets a private pathway identity. The shared Academy seeds stay unchanged." }),
        /* @__PURE__ */ jsxs4("div", { className: "field", children: [
          /* @__PURE__ */ jsx11("label", { htmlFor: "content-seed", children: "Seed pathway" }),
          /* @__PURE__ */ jsx11("select", { id: "content-seed", value: source, onChange: (e) => setSource(e.target.value), children: academy_curriculum_default.pathways.map((p) => /* @__PURE__ */ jsx11("option", { value: p.id, children: p.title }, p.id)) })
        ] }),
        /* @__PURE__ */ jsxs4(Button, { disabled: busy || copying || drafts.filter((d) => !["published", "archived"].includes(d.state)).length >= 4, onClick: async () => {
          setCopying(true);
          try {
            await cmd({ type: "content-copy", sourceRef: currentRef(source) }, "Private draft copied");
          } finally {
            setCopying(false);
          }
        }, children: [
          /* @__PURE__ */ jsx11(Copy, { size: 17 }),
          "Copy seed to private draft"
        ] }),
        /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "This pilot keeps three lessons, nine knowledge checks, seven practical fields and four rubric criteria. Up to four active drafts, 24 retained draft records and eight immutable publications." })
      ] }),
      /* @__PURE__ */ jsxs4("div", { className: "section-title", children: [
        /* @__PURE__ */ jsx11("h2", { children: "Your workspace drafts" }),
        /* @__PURE__ */ jsxs4("span", { children: [
          drafts.filter((d) => !["published", "archived"].includes(d.state)).length,
          " active"
        ] })
      ] }),
      /* @__PURE__ */ jsx11("div", { className: "two-grid", children: drafts.filter((d) => !["published", "archived"].includes(d.state)).map((d) => /* @__PURE__ */ jsxs4("section", { className: "panel", "data-content-draft-id": d.id, children: [
        /* @__PURE__ */ jsxs4("div", { className: "discussion-meta", children: [
          /* @__PURE__ */ jsx11(Tag, { children: d.state.replaceAll("_", " ") }),
          /* @__PURE__ */ jsx11(Tag, { children: d.authorName })
        ] }),
        /* @__PURE__ */ jsx11("h3", { className: "mt", children: d.document.title || "Untitled private practice" }),
        /* @__PURE__ */ jsxs4("p", { className: "form-hint", children: [
          "Saved ",
          date(d.updatedAt),
          " \xB7 Revision ",
          d.revision
        ] }),
        /* @__PURE__ */ jsx11(Button, { className: "mt", variant: "outline", onClick: () => setScratch((s) => ({ ...s, selected: d.id, section: d.state === "in_review" ? "review" : "overview" })), children: "Open content draft" })
      ] }, d.id)) }),
      !drafts.some((d) => !["published", "archived"].includes(d.state)) && /* @__PURE__ */ jsx11(Empty, { icon: BookOpen, title: "Make the learning fit the work", body: "Copy a seed to begin. Replace fictional facts, examples and explanations while keeping a bounded practical assessment." }),
      /* @__PURE__ */ jsxs4("details", { className: "source-packet mt", children: [
        /* @__PURE__ */ jsxs4("summary", { children: [
          "Archived content drafts (",
          drafts.filter((d) => String(d.state) === "archived").length,
          ")"
        ] }),
        /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "Archived documents and change history remain read only. Archiving frees an active draft slot and does not publish the content." }),
        /* @__PURE__ */ jsx11("div", { className: "two-grid mt", children: drafts.filter((d) => String(d.state) === "archived").map((d) => /* @__PURE__ */ jsxs4("section", { className: "panel", "data-content-draft-id": d.id, children: [
          /* @__PURE__ */ jsx11(Tag, { children: "Archived \xB7 read only" }),
          /* @__PURE__ */ jsx11("h3", { className: "mt", children: d.document.title || "Untitled private practice" }),
          /* @__PURE__ */ jsxs4("p", { className: "form-hint", children: [
            "Author: ",
            d.authorName,
            " \xB7 Last changed ",
            date(d.updatedAt)
          ] }),
          /* @__PURE__ */ jsx11(Button, { className: "mt", variant: "outline", onClick: () => setScratch((s) => ({ ...s, selected: d.id, section: "preview" })), children: "Read archived content draft" })
        ] }, d.id)) })
      ] }),
      /* @__PURE__ */ jsx11("div", { className: "section-title", children: /* @__PURE__ */ jsx11("h2", { children: "Immutable private publications" }) }),
      /* @__PURE__ */ jsx11("div", { className: "two-grid", children: publications.map((p) => /* @__PURE__ */ jsxs4("section", { className: "panel", "data-content-publication-id": p.id, children: [
        /* @__PURE__ */ jsxs4("div", { className: "discussion-meta", children: [
          /* @__PURE__ */ jsx11(Tag, { children: p.availability === "available" ? "Open to new enrollment" : "Closed to new enrollment" }),
          /* @__PURE__ */ jsx11(Tag, { children: "Nonaccredited" })
        ] }),
        /* @__PURE__ */ jsx11("h3", { className: "mt", children: p.title }),
        /* @__PURE__ */ jsxs4("p", { className: "form-hint", children: [
          "Reviewed by ",
          p.reviewerName,
          " \xB7 Published ",
          date(p.publishedAt),
          " \xB7 Review due ",
          date(p.reviewDueAt)
        ] }),
        /* @__PURE__ */ jsxs4("details", { className: "mt", children: [
          /* @__PURE__ */ jsx11("summary", { children: "Version reference" }),
          /* @__PURE__ */ jsx11("p", { className: "form-hint", children: p.ref.versionId }),
          /* @__PURE__ */ jsxs4("p", { className: "form-hint", children: [
            "SHA256 ",
            p.documentHash
          ] })
        ] }),
        /* @__PURE__ */ jsxs4("div", { className: "actions", children: [
          /* @__PURE__ */ jsx11(Button, { variant: "outline", onClick: () => setPublication(p), children: "Preview publication" }),
          /* @__PURE__ */ jsx11(Button, { variant: "outline", disabled: busy || drafts.filter((d) => !["published", "archived"].includes(d.state)).length >= 4, onClick: () => cmd({ type: "content-copy", sourceRef: p.ref }, "New private revision copied"), children: "Create revision" }),
          p.availability === "available" && /* @__PURE__ */ jsx11(Button, { disabled: busy, onClick: () => go("teams"), children: "Offer in new cohort" }),
          p.availability === "available" && /* @__PURE__ */ jsx11(Button, { variant: "outline", disabled: busy, onClick: () => {
            setRetire(p);
            setRetireReason("");
          }, children: "Close new enrollment" })
        ] })
      ] }, p.id)) }),
      !publications.length && /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "Reviewed versions will appear here. Existing learners stay on the version chosen by their cohort." })
    ] }),
    /* @__PURE__ */ jsx11(Dialog2, { open: !!publication, onOpenChange: (v) => !v && setPublication(null), children: /* @__PURE__ */ jsxs4(DialogContent3, { className: "wide-dialog content-preview-dialog", children: [
      /* @__PURE__ */ jsxs4(DialogHeader, { children: [
        /* @__PURE__ */ jsx11(DialogTitle3, { children: "Published private practice" }),
        /* @__PURE__ */ jsxs4(DialogDescription3, { children: [
          AUTHORING_CLASSIFICATION,
          ". This preserved version is read only."
        ] })
      ] }),
      publication && /* @__PURE__ */ jsx11(DocumentPreview, { document: (contentVersions ?? []).find((s) => s.ref.scope === publication.ref.scope && s.ref.programId === publication.ref.programId && s.ref.versionId === publication.ref.versionId)?.program })
    ] }) }),
    /* @__PURE__ */ jsx11(Dialog2, { open: !!retire, onOpenChange: (v) => !v && setRetire(null), children: /* @__PURE__ */ jsxs4(DialogContent3, { children: [
      /* @__PURE__ */ jsx11(FormError, {}),
      /* @__PURE__ */ jsxs4(DialogHeader, { children: [
        /* @__PURE__ */ jsx11(DialogTitle3, { children: "Close this version to new enrollment?" }),
        /* @__PURE__ */ jsx11(DialogDescription3, { children: "Existing cohorts and learners keep their preserved content. Pause an affected cohort separately when learning needs an immediate safety stop." })
      ] }),
      /* @__PURE__ */ jsx11(Text, { id: "content-retire-reason", label: "Reason for closing new enrollment", value: retireReason, onChange: setRetireReason, minLength: 10, maxLength: 1e3 }),
      /* @__PURE__ */ jsxs4("div", { className: "actions", children: [
        /* @__PURE__ */ jsx11(Button, { variant: "outline", onClick: () => setRetire(null), children: "Keep available" }),
        /* @__PURE__ */ jsx11(Button, { disabled: busy || retireReason.trim().length < 10, onClick: async () => {
          if (await cmd({ type: "content-retire", publicationId: retire.id, reason: retireReason }, "New enrollment closed \xB7 snapshots preserved")) setRetire(null);
        }, children: "Confirm close new enrollment" })
      ] })
    ] }) })
  ] });
}
function DraftEditor({ draft: d, section, setSection, working, setWorking, onBack }) {
  const { team, cmd, busy } = useAcademy(), author = d.authorId === team.currentUserId, terminal = ["published", "archived"].includes(d.state), editable = author && d.state === "draft";
  const [request, setRequest] = useState11(false), [recall, setRecall] = useState11(false), [publish, setPublish] = useState11(false), [archive, setArchive] = useState11(false);
  const [input, setInput] = useWorkspaceDraft("content-review-" + d.id, { reviewerId: "", dueDate: new Date(Date.now() + 365 * 864e5).toISOString().slice(0, 10), reason: "", reviewNote: "", reviewChecks: {}, rebaseAck: false });
  const { reviewerId, dueDate, reason, reviewNote, reviewChecks, rebaseAck } = input;
  const setReviewerId = (value) => setInput((v) => ({ ...v, reviewerId: value })), setDueDate = (value) => setInput((v) => ({ ...v, dueDate: value })), setReason = (value) => setInput((v) => ({ ...v, reason: value })), setReviewNote = (value) => setInput((v) => ({ ...v, reviewNote: value })), setRebaseAck = (value) => setInput((v) => ({ ...v, rebaseAck: value }));
  const setReviewChecks = (value) => setInput((v) => ({ ...v, reviewChecks: typeof value === "function" ? value(v.reviewChecks) : value }));
  useEffect13(() => {
    if (author && !working) setWorking({ document: clone(d.document), baseDocument: clone(d.document), baseRevision: d.revision });
  }, [author, d.id, working]);
  const local = author && working ? working : { document: d.document, baseDocument: d.document, baseRevision: d.revision };
  const retainedUnsent = author && !same(local.document, local.baseDocument), dirty = retainedUnsent && !terminal, conflict = author && !terminal && local.baseRevision !== d.revision, document2 = !terminal && author && working ? working.document : d.document;
  const issues = useMemo7(() => validateDocument(document2, d.document), [document2, d.document]);
  useEffect13(() => {
    if (author && working && !dirty && working.baseRevision !== d.revision && same(working.document, d.document)) setWorking({ document: clone(d.document), baseDocument: clone(d.document), baseRevision: d.revision });
  }, [author, working, dirty, d.revision, d.document]);
  const update = (path, value) => {
    if (!editable) return;
    const next = clone(document2);
    let target = next;
    for (const key of path.slice(0, -1)) target = target[key];
    target[path.at(-1)] = value;
    setWorking({ ...local, document: next });
  };
  const savedRevision = author ? local.baseRevision : d.revision;
  const reviewers = team.members.filter((m) => m.active && m.roles.includes("admin") && m.userId !== d.authorId);
  const canReview = d.state === "in_review" && d.reviewerId === team.currentUserId && d.authorId !== team.currentUserId;
  const text = (path, label, value, props = {}) => /* @__PURE__ */ jsx11(Text, { id: "content-" + path.join("-"), label, value, onChange: (v) => update(path, v), disabled: !editable, ...props });
  const list = (path, label, values) => /* @__PURE__ */ jsx11(StringList, { path, label, values, editable, update });
  return /* @__PURE__ */ jsxs4("section", { className: "content-editor mt", "data-content-editor-id": d.id, children: [
    /* @__PURE__ */ jsxs4("div", { className: "section-title no-top", children: [
      /* @__PURE__ */ jsxs4("div", { children: [
        /* @__PURE__ */ jsx11(Button, { variant: "outline", onClick: onBack, children: "Back to content studio" }),
        /* @__PURE__ */ jsx11("h2", { className: "mt", children: document2.title || "Untitled private practice" }),
        /* @__PURE__ */ jsxs4("div", { className: "discussion-meta", children: [
          /* @__PURE__ */ jsx11(Tag, { children: d.state.replaceAll("_", " ") }),
          /* @__PURE__ */ jsx11(Tag, { children: AUTHORING_CLASSIFICATION }),
          /* @__PURE__ */ jsx11("span", { role: "status", "aria-live": "polite", children: dirty ? "Unsaved changes" : "Saved revision " + d.revision })
        ] })
      ] }),
      /* @__PURE__ */ jsxs4("div", { className: "actions", children: [
        /* @__PURE__ */ jsx11(Button, { variant: "outline", onClick: () => setSection("preview"), children: "Preview draft" }),
        editable && /* @__PURE__ */ jsx11(Button, { disabled: busy || !dirty || conflict, onClick: async () => {
          if (await cmd({ type: "content-save", draftId: d.id, revision: savedRevision, document: document2 }, "Private content draft saved")) setWorking({ document: clone(document2), baseDocument: clone(document2), baseRevision: savedRevision + 1 });
        }, children: "Save content draft" })
      ] })
    ] }),
    terminal && retainedUnsent && /* @__PURE__ */ jsx11("div", { className: "notice mt", children: /* @__PURE__ */ jsxs4("div", { children: [
      /* @__PURE__ */ jsx11("strong", { children: "Your earlier unsent edits are separate from this preserved document." }),
      /* @__PURE__ */ jsx11("p", { children: "The archived or published view shows the exact saved content. Your own earlier editor text remains in this session; it has not been stored in this terminal version." }),
      /* @__PURE__ */ jsxs4("details", { className: "mt", children: [
        /* @__PURE__ */ jsx11("summary", { children: "My retained unsent editor text" }),
        /* @__PURE__ */ jsx11(DocumentPreview, { document: local.document })
      ] })
    ] }) }),
    conflict && /* @__PURE__ */ jsx11("div", { className: "notice error-notice", role: "alert", children: /* @__PURE__ */ jsxs4("div", { children: [
      /* @__PURE__ */ jsx11("strong", { children: "The saved draft changed. Your unsaved document is still here." }),
      /* @__PURE__ */ jsxs4("p", { children: [
        "Current saved revision ",
        d.revision,
        "; your editor began at revision ",
        local.baseRevision,
        ". Read the saved preview before choosing whether to reload or keep your edits."
      ] }),
      /* @__PURE__ */ jsxs4("details", { className: "mt", children: [
        /* @__PURE__ */ jsx11("summary", { children: "Read current saved document" }),
        /* @__PURE__ */ jsx11(DocumentPreview, { document: d.document })
      ] }),
      /* @__PURE__ */ jsxs4("label", { className: "check-line mt", children: [
        /* @__PURE__ */ jsx11("input", { type: "checkbox", checked: rebaseAck, onChange: (e) => setRebaseAck(e.target.checked) }),
        "I checked the current saved document and want to save my edited version."
      ] }),
      /* @__PURE__ */ jsxs4("div", { className: "actions", children: [
        /* @__PURE__ */ jsx11(Button, { variant: "outline", onClick: () => {
          setWorking({ document: clone(d.document), baseDocument: clone(d.document), baseRevision: d.revision });
          setRebaseAck(false);
        }, children: "Reload saved draft and discard my edits" }),
        editable && /* @__PURE__ */ jsx11(Button, { disabled: !rebaseAck || busy, onClick: () => {
          setWorking({ ...local, baseRevision: d.revision, baseDocument: clone(d.document) });
          setRebaseAck(false);
        }, children: "Keep my edits against current revision" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx11("nav", { className: "content-sections mt", "aria-label": "Content draft sections", children: Object.entries(sectionNames).map(([id, label]) => /* @__PURE__ */ jsx11(Button, { variant: section === id ? "default" : "outline", "aria-current": section === id ? "page" : void 0, onClick: () => setSection(id), children: label }, id)) }),
    /* @__PURE__ */ jsx11("div", { className: "panel spacious mt", children: section === "overview" ? /* @__PURE__ */ jsxs4(Fragment7, { children: [
      /* @__PURE__ */ jsx11("h3", { children: "Make the work goal clear" }),
      text(["title"], "Pathway title", document2.title, { maxLength: 160, rows: 2 }),
      text(["summary"], "Pathway summary", document2.summary, { maxLength: 2e3 }),
      text(["promise"], "Pathway promise", document2.promise, { maxLength: 1e3 }),
      /* @__PURE__ */ jsx11(NumberInput, { id: "content-minutes", label: "Pathway estimated minutes", value: document2.estimatedMinutes, onChange: (v) => update(["estimatedMinutes"], v), disabled: !editable, min: 5, max: 720 }),
      list(["prerequisites"], "Prerequisite", document2.prerequisites),
      list(["outcomes"], "Outcome", document2.outcomes),
      /* @__PURE__ */ jsxs4("div", { className: "notice mt", children: [
        /* @__PURE__ */ jsx11(LockKeyhole, {}),
        /* @__PURE__ */ jsxs4("div", { children: [
          /* @__PURE__ */ jsx11("strong", { children: "Fixed pilot classification and claims" }),
          /* @__PURE__ */ jsxs4("p", { children: [
            document2.ecosystem,
            " \xB7 ",
            document2.role,
            " \xB7 ",
            document2.level
          ] }),
          /* @__PURE__ */ jsx11("p", { children: document2.credentialClaim }),
          /* @__PURE__ */ jsx11("ul", { children: document2.credentialExclusions.map((v, i) => /* @__PURE__ */ jsx11("li", { children: v }, i)) }),
          /* @__PURE__ */ jsx11("p", { children: document2.sourceNotice })
        ] })
      ] })
    ] }) : section.startsWith("lesson-") ? (() => {
      const i = Number(section.split("-")[1]), l = document2.lessons[i], base = ["lessons", i];
      return /* @__PURE__ */ jsxs4(Fragment7, { children: [
        /* @__PURE__ */ jsxs4("h3", { children: [
          "Lesson ",
          i + 1,
          ": useful explanation and checked practice"
        ] }),
        text([...base, "title"], "Lesson title", l.title, { maxLength: 160, rows: 2 }),
        text([...base, "objective"], "Lesson objective", l.objective, { maxLength: 1e3 }),
        /* @__PURE__ */ jsx11(NumberInput, { id: "content-lesson-minutes", label: "Lesson estimated minutes", value: l.estimatedMinutes, onChange: (v) => update([...base, "estimatedMinutes"], v), disabled: !editable, min: 5, max: 720 }),
        text([...base, "lessonText"], "Lesson explanation", l.lessonText, { rows: 10, maxLength: 12e3 }),
        list([...base, "steps"], "Practice step", l.steps),
        /* @__PURE__ */ jsx11("h4", { className: "mt", children: "Fictional source facts and practice" }),
        text([...base, "exercise", "title"], "Exercise title", l.exercise.title, { maxLength: 160, rows: 2 }),
        /* @__PURE__ */ jsx11(SourceEditor, { rows: l.exercise.sourcePacket, editable, update: (rows) => update([...base, "exercise", "sourcePacket"], rows) }),
        text([...base, "exercise", "suppliedAiDraft"], "Supplied AI draft", l.exercise.suppliedAiDraft, { maxLength: 4e3 }),
        text([...base, "exercise", "optionalAiPrompt"], "Optional tool prompt", l.exercise.optionalAiPrompt, { maxLength: 4e3 }),
        text([...base, "exercise", "learnerTask"], "Learner practice task", l.exercise.learnerTask, { maxLength: 4e3 }),
        list([...base, "exercise", "expectedEvidence"], "Expected evidence", l.exercise.expectedEvidence),
        text([...base, "exercise", "assessorReference"], "Assessor reference", l.exercise.assessorReference, { maxLength: 4e3 }),
        /* @__PURE__ */ jsx11("h4", { className: "mt", children: "Three knowledge checks" }),
        l.quiz.map((q, j) => /* @__PURE__ */ jsxs4("fieldset", { className: "content-question mt", children: [
          /* @__PURE__ */ jsxs4("legend", { children: [
            "Question ",
            j + 1
          ] }),
          text([...base, "quiz", j, "question"], `Question ${j + 1} text`, q.question, { maxLength: 1e3 }),
          q.options.map((o, k) => text([...base, "quiz", j, "options", k], `Question ${j + 1} option ${k + 1}`, o, { maxLength: 500, rows: 2 })),
          /* @__PURE__ */ jsxs4("div", { className: "field", children: [
            /* @__PURE__ */ jsxs4("label", { htmlFor: "content-correct-" + j, children: [
              "Question ",
              j + 1,
              " correct option"
            ] }),
            /* @__PURE__ */ jsx11("select", { id: "content-correct-" + j, disabled: !editable, value: q.correctOptionIndex, onChange: (e) => update([...base, "quiz", j, "correctOptionIndex"], Number(e.target.value)), children: q.options.map((o, k) => /* @__PURE__ */ jsxs4("option", { value: k, children: [
              "Option ",
              k + 1,
              ": ",
              o
            ] }, k)) })
          ] }),
          text([...base, "quiz", j, "explanation"], `Question ${j + 1} explanation`, q.explanation, { maxLength: 2e3 })
        ] }, q.id)),
        text([...base, "reflectionPrompt"], "Reflection prompt", l.reflectionPrompt, { maxLength: 1e3 }),
        text([...base, "returnToWorkAction"], "Return-to-work action", l.returnToWorkAction, { maxLength: 2e3 })
      ] });
    })() : section === "practical" ? /* @__PURE__ */ jsxs4(Fragment7, { children: [
      /* @__PURE__ */ jsx11("h3", { children: "Evidence that shows careful judgment" }),
      text(["practicalAssessment", "title"], "Practical task title", document2.practicalAssessment.title, { maxLength: 160, rows: 2 }),
      text(["practicalAssessment", "scenario"], "Practical scenario", document2.practicalAssessment.scenario, { maxLength: 5e3 }),
      /* @__PURE__ */ jsx11("h4", { className: "mt", children: "Seven evidence fields" }),
      document2.practicalAssessment.submissionPrompts.map((p, i) => /* @__PURE__ */ jsxs4("fieldset", { className: "content-question mt", children: [
        /* @__PURE__ */ jsxs4("legend", { children: [
          "Evidence field ",
          i + 1
        ] }),
        text(["practicalAssessment", "submissionPrompts", i, "label"], `Evidence field ${i + 1} label`, p.label, { maxLength: 160, rows: 2 }),
        text(["practicalAssessment", "submissionPrompts", i, "help"], `Evidence field ${i + 1} guidance`, p.help, { maxLength: 1e3 })
      ] }, p.id)),
      /* @__PURE__ */ jsx11("h4", { className: "mt", children: "Four criterion rubrics" }),
      /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "Weights must total 100. A score of 70/100 and every critical gate are required." }),
      document2.practicalAssessment.rubric.map((r2, i) => /* @__PURE__ */ jsxs4("fieldset", { className: "content-question mt", children: [
        /* @__PURE__ */ jsxs4("legend", { children: [
          "Criterion ",
          i + 1
        ] }),
        text(["practicalAssessment", "rubric", i, "dimension"], `Criterion ${i + 1} name`, r2.dimension, { maxLength: 160, rows: 2 }),
        /* @__PURE__ */ jsx11(NumberInput, { id: "content-weight-" + i, label: `Criterion ${i + 1} weight`, value: r2.weight, onChange: (v) => update(["practicalAssessment", "rubric", i, "weight"], v), disabled: !editable, min: 1, max: 97 }),
        [0, 1, 2, 3, 4].map((n) => text(["practicalAssessment", "rubric", i, "anchors", String(n)], `Criterion ${i + 1} score ${n} anchor`, r2.anchors[String(n)], { maxLength: 1e3 })),
        r2.criticalGate !== null ? text(["practicalAssessment", "rubric", i, "criticalGate"], `Criterion ${i + 1} critical gate`, r2.criticalGate, { maxLength: 2e3 }) : /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "This criterion has no critical gate. The pilot preserves the three existing gate positions." })
      ] }, r2.id)),
      text(["practicalAssessment", "samplePassingEvidence"], "Passing evidence example", document2.practicalAssessment.samplePassingEvidence, { maxLength: 5e3 }),
      text(["practicalAssessment", "sampleCriticalFailure"], "Critical-failure example", document2.practicalAssessment.sampleCriticalFailure, { maxLength: 5e3 }),
      text(["practicalAssessment", "assessorNote"], "Assessor guidance", document2.practicalAssessment.assessorNote, { maxLength: 5e3 })
    ] }) : section === "preview" ? /* @__PURE__ */ jsxs4(Fragment7, { children: [
      /* @__PURE__ */ jsx11("h3", { children: "Content preview" }),
      /* @__PURE__ */ jsx11("p", { className: "form-hint", children: dirty ? "This preview includes your unsaved edits. Save them before requesting human review." : "This preview shows the saved document." }),
      /* @__PURE__ */ jsx11(Validation, { issues }),
      /* @__PURE__ */ jsx11(DocumentPreview, { document: document2 })
    ] }) : /* @__PURE__ */ jsxs4(Fragment7, { children: [
      /* @__PURE__ */ jsx11("h3", { children: "Independent review and publication" }),
      /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
        "Author: ",
        d.authorName,
        ". ",
        d.reviewerId ? "Assigned reviewer: " + (team.members.find((m) => m.userId === d.reviewerId)?.name ?? "Owner account") : "No reviewer assigned yet."
      ] }),
      /* @__PURE__ */ jsx11(Validation, { issues }),
      dirty && /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "Save your document before requesting review. Review and publication always act on the saved revision." }),
      author && d.state === "draft" && /* @__PURE__ */ jsxs4(Fragment7, { children: [
        /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "Another active owner must review sources, answers, assessment, boundaries and clarity. One account cannot author and approve its own content." }),
        /* @__PURE__ */ jsx11(Button, { disabled: busy || dirty || conflict || issues.length > 0 || !reviewers.length, onClick: () => setRequest(true), children: "Request content review" }),
        !reviewers.length && /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "Ask a workspace owner to arrange another current owner account for independent review. Authoring does not send invitations or change site access." })
      ] }),
      author && ["in_review", "approved"].includes(d.state) && /* @__PURE__ */ jsx11(Button, { variant: "outline", disabled: busy, onClick: () => {
        setReason("");
        setRecall(true);
      }, children: "Recall for editing" }),
      canReview && /* @__PURE__ */ jsxs4(Fragment7, { children: [
        /* @__PURE__ */ jsxs4("details", { className: "source-packet mt", open: true, children: [
          /* @__PURE__ */ jsx11("summary", { children: "Read the saved document" }),
          /* @__PURE__ */ jsx11(DocumentPreview, { document: d.document })
        ] }),
        /* @__PURE__ */ jsxs4("fieldset", { className: "role-options mt", children: [
          /* @__PURE__ */ jsx11("legend", { children: "Independent content checks" }),
          checks.map((key) => /* @__PURE__ */ jsxs4("label", { className: "check-line", children: [
            /* @__PURE__ */ jsx11("input", { type: "checkbox", checked: !!reviewChecks[key], onChange: (e) => setReviewChecks((c) => ({ ...c, [key]: e.target.checked })) }),
            checkLabels[key]
          ] }, key))
        ] }),
        /* @__PURE__ */ jsx11(Text, { id: "content-review-note", label: "Content review note", value: reviewNote, onChange: setReviewNote, maxLength: 2e3, help: "At least 30 characters. Reference the checks, corrections and remaining boundaries." }),
        /* @__PURE__ */ jsxs4("div", { className: "actions", children: [
          /* @__PURE__ */ jsx11(Button, { variant: "outline", disabled: busy || reviewNote.trim().length < 30, onClick: async () => {
            if (await cmd({ type: "content-review", draftId: d.id, revision: d.revision, decision: "changes", note: reviewNote }, "Content changes requested")) {
              setReviewNote("");
              setReviewChecks({});
            }
          }, children: "Request content changes" }),
          /* @__PURE__ */ jsx11(Button, { disabled: busy || reviewNote.trim().length < 30 || !checks.every((k) => reviewChecks[k]), onClick: async () => {
            if (await cmd({ type: "content-review", draftId: d.id, revision: d.revision, decision: "approve", note: reviewNote, checks: reviewChecks }, "Private practice draft approved")) {
              setReviewNote("");
              setReviewChecks({});
            }
          }, children: "Approve private practice draft" })
        ] })
      ] }),
      d.state === "approved" && /* @__PURE__ */ jsxs4(Fragment7, { children: [
        /* @__PURE__ */ jsxs4("p", { className: "form-hint", children: [
          "Approval preserved by ",
          d.approval?.reviewerName,
          " on ",
          date(d.approval?.reviewedAt),
          ". Publishing checks the exact approved document hash and reviewer\u2019s current permission."
        ] }),
        /* @__PURE__ */ jsx11(Button, { disabled: busy || dirty || conflict || issues.length > 0, onClick: () => setPublish(true), children: "Publish private practice version" })
      ] }),
      d.state === "published" && /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "This source draft is preserved. Create a new revision from its publication to make changes." }),
      d.state === "archived" && /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "This archived document and its history are read only. It cannot be submitted, approved or published." }),
      !["published", "archived"].includes(d.state) && /* @__PURE__ */ jsx11(Button, { className: "mt", variant: "outline", disabled: busy, onClick: () => {
        setReason("");
        setArchive(true);
      }, children: "Archive this content draft" }),
      /* @__PURE__ */ jsxs4("details", { className: "source-packet mt", children: [
        /* @__PURE__ */ jsx11("summary", { children: "Preserved draft history" }),
        d.history.map((h) => /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
          /* @__PURE__ */ jsx11("strong", { children: h.action }),
          " \xB7 ",
          h.actorName,
          " \xB7 ",
          date(h.at),
          h.note && /* @__PURE__ */ jsxs4(Fragment7, { children: [
            /* @__PURE__ */ jsx11("br", {}),
            h.note
          ] })
        ] }, h.id))
      ] })
    ] }) }),
    /* @__PURE__ */ jsx11(Dialog2, { open: request, onOpenChange: setRequest, children: /* @__PURE__ */ jsxs4(DialogContent3, { children: [
      /* @__PURE__ */ jsx11(FormError, {}),
      /* @__PURE__ */ jsxs4(DialogHeader, { children: [
        /* @__PURE__ */ jsx11(DialogTitle3, { children: "Request independent content review" }),
        /* @__PURE__ */ jsx11(DialogDescription3, { children: "The saved draft becomes read only until you recall it or the reviewer requests changes." })
      ] }),
      /* @__PURE__ */ jsxs4("div", { className: "field", children: [
        /* @__PURE__ */ jsx11("label", { htmlFor: "content-reviewer", children: "Independent owner reviewer" }),
        /* @__PURE__ */ jsxs4("select", { id: "content-reviewer", value: reviewerId, onChange: (e) => setReviewerId(e.target.value), children: [
          /* @__PURE__ */ jsx11("option", { value: "", children: "Choose another owner" }),
          reviewers.map((m) => /* @__PURE__ */ jsx11("option", { value: m.userId, children: m.name }, m.userId))
        ] })
      ] }),
      /* @__PURE__ */ jsxs4("div", { className: "field", children: [
        /* @__PURE__ */ jsx11("label", { htmlFor: "content-due-date", children: "Next content review date" }),
        /* @__PURE__ */ jsx11("input", { id: "content-due-date", type: "date", value: dueDate, onChange: (e) => setDueDate(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxs4("div", { className: "actions", children: [
        /* @__PURE__ */ jsx11(Button, { variant: "outline", onClick: () => setRequest(false), children: "Cancel review request" }),
        /* @__PURE__ */ jsx11(Button, { disabled: busy || !reviewerId || !dueDate || dirty || conflict, onClick: async () => {
          if (await cmd({ type: "content-submit", draftId: d.id, revision: d.revision, reviewerId, reviewDueAt: dueDate + "T00:00:00.000Z" }, "Independent content review requested")) setRequest(false);
        }, children: "Send for content review" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx11(Dialog2, { open: recall, onOpenChange: setRecall, children: /* @__PURE__ */ jsxs4(DialogContent3, { children: [
      /* @__PURE__ */ jsx11(FormError, {}),
      /* @__PURE__ */ jsxs4(DialogHeader, { children: [
        /* @__PURE__ */ jsx11(DialogTitle3, { children: "Recall this draft for editing?" }),
        /* @__PURE__ */ jsx11(DialogDescription3, { children: "Approval is cleared. The edited document needs another independent review before publication." })
      ] }),
      /* @__PURE__ */ jsx11(Text, { id: "content-recall-reason", label: "Reason to recall content", value: reason, onChange: setReason, maxLength: 1e3 }),
      /* @__PURE__ */ jsx11(Button, { disabled: busy || reason.trim().length < 10, onClick: async () => {
        if (await cmd({ type: "content-recall", draftId: d.id, revision: d.revision, reason }, "Draft recalled \xB7 approval cleared")) setRecall(false);
      }, children: "Confirm content recall" })
    ] }) }),
    /* @__PURE__ */ jsx11(Dialog2, { open: publish, onOpenChange: setPublish, children: /* @__PURE__ */ jsxs4(DialogContent3, { children: [
      /* @__PURE__ */ jsx11(FormError, {}),
      /* @__PURE__ */ jsxs4(DialogHeader, { children: [
        /* @__PURE__ */ jsx11(DialogTitle3, { children: "Publish this exact private practice version?" }),
        /* @__PURE__ */ jsx11(DialogDescription3, { children: "Publication creates an immutable workspace version. New cohorts can select it; existing cohorts and learners keep their previous references." })
      ] }),
      /* @__PURE__ */ jsx11(Tag, { children: AUTHORING_CLASSIFICATION }),
      /* @__PURE__ */ jsx11("p", { className: "mt", children: d.document.title }),
      /* @__PURE__ */ jsxs4("p", { className: "form-hint", children: [
        "Reviewed by ",
        d.approval?.reviewerName,
        ". Publication remains private to this workspace and does not join the global Academy catalog."
      ] }),
      /* @__PURE__ */ jsxs4("div", { className: "actions", children: [
        /* @__PURE__ */ jsx11(Button, { variant: "outline", onClick: () => setPublish(false), children: "Keep approved draft" }),
        /* @__PURE__ */ jsx11(Button, { disabled: busy || dirty || conflict, onClick: async () => {
          if (await cmd({ type: "content-publish", draftId: d.id, revision: d.revision }, "Immutable private practice version published")) {
            setPublish(false);
            onBack();
          }
        }, children: "Confirm private publication" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx11(Dialog2, { open: archive, onOpenChange: setArchive, children: /* @__PURE__ */ jsxs4(DialogContent3, { children: [
      /* @__PURE__ */ jsx11(FormError, {}),
      /* @__PURE__ */ jsxs4(DialogHeader, { children: [
        /* @__PURE__ */ jsx11(DialogTitle3, { children: "Archive this unpublished draft?" }),
        /* @__PURE__ */ jsx11(DialogDescription3, { children: "Archiving ends editing, review and publication for this draft, frees its active slot and preserves the document and full change history. It does not publish or delete content. Any current owner may archive an abandoned draft." })
      ] }),
      dirty && /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "Your unsaved editor changes have not been stored in this document. Save them first if they should be part of the preserved draft." }),
      /* @__PURE__ */ jsx11(Text, { id: "content-archive-reason", label: "Reason to archive content", value: reason, onChange: setReason, maxLength: 1e3 }),
      /* @__PURE__ */ jsxs4("div", { className: "actions", children: [
        /* @__PURE__ */ jsx11(Button, { variant: "outline", onClick: () => setArchive(false), children: "Keep content draft" }),
        /* @__PURE__ */ jsx11(Button, { disabled: busy || reason.trim().length < 10, onClick: async () => {
          if (await cmd({ type: "content-archive", draftId: d.id, revision: d.revision, reason }, "Unpublished draft archived \xB7 history retained")) {
            setArchive(false);
            onBack();
          }
        }, children: "Confirm content archive" })
      ] })
    ] }) })
  ] });
}
function Text({ id, label, value, onChange, help, rows = 4, ...props }) {
  return /* @__PURE__ */ jsxs4("div", { className: "field", children: [
    /* @__PURE__ */ jsx11("label", { htmlFor: id, children: label }),
    help && /* @__PURE__ */ jsx11("p", { id: id + "-help", children: help }),
    /* @__PURE__ */ jsx11("textarea", { id, value: value ?? "", rows, "aria-describedby": help ? id + "-help" : void 0, onChange: (e) => onChange(e.target.value), ...props })
  ] });
}
function NumberInput({ id, label, value, onChange, ...props }) {
  return /* @__PURE__ */ jsxs4("div", { className: "field", children: [
    /* @__PURE__ */ jsx11("label", { htmlFor: id, children: label }),
    /* @__PURE__ */ jsx11("input", { id, type: "number", step: "1", value: Number.isFinite(value) ? value : "", onChange: (e) => onChange(e.target.value === "" ? 0 : Number(e.target.value)), ...props })
  ] });
}
function StringList({ path, label, values, editable, update }) {
  return /* @__PURE__ */ jsxs4("fieldset", { className: "mt", children: [
    /* @__PURE__ */ jsxs4("legend", { children: [
      label,
      "s"
    ] }),
    values.map((v, i) => /* @__PURE__ */ jsxs4("div", { children: [
      /* @__PURE__ */ jsx11(Text, { id: "content-" + path.join("-") + "-" + i, label: `${label} ${i + 1}`, value: v, onChange: (v2) => update([...path, i], v2), disabled: !editable, maxLength: 700, rows: 2 }),
      " ",
      editable && values.length > 1 && /* @__PURE__ */ jsxs4(Button, { type: "button", size: "sm", variant: "outline", onClick: () => update(path, values.filter((_, j) => j !== i)), children: [
        "Remove ",
        label.toLowerCase(),
        " ",
        i + 1
      ] })
    ] }, i)),
    editable && /* @__PURE__ */ jsxs4(Button, { className: "mt", type: "button", variant: "outline", disabled: values.length >= 20, onClick: () => update(path, [...values, ""]), children: [
      "Add ",
      label.toLowerCase()
    ] })
  ] });
}
function SourceEditor({ rows, editable, update }) {
  return /* @__PURE__ */ jsxs4("fieldset", { className: "mt", children: [
    /* @__PURE__ */ jsx11("legend", { children: "Fictional source packet" }),
    /* @__PURE__ */ jsx11("p", { className: "form-hint", children: "Use synthetic facts only. Keep stable references so knowledge checks and evidence can cite them." }),
    rows.map((row, i) => /* @__PURE__ */ jsxs4("fieldset", { className: "content-question mt", children: [
      /* @__PURE__ */ jsxs4("legend", { children: [
        "Source ",
        i + 1
      ] }),
      Object.entries(row).map(([key, value]) => typeof value === "boolean" ? /* @__PURE__ */ jsxs4("div", { className: "field", children: [
        /* @__PURE__ */ jsxs4("label", { htmlFor: `source-${i}-${key}`, children: [
          "Source ",
          i + 1,
          " ",
          key
        ] }),
        /* @__PURE__ */ jsxs4("select", { id: `source-${i}-${key}`, disabled: !editable, value: value ? "true" : "false", onChange: (e) => update(rows.map((r2, j) => j === i ? { ...r2, [key]: e.target.value === "true" } : r2)), children: [
          /* @__PURE__ */ jsx11("option", { value: "true", children: "True" }),
          /* @__PURE__ */ jsx11("option", { value: "false", children: "False" })
        ] })
      ] }, key) : typeof value === "number" ? /* @__PURE__ */ jsx11(NumberInput, { id: `source-${i}-${key}`, label: `Source ${i + 1} ${key}`, value, disabled: !editable, onChange: (v) => update(rows.map((r2, j) => j === i ? { ...r2, [key]: v } : r2)) }, key) : value === null ? /* @__PURE__ */ jsxs4("p", { className: "form-hint", children: [
        "Source ",
        i + 1,
        " ",
        key,
        ": no value"
      ] }, key) : /* @__PURE__ */ jsx11(Text, { id: `source-${i}-${key}`, label: `Source ${i + 1} ${key}`, value, maxLength: key === "sourceId" ? 80 : 2e3, disabled: !editable, onChange: (v) => update(rows.map((r2, j) => j === i ? { ...r2, [key]: v } : r2)) }, key)),
      editable && rows.length > 1 && /* @__PURE__ */ jsxs4(Button, { variant: "outline", size: "sm", onClick: () => update(rows.filter((_, j) => j !== i)), children: [
        "Remove source ",
        i + 1
      ] })
    ] }, i)),
    editable && /* @__PURE__ */ jsx11(Button, { className: "mt", variant: "outline", disabled: rows.length >= 20, onClick: () => update([...rows, { sourceId: "SOURCE-" + (rows.length + 1), content: "" }]), children: "Add fictional source" })
  ] });
}
function Validation({ issues }) {
  return /* @__PURE__ */ jsxs4("div", { className: "notice mt" + (issues.length ? " error-notice" : ""), role: "status", children: [
    /* @__PURE__ */ jsx11(FileCheckCorner, {}),
    /* @__PURE__ */ jsxs4("div", { children: [
      /* @__PURE__ */ jsx11("strong", { children: issues.length ? `${issues.length} content issue${issues.length === 1 ? "" : "s"} to resolve` : "Ready for independent content review" }),
      issues.length ? /* @__PURE__ */ jsx11("ul", { children: issues.map((i, n) => /* @__PURE__ */ jsxs4("li", { children: [
        /* @__PURE__ */ jsxs4("strong", { children: [
          friendlyPath(i.path),
          ":"
        ] }),
        " ",
        i.message
      ] }, n)) }) : /* @__PURE__ */ jsx11("p", { children: "Structural checks passed. A human reviewer must still check facts, answer keys, rubric quality, safety and clarity." })
    ] })
  ] });
}
function friendlyPath(path) {
  return path.replace(/^program\.?/, "").replace(/lessons\.(\d+)/g, (_, n) => "Lesson " + (Number(n) + 1)).replace(/quiz\.(\d+)/g, (_, n) => "question " + (Number(n) + 1)).replace(/rubric\.(\d+)/g, (_, n) => "criterion " + (Number(n) + 1)).replace(/submissionPrompts\.(\d+)/g, (_, n) => "evidence field " + (Number(n) + 1)).replace(/([A-Z])/g, " $1").replaceAll(".", " \u203A ").replaceAll("source Packet", "source facts");
}
function DocumentPreview({ document: p }) {
  if (!p) return /* @__PURE__ */ jsx11("p", { children: "The exact published body is unavailable. Refresh the workspace before reviewing it." });
  return /* @__PURE__ */ jsxs4("article", { className: "content-readonly", children: [
    /* @__PURE__ */ jsx11("h3", { children: p.title || "Untitled private practice" }),
    /* @__PURE__ */ jsx11("p", { className: "pre-wrap mt", children: p.summary }),
    /* @__PURE__ */ jsx11("p", { className: "mt", children: p.promise }),
    /* @__PURE__ */ jsx11("ul", { children: p.outcomes.map((s, i) => /* @__PURE__ */ jsx11("li", { children: s }, i)) }),
    /* @__PURE__ */ jsx11("p", { className: "form-hint", children: p.sourceNotice }),
    p.lessons.map((l, i) => /* @__PURE__ */ jsxs4("details", { className: "source-packet mt", children: [
      /* @__PURE__ */ jsxs4("summary", { children: [
        "Lesson ",
        i + 1,
        ": ",
        l.title
      ] }),
      /* @__PURE__ */ jsx11("p", { className: "mt", children: l.objective }),
      /* @__PURE__ */ jsx11("p", { className: "pre-wrap mt", children: l.lessonText }),
      /* @__PURE__ */ jsx11("ol", { children: l.steps.map((s, j) => /* @__PURE__ */ jsx11("li", { children: s }, j)) }),
      /* @__PURE__ */ jsx11("h4", { children: l.exercise.title }),
      l.exercise.sourcePacket.map((r2, j) => /* @__PURE__ */ jsx11("dl", { className: "content-source-preview", children: Object.entries(r2).map(([k, v]) => /* @__PURE__ */ jsxs4("div", { children: [
        /* @__PURE__ */ jsx11("dt", { children: k }),
        /* @__PURE__ */ jsx11("dd", { children: v === null ? "No value" : String(v) })
      ] }, k)) }, j)),
      /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
        /* @__PURE__ */ jsx11("strong", { children: "Supplied AI draft:" }),
        " ",
        l.exercise.suppliedAiDraft
      ] }),
      /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
        /* @__PURE__ */ jsx11("strong", { children: "Optional tool prompt:" }),
        " ",
        l.exercise.optionalAiPrompt
      ] }),
      /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
        /* @__PURE__ */ jsx11("strong", { children: "Learner task:" }),
        " ",
        l.exercise.learnerTask
      ] }),
      /* @__PURE__ */ jsx11("ul", { children: l.exercise.expectedEvidence.map((s, j) => /* @__PURE__ */ jsx11("li", { children: s }, j)) }),
      /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
        /* @__PURE__ */ jsx11("strong", { children: "Assessor reference:" }),
        " ",
        l.exercise.assessorReference
      ] }),
      l.quiz.map((q, j) => /* @__PURE__ */ jsxs4("div", { className: "mt", children: [
        /* @__PURE__ */ jsxs4("strong", { children: [
          "Question ",
          j + 1,
          ": ",
          q.question
        ] }),
        /* @__PURE__ */ jsx11("ol", { children: q.options.map((o, k) => /* @__PURE__ */ jsxs4("li", { children: [
          o,
          k === q.correctOptionIndex ? " \xB7 correct option" : ""
        ] }, k)) }),
        /* @__PURE__ */ jsx11("p", { children: q.explanation })
      ] }, q.id)),
      /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
        /* @__PURE__ */ jsx11("strong", { children: "Reflection:" }),
        " ",
        l.reflectionPrompt
      ] }),
      /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
        /* @__PURE__ */ jsx11("strong", { children: "Return to work:" }),
        " ",
        l.returnToWorkAction
      ] })
    ] }, l.id)),
    /* @__PURE__ */ jsxs4("details", { className: "source-packet mt", open: true, children: [
      /* @__PURE__ */ jsxs4("summary", { children: [
        "Practical task: ",
        p.practicalAssessment.title
      ] }),
      /* @__PURE__ */ jsx11("p", { className: "mt", children: p.practicalAssessment.scenario }),
      /* @__PURE__ */ jsx11("ol", { children: p.practicalAssessment.submissionPrompts.map((f) => /* @__PURE__ */ jsxs4("li", { children: [
        /* @__PURE__ */ jsxs4("strong", { children: [
          f.label,
          ":"
        ] }),
        " ",
        f.help
      ] }, f.id)) }),
      p.practicalAssessment.rubric.map((r2) => /* @__PURE__ */ jsxs4("div", { className: "mt", children: [
        /* @__PURE__ */ jsxs4("h4", { children: [
          r2.dimension,
          " \xB7 ",
          r2.weight,
          "%"
        ] }),
        /* @__PURE__ */ jsx11("ol", { start: 0, children: [0, 1, 2, 3, 4].map((n) => /* @__PURE__ */ jsx11("li", { children: r2.anchors[String(n)] }, n)) }),
        r2.criticalGate && /* @__PURE__ */ jsxs4("p", { children: [
          /* @__PURE__ */ jsx11("strong", { children: "Critical gate:" }),
          " ",
          r2.criticalGate
        ] })
      ] }, r2.id)),
      /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
        /* @__PURE__ */ jsx11("strong", { children: "Passing evidence:" }),
        " ",
        p.practicalAssessment.samplePassingEvidence
      ] }),
      /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
        /* @__PURE__ */ jsx11("strong", { children: "Critical failure:" }),
        " ",
        p.practicalAssessment.sampleCriticalFailure
      ] }),
      /* @__PURE__ */ jsxs4("p", { className: "mt", children: [
        /* @__PURE__ */ jsx11("strong", { children: "Assessor guidance:" }),
        " ",
        p.practicalAssessment.assessorNote
      ] })
    ] }),
    /* @__PURE__ */ jsxs4("div", { className: "notice mt", children: [
      /* @__PURE__ */ jsx11(ShieldCheck, {}),
      /* @__PURE__ */ jsxs4("div", { children: [
        /* @__PURE__ */ jsx11("strong", { children: AUTHORING_CLASSIFICATION }),
        /* @__PURE__ */ jsx11("p", { children: p.credentialClaim }),
        /* @__PURE__ */ jsx11("ul", { children: p.credentialExclusions.map((s, i) => /* @__PURE__ */ jsx11("li", { children: s }, i)) })
      ] })
    ] })
  ] });
}
export {
  ContentStudio
};
/*! Bundled license information:

lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs:
lucide-react/dist/esm/shared/src/utils/toKebabCase.mjs:
lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs:
lucide-react/dist/esm/shared/src/utils/toPascalCase.mjs:
lucide-react/dist/esm/defaultAttributes.mjs:
lucide-react/dist/esm/shared/src/utils/hasA11yProp.mjs:
lucide-react/dist/esm/context.mjs:
lucide-react/dist/esm/Icon.mjs:
lucide-react/dist/esm/createLucideIcon.mjs:
lucide-react/dist/esm/icons/book-open.mjs:
lucide-react/dist/esm/icons/copy.mjs:
lucide-react/dist/esm/icons/file-check-corner.mjs:
lucide-react/dist/esm/icons/lock-keyhole.mjs:
lucide-react/dist/esm/icons/shield-check.mjs:
lucide-react/dist/esm/icons/x.mjs:
lucide-react/dist/esm/lucide-react.mjs:
  (**
   * @license lucide-react v1.31.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)
*/
