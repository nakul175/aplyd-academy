// QA-only import bridge. Do not copy this file into app/.
export {Head,Tag,Empty,FormError,date} from '../../../../work/aplyd-academy/app/academy-ui';
