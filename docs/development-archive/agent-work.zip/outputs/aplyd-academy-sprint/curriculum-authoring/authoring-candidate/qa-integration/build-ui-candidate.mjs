import {createRequire} from 'node:module';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const dir=resolve(dirname(fileURLToPath(import.meta.url)),'..'),app=resolve(process.env.ACADEMY_APP_PATH??'work/aplyd-academy'),runtime=process.env.ACADEMY_NODE_PATH??'/Users/athena/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';
const require=createRequire(import.meta.url),esbuild=require(resolve(app,'node_modules/esbuild/lib/main.js'));
mkdirSync(resolve(dir,'.compiled'),{recursive:true});
const paths={'@/lib/academy-authoring':[resolve(dir,'workspace-authoring.ts')],'@/*':[resolve(app,'*')],'react':[resolve(app,'node_modules/@types/react/index.d.ts')],'react/*':[resolve(app,'node_modules/@types/react/*')],'react-dom':[resolve(app,'node_modules/@types/react-dom/index.d.ts')],'react-dom/*':[resolve(app,'node_modules/@types/react-dom/*')],'*':[resolve(app,'node_modules/*')]};
const config={compilerOptions:{target:'ES2022',lib:['dom','dom.iterable','esnext'],strict:true,noEmit:true,esModuleInterop:true,module:'ESNext',moduleResolution:'bundler',resolveJsonModule:true,isolatedModules:true,jsx:'react-jsx',skipLibCheck:true,baseUrl:app,paths,typeRoots:[resolve(app,'node_modules/@types')]},include:[resolve(dir,'academy-authoring-ui.tsx'),resolve(dir,'academy-context.ts'),resolve(dir,'academy-ui.ts')]};
writeFileSync(resolve(dir,'.compiled/tsconfig.ui.json'),JSON.stringify(config,null,2));
const tsc=spawnSync(runtime,[resolve(app,'node_modules/typescript/bin/tsc'),'--project',resolve(dir,'.compiled/tsconfig.ui.json')],{encoding:'utf8'});
writeFileSync(resolve(dir,'.compiled/ui-typescript.txt'),tsc.stdout+tsc.stderr);if(tsc.status!==0){console.error(tsc.stdout+tsc.stderr);process.exitCode=1;}
await esbuild.build({entryPoints:[resolve(dir,'workspace-authoring.ts')],outfile:resolve(dir,'.compiled/authoring.mjs'),bundle:true,platform:'node',format:'esm',target:'es2022'});
await esbuild.build({entryPoints:[resolve(dir,'academy-authoring-ui.tsx')],outfile:resolve(dir,'.compiled/authoring-ui.mjs'),bundle:true,platform:'browser',format:'esm',target:'es2022',nodePaths:[resolve(app,'node_modules')],tsconfig:resolve(dir,'.compiled/tsconfig.ui.json'),external:['react','react-dom','react/jsx-runtime']});
console.log(JSON.stringify({candidateOnly:true,typescriptPassed:tsc.status===0,bundled:true,component:resolve(dir,'academy-authoring-ui.tsx'),artifacts:resolve(dir,'.compiled'),note:'Uses QA-only import bridges to actual context and shared UI; does not edit or deploy the application.'}));
