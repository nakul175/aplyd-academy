import {
 curriculumRegistry,pinnedRef,ContentResolutionError,
 type CurriculumRegistry,type ContentSnapshot,type ContentScope,
} from '../../resolver-candidate/academy-curriculum';

/**
 * Internal read capability only: caller assembles this registry from global
 * immutable archives plus ONE authenticated workspace's canonical publications.
 * No client argument or shared singleton may supply or accumulate this value.
 */
export type TrustedContentContext={registry:CurriculumRegistry;allowedScopes:readonly ContentScope[]};
export function resolvePinnedWithRegistry(record:unknown,context?:TrustedContentContext):ContentSnapshot{
 const ref=pinnedRef(record);
 // Allowed scopes come only from authenticated server workspace policy.
 return (context?.registry??curriculumRegistry).resolve(ref,context?.allowedScopes??['global']);
}

/** Whole records preserve mixed legacy/explicit-reference validation. */
export function trustedPlanResolver(context?:TrustedContentContext){
 return (programId:string,version:string,record?:unknown)=>{
  try{return resolvePinnedWithRegistry(record??{programId,version},context).program;}
  catch(error){if(error instanceof ContentResolutionError)return undefined;throw error;}
 };
}
