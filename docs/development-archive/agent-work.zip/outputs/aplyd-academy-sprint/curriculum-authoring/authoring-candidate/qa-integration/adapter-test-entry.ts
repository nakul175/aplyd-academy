export {workspaceRegistry,AUTHORING_CLASSIFICATION} from '../workspace-authoring';
export {resolvePinnedWithRegistry,trustedPlanResolver} from './trusted-registry-adapter';
