// QA-only import bridge. Do not copy this file into app/.
export {useAcademy,useWorkspaceDraft} from '../../../../work/aplyd-academy/app/academy-context';
