// outputs/aplyd-academy-sprint/curriculum-authoring/resolver-candidate/curriculum-versions/0.1-review-draft.json
var review_draft_default = {
  schemaVersion: "1.0",
  contentVersion: "0.1-review-draft",
  product: "Aplyd Academy",
  status: "Review draft: not approved sector training, accredited curriculum, or professional advice",
  language: "en",
  audience: "Adult learners",
  designNotes: [
    "All people, orders, records, documents, policies and AI outputs in this file are fictional teaching fixtures.",
    "Supplied AI drafts allow the whole journey to work without an external AI account or API call.",
    "An approved external AI tool may optionally produce another draft using the synthetic packet only. Learners must not enter real confidential material or credentials.",
    "Quiz feedback supports learning. A quiz score alone must not issue a competency credential.",
    "Practical assessment requires an assigned human reviewer. Rubric weights and critical gates are proposed, published training standards for this draft.",
    "A facilitator may read lesson text and capture an oral response with learner confirmation when an approved accommodation exists. Assistance must be recorded and must not supply the judgment answer."
  ],
  assessmentPolicy: {
    scoreScale: [0, 1, 2, 3, 4],
    weightedScoreFormula: "Sum of criterion weight multiplied by criterion score divided by 4; maximum 100",
    minimumWeightedScore: 70,
    passingRule: "Weighted score is at least 70 AND every declared critical gate is met. A critical failure cannot be averaged away.",
    decisionAuthority: "Assigned independent human assessor; no self-assessment or autonomous AI credential decision",
    feedbackRule: "Record score, evidence reference, critical-gate decision and actionable feedback for each criterion.",
    retryRule: "Retries and deadlines must be published by the offering before enrollment. Do not infer a fixed retry allowance from this seed file.",
    appealRule: "A learner may request a reasoned review under the offering's published appeal policy. The appeal reviewer must be independent of the original decision."
  },
  pathways: [
    {
      id: "farmer-work-records",
      title: "Farm records and better questions with AI",
      ecosystem: "Agri Saha",
      role: "Farmer",
      level: "Foundation to applied",
      summary: "Organize an activity record, check an AI-generated summary, and prepare useful questions for an agricultural expert.",
      promise: "You can turn a simple farm record into a verified summary and explain what still needs expert input.",
      estimatedMinutes: 110,
      prerequisites: ["Understand the example currency amounts with help if needed", "Use a simple form or receive planned facilitator assistance"],
      outcomes: ["Distinguish a duplicate transaction from a separate expense", "Check totals against source records", "Spot unsupported AI claims", "Create a clear expert question brief", "Keep private or commercially sensitive records out of unapproved tools"],
      credentialClaim: "Demonstrated farm-record organization, information checking and expert-question preparation using synthetic training data",
      credentialExclusions: ["No agricultural professional qualification", "No certification to prescribe farm inputs or make agronomic decisions"],
      sourceNotice: "Synthetic farm records supplied within each activity are the only factual source for this exercise.",
      lessons: [
        {
          id: "farm-01",
          title: "Make a useful work record",
          estimatedMinutes: 25,
          objective: "Build a consistent record and verify a duplicate before calculating a total.",
          lessonText: "A useful record separates what happened from what you think it means. Start with a date, activity, transaction reference, amount and unit where needed. A repeated line may be a duplicate, but two similar expenses can also be real. Check the reference or original receipt before removing anything. In this exercise, the source packet explicitly says that T02 was copied twice and represents one transport payment. Keep a note of that correction. Add the verified amounts rather than trusting a total supplied by a tool. AI can help organize a table or explain a calculation, but it cannot know which entry is genuine without evidence. When you use your own records later, keep the master copy in your approved location and choose a tool you are permitted to use. You do not need to upload names, telephone numbers, bank information or exact location details to practise this skill.",
          steps: ["Read the source packet", "Create one row per confirmed transaction", "Record why the extra T02 line was removed", "Calculate the verified total", "Identify one field you would add for future records"],
          exercise: {
            title: "Clean the fictional farm activity record",
            sourcePacket: [
              { sourceId: "T01", date: "2026-10-01", activity: "Recordkeeping support", quantity: 3, unit: "hours", rate: 150, amount: 450, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR" },
              { sourceId: "T03", date: "2026-10-03", activity: "Storage materials", quantity: 1, unit: "lot", rate: 800, amount: 800, currency: "INR" },
              { sourceId: "T02", date: "2026-10-02", activity: "Transport", quantity: 1, unit: "trip", rate: 150, amount: 150, currency: "INR", sourceNote: "Confirmed copied line; same receipt and payment as T02 above" }
            ],
            suppliedAiDraft: "The four entries total INR 1,550. Each row is a separate expense.",
            optionalAiPrompt: "Organize the supplied fictional transactions into a table. Use the source note to handle duplicates, show the calculation, and list uncertainty. Do not infer farm area, crop performance or missing transactions.",
            learnerTask: "Produce a corrected three-row table, show your total and explain the duplicate correction.",
            expectedEvidence: ["Corrected rows with source references", "450 + 150 + 800 = 1,400", "Note that T02 was removed once because the source confirms a copied payment", "One useful future record field such as receipt reference or unit"],
            assessorReference: "There are three confirmed transactions totaling INR 1,400. The raw four-line total is INR 1,550, but that counts the confirmed T02 copy twice. A learner must not generalize that every repeated amount is a duplicate."
          },
          quiz: [
            { id: "farm-01-q1", question: "What is the verified expense total?", options: ["INR 1,400", "INR 1,550", "INR 1,250", "It must be guessed from the activities"], correctOptionIndex: 0, explanation: "T02 is a confirmed copy of the same payment. The three verified amounts are 450, 150 and 800, which total 1,400." },
            { id: "farm-01-q2", question: "Two entries have the same amount but different receipt references. What should you do?", options: ["Delete the second amount automatically", "Keep both as confirmed without checking", "Check the source records before deciding whether either is duplicated", "Ask AI to choose the genuine one without evidence"], correctOptionIndex: 2, explanation: "Equal amounts are not proof of duplication. The original references and payment evidence decide whether the expenses are separate." },
            { id: "farm-01-q3", question: "Which practice input is suitable for this activity?", options: ["Your bank login details", "The supplied fictional record", "A neighbor's private transaction history", "Any record because AI makes it anonymous"], correctOptionIndex: 1, explanation: "The fictional record provides enough information for practice. Uploading private or secret information is unnecessary and inappropriate." }
          ],
          reflectionPrompt: "Which record field would make it easier for you to check a future total, and why?",
          returnToWorkAction: "Create a blank record template in an approved location. Use it for one permitted task and check entries against the original records before any sharing."
        },
        {
          id: "farm-02",
          title: "Check an AI summary before using it",
          estimatedMinutes: 20,
          objective: "Separate supported observations, missing context and unsupported recommendations.",
          lessonText: "A summary can sound confident while mixing correct statements with invented ones. Check important statements one at a time. Ask what evidence supports each claim. A total can be checked against transaction rows. A cost per acre needs area information. A claim about crop results needs relevant evidence, rather than a guess based on expenses. In this activity, the verified spending record tells you what was recorded; it does not tell you the farm area, complete budget, crop condition or likely yield. Mark these gaps explicitly. When a claim could affect a significant farm decision, prepare a question for an appropriate expert instead of treating an AI draft as a recommendation. A useful summary includes the known total, its limited scope, and the missing information. Verification is part of the work, even when it takes more time than generating the draft.",
          steps: ["Check the total", "Label each claim supported, unsupported or unknown", "Explain what evidence a per-acre figure would need", "Rewrite the summary with limits", "Identify the claim that needs expert input"],
          exercise: {
            title: "Find the unsupported claims",
            sourcePacket: ["Verified transactions: T01 INR 450; T02 INR 150; T03 INR 800.", "Recorded total: INR 1,400.", "Farm area, crop condition, total seasonal budget and crop outcomes are not supplied."],
            suppliedAiDraft: "The recorded expenses are INR 1,400. That is INR 700 per acre. These purchases will increase yield by 30%, so the farmer should immediately repeat them.",
            optionalAiPrompt: "Summarize only the supplied synthetic expense record. For every statement distinguish source-supported facts from missing context. Do not predict yield or recommend actions.",
            learnerTask: "Annotate the draft and create a two- or three-sentence corrected summary.",
            expectedEvidence: ["Total supported by the three transaction rows", "Per-acre claim rejected because area is missing", "Yield and immediate-action claims rejected as unsupported", "Corrected summary describes recorded expenses and missing context", "Expert referral for consequential recommendations"],
            assessorReference: "The packet supports only the INR 1,400 recorded total. It does not establish cost per acre, a 30% yield effect or a decision to repeat the purchases. Accept a cautious summary using equivalent plain language."
          },
          quiz: [
            { id: "farm-02-q1", question: "Which claim is supported by the packet?", options: ["Yield will rise by 30%", "The farm has two acres", "The recorded expenses total INR 1,400", "Repeating the purchases is the right decision"], correctOptionIndex: 2, explanation: "The transaction amounts support the total. Area, yield and action advice are not in the source packet." },
            { id: "farm-02-q2", question: "Why is INR 700 per acre unverified?", options: ["It is too small", "The packet does not give the farm area", "All AI calculations are wrong", "Per-acre costs can never be calculated"], correctOptionIndex: 1, explanation: "A cost per acre requires a relevant area and a defined cost scope. The area is absent, so the figure is unsupported here." },
            { id: "farm-02-q3", question: "What is the appropriate response to the draft's yield recommendation?", options: ["Act immediately because the wording is confident", "Forward it as approved guidance", "Ask AI to make the recommendation stronger", "Mark it unsupported and seek appropriate expert input before a consequential action"], correctOptionIndex: 3, explanation: "The provided record does not support a yield prediction or action. Recognizing the limit and escalating is the responsible response." }
          ],
          reflectionPrompt: "What is one confident-sounding statement you would still need to check?",
          returnToWorkAction: "For your next permitted AI-assisted summary, label important statements as verified, unverified or requiring expert input before using the draft."
        },
        {
          id: "farm-03",
          title: "Prepare a useful expert conversation",
          estimatedMinutes: 30,
          objective: "Turn a checked record into a concise question brief without claiming an unsupported decision.",
          lessonText: "AI is useful when it helps you organize questions, rather than deciding something it cannot support. A good expert brief states the purpose, summarizes verified information, identifies missing context, and asks specific questions. Keep facts separate from assumptions. Do not turn a missing detail into a made-up answer. In this example, you can explain that three recorded expenses total INR 1,400 and that a previous draft invented a yield claim. You can ask what additional records an expert needs and how to check any recommendation. The expert may need information beyond the training packet; share it only through an approved channel and only when relevant. Keep the brief short enough to use during a conversation. Afterward, record what was confirmed, what remains uncertain and who will take the next step. This pathway demonstrates recordkeeping and information judgment, not authority to prescribe farm practices.",
          steps: ["State the conversation's purpose", "Include the checked record total and sources", "List three relevant missing details", "Write three specific expert questions", "Choose an approved way to use the brief"],
          exercise: {
            title: "Build the expert question brief",
            sourcePacket: ["Use the verified three-row record from farm-01.", "The earlier AI draft's per-acre and yield claims were unsupported.", "No farm area, crop condition or complete seasonal expense record is provided."],
            suppliedAiDraft: "Expert brief: Our two-acre farm will gain 30% yield if we repeat the purchases. Please approve this plan.",
            optionalAiPrompt: "Create a short question brief from the supplied fictional packet. Separate verified facts, missing context and questions. Do not invent area, crop condition or outcomes, and do not request approval of an unsupported plan.",
            learnerTask: "Produce a 120\u2013200 word brief or equivalent oral response with verified facts, gaps, questions and next action.",
            expectedEvidence: ["Purpose: seek informed guidance about what information is needed", "Checked INR 1,400 recorded total with transaction references", "Missing area, crop context and record completeness", "Questions about needed information and verification, rather than a demanded action", "Next action stays within recordkeeping and approved expert consultation"],
            assessorReference: "A suitable brief says the record is limited, removes invented area/yield details, asks what further information is needed and how to verify advice, and uses an approved channel. Equivalent plain-language or approved oral evidence is acceptable."
          },
          quiz: [
            { id: "farm-03-q1", question: "Which question best fits the available information?", options: ["Can you confirm the promised 30% increase?", "What additional information do you need to interpret these recorded expenses?", "Which input should everyone buy?", "Can we omit the original records?"], correctOptionIndex: 1, explanation: "The question acknowledges the limited packet and asks an expert for the missing context needed for interpretation." },
            { id: "farm-03-q2", question: "What should the brief do with the invented two-acre detail?", options: ["Keep it because it is convenient", "Describe it as verified", "Remove it and state that area is not supplied", "Replace it with another guess"], correctOptionIndex: 2, explanation: "A missing field should remain a documented gap until appropriate evidence is available." },
            { id: "farm-03-q3", question: "What does this pathway's competency credential demonstrate?", options: ["Authority to prescribe crop inputs", "A professional agricultural qualification", "A guaranteed yield improvement", "Record organization, information checking and expert-question preparation"], correctOptionIndex: 3, explanation: "The credential must describe the assessed capability accurately. It does not create professional authority or guarantee an outcome." }
          ],
          reflectionPrompt: "How would this brief help an expert understand your question without pretending that every detail is known?",
          returnToWorkAction: "Use a blank fact\u2013gap\u2013question template for one permitted work conversation. Record the expert's confirmed guidance separately from your own assumptions."
        }
      ],
      practicalAssessment: {
        id: "farm-practical-01",
        title: "A verified farm record and expert brief",
        scenario: "A facilitator asks you to prepare the fictional T01/T02/T03 record for an expert conversation. The extra T02 row is a confirmed copy. The supplied AI output contains unsupported area and yield statements.",
        submissionPrompts: [
          { id: "task", label: "What are you trying to achieve and for whom?", help: "State the purpose of the record and expert conversation." },
          { id: "record", label: "Your corrected record and calculation", help: "Include source IDs, explain the duplicate treatment and show the INR total." },
          { id: "safe-input", label: "What information is safe to use?", help: "Identify the synthetic packet and information you would exclude from an unapproved tool." },
          { id: "ai-evidence", label: "The draft you reviewed and instructions you used", help: "You may review the supplied draft without opening an AI tool. Describe instructions for a safer draft." },
          { id: "checks", label: "Checks, errors and corrections", help: "Explain the total, area gap, invented yield statement and action recommendation." },
          { id: "final", label: "Final expert question brief", help: "Separate verified facts, missing information and questions." },
          { id: "return", label: "Your return-to-work action and boundary", help: "Describe a safe action such as improving records or using an approved expert channel." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable record or brief", "1": "Major record errors or an unclear brief", "2": "Mostly usable output with a material omission", "3": "Correct three-row record, INR 1,400 total and clear brief", "4": "Correct output with concise source mapping, useful questions and a reusable structure" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts the flawed output without checks", "1": "Checks only one minor detail", "2": "Checks total and duplicate but incompletely explains unsupported claims", "3": "Shows arithmetic and source-based rejection of invented area/yield claims", "4": "Checks all material claims and clearly distinguishes confirmed facts from unknowns" }, criticalGate: "Must not retain the invented yield or immediate-action claim as verified guidance" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual secrets or inappropriate private records", "1": "Cannot identify what should be excluded", "2": "Uses the synthetic packet but gives incomplete handling reasons", "3": "Uses only synthetic evidence and identifies private information to withhold", "4": "Adds an approved-channel plan with minimal necessary sharing" }, criticalGate: "No actual private records, third-party personal information or credentials submitted or proposed for unapproved use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Acts on unsupported consequential advice", "1": "Mentions caution without a usable next step", "2": "Identifies a limit but an unclear expert question", "3": "Asks relevant expert questions and limits the immediate action to permitted work", "4": "Explains escalation, missing context and how confirmed advice will be recorded" }, criticalGate: "Consequential farm decisions are not justified by this expense packet; the brief seeks appropriate expert input" }
        ],
        samplePassingEvidence: "I counted T02 once because the source identifies its duplicate. The total is 450 + 150 + 800 = INR 1,400. No farm area or yield evidence is supplied, so I removed INR 700 per acre and 30% yield improvement. I used fictional data only. My brief asks what context and further records an expert needs. My immediate work action is to maintain a checked record and seek guidance through an approved channel.",
        sampleCriticalFailure: "The learner produces a polished brief but recommends repeating the purchases to obtain a 30% yield improvement without verification. The verification and judgment gates fail regardless of aggregate score.",
        assessorNote: "Do not require advanced agricultural terminology, typing speed or use of a particular AI brand. Assess the record, checks, handling and explanation."
      },
      followUp: { afterDays: 14, question: "Did you use a checked record or expert question brief for a permitted task?", evidenceOptions: ["A structured reflection with no private record contents", "A blank improved template", "Facilitator-confirmed use under an approved process"], successSignal: "The learner can explain one check performed and one limit or question identified", privacyNote: "Do not collect real farm documents by default." }
    },
    {
      id: "msme-customer-operations",
      title: "Customer communication and daily operations with AI",
      ecosystem: "MSME",
      role: "MSME owner or team member",
      level: "Foundation to applied",
      summary: "Draft an accurate customer response, organize a daily work checklist, and measure whether AI assistance actually helped.",
      promise: "You can produce a useful customer draft and operations checklist while checking promises, information use and task quality.",
      estimatedMinutes: 110,
      prerequisites: ["Read a short order policy with help if needed", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Separate customer-relevant facts from internal details", "Avoid invented stock, dispatch and pricing commitments", "Create a source-based action checklist", "Compare time and quality including verification work", "Keep human approval for commitments outside the stated policy"],
      credentialClaim: "Demonstrated customer-draft preparation, operations checklist creation and responsible AI checking using synthetic business records",
      credentialExclusions: ["No financial, tax or legal professional qualification", "No assurance of business results or automated customer commitments"],
      sourceNotice: "The example order policy and records are fictional fixtures, not a recommended business policy.",
      lessons: [
        {
          id: "msme-01",
          title: "Write a customer response you can stand behind",
          estimatedMinutes: 25,
          objective: "Draft an accurate response using permitted facts and withhold irrelevant internal details.",
          lessonText: "A helpful customer response is clear about what is confirmed and what still needs checking. AI can make a message sound polished, but it may invent a discount, a delivery promise or available stock. Start by listing the facts the customer needs. Keep internal costs, private contact information and unrelated customer details out of an unapproved AI prompt. In this fictional policy, an item costs INR 120, delivery is INR 60 and pickup has no delivery fee. Only four units are confirmed in stock, while the customer requests six. That means a six-unit dispatch cannot be promised yet. You can explain the confirmed stock and say the team will check options; do not assume an arrival date. Check every promise in the draft against the supplied policy and records. Treat the final response as a draft for human approval whenever it changes a commitment or exceeds your role.",
          steps: ["Read the request, stock and policy", "Identify customer-relevant facts", "Remove irrelevant internal details from the prompt", "Correct the supplied AI draft", "Mark the check needed before sending"],
          exercise: {
            title: "Respond to a six-unit request",
            sourcePacket: [
              { sourceId: "P1", type: "fictional policy", content: "Unit price INR 120. Delivery fee INR 60 per order. Pickup delivery fee INR 0. Dispatch quantity and date require stock-team confirmation. Exceptions require supervisor approval." },
              { sourceId: "O101", type: "fictional request", content: "Customer C requests six blue units and asks whether all can be delivered on Friday." },
              { sourceId: "S1", type: "fictional stock record", content: "Four blue units are confirmed available. Arrival date for additional units is unknown." },
              { sourceId: "I1", type: "internal fixture", content: "Internal unit cost INR 75; private contact marker [PRIVATE CONTACT]; unrelated account notes. These are not needed for the customer draft." }
            ],
            suppliedAiDraft: "We confirm six units for Friday delivery at INR 120 each, with free delivery and a special 10% discount. Our internal unit cost is INR 75.",
            optionalAiPrompt: "Draft a short response using fictional P1, O101 and S1 only. State confirmed stock, do not promise unconfirmed quantity or date, do not invent discounts, and do not include internal details. Mark the team check required.",
            learnerTask: "Write a corrected customer response and a separate internal note identifying the required stock check.",
            expectedEvidence: ["Response does not confirm six-unit Friday delivery", "No invented free delivery or discount", "INR 120 unit price and applicable INR 60 delivery fee stated accurately if mentioned", "Internal unit cost and private marker excluded", "Stock team check required before commitment"],
            assessorReference: "A suitable response explains that four units are confirmed, the remaining quantity/date must be checked, and published price/delivery terms apply. It does not promise a split order unless approved. A requested six-unit order would total INR 780 including delivery, but calculating that is not confirmation that the order can be fulfilled."
          },
          quiz: [
            { id: "msme-01-q1", question: "What can the response currently confirm?", options: ["Six units will arrive Friday", "Four units are recorded as available, and the rest needs a team check", "Every order has free delivery", "A 10% discount is approved"], correctOptionIndex: 1, explanation: "The stock record confirms four units only. Quantity, date and any exception need the specified human check." },
            { id: "msme-01-q2", question: "If a six-unit order is later confirmed for delivery under P1, what is the stated total?", options: ["INR 720", "INR 780", "INR 702", "INR 840"], correctOptionIndex: 1, explanation: "Six units at INR 120 are INR 720, plus INR 60 delivery, totaling INR 780. This calculation does not confirm stock or delivery timing." },
            { id: "msme-01-q3", question: "Which source should be excluded from the customer-drafting prompt?", options: ["The published unit price", "The confirmed stock count", "The internal cost and private contact marker", "The customer's requested quantity without identity details"], correctOptionIndex: 2, explanation: "The internal details are unnecessary for the draft and should not be sent to an unapproved tool or disclosed to the customer." }
          ],
          reflectionPrompt: "Which invented promise in the original draft could create a problem for the team, and how did you correct it?",
          returnToWorkAction: "For one permitted customer draft, check quantity, price, fees and timing against approved records before an authorized person sends it."
        },
        {
          id: "msme-02",
          title: "Turn records into a daily action checklist",
          estimatedMinutes: 25,
          objective: "Create actions with owners and checks without inventing completion or commitments.",
          lessonText: "A useful checklist helps someone act: it states the task, owner, source and completion check. A vague list such as 'handle orders' is hard to follow. AI can group tasks, but it must not convert an unresolved issue into a completed action. Read the current status before choosing the next step. A ready order may need pickup confirmation; a stock issue needs a stock-team check; an address issue needs a permitted customer contact. Priorities should reflect an agreed rule, not a made-up deadline. This fictional packet gives no emergency ranking, so explain your proposed order as a suggestion for the supervisor. Keep personal customer details in the approved system. A checklist can use opaque order references. Before marking an action complete, record the actual check or confirmation. This preserves accountability and helps the next team member understand what remains open.",
          steps: ["Read each order status", "Identify its next allowed action", "Assign a role rather than inventing a person's availability", "Define evidence of completion", "Label suggested priorities as requiring review"],
          exercise: {
            title: "Build the day's three-order checklist",
            sourcePacket: [
              { sourceId: "O101", status: "Stock check pending", nextCheck: "Requested six units; four confirmed; additional arrival unknown", ownerRole: "Stock team" },
              { sourceId: "O102", status: "Packed", nextCheck: "Three units packed; payment confirmed in the fictional record; pickup time not yet agreed", ownerRole: "Customer service" },
              { sourceId: "O103", status: "On hold", nextCheck: "Delivery address confirmation missing; no private address is included in the teaching packet", ownerRole: "Customer service" },
              { sourceId: "P2", status: "Policy", nextCheck: "No new surcharge or completed dispatch without approved evidence. Supervisor reviews priority suggestions.", ownerRole: "Supervisor" }
            ],
            suppliedAiDraft: "Dispatch all six O101 units now. Add INR 50 urgency fees to every order. Mark O103 resolved. O102 needs no action because it is packed.",
            optionalAiPrompt: "Create a checklist from fictional O101\u2013O103 and P2. Include order reference, next action, owner role, dependency and evidence required to mark complete. Do not invent charges, stock, pickup timing or resolution.",
            learnerTask: "Create three checklist rows and explain why the supplied draft is unsafe to use unchanged.",
            expectedEvidence: ["O101: stock-team confirmation before dispatch commitment", "O102: agree pickup time through approved customer process", "O103: obtain address confirmation through approved channel; keep on hold until confirmed", "No invented fee", "Completion evidence and responsible owner role for each row"],
            assessorReference: "Accept equivalent actionable checklists. Do not require one priority ranking because the packet has no authoritative priority rule. The learner must preserve unresolved statuses until actual confirmation."
          },
          quiz: [
            { id: "msme-02-q1", question: "Which item can be marked complete solely from the supplied packet?", options: ["O101 full dispatch", "O103 address confirmation", "O102 packing", "All three orders"], correctOptionIndex: 2, explanation: "O102 is recorded as packed. Its pickup arrangement remains open. The other listed actions require further confirmation." },
            { id: "msme-02-q2", question: "What makes a checklist item actionable?", options: ["A confident sentence with no source", "Task, owner role, dependency and completion check", "A long paragraph repeating every private detail", "Automatic completion when AI writes it"], correctOptionIndex: 1, explanation: "These fields tell the team what to do, who handles it, what must happen first and how completion will be established." },
            { id: "msme-02-q3", question: "How should the INR 50 urgency fee be handled?", options: ["Apply it because AI suggested it", "Apply it only to the oldest order without approval", "Treat it as an unsupported addition and remove it", "Hide it from the checklist"], correctOptionIndex: 2, explanation: "The packet authorizes no urgency fee. A generated addition is not a business policy or approval." }
          ],
          reflectionPrompt: "Which unresolved action is easiest to accidentally mark complete, and what evidence should prevent that?",
          returnToWorkAction: "Create a small approved checklist using order references and completion evidence, then have the relevant team member verify one completed item."
        },
        {
          id: "msme-03",
          title: "Measure usefulness, including the checking time",
          estimatedMinutes: 25,
          objective: "Compare time and quality fairly and define a safe return-to-work trial.",
          lessonText: "Fast generation is only one part of a task. Include preparation, checking, correction and approval when comparing AI-assisted work with your usual approach. A faster draft with inaccurate promises may create more work later. In this exercise, manual preparation takes 12 minutes. The assisted route takes six minutes to prepare and generate, plus five minutes to check and correct. Its total is 11 minutes, a one-minute saving in this single fictional trial. The draft initially contains two unsupported commitments, and both must be corrected before approval. This small example does not establish a general productivity gain for your business. A useful trial uses comparable tasks and the same quality standard, records limitations, and stops if information handling or quality becomes unacceptable. Choose a low-consequence task, obtain permission, and keep final sending or operational commitments with the authorized person.",
          steps: ["Add all assisted-task time components", "Compare with manual time", "Check final quality against the same standard", "Describe the sample's limits", "Plan one permitted, low-consequence work trial"],
          exercise: {
            title: "Evaluate a fictional productivity trial",
            sourcePacket: [
              { sourceId: "M1", method: "Manual", minutes: 12, finalQuality: "Meets the scenario policy" },
              { sourceId: "A1", method: "AI-assisted preparation and generation", minutes: 6, draftQuality: "Two unsupported commitments" },
              { sourceId: "A2", method: "AI-assisted verification and correction", minutes: 5, finalQuality: "Both errors corrected; meets the same policy" },
              { sourceId: "N1", note: "One fictional comparable task only. No broader business productivity evidence is supplied." }
            ],
            suppliedAiDraft: "AI cut the task time in half from 12 minutes to 6 minutes and can be used to send all customer messages automatically.",
            optionalAiPrompt: "Calculate total assisted task time including checking. Compare the single fictional trial with manual preparation, discuss final quality and limits, and do not recommend automatic sending.",
            learnerTask: "Write a short evaluation and a safe one-task trial plan.",
            expectedEvidence: ["Assisted total 6 + 5 = 11 minutes", "Saving 12 - 11 = 1 minute", "If a percentage is included, approximately 8.3%, with single-trial limitation", "Same final quality check required", "No automatic customer sending or unauthorized data use"],
            assessorReference: "The six-minute figure excludes essential review. Accept one-minute saving without a percentage. A small or absent saving can still be a valid finding; learners are not rewarded for claiming AI is always better."
          },
          quiz: [
            { id: "msme-03-q1", question: "What is the full assisted-task time?", options: ["6 minutes", "5 minutes", "11 minutes", "17 minutes"], correctOptionIndex: 2, explanation: "Preparation/generation takes six minutes and checking/correction takes five. Both belong in the assisted-task total." },
            { id: "msme-03-q2", question: "What does this single fictional trial establish?", options: ["Every task will save half its time", "The comparable task saved one minute after review, with limited evidence", "Checking can now be skipped", "AI should automatically send every message"], correctOptionIndex: 1, explanation: "The result is limited to one synthetic trial and includes the verification work. It does not justify broad claims or removal of human approval." },
            { id: "msme-03-q3", question: "If an assisted draft is faster but retains an unsupported promise, what should happen?", options: ["Accept it because speed is the only measure", "Hide the error from the comparison", "Send it and correct it later", "Correct or reject it before use and record the quality failure"], correctOptionIndex: 3, explanation: "Quality and authorized commitments matter alongside time. A speed gain does not override an unacceptable output." }
          ],
          reflectionPrompt: "What checking or approval work would your own time comparison need to include?",
          returnToWorkAction: "With approval, compare one low-consequence task using the same quality checks for both methods. Record preparation, checking, correction and approval time without collecting confidential artifacts."
        }
      ],
      practicalAssessment: {
        id: "msme-practical-01",
        title: "An accurate customer draft and operations checklist",
        scenario: "Use fictional P1, S1 and O101\u2013O103 to prepare a customer response and checklist. Evaluate the supplied productivity trial without making unsupported business claims.",
        submissionPrompts: [
          { id: "task", label: "Task, audience and success criteria", help: "State what the customer and team need from your work." },
          { id: "safe-input", label: "Information included and information withheld", help: "Identify why internal cost and private markers do not belong in the drafting prompt." },
          { id: "ai-evidence", label: "Draft and safer instructions", help: "Use the supplied draft or an optional tool with synthetic inputs only." },
          { id: "checks", label: "Promises and calculations you checked", help: "Check stock, timing, price, delivery fee, discount and invented surcharge." },
          { id: "final", label: "Corrected customer response", help: "Keep unconfirmed stock and date explicit and avoid unauthorized commitments." },
          { id: "checklist", label: "Three-row action checklist", help: "Include owner role, dependency and evidence of completion." },
          { id: "return", label: "Productivity evaluation and return-to-work plan", help: "Include verification time, quality checks, limited evidence and authorized approval." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable response or checklist", "1": "Major source errors and unclear actions", "2": "Usable draft or checklist but material omissions", "3": "Clear accurate response and three actionable checklist rows", "4": "Concise audience-appropriate work with complete owners, dependencies and checks" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented promises and calculations", "1": "Checks only a minor fact", "2": "Checks key commitments but omits an important inconsistency", "3": "Corrects stock/date/discount/fee claims and includes full assisted time", "4": "Maps all material checks to sources and reports uncertainty and trial limits clearly" }, criticalGate: "No unconfirmed six-unit Friday promise, invented discount/free delivery or INR 50 surcharge remains as an authorized commitment" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Discloses inappropriate private information or actual secrets", "1": "Cannot distinguish relevant from internal information", "2": "Uses synthetic records but incompletely explains exclusions", "3": "Uses permitted facts and excludes internal cost/private contact data", "4": "Explains minimal input, approved channels and restricted customer-record handling" }, criticalGate: "No actual private customer records or credentials used; unnecessary internal/private fields are excluded from the customer draft and unapproved prompt" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Automatically commits or dispatches based on the draft", "1": "General caution without an approval route", "2": "Recognizes review but leaves a key operational action unclear", "3": "Preserves pending status and names human approval/checks and a bounded work trial", "4": "Explains stop conditions, source-based completion and limits of productivity conclusions" }, criticalGate: "Unresolved stock/address/pickup items are not falsely completed; customer sending and operational exceptions retain authorized human review" }
        ],
        samplePassingEvidence: "Four units are confirmed; six-unit Friday delivery needs the stock team's check. I removed the discount, free delivery and internal cost. O101 needs stock confirmation; O102 needs pickup arrangement; O103 needs approved address confirmation and remains on hold. I did not add a surcharge. The assisted trial takes 11 minutes including checks, saving one minute on one synthetic task. My work trial will use an approved low-consequence task and an authorized sender.",
        sampleCriticalFailure: "The learner calculates the right price and writes an elegant response but promises Friday delivery of six units, despite only four confirmed units. The verification gate fails.",
        assessorNote: "Accept different courteous wording and supervisor-reviewed priority suggestions. Do not require a positive productivity result or treat a calculated price as confirmed order acceptance."
      },
      followUp: { afterDays: 14, question: "Did you use a checked draft or action checklist on a permitted task, and what changed?", evidenceOptions: ["Structured reflection with task category and checks", "Blank checklist template", "Aggregate time comparison without customer details"], successSignal: "A learner describes a corrected commitment or clearer operational action and includes checking effort", privacyNote: "Do not require actual customer messages, prices negotiated with named customers or business account records." }
    },
    {
      id: "public-servant-source-briefs",
      title: "Clear administrative briefs with accountable AI use",
      ecosystem: "Government",
      role: "Public servant",
      level: "Foundation to applied",
      summary: "Create a source-traceable administrative draft, verify a simple summary, and retain authorized review before official use.",
      promise: "You can prepare a clear draft from permitted reference material and show which facts and judgments need review.",
      estimatedMinutes: 110,
      prerequisites: ["Read short supplied reference material", "Know that official approval is distinct from a draft", "Use a form or receive planned facilitator assistance"],
      outcomes: ["Classify source material before tool use", "Map claims to supplied sources", "Reject invented requirements, fees and references", "Verify totals and rates with clear denominators", "Keep accountable approval and publication within assigned authority"],
      credentialClaim: "Demonstrated administrative drafting, source verification and responsible information-handling using synthetic training material",
      credentialExclusions: ["No authority to issue official decisions", "No legal or statutory qualification", "No assurance that an external AI tool is approved by an employer"],
      sourceNotice: "Every notice, department, programme, figure and policy below is fictional. No actual law, administrative direction or citizen service rule is stated.",
      lessons: [
        {
          id: "gov-01",
          title: "Draft from permitted sources, not invented rules",
          estimatedMinutes: 25,
          objective: "Create a source-based brief and remove invented requirements and authority.",
          lessonText: "An administrative draft should make it easy to identify the source of each important fact. First confirm whether the material is permitted for the chosen tool; a source being available to you does not automatically make external upload acceptable. This exercise supplies fictional shareable references, so no real file is needed. Read the sources before reviewing the AI draft. A generated instruction such as 'attendance is mandatory' is not authority unless the source actually states it. A fee or penalty must not be invented to make a notice sound official. Keep the document visibly marked as a draft, name the intended reader, and identify the review needed before official use. If a detail is missing, ask for confirmation or omit it. Do not add a fabricated circular number or present the AI output as an approved decision.",
          steps: ["Confirm the fictional packet is the approved practice input", "Map each material fact to a source", "Remove unsupported fee, penalty and mandatory-attendance claims", "Create a clear draft brief", "Name the approval step"],
          exercise: {
            title: "Correct the fictional staff-orientation brief",
            sourcePacket: [
              { sourceId: "G1", content: "Fictional staff orientation is planned for 8 October 2026 from 10:00 to 11:00." },
              { sourceId: "G2", content: "Venue: Room B. Participants are asked to respond by 6 October 2026." },
              { sourceId: "G3", content: "Attendance is voluntary. This material is a draft for authorized administrative review. No fee, penalty or circular number is supplied." },
              { sourceId: "G4", content: "Teaching packet is fictional and approved for this practice only. It contains no actual personnel or citizen records." }
            ],
            suppliedAiDraft: "Under Circular GOV-X, every employee must attend Room B on 8 October from 10:00 to 11:00. A fee of INR 500 applies. Late responses will result in a penalty. This notice is approved for issue.",
            optionalAiPrompt: "Prepare a brief from fictional G1\u2013G4 only. Include source references, distinguish draft status and voluntary attendance, and do not invent fees, penalties or circulars. Identify authorized review before issue.",
            learnerTask: "Write a short corrected draft and a fact-to-source list.",
            expectedEvidence: ["Correct date, time, room and response date", "Voluntary attendance retained", "GOV-X, fee and penalty removed as unsupported", "Draft status and authorized review explicit", "Important facts mapped to G1\u2013G3"],
            assessorReference: "The sources support a voluntary fictional event in Room B, 8 October 10:00\u201311:00, response by 6 October. They do not support a fee, penalty, circular or approved-issue status. Equivalent brief formats are acceptable."
          },
          quiz: [
            { id: "gov-01-q1", question: "Which statement matches G3?", options: ["Attendance is compulsory", "A fee of INR 500 applies", "Attendance is voluntary and the material needs authorized review", "Circular GOV-X authorizes publication"], correctOptionIndex: 2, explanation: "G3 explicitly states voluntary attendance and draft status. The generated fee, circular and authority are unsupported." },
            { id: "gov-01-q2", question: "How should GOV-X be treated?", options: ["As valid because it looks official", "As an unsupported reference to remove or verify before any use", "As a required citation", "As a confidential password"], correctOptionIndex: 1, explanation: "No such reference is supplied. Official-looking formatting does not establish authenticity." },
            { id: "gov-01-q3", question: "What is appropriate for this external-tool practice?", options: ["Upload actual restricted personnel files", "Use the supplied approved fictional packet only", "Assume every work file is public", "Include citizen identities to make the example realistic"], correctOptionIndex: 1, explanation: "The fictional packet is designed for practice. Real work material requires the organization's approved handling and tool rules." }
          ],
          reflectionPrompt: "How can the reader tell which facts came from the sources and which parts still need approval?",
          returnToWorkAction: "Use a claim\u2013source\u2013review template with permitted material in an approved environment. Keep draft status until the authorized approval step is completed."
        },
        {
          id: "gov-02",
          title: "Check numbers and the story they tell",
          estimatedMinutes: 25,
          objective: "Calculate a correct summary and avoid unsupported explanations of cause or performance.",
          lessonText: "A numerical brief needs a clear denominator and time period. In this fictional weekly packet, 80 items were received and 55 were recorded resolved. Dividing 55 by 80 gives 68.75%. That describes the packet's recorded figures; it does not automatically establish why outcomes changed or whether every item was handled satisfactorily. An AI draft may mix a wrong rate with a persuasive explanation. Check the calculation yourself, compare it with the source rows, and state the exact scope. Do not call a record 'improved' without a comparable earlier period and an agreed quality measure. A useful brief can explain the current counts and the limits of interpretation. If someone asks for a causal conclusion, identify the additional evidence needed rather than manufacturing one. Preserve accountability by asking the relevant data owner to confirm the figures before official circulation.",
          steps: ["Total received and resolved counts", "Calculate the rate with its denominator", "Compare the draft's rate", "Remove unsupported cause and quality claims", "Write a scoped summary for review"],
          exercise: {
            title: "Verify the fictional weekly service summary",
            sourcePacket: [
              { sourceId: "W1", category: "Category A", received: 40, recordedResolved: 25 },
              { sourceId: "W2", category: "Category B", received: 25, recordedResolved: 20 },
              { sourceId: "W3", category: "Category C", received: 15, recordedResolved: 10 },
              { sourceId: "W4", scope: "One fictional reporting week; no earlier period, case-level quality evidence or cause analysis is supplied." }
            ],
            suppliedAiDraft: "The programme resolved 95% of the 80 items and its new policy caused a major improvement in service quality.",
            optionalAiPrompt: "Summarize fictional W1\u2013W4. Show counts and denominator, calculate the rate, state scope, and avoid causal or quality claims unsupported by the packet.",
            learnerTask: "Create a verified three-sentence numerical brief with a visible calculation and one interpretation limit.",
            expectedEvidence: ["Received: 40 + 25 + 15 = 80", "Recorded resolved: 25 + 20 + 10 = 55", "55 / 80 \xD7 100 = 68.75%", "95% claim corrected", "No unsupported improvement, policy causation or case-quality claim"],
            assessorReference: "Accept 68.75% or appropriately labeled rounding such as 68.8%. The source uses 'recorded resolved'; avoid turning that into independently verified service quality. No previous-period or causal claim is justified."
          },
          quiz: [
            { id: "gov-02-q1", question: "What percentage of received items is recorded resolved?", options: ["95%", "55%", "68.75%", "80%"], correctOptionIndex: 2, explanation: "There are 55 recorded resolved items out of 80 received. 55 divided by 80, multiplied by 100, is 68.75%." },
            { id: "gov-02-q2", question: "What additional evidence is needed before calling this an improvement?", options: ["A more confident AI sentence", "A comparable baseline and agreed measures", "A larger font", "A made-up prior-period figure"], correctOptionIndex: 1, explanation: "Improvement requires an appropriate comparison and defined measures. The single-week packet provides neither." },
            { id: "gov-02-q3", question: "Which wording is best supported?", options: ["The policy caused better quality", "Every item was handled satisfactorily", "The packet records 55 of 80 items resolved for one fictional week", "The result applies to every department"], correctOptionIndex: 2, explanation: "This describes the supplied counts and scope without adding unverified quality, causal or generalization claims." }
          ],
          reflectionPrompt: "What would you ask the data owner before this summary was used in an official report?",
          returnToWorkAction: "On one permitted numerical summary, record the denominator, period, calculation and data-owner check before circulation."
        },
        {
          id: "gov-03",
          title: "Keep the draft-to-official boundary clear",
          estimatedMinutes: 25,
          objective: "Build a review handoff and safe work plan without assuming publication authority.",
          lessonText: "Preparing a draft and authorizing its official use are different responsibilities. A learning role such as public servant does not give permission to view every file or issue a notice. Keep the active work context and intended recipient clear. Your review handoff should identify the draft version, source packet, checks completed, uncertainties and the person or role that must approve it. AI can suggest text, but it cannot provide organizational authority. In this exercise, the reviewer role may confirm the source figures and wording; publication remains with the designated approver. Do not bypass that handoff because the document looks finished. If the approved AI tool is unavailable, use the supplied draft or prepare the brief manually. The skill is accurate and accountable work, not dependence on a tool. Return to your work with a small permitted task and an explicit stop condition if classification, access or approval is unclear.",
          steps: ["Mark the document as a draft", "List sources, version and checks", "Identify unresolved questions", "Route to the designated review and approval roles", "Define one bounded return-to-work task"],
          exercise: {
            title: "Prepare the accountable review handoff",
            sourcePacket: [
              { sourceId: "R1", content: "Fictional review process: learner prepares draft; data owner confirms supplied figures; designated administrative approver decides official issue. No role is granted through Academy enrollment." },
              { sourceId: "R2", content: "Use corrected G1\u2013G3 event brief and W1\u2013W4 numerical summary. Both remain draft teaching materials." },
              { sourceId: "R3", content: "Actual restricted work records, access credentials and citizen identities must not be included in this practice." }
            ],
            suppliedAiDraft: "The brief looks complete. Publish it immediately using your Academy learner role and skip data-owner review.",
            optionalAiPrompt: "Create a review checklist from fictional R1\u2013R3. Preserve draft status, source checks, data-owner review and designated approval. Do not grant permissions or propose immediate publication.",
            learnerTask: "Write a review note naming the source packet, checks, questions, next reviewer, final approval step and work-trial stop condition.",
            expectedEvidence: ["Draft status explicit", "Corrected sources and calculations listed", "Data-owner review and designated approval separated", "No implied administrative privileges from Academy role", "Stop when classification, permitted tool or authority is unclear"],
            assessorReference: "A passing handoff preserves the R1 process and does not issue anything. The learner can use equivalent role labels without naming a real official. A safe work trial uses permitted material and retains employer-approved review."
          },
          quiz: [
            { id: "gov-03-q1", question: "What permission does selecting the public-servant learner role grant?", options: ["Access to all official records", "Permission to publish a notice", "No administrative or publication permission by itself", "Permission to bypass review"], correctOptionIndex: 2, explanation: "A learning context supports relevance. Actual access and authority require explicit assignments in the relevant system and process." },
            { id: "gov-03-q2", question: "What should happen when the data classification or approved tool is unclear?", options: ["Upload the file and ask later", "Stop and seek the appropriate approval or handling guidance", "Rename the file to make it public", "Assume Academy enrollment authorizes it"], correctOptionIndex: 1, explanation: "Unclear handling rules are a reason to pause the tool use and seek the responsible owner, not to guess." },
            { id: "gov-03-q3", question: "If an external AI tool is unavailable during this activity, what is acceptable?", options: ["Use another unapproved tool with restricted records", "Skip all verification", "Claim the task is passed without evidence", "Review the supplied draft or prepare the work manually with the same checks"], correctOptionIndex: 3, explanation: "The assessed skill is responsible task performance. The provided draft supports practice without tool access, and the checking standard remains the same." }
          ],
          reflectionPrompt: "What part of your handoff ensures that a polished draft is not mistaken for an approved decision?",
          returnToWorkAction: "Use a draft-review checklist for one permitted administrative task. Record sources, checks, remaining questions and the authorized approval route without submitting confidential work to Academy."
        }
      ],
      practicalAssessment: {
        id: "gov-practical-01",
        title: "A verified administrative brief and review handoff",
        scenario: "Prepare a corrected fictional staff-orientation brief, a numerical summary of W1\u2013W4, and a review handoff under R1\u2013R3. Explain why generated wording is not official authority.",
        submissionPrompts: [
          { id: "task", label: "Purpose, reader and draft status", help: "Identify the intended administrative use and why approval remains necessary." },
          { id: "safe-input", label: "Permitted input and handling boundary", help: "Use the fictional packet and identify what you would keep out of an unapproved tool." },
          { id: "ai-evidence", label: "Supplied draft and safer instructions", help: "Describe the source-bound instructions without providing any actual restricted file." },
          { id: "checks", label: "Fact-to-source map and numerical checks", help: "Check event facts, invented circular/fee/penalty, totals and rate." },
          { id: "final", label: "Corrected brief and scoped numerical summary", help: "Keep voluntary attendance, draft status and the exact count scope." },
          { id: "handoff", label: "Review and approval handoff", help: "Identify data-owner confirmation, unresolved questions and designated approval." },
          { id: "return", label: "Return-to-work task and stop conditions", help: "Choose a permitted task and explain when access, classification or authority needs clarification." }
        ],
        rubric: [
          { id: "task-quality", dimension: "Task quality", weight: 40, anchors: { "0": "No usable brief or handoff", "1": "Major factual errors and unclear audience", "2": "Mostly usable work with material omissions", "3": "Clear corrected event brief, numerical summary and review note", "4": "Concise audience-appropriate work with complete source mapping and actionable handoff" }, criticalGate: null },
          { id: "verification", dimension: "Verification", weight: 25, anchors: { "0": "Accepts invented official references and rate", "1": "Checks isolated facts only", "2": "Checks main facts but leaves an important unsupported assertion", "3": "Removes invented authority/fee/penalty and verifies 55 of 80 equals 68.75%", "4": "Maps every important assertion to sources and explains scope, denominator and interpretation limits" }, criticalGate: "No fabricated circular, fee, penalty, mandatory-attendance claim or unsupported causal improvement remains presented as source-supported fact" },
          { id: "information-handling", dimension: "Information handling", weight: 20, anchors: { "0": "Includes actual restricted records or credentials", "1": "Treats all work material as permitted", "2": "Uses synthetic material but lacks a clear tool boundary", "3": "Uses only approved fictional packet and identifies restricted information to withhold", "4": "Explains approved environment, minimum necessary sharing and a clear uncertainty stop" }, criticalGate: "No actual restricted administrative/citizen records or credentials are submitted or proposed for unapproved tool use" },
          { id: "judgment", dimension: "Judgment", weight: 15, anchors: { "0": "Issues or authorizes the draft without required authority", "1": "Mentions review but does not distinguish approval", "2": "Identifies review with an incomplete handoff", "3": "Preserves draft status, data-owner check and designated approval", "4": "Adds specific unresolved questions, stop conditions and a bounded permitted work trial" }, criticalGate: "Academy role and AI output are not treated as official authority; required review and designated approval are retained" }
        ],
        samplePassingEvidence: "G1 and G2 support the event date, time, venue and response date. G3 says attendance is voluntary and the material is a draft. I removed GOV-X, INR 500 and the penalty. W1\u2013W3 total 80 received and 55 recorded resolved, or 68.75%, for one fictional week; no causal improvement is established. My handoff requests data-owner checks and designated approval before issue. I used only the synthetic packet and will stop a work trial if classification, tool approval or authority is unclear.",
        sampleCriticalFailure: "The learner calculates the rate correctly but retains an invented circular and describes the draft as officially approved. The verification and judgment gates fail.",
        assessorNote: "Assess source accountability and authority boundaries rather than legal knowledge. Do not infer that any real organization's tool or publication policy matches the fictional process."
      },
      followUp: { afterDays: 14, question: "Did you use a source-and-review checklist for a permitted administrative task?", evidenceOptions: ["Structured reflection without document contents", "Blank claim\u2013source\u2013review template", "Authorized facilitator confirmation under the approved pilot process"], successSignal: "The learner describes a checked claim, a documented uncertainty and the correct approval handoff", privacyNote: "Do not collect actual administrative briefs, citizen records or employer-restricted information by default." }
    }
  ]
};

// outputs/aplyd-academy-sprint/curriculum-authoring/resolver-candidate/academy-curriculum.ts
var LEGACY_CONTENT_VERSION = "0.1-review-draft";
var LEGACY_SOURCE_SHA256 = "9fc83c8dd615456db8f49d140f56bff566e05c14d32ebb70a14cdcb73078b7e4";
var CONTENT_VERSION = LEGACY_CONTENT_VERSION;
var ContentResolutionError = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
    this.name = "ContentResolutionError";
  }
  status;
};
function deepFreeze(value) {
  if (value !== null && typeof value === "object" && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) deepFreeze(child);
    Object.freeze(value);
  }
  return value;
}
function validScope(value) {
  return value === "global" || typeof value === "string" && /^tw-[a-z0-9-]{20,80}$/i.test(value);
}
function contentRef(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ContentResolutionError("The saved content reference is invalid. Contact support before continuing.");
  }
  const ref = value;
  if (Object.keys(ref).some((key) => !["scope", "programId", "versionId"].includes(key)) || !validScope(ref.scope) || typeof ref.programId !== "string" || !/^[a-z0-9][a-z0-9-]{0,99}$/i.test(ref.programId) || typeof ref.versionId !== "string" || !/^[a-z0-9][a-z0-9._-]{0,99}$/i.test(ref.versionId)) {
    throw new ContentResolutionError("The saved content reference is invalid. Contact support before continuing.");
  }
  return Object.freeze({ scope: ref.scope, programId: ref.programId, versionId: ref.versionId });
}
function contentKey(value) {
  const ref = contentRef(value);
  return JSON.stringify([ref.scope, ref.programId, ref.versionId]);
}
function pinnedRef(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new ContentResolutionError("The saved learning reference is invalid.");
  }
  const record = value;
  if (Object.hasOwn(record, "contentRef")) {
    const ref = contentRef(record.contentRef);
    if (record.programId !== void 0 && record.programId !== ref.programId || record.version !== void 0 && record.version !== ref.versionId) {
      throw new ContentResolutionError("Saved learning and content references disagree. Contact support before continuing.");
    }
    return ref;
  }
  return contentRef({ scope: "global", programId: record.programId, versionId: record.version });
}
function createCurriculumRegistry(entries) {
  const index = /* @__PURE__ */ new Map();
  for (const entry of entries) {
    const ref = contentRef(entry.ref);
    if (entry.program.id !== ref.programId) {
      throw new ContentResolutionError("A content snapshot has a mismatched pathway identity.");
    }
    const key = contentKey(ref);
    if (index.has(key)) throw new ContentResolutionError("An immutable content key is already registered.");
    index.set(key, deepFreeze(structuredClone({ ...entry, ref })));
  }
  function resolve2(input, allowedScopes = ["global"]) {
    const ref = contentRef(input);
    if (!allowedScopes.includes(ref.scope)) {
      throw new ContentResolutionError("This content is not available in your learning space.", 404);
    }
    const found = index.get(contentKey(ref));
    if (!found) {
      throw new ContentResolutionError("Your pinned curriculum version is unavailable. Contact support before continuing.");
    }
    return found;
  }
  return Object.freeze({ resolve: resolve2, has: (ref, allowedScopes) => {
    try {
      resolve2(ref, allowedScopes);
      return true;
    } catch (error) {
      if (error instanceof ContentResolutionError) return false;
      throw error;
    }
  } });
}
var curriculum = deepFreeze(structuredClone(review_draft_default));
var programs = curriculum.pathways;
var seedSnapshots = programs.map((program) => ({
  ref: contentRef({ scope: "global", programId: program.id, versionId: LEGACY_CONTENT_VERSION }),
  program,
  language: curriculum.language,
  audience: curriculum.audience,
  classification: curriculum.status
}));
var curriculumRegistry = createCurriculumRegistry(seedSnapshots);
function currentRef(programId) {
  return contentRef({ scope: "global", programId, versionId: CONTENT_VERSION });
}
function resolveCurrentProgram(programId) {
  if (!programs.some((program) => program.id === programId)) {
    throw new ContentResolutionError("Pathway not found.", 404);
  }
  return curriculumRegistry.resolve(currentRef(programId)).program;
}
function resolvePinnedContent(record, allowedScopes) {
  return curriculumRegistry.resolve(pinnedRef(record), allowedScopes);
}
function resolvePinnedProgram(record, allowedScopes) {
  return resolvePinnedContent(record, allowedScopes).program;
}
function tryResolvePinnedContent(record, allowedScopes) {
  try {
    return { available: true, snapshot: resolvePinnedContent(record, allowedScopes) };
  } catch (error) {
    if (error instanceof ContentResolutionError) return { available: false, message: error.message };
    throw error;
  }
}

// outputs/aplyd-academy-sprint/curriculum-authoring/authoring-candidate/workspace-authoring.ts
var AUTHORING_CLASSIFICATION = "Private workspace practice draft \xB7 nonaccredited";
var AUTHORING_LIMITS = { activeDrafts: 4, publications: 8, documentBytes: 65536, contentBytes: 65e4 };
var CLAIM = "Demonstrated the published synthetic practice exercise through checked work, careful information handling and human review";
var EXCLUSIONS = ["Nonaccredited private practice record", "No medical, legal, financial, agricultural or other professional qualification", "No authority to make consequential professional decisions"];
var NOTICE = "All sources, people, work records and AI drafts in this pathway are fictional teaching fixtures. Submit no actual private work records or credentials.";
var AuthoringError = class extends Error {
  constructor(message, status = 422) {
    super(message);
    this.status = status;
  }
  status;
};
var copy = (value) => structuredClone(value);
function freshAuthoring() {
  return { drafts: [], publications: [] };
}
var CONTENT_COMMANDS = ["content-copy", "content-save", "content-submit", "content-recall", "content-review", "content-publish", "content-retire"];
function isContentCommand(c) {
  return !!c && CONTENT_COMMANDS.includes(c.type);
}
function member(host, user) {
  const m = host.members.find((m2) => m2.userId === user.userId);
  if (!m || !m.active) throw new AuthoringError("This workspace is unavailable for your current account.", 404);
  return m;
}
function owner(host, user) {
  const m = member(host, user);
  if (!m.roles.includes("admin")) throw new AuthoringError("A current workspace owner permission is required.", 403);
  return m;
}
function exact(c, allowed) {
  if (!c || typeof c !== "object" || Array.isArray(c) || Object.keys(c).some((k) => !["type", ...allowed].includes(k))) throw new AuthoringError("This content action has unsupported fields.", 400);
}
function text(v, label, min, max) {
  if (typeof v !== "string" || v.trim().length < min || v.length > max) throw new AuthoringError(`${label} needs ${min}\u2013${max} characters.`);
  return v.trim();
}
function scopedRef(host, ref) {
  try {
    const x = contentRef(ref);
    if (x.scope !== "global" && x.scope !== host.id) throw new AuthoringError("Content from another workspace is unavailable.", 404);
    return x;
  } catch (e) {
    if (e instanceof AuthoringError) throw e;
    throw new AuthoringError(e.message, e.status ?? 409);
  }
}
function workspaceRegistry(host) {
  return createCurriculumRegistry([...programs.map((program) => curriculumRegistry.resolve({ scope: "global", programId: program.id, versionId: LEGACY_CONTENT_VERSION })), ...(host.content?.publications ?? []).map((p) => p.snapshot)]);
}
function resolve(host, ref) {
  try {
    return workspaceRegistry(host).resolve(scopedRef(host, ref), ["global", host.id]);
  } catch (e) {
    if (e instanceof AuthoringError) throw e;
    throw new AuthoringError(e.message, e.status ?? 409);
  }
}
function template(host, draft) {
  const doc = copy(resolve(host, draft.baseRef).program);
  doc.id = draft.programId;
  doc.credentialClaim = CLAIM;
  doc.credentialExclusions = copy(EXCLUSIONS);
  doc.sourceNotice = NOTICE;
  doc.lessons.forEach((lesson) => {
    lesson.exercise.sourcePacket = lesson.exercise.sourcePacket.map((row, index) => typeof row === "string" ? { sourceId: lesson.id + "-source-" + (index + 1), content: row } : row);
  });
  return doc;
}
function plain(v) {
  if (!v || typeof v !== "object" || Array.isArray(v)) return false;
  const p = Object.getPrototypeOf(v);
  return p === Object.prototype || p === null;
}
function canonicalJson(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(canonicalJson).join(",") + "]";
  return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonicalJson(value[k])).join(",") + "}";
}
async function documentHash(document) {
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalJson(document))))).map((x) => x.toString(16).padStart(2, "0")).join("");
}
function validateDocument(document, expected) {
  const issues = [], issue = (path, kind, message) => issues.push({ path, kind, message });
  const locked = /* @__PURE__ */ new Set(["id", "ecosystem", "role", "level", "credentialClaim", "credentialExclusions", "sourceNotice", "followUp"]);
  function walk(v, t, path) {
    if (path.endsWith(".sourcePacket")) {
      if (!Array.isArray(v) || v.length < 1 || v.length > 20) {
        issue(path, "shape", "Provide 1\u201320 fictional source records.");
        return;
      }
      v.forEach((row, i) => {
        if (!plain(row) || Object.keys(row).length < 2 || Object.keys(row).length > 15) {
          issue(path + "." + i, "shape", "A source record needs a reference and bounded plain facts.");
          return;
        }
        if (typeof row.sourceId !== "string" || row.sourceId.trim().length < 1 || row.sourceId.length > 80) issue(path + "." + i + ".sourceId", "shape", "Provide a source reference of 1\u201380 characters.");
        for (const [key, value] of Object.entries(row)) {
          if (key.length > 60 || ["__proto__", "constructor", "prototype"].includes(key)) {
            issue(path + "." + i, "shape", "This source field name is unsupported.");
            continue;
          }
          if (typeof value === "string") {
            if (value.length > 2e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value)) issue(path + "." + i + "." + key, "limit", "Keep source facts within 2,000 characters using ordinary text.");
          } else if (typeof value === "number") {
            if (!Number.isFinite(value) || Math.abs(value) > 1e12) issue(path + "." + i + "." + key, "shape", "Use a finite bounded number.");
          } else if (value !== null && typeof value !== "boolean") issue(path + "." + i + "." + key, "shape", "Source facts must be plain text, numbers or simple flags.");
        }
      });
      return;
    }
    if (Array.isArray(t)) {
      if (!Array.isArray(v)) {
        issue(path, "shape", "This field must be a list.");
        return;
      }
      const fixed = /\.(lessons|quiz|options|submissionPrompts|rubric)$/.test(path);
      if (fixed && v.length !== t.length || !fixed && (v.length < 1 || v.length > 20)) {
        issue(path, "shape", fixed ? `This pilot keeps exactly ${t.length} entries here.` : "Provide 1\u201320 entries.");
        return;
      }
      v.forEach((child, i) => walk(child, fixed ? t[i] : t[0], path + "." + i));
      return;
    }
    if (t === null) {
      if (v !== null) issue(path, "locked", "This pilot preserves the original critical-gate structure.");
      return;
    }
    if (typeof t === "object") {
      if (!plain(v)) {
        issue(path, "shape", "Provide a plain content object.");
        return;
      }
      if (Object.keys(v).some((k) => !Object.hasOwn(t, k)) || Object.keys(t).some((k) => !Object.hasOwn(v, k))) {
        issue(path, "shape", "Content fields are missing or unsupported.");
        return;
      }
      for (const key of Object.keys(t)) {
        if (path === "program" && locked.has(key) || key === "id") {
          if (canonicalJson(v[key]) !== canonicalJson(t[key])) issue(path + "." + key, "locked", "Published identity, classification and supported structure are fixed for this pilot.");
        } else walk(v[key], t[key], path + "." + key);
      }
      return;
    }
    if (typeof v !== typeof t) {
      issue(path, "shape", "This field has an unsupported value type.");
      return;
    }
    if (typeof v === "string" && (v.length > 12e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v))) issue(path, "limit", "Use ordinary text within the field limit.");
    if (typeof v === "number" && !Number.isFinite(v)) issue(path, "shape", "Use a finite number.");
  }
  walk(document, expected, "program");
  try {
    if (new TextEncoder().encode(JSON.stringify(document)).length > AUTHORING_LIMITS.documentBytes) issue("program", "limit", "This pathway exceeds the 64 KiB pilot document limit.");
  } catch {
    issue("program", "shape", "Content must be serializable text and facts.");
  }
  if (issues.some((x) => ["shape", "locked", "limit"].includes(x.kind))) return issues;
  function required(value, path, min = 10, max = 2e3) {
    if (typeof value !== "string" || value.trim().length < min) issue(path, "required", `Add at least ${min} characters.`);
    else if (value.length > max) issue(path, "limit", `Keep this field within ${max} characters.`);
  }
  function minutes(value, path) {
    if (!Number.isInteger(value) || value < 5 || value > 720) issue(path, "consistency", "Use whole minutes between 5 and 720.");
  }
  required(document.title, "program.title", 3, 160);
  required(document.summary, "program.summary", 20, 2e3);
  required(document.promise, "program.promise", 20, 1e3);
  minutes(document.estimatedMinutes, "program.estimatedMinutes");
  for (const key of ["prerequisites", "outcomes"]) document[key].forEach((v, i) => required(v, "program." + key + "." + i, 10, 500));
  for (const [i, l] of document.lessons.entries()) {
    const base = "program.lessons." + i;
    required(l.title, base + ".title", 3, 160);
    required(l.objective, base + ".objective", 20, 1e3);
    required(l.lessonText, base + ".lessonText", 100, 12e3);
    minutes(l.estimatedMinutes, base + ".estimatedMinutes");
    l.steps.forEach((v, j) => required(v, base + ".steps." + j, 5, 500));
    required(l.reflectionPrompt, base + ".reflectionPrompt", 15, 1e3);
    required(l.returnToWorkAction, base + ".returnToWorkAction", 30, 2e3);
    const ex = l.exercise;
    for (const key of ["title", "suppliedAiDraft", "optionalAiPrompt", "learnerTask", "assessorReference"]) required(ex[key], base + ".exercise." + key, key === "title" ? 3 : 30, key === "title" ? 160 : 4e3);
    ex.expectedEvidence.forEach((v, j) => required(v, base + ".exercise.expectedEvidence." + j, 10, 700));
    for (const [j, q] of l.quiz.entries()) {
      required(q.question, base + ".quiz." + j + ".question", 10, 1e3);
      required(q.explanation, base + ".quiz." + j + ".explanation", 20, 2e3);
      q.options.forEach((v, k) => required(v, base + ".quiz." + j + ".options." + k, 1, 500));
      if (!Number.isInteger(q.correctOptionIndex) || q.correctOptionIndex < 0 || q.correctOptionIndex > 3) issue(base + ".quiz." + j + ".correctOptionIndex", "consistency", "Choose one of the four answer options.");
    }
  }
  const a = document.practicalAssessment;
  required(a.title, "program.practicalAssessment.title", 3, 160);
  required(a.scenario, "program.practicalAssessment.scenario", 30, 5e3);
  for (const [i, p] of a.submissionPrompts.entries()) {
    required(p.label, "program.practicalAssessment.submissionPrompts." + i + ".label", 3, 160);
    required(p.help, "program.practicalAssessment.submissionPrompts." + i + ".help", 10, 1e3);
  }
  for (const [i, r] of a.rubric.entries()) {
    const b = "program.practicalAssessment.rubric." + i;
    required(r.dimension, b + ".dimension", 3, 160);
    if (!Number.isInteger(r.weight) || r.weight < 1 || r.weight > 97) issue(b + ".weight", "consistency", "Use a positive whole weight, keeping the total at 100.");
    for (const level of ["0", "1", "2", "3", "4"]) required(r.anchors[level], b + ".anchors." + level, 10, 1e3);
    if (r.criticalGate !== null) required(r.criticalGate, b + ".criticalGate", 30, 2e3);
  }
  if (a.rubric.reduce((n, r) => n + r.weight, 0) !== 100) issue("program.practicalAssessment.rubric", "consistency", "Criterion weights must total exactly 100.");
  for (const key of ["samplePassingEvidence", "sampleCriticalFailure", "assessorNote"]) required(a[key], "program.practicalAssessment." + key, 30, 5e3);
  return issues;
}
function findDraft(host, id, revision) {
  const d = host.content?.drafts.find((d2) => d2.id === id);
  if (!d) throw new AuthoringError("Content draft not found in this workspace.", 404);
  if (!Number.isInteger(revision) || revision !== d.revision) throw new AuthoringError("This content draft changed. Reload its latest revision before saving.", 409);
  return d;
}
function byAuthor(d, user) {
  if (d.authorId !== user.userId) throw new AuthoringError("Only this draft author may edit or submit it.", 403);
}
function due(value, now) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value) || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString() !== value || Date.parse(value) <= Date.parse(now) || Date.parse(value) > Date.parse(now) + 730 * 864e5) throw new AuthoringError("Choose a future content review date within two years.");
  return value;
}
function bump(d, actor, action, now, note) {
  d.revision++;
  d.updatedAt = now;
  d.history.push({ id: crypto.randomUUID(), actor: actor.userId, actorName: actor.name || "Workspace owner", action, at: now, ...note ? { note } : {} });
  if (d.history.length > 100) throw new AuthoringError("This draft reached its pilot history limit. Copy its latest publication or seek support.", 409);
}
var complete = (issues) => {
  if (issues.length) throw new AuthoringError("Resolve the content preview issues before requesting review or publishing.");
};
async function applyWorkspaceContentCommand(original, user, c, now = (/* @__PURE__ */ new Date()).toISOString()) {
  if (!isContentCommand(c)) throw new AuthoringError("Unknown content action.", 400);
  if (!Number.isFinite(Date.parse(now))) throw new AuthoringError("A trusted action time is required.", 400);
  const t = copy(original), actor = owner(t, user);
  t.content ??= freshAuthoring();
  switch (c.type) {
    case "content-copy": {
      exact(c, ["sourceRef"]);
      if (t.content.drafts.filter((d) => d.state !== "published").length >= AUTHORING_LIMITS.activeDrafts) throw new AuthoringError("This pilot supports four active content drafts per workspace.", 409);
      const source = scopedRef(t, c.sourceRef), resolved = resolve(t, source), programId = source.scope === t.id ? source.programId : "path-" + crypto.randomUUID(), id = "cd-" + crypto.randomUUID();
      const draft = { id, programId, baseRef: source, authorId: user.userId, authorName: actor.name || "Workspace owner", state: "draft", revision: 1, documentRevision: 1, document: {}, createdAt: now, updatedAt: now, history: [{ id: crypto.randomUUID(), actor: user.userId, actorName: actor.name || "Workspace owner", action: "copied", at: now }] };
      draft.document = template(t, draft);
      t.content.drafts.push(draft);
      break;
    }
    case "content-save": {
      exact(c, ["draftId", "revision", "document"]);
      const d = findDraft(t, c.draftId, c.revision);
      byAuthor(d, user);
      if (d.state !== "draft") throw new AuthoringError("Recall the draft before editing reviewed content.", 409);
      const issues = validateDocument(c.document, template(t, d));
      if (issues.some((x) => ["shape", "locked", "limit"].includes(x.kind))) throw new AuthoringError("Keep the supported content structure, classification and text limits.");
      d.document = copy(c.document);
      d.documentRevision++;
      delete d.approval;
      bump(d, actor, "saved", now);
      break;
    }
    case "content-submit": {
      exact(c, ["draftId", "revision", "reviewerId", "reviewDueAt"]);
      const d = findDraft(t, c.draftId, c.revision);
      byAuthor(d, user);
      if (d.state !== "draft") throw new AuthoringError("Only an editable draft can request review.", 409);
      complete(validateDocument(d.document, template(t, d)));
      const reviewer = t.members.find((m) => m.userId === c.reviewerId && m.active && m.roles.includes("admin"));
      if (!reviewer || reviewer.userId === d.authorId) throw new AuthoringError("Choose another active workspace owner for independent content review.", 403);
      d.reviewerId = reviewer.userId;
      d.reviewDueAt = due(c.reviewDueAt, now);
      d.state = "in_review";
      delete d.approval;
      bump(d, actor, "submitted for independent review", now);
      break;
    }
    case "content-recall": {
      exact(c, ["draftId", "revision", "reason"]);
      const d = findDraft(t, c.draftId, c.revision);
      byAuthor(d, user);
      if (!["in_review", "approved"].includes(d.state)) throw new AuthoringError("Only unpublished reviewed content may be recalled.", 409);
      const reason = text(c.reason, "Reason for recall", 10, 1e3);
      d.state = "draft";
      delete d.approval;
      bump(d, actor, "recalled for editing", now, reason);
      break;
    }
    case "content-review": {
      exact(c, ["draftId", "revision", "decision", "note", "checks"]);
      const d = findDraft(t, c.draftId, c.revision);
      if (d.state !== "in_review") throw new AuthoringError("This draft is not awaiting review.", 409);
      if (d.reviewerId !== user.userId || d.authorId === user.userId) throw new AuthoringError("Only the assigned independent owner may review this content.", 403);
      if (!["approve", "changes"].includes(c.decision)) throw new AuthoringError("Choose approval or request changes.");
      const note = text(c.note, "Content review note", 30, 2e3);
      if (c.decision === "changes") {
        d.state = "draft";
        delete d.approval;
        bump(d, actor, "changes requested", now, note);
        break;
      }
      const keys = ["sources", "answers", "rubric", "safety", "accessibility"];
      if (!plain(c.checks) || Object.keys(c.checks).some((k) => !keys.includes(k)) || keys.some((k) => c.checks[k] !== true)) throw new AuthoringError("Record every required content review check before approval.");
      complete(validateDocument(d.document, template(t, d)));
      due(d.reviewDueAt, now);
      d.approval = { reviewerId: user.userId, reviewerName: actor.name || "Workspace owner", documentRevision: d.documentRevision, documentHash: await documentHash(d.document), reviewedAt: now, note, checks: copy(c.checks) };
      d.state = "approved";
      bump(d, actor, "approved private practice draft", now, note);
      break;
    }
    case "content-publish": {
      exact(c, ["draftId", "revision"]);
      const d = findDraft(t, c.draftId, c.revision);
      if (d.state !== "approved" || !d.approval) throw new AuthoringError("Publish only content approved by an independent owner.", 409);
      const reviewer = t.members.find((m) => m.userId === d.approval.reviewerId && m.active && m.roles.includes("admin"));
      if (!reviewer || reviewer.userId === d.authorId) throw new AuthoringError("Independent reviewer permission changed. Request a current content review.", 403);
      complete(validateDocument(d.document, template(t, d)));
      due(d.reviewDueAt, now);
      const hash = await documentHash(d.document);
      if (d.approval.documentRevision !== d.documentRevision || hash !== d.approval.documentHash) throw new AuthoringError("The document differs from the independently approved revision.", 409);
      if (t.content.publications.length >= AUTHORING_LIMITS.publications) throw new AuthoringError("This pilot supports eight immutable workspace publications.", 409);
      const ref = contentRef({ scope: t.id, programId: d.programId, versionId: "cp-" + crypto.randomUUID() });
      t.content.publications.push({ id: ref.versionId, snapshot: { ref, program: copy(d.document), language: "en", audience: "Adult learners", classification: AUTHORING_CLASSIFICATION, policy: { minimumWeightedScore: 70, scoreMaximum: 4, criticalGates: "all", maxAttempts: 3, appealDays: 14, lessonCount: 3, questionsPerLesson: 3, optionsPerQuestion: 4, submissionFieldCount: 7, evidenceMinCharacters: 30, evidenceMaxCharacters: 1e4 } }, documentHash: hash, authorId: d.authorId, authorName: d.authorName, reviewerId: d.approval.reviewerId, reviewerName: d.approval.reviewerName, reviewedAt: d.approval.reviewedAt, publishedBy: user.userId, publishedByName: actor.name || "Workspace owner", publishedAt: now, reviewDueAt: d.reviewDueAt, availability: "available" });
      d.state = "published";
      d.publishedRef = ref;
      bump(d, actor, "published immutable private practice draft", now);
      break;
    }
    case "content-retire": {
      exact(c, ["publicationId", "reason"]);
      const p = t.content.publications.find((p2) => p2.id === c.publicationId);
      if (!p) throw new AuthoringError("Publication not found in this workspace.", 404);
      if (p.availability === "retired") throw new AuthoringError("This publication is already closed to new enrollment.", 409);
      const reason = text(c.reason, "Reason for closing new enrollment", 10, 1e3);
      p.availability = "retired";
      p.retirement = { reason, actor: user.userId, actorName: actor.name || "Workspace owner", at: now };
      break;
    }
  }
  const previousBytes = new TextEncoder().encode(JSON.stringify(original.content ?? freshAuthoring())).length, newBytes = new TextEncoder().encode(JSON.stringify(t.content)).length;
  if (c.type !== "content-retire" && newBytes > previousBytes && newBytes > AUTHORING_LIMITS.contentBytes) throw new AuthoringError("This workspace reached its pilot content-authoring limit. Existing learning and protective access controls remain available.", 413);
  return t;
}
function previewDraft(host, user, id) {
  owner(host, user);
  const d = host.content?.drafts.find((d2) => d2.id === id);
  if (!d) throw new AuthoringError("Content draft not found in this workspace.", 404);
  return { draft: copy(d), issues: validateDocument(d.document, template(host, d)), classification: AUTHORING_CLASSIFICATION };
}
function requireAvailablePublication(host, refValue, now = (/* @__PURE__ */ new Date()).toISOString()) {
  const ref = scopedRef(host, refValue);
  if (ref.scope === "global") return resolve(host, ref);
  const p = host.content?.publications.find((p2) => p2.snapshot.ref.programId === ref.programId && p2.snapshot.ref.versionId === ref.versionId);
  if (!p || p.availability !== "available") throw new AuthoringError("This private pathway is closed to new cohort offerings and enrollment.", 409);
  if (!Number.isFinite(Date.parse(now))) throw new AuthoringError("A trusted action time is required.", 400);
  if (Date.parse(p.reviewDueAt) <= Date.parse(now)) throw new AuthoringError("Content review is due before new enrollment.", 409);
  return copy(p.snapshot);
}
function projectWorkspaceContent(host, user, neededRefs) {
  const m = host.members.find((m2) => m2.userId === user.userId);
  if (!m) throw new AuthoringError("Workspace not found.", 404);
  const admin = m.active && m.roles.includes("admin"), content = host.content ?? freshAuthoring();
  const keys = new Set(neededRefs.map((ref) => contentKey(scopedRef(host, ref))));
  const versions = content.publications.filter((p) => admin || keys.has(contentKey(p.snapshot.ref))).map((p) => copy(p.snapshot));
  return { versions, ...admin ? { drafts: copy(content.drafts), publications: content.publications.map((p) => ({ id: p.id, ref: p.snapshot.ref, title: p.snapshot.program.title, availability: p.availability, classification: p.snapshot.classification, authorName: p.authorName, reviewerName: p.reviewerName, publishedAt: p.publishedAt, reviewDueAt: p.reviewDueAt, documentHash: p.documentHash, retirement: p.retirement })) } : {} };
}

// outputs/aplyd-academy-sprint/curriculum-authoring/authoring-candidate/qa-integration/trusted-registry-adapter.ts
function resolvePinnedWithRegistry(record, registry) {
  const ref = pinnedRef(record);
  return (registry ?? curriculumRegistry).resolve(ref, registry ? [ref.scope] : ["global"]);
}
function trustedPlanResolver(registry) {
  return (programId, version, record) => {
    try {
      return resolvePinnedWithRegistry(record ?? { programId, version }, registry).program;
    } catch (error) {
      if (error instanceof ContentResolutionError) return void 0;
      throw error;
    }
  };
}
export {
  AUTHORING_CLASSIFICATION,
  AUTHORING_LIMITS,
  AuthoringError,
  CONTENT_COMMANDS,
  CONTENT_VERSION,
  ContentResolutionError,
  LEGACY_CONTENT_VERSION,
  LEGACY_SOURCE_SHA256,
  applyWorkspaceContentCommand,
  canonicalJson,
  contentKey,
  contentRef,
  createCurriculumRegistry,
  currentRef,
  curriculum,
  curriculumRegistry,
  deepFreeze,
  documentHash,
  freshAuthoring,
  isContentCommand,
  pinnedRef,
  previewDraft,
  programs,
  projectWorkspaceContent,
  requireAvailablePublication,
  resolveCurrentProgram,
  resolvePinnedContent,
  resolvePinnedProgram,
  resolvePinnedWithRegistry,
  trustedPlanResolver,
  tryResolvePinnedContent,
  validateDocument,
  workspaceRegistry
};
