// Post-integration candidate: not executed against the prototype, which does not
// implement content-archive. Build with ACADEMY_AUTHORING_SOURCE set to the lead's
// actual integrated authoring module, then run this suite.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),runtime=resolve(process.env.ACADEMY_AUTHORING_SECURITY_RUNTIME??resolve(here,'runtime'));
const {applyWorkspaceContentCommand:act,programs}=await import(pathToFileURL(resolve(runtime,'authoring.mjs')).href);
const now='2026-10-05T10:00:00.000Z',due='2027-10-05T10:00:00.000Z',a={userId:'author'},r={userId:'reviewer'},l={userId:'learner'};
const host=()=>({id:'tw-11111111-1111-1111-1111-111111111111',members:[{userId:a.userId,name:'Author',active:true,roles:['admin']},{userId:r.userId,name:'Reviewer',active:true,roles:['admin']},{userId:l.userId,name:'Learner',active:true,roles:['learner']}]});
const last=t=>t.content.drafts.at(-1),sourceRef={scope:'global',programId:programs[1].id,versionId:'0.1-review-draft'},checks={sources:true,answers:true,rubric:true,safety:true,accessibility:true};
const copy=t=>act(t,a,{type:'content-copy',sourceRef},now);
const archive=(t,u=r)=>act(t,u,{type:'content-archive',draftId:last(t).id,revision:last(t).revision,reason:'Preserve this unpublished practice draft and close its active work.'},now);
test('another current owner archives history100 as event101, keeps work/history and blocks every later draft transition',async()=>{
 let t=await copy(host());for(let i=0;i<98;i++)t=await act(t,a,{type:'content-save',draftId:last(t).id,revision:last(t).revision,document:last(t).document},now);
 t=await act(t,a,{type:'content-submit',draftId:last(t).id,revision:last(t).revision,reviewerId:r.userId,reviewDueAt:due},now);
 const before=structuredClone(last(t));assert.equal(before.history.length,100);t=await archive(t);const d=last(t);
 assert.equal(d.state,'archived');assert.equal(d.history.length,101);assert.equal(d.history.at(-1).action,'archived private practice draft');assert.equal(d.history.at(-1).actor,r.userId);assert.deepEqual(d.history.slice(0,100),before.history);assert.deepEqual(d.document,before.document);assert.equal(d.revision,before.revision+1);assert.equal(d.approval,undefined);
 for(const c of [
  {type:'content-save',draftId:d.id,revision:d.revision,document:d.document},
  {type:'content-submit',draftId:d.id,revision:d.revision,reviewerId:r.userId,reviewDueAt:due},
  {type:'content-recall',draftId:d.id,revision:d.revision,reason:'An archived draft must stay read only.'},
  {type:'content-publish',draftId:d.id,revision:d.revision},
  {type:'content-archive',draftId:d.id,revision:d.revision,reason:'Duplicate archive must not add history.'},
 ])await assert.rejects(act(t,a,c,now),e=>e.status===409);
 await assert.rejects(act(t,r,{type:'content-review',draftId:d.id,revision:d.revision,decision:'approve',note:'Archived content must not receive a new review decision.',checks},now),e=>e.status===409);
 t=await copy(t);assert.equal(last(t).state,'draft');
});
test('archived drafts free active slots while the total24 document cap stops unbounded retention',async()=>{
 let t=host();for(let i=0;i<24;i++){t=await copy(t);t=await archive(t);}
 assert.equal(t.content.drafts.length,24);assert.ok(t.content.drafts.every(d=>d.state==='archived'));
 await assert.rejects(copy(t),e=>e.status===409);
});
test('archive remains owner-only, rejects revision/field injection and cannot close a publication draft',async()=>{
 let t=await copy(host()),d=last(t);await assert.rejects(archive(t,l),e=>e.status===403);
 await assert.rejects(act(t,r,{type:'content-archive',draftId:d.id,revision:d.revision-1,reason:'Stale archive must not overwrite current work.'},now),e=>e.status===409);
 await assert.rejects(act(t,r,{type:'content-archive',draftId:d.id,revision:d.revision,reason:'Unsupported actor must not be honored.',actor:a.userId},now),e=>e.status===400);
 t=await act(t,a,{type:'content-submit',draftId:d.id,revision:d.revision,reviewerId:r.userId,reviewDueAt:due},now);d=last(t);
 t=await act(t,r,{type:'content-review',draftId:d.id,revision:d.revision,decision:'approve',note:'Checked fictional source, answers, rubric and safe boundaries before publication.',checks},now);d=last(t);
 t=await act(t,a,{type:'content-publish',draftId:d.id,revision:d.revision},now);
 await assert.rejects(archive(t),e=>e.status===409);assert.equal(last(t).state,'published');assert.equal(t.content.publications.length,1);
});
