import {test} from 'node:test';
import assert from 'node:assert/strict';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {authoringRetirementReserve,authoringClosureReserve,archiveGrowth,retirementGrowth,utf8JsonBytes,checkAuthoringCapacity,checkCombinedWorkspaceCapacity,combinedClosureReserve} from './authoring-retirement-reserve.mjs';
import {archiveDraftCandidate} from './archive-command-candidate.mjs';
const here=dirname(fileURLToPath(import.meta.url)),runtime=resolve(process.env.ACADEMY_AUTHORING_SECURITY_RUNTIME??resolve(here,'runtime'));
const domain=await import(pathToFileURL(resolve(runtime,'authoring.mjs')).href),support=await import(pathToFileURL(resolve(runtime,'support.mjs')).href);
const {applyWorkspaceContentCommand:act,programs,documentHash}=domain,{applySupportCommand,supportClosureReserve}=support;
const now='2026-10-05T10:00:00.000Z',due='2027-10-05T10:00:00.000Z',a={userId:'author'},r={userId:'reviewer'};
const host=()=>({id:'tw-11111111-1111-1111-1111-111111111111',members:[{userId:a.userId,name:'Author',active:true,roles:['admin']},{userId:r.userId,name:'Reviewer',active:true,roles:['admin']},{userId:'learner',name:'Learner',active:true,roles:['learner']}],cohorts:[{id:'c-one',title:'Fictional source practice'}],learners:[],activity:[],moderation:[]});
const checks={sources:true,answers:true,rubric:true,safety:true,accessibility:true};
async function publish(t){
 t=await act(t,a,{type:'content-copy',sourceRef:{scope:'global',programId:programs[1].id,versionId:'0.1-review-draft'}},now);let d=t.content.drafts.at(-1);
 t=await act(t,a,{type:'content-submit',draftId:d.id,revision:d.revision,reviewerId:r.userId,reviewDueAt:due},now);d=t.content.drafts.at(-1);
 t=await act(t,r,{type:'content-review',draftId:d.id,revision:d.revision,decision:'approve',note:'Checked fictional source facts, answer explanations, rubric and safe practice.',checks},now);d=t.content.drafts.at(-1);
 return act(t,a,{type:'content-publish',draftId:d.id,revision:d.revision},now);
}
const retire=(t,id,u=a)=>act(t,u,{type:'content-retire',publicationId:id,reason:String.fromCharCode(0).repeat(1000)},now);
function padAuthoring(t){t.content.padding='';t.content.padding='x'.repeat(650000-authoringClosureReserve(t)-utf8JsonBytes(t.content));assert.equal(utf8JsonBytes(t.content)+authoringClosureReserve(t),650000);}
function padWorkspace(t){t.padding='';t.padding='x'.repeat(1800000-combinedClosureReserve(t,supportClosureReserve)-utf8JsonBytes(t));assert.equal(utf8JsonBytes(t)+combinedClosureReserve(t,supportClosureReserve),1800000);}
test('eight available publications can all retire at effective 650KB while immutable snapshots/hashes stay exact',async()=>{
 let t=host();for(let i=0;i<8;i++)t=await publish(t);t.members[0].name=String.fromCharCode(0).repeat(80);padAuthoring(t);
 const snapshots=t.content.publications.map(p=>JSON.stringify(p.snapshot)),hashes=t.content.publications.map(p=>p.documentHash);let reserve=authoringRetirementReserve(t);assert.ok(reserve>0);
 for(const [i,p]of t.content.publications.entries()){
  const next=await retire(t,p.id);assert.ok(checkAuthoringCapacity(t,next).newEffective<=650000);t=next;
  assert.equal(JSON.stringify(t.content.publications[i].snapshot),snapshots[i]);assert.equal(t.content.publications[i].documentHash,hashes[i]);assert.equal(await documentHash(t.content.publications[i].snapshot.program),hashes[i]);
  const remaining=authoringRetirementReserve(t);assert.ok(remaining<reserve);reserve=remaining;
 }
 assert.equal(authoringRetirementReserve(t),0);assert.ok(utf8JsonBytes(t.content)<=650000);
});
test('authoring admission cannot spend retirement room and shrinking effective legacy content remains possible',async()=>{
 const t=await publish(host());padAuthoring(t);const growth=structuredClone(t);growth.content.extra='More ordinary content';
 assert.throws(()=>checkAuthoringCapacity(t,growth),e=>e.status===413);
 const legacy=structuredClone(t);legacy.content.padding+='x'.repeat(1000);const shrink=structuredClone(legacy);shrink.content.padding=shrink.content.padding.slice(0,-100);
 assert.ok(checkAuthoringCapacity(legacy,shrink).newEffective<checkAuthoringCapacity(legacy,shrink).oldEffective);
});
test('global growth of other protective writes cannot consume either closure reserve; both final actions remain available',async()=>{
 let t=await publish(host());t.members[0].name=String.fromCharCode(0).repeat(80);t.members[2].name=String.fromCharCode(0).repeat(80);
 applySupportCommand(t,'learner',{type:'support-open',category:'access',cohortId:null,subject:'Generic fictional access question',body:'A fictional support question with no real records.',audienceAcknowledged:true},now);padWorkspace(t);
 const growth=structuredClone(t);growth.anotherProtectiveEvent='x'.repeat(50);
 assert.throws(()=>checkCombinedWorkspaceCapacity(t,growth,supportClosureReserve),e=>e.status===413);
 let next=await retire(t,t.content.publications[0].id);assert.ok(checkCombinedWorkspaceCapacity(t,next,supportClosureReserve).newEffective<=1800000);t=next;
 next=structuredClone(t);applySupportCommand(next,'learner',{type:'support-withdraw',requestId:t.support[0].id},now);
 assert.ok(checkCombinedWorkspaceCapacity(t,next,supportClosureReserve).newEffective<=1800000);assert.equal(combinedClosureReserve(next,supportClosureReserve),0);assert.ok(utf8JsonBytes(next)<=1800000);
});
test('a future larger member ID increases the reserve before accepting that identity, including inactive restoration candidates',async()=>{
 const t=await publish(host()),before=authoringRetirementReserve(t);padWorkspace(t);
 const after=structuredClone(t);after.members.push({userId:String.fromCharCode(0).repeat(1000),name:'Future owner',roles:['learner'],active:false});
 assert.ok(authoringRetirementReserve(after)>before);assert.throws(()=>checkCombinedWorkspaceCapacity(t,after,supportClosureReserve),e=>e.status===413);
});
test('reserve measures escaped UTF-8 identifiers and existing retirement-field representations exactly',async()=>{
 const t=await publish(host()),p=t.content.publications[0],actor=String.fromCharCode(0).repeat(12)+'人';
 for(const original of [p,{...p,retirement:null},{...p,retirement:{reason:'Legacy cancelled closure metadata'}}]){
  const final={...original,availability:'retired',retirement:{reason:String.fromCharCode(0).repeat(1000),actor,actorName:String.fromCharCode(0).repeat(80),at:'2000-01-01T00:00:00.000Z'}};
  assert.equal(retirementGrowth(original,actor),Math.max(0,utf8JsonBytes(final)-utf8JsonBytes(original)));
 }
 assert.equal(retirementGrowth({...p,availability:'retired'},actor),0);
});

async function withAllClosureKinds(){
 let t=host();for(let i=0;i<8;i++)t=await publish(t);
 for(let i=0;i<4;i++)t=await act(t,a,{type:'content-copy',sourceRef:{scope:'global',programId:programs[1].id,versionId:'0.1-review-draft'}},now);
 const drafts=t.content.drafts.filter(d=>d.state!=='published'),first=drafts[0];
 for(let i=0;i<98;i++){const d=t.content.drafts.find(d=>d.id===first.id);t=await act(t,a,{type:'content-save',draftId:d.id,revision:d.revision,document:d.document},now);}
 for(const id of [first.id,drafts[2].id,drafts[3].id]){const d=t.content.drafts.find(d=>d.id===id);t=await act(t,a,{type:'content-submit',draftId:d.id,revision:d.revision,reviewerId:r.userId,reviewDueAt:due},now);}
 const fourth=t.content.drafts.find(d=>d.id===drafts[3].id);t=await act(t,r,{type:'content-review',draftId:fourth.id,revision:fourth.revision,decision:'approve',note:'Checked all fictional source facts, answers, rubric and responsible-use boundaries.',checks},now);
 t.members[1].name=String.fromCharCode(0).repeat(80);return t;
}
function archive(t,id){const d=t.content.drafts.find(d=>d.id===id);return archiveDraftCandidate(t,r,{type:'content-archive',draftId:id,revision:d.revision,reason:String.fromCharCode(0).repeat(1000)},now);}
test('all eight publications and four active draft phases close at effective 650KB, including history100 final event101',async()=>{
 let t=await withAllClosureKinds();padAuthoring(t);const draftIds=t.content.drafts.filter(d=>['draft','in_review','approved'].includes(d.state)).map(d=>d.id),first=t.content.drafts.find(d=>d.id===draftIds[0]);
 assert.equal(first.history.length,100);const savedHistory=structuredClone(first.history),documents=Object.fromEntries(draftIds.map(id=>[id,JSON.stringify(t.content.drafts.find(d=>d.id===id).document)]));
 let reserve=authoringClosureReserve(t);assert.ok(reserve>authoringRetirementReserve(t));
 for(const id of draftIds){const next=archive(t,id);assert.ok(checkAuthoringCapacity(t,next).newEffective<=650000);t=next;const d=t.content.drafts.find(d=>d.id===id);assert.equal(d.state,'archived');assert.equal(JSON.stringify(d.document),documents[id]);assert.equal(d.approval,undefined);assert.ok(authoringClosureReserve(t)<reserve);reserve=authoringClosureReserve(t);await assert.rejects(act(t,a,{type:'content-publish',draftId:id,revision:d.revision},now),e=>e.status===409);}
 const closed=t.content.drafts.find(d=>d.id===draftIds[0]);assert.equal(closed.history.length,101);assert.deepEqual(closed.history.slice(0,100),savedHistory);assert.equal(closed.history.at(-1).action,'archived private practice draft');
 for(const p of t.content.publications){const next=await retire(t,p.id,r);assert.ok(checkAuthoringCapacity(t,next).newEffective<=650000);t=next;}
 assert.equal(authoringClosureReserve(t),0);assert.ok(utf8JsonBytes(t.content)<=650000);
});
test('combined 1.8MB budget protects every publication, active draft and support closure from other protective growth',async()=>{
 let t=await withAllClosureKinds();t.members[2].name=String.fromCharCode(0).repeat(80);
 applySupportCommand(t,'learner',{type:'support-open',category:'access',cohortId:null,subject:'Generic closure reserve fixture',body:'A fictional help request with no real records.',audienceAcknowledged:true},now);padWorkspace(t);
 const growth=structuredClone(t);growth.otherProtectiveEvent='More protective history';assert.throws(()=>checkCombinedWorkspaceCapacity(t,growth,supportClosureReserve),e=>e.status===413);
 for(const d of t.content.drafts.filter(d=>['draft','in_review','approved'].includes(d.state))){const next=archive(t,d.id);checkCombinedWorkspaceCapacity(t,next,supportClosureReserve);t=next;}
 for(const p of t.content.publications){const next=await retire(t,p.id,r);checkCombinedWorkspaceCapacity(t,next,supportClosureReserve);t=next;}
 const next=structuredClone(t);applySupportCommand(next,'learner',{type:'support-withdraw',requestId:t.support[0].id},now);checkCombinedWorkspaceCapacity(t,next,supportClosureReserve);assert.equal(combinedClosureReserve(next,supportClosureReserve),0);assert.ok(utf8JsonBytes(next)<=1800000);
});
test('archive reserve covers revision digit growth, state changes, clock replacement and escaped final note without erasing history',async()=>{
 let t=await act(host(),a,{type:'content-copy',sourceRef:{scope:'global',programId:programs[1].id,versionId:'0.1-review-draft'}},now);const d=t.content.drafts[0],actor=String.fromCharCode(0).repeat(12)+'人';
 for(const state of ['draft','in_review','approved']){
  const original={...structuredClone(d),state,revision:99,updatedAt:'2000-01-01Z'};
  const final={...original,state:'archived',revision:100,updatedAt:'2000-01-01T00:00:00.000Z',history:[...original.history,{id:'0'.repeat(36),actor,actorName:String.fromCharCode(0).repeat(80),action:'archived private practice draft',at:'2000-01-01T00:00:00.000Z',note:String.fromCharCode(0).repeat(1000)}]};
  assert.equal(archiveGrowth(original,actor),Math.max(0,utf8JsonBytes(final)-utf8JsonBytes(original)));
 }
 assert.equal(archiveGrowth({...d,state:'archived'},actor),0);assert.equal(archiveGrowth({...d,state:'published'},actor),0);
});
