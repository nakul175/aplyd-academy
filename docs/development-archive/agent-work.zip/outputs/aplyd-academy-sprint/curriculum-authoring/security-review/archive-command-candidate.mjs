// Isolated transition for closure-capacity tests. This is NOT the Site's command.
// The lead implements the same terminal transition under the Team CAS.
export class ArchiveCandidateError extends Error{constructor(message,status=422){super(message);this.status=status;}}
export function archiveDraftCandidate(original,user,command,now){
 const t=structuredClone(original),m=t.members.find(m=>m.userId===user.userId&&m.active&&m.roles.includes('admin'));
 if(!m)throw new ArchiveCandidateError('A current workspace owner is required.',403);
 if(!command||command.type!=='content-archive'||Object.keys(command).some(k=>!['type','draftId','revision','reason'].includes(k)))throw new ArchiveCandidateError('Unsupported archive command fields.',400);
 const d=t.content?.drafts.find(d=>d.id===command.draftId);if(!d)throw new ArchiveCandidateError('Workspace draft not found.',404);
 if(!Number.isInteger(command.revision)||d.revision!==command.revision)throw new ArchiveCandidateError('Refresh the current draft revision.',409);
 if(!['draft','in_review','approved'].includes(d.state))throw new ArchiveCandidateError('Only an unpublished active draft can be archived.',409);
 if(typeof command.reason!=='string'||command.reason.trim().length<10||command.reason.length>1000)throw new ArchiveCandidateError('Archive reason needs 10–1000 characters.');
 const clock=new Date(now).toISOString();if(clock.length!==24)throw new ArchiveCandidateError('Use a canonical four-digit-year timestamp.',400);
 if(d.history.length>100)throw new ArchiveCandidateError('This draft is already beyond the final archive allowance.',409);
 d.state='archived';d.revision++;d.updatedAt=clock;delete d.approval;
 d.history.push({id:crypto.randomUUID(),actor:user.userId,actorName:String(m.name||'Workspace owner').slice(0,80),action:'archived private practice draft',at:clock,note:command.reason.trim()});
 return t;
}
