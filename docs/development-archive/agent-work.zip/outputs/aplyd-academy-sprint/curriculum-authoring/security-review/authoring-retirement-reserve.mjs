// Isolated candidate helper. Do not treat this as integrated production code.
// Assumptions to enforce in the authoring mutation: reason <=1000 UTF-16 units,
// every stored actor name <=80 UTF-16 units, and canonical 24-character clock.
export const AUTHORING_CAPACITY=650000,WORKSPACE_CAPACITY=1800000;
export const utf8JsonBytes=value=>new TextEncoder().encode(JSON.stringify(value)).length;
export const authoringSnapshotName=value=>String(value||'Workspace owner').slice(0,80);
const WORST_REASON=String.fromCharCode(0).repeat(1000),WORST_NAME=String.fromCharCode(0).repeat(80),CLOCK='2000-01-01T00:00:00.000Z';
export function largestSavedActorId(host){
 let actor='';for(const m of host.members??[]){if(typeof m.userId!=='string')throw new TypeError('Saved member identities must be strings.');if(utf8JsonBytes(m.userId)>utf8JsonBytes(actor))actor=m.userId;}return actor;
}
export function retirementGrowth(publication,actorId){
 if(publication.availability!=='available')return 0;
 // Serialize the actual immutable publication shape on both sides rather than
 // guessing key/comma overhead or existing retirement-field representation.
 const final={...publication,availability:'retired',retirement:{reason:WORST_REASON,actor:actorId,actorName:WORST_NAME,at:CLOCK}};
 return Math.max(0,utf8JsonBytes(final)-utf8JsonBytes(publication));
}
export function authoringRetirementReserve(host){
 const actor=largestSavedActorId(host);return (host.content?.publications??[]).reduce((total,p)=>total+retirementGrowth(p,actor),0);
}
export function archiveGrowth(draft,actorId){
 if(!['draft','in_review','approved'].includes(draft.state))return 0;
 const final={...draft,state:'archived',revision:draft.revision+1,updatedAt:CLOCK,history:[...draft.history,{id:'0'.repeat(36),actor:actorId,actorName:WORST_NAME,action:'archived private practice draft',at:CLOCK,note:WORST_REASON}]};
 // Retain any prior approval in the WORST shape. An implementation that clears
 // it on archive adds fewer bytes and remains covered by this conservative bound.
 return Math.max(0,utf8JsonBytes(final)-utf8JsonBytes(draft));
}
export function authoringClosureReserve(host){
 const actor=largestSavedActorId(host);return authoringRetirementReserve(host)+(host.content?.drafts??[]).reduce((total,d)=>total+archiveGrowth(d,actor),0);
}
export function checkAuthoringCapacity(before,after){
 const oldBytes=utf8JsonBytes(before.content??{drafts:[],publications:[]}),newBytes=utf8JsonBytes(after.content??{drafts:[],publications:[]});
 const oldEffective=oldBytes+authoringClosureReserve(before),newEffective=newBytes+authoringClosureReserve(after);
 if(newEffective>oldEffective&&newEffective>AUTHORING_CAPACITY)throw Object.assign(new Error('Authoring must retain publication retirement capacity.'),{status:413});
 return {oldBytes,newBytes,oldEffective,newEffective};
}
export function combinedClosureReserve(host,supportReserve=()=>0){return authoringClosureReserve(host)+supportReserve(host);}
export function checkCombinedWorkspaceCapacity(before,after,supportReserve=()=>0){
 const oldEffective=utf8JsonBytes(before)+combinedClosureReserve(before,supportReserve),newEffective=utf8JsonBytes(after)+combinedClosureReserve(after,supportReserve);
 if(newEffective>oldEffective&&newEffective>WORKSPACE_CAPACITY)throw Object.assign(new Error('Other writes must retain support and publication closure capacity.'),{status:413});
 return {oldEffective,newEffective};
}
