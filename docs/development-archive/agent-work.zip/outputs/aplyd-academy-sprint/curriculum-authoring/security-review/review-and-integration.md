# Curriculum authoring security review

This review reads the outside-checkout authoring candidate and the integrated app. It edits only review artifacts outside the checkout. The examples use fictional users and cloned fixtures; no Site, API, D1 data, archive seed or publication has been changed by this workstream. The final integrated Team suite has ten passing tests against a fresh, source-stable bundle.

## Provenance and authority

The candidate's central publication checks are sound within the documented trusted-state model: only current owners can act, another assigned current owner approves, the approved document hash and document revision must still agree, and the publisher checks the reviewer's current authority. Published documents are copied into a new scoped version and cannot be edited through the draft commands. Retirement changes only availability metadata and leaves the snapshot/hash intact. The existing authoring test suite covers these domain guards.

The async hash must remain inside the original Team revision fence. The API must await the domain result and commit the Team update, audit and any archive packet atomically against that original revision. A membership or reviewer change that wins while hashing must make the content commit fail. A pure candidate does not prove that database race. Root's authoring API candidate is the place to test it.

Approval records are durable review attestations, not independent authorization tokens. Current permission is required for each new review/publication command. A restored reviewer role may satisfy the current-role rule for an unchanged old approval; if the product requires a fresh review after any revocation, that must be an explicit additional reconciliation policy. The current specification does not promise that stronger rule.

Keep fixed classification, language, audience and assessment policy outside author editing. The document hash binds the reviewed program; server-selected identity/classification/policy and publication provenance must remain immutable alongside it. Existing historical rows use their exact snapshot, never a newer catalog document. Source, question and rubric comparisons must show the reviewer's actual submitted revision.

## Concrete validation findings

| Finding | Current evidence | Required handling |
| --- | --- | --- |
| Farmer seed has legacy string source rows | Originally reproduced six structural errors. The authoring workstream added normalization; the latest seed regression passes for all three seeds. | Normalize only the copied private document into stable `{sourceId, content}` rows; preserve archive bytes and existing object references. |
| Duplicate source references | Integrated regression passes. The farmer seed intentionally teaches a copied transaction. | Repeated trimmed IDs require an exact `duplicateOf` marker referring to the earlier ID and a meaningful `sourceNote`; unmarked or mismatched repeats fail. |
| Empty source facts | Integrated regression passes, including blank/null metadata-only rows. | Require a meaningful primitive fact excluding `sourceId`, `duplicateOf`, `sourceNote` and `type`. Numeric zero and boolean false are meaningful; whitespace strings/null alone are incomplete. |
| Indistinguishable answers | Integrated regression passes. | Reject duplicate trimmed options. Different indices must describe different visible choices. |
| Understated time | Integrated regression passes. | Require whole total minutes at least the sum of lesson minutes; use the exact snapshot's estimates everywhere. |
| History100 active draft dead end | Integrated Team regression passes for final event101. | Any current owner can archive an unpublished active draft. Retain document/history and any approval as historical evidence; terminal state forbids save, submit, recall, review, publish and repeat archive. Free active slots while retaining the total24 document cap. |

Text/source/answer/rubric factual coherence still requires human review. Structural checks do not demonstrate that every explanation follows the supplied facts. Present sources, displayed lesson text, questions/options/correct answer and explanation together during review; show differences from the base version and require the existing five reviewer declarations. Do not claim automated factual verification.

Source field names should be trimmed nonempty ordinary labels. Continue rejecting prototype names, nested objects, nonfinite numbers, control text and unsupported document fields. Required missing text may remain an incomplete saved draft but must prevent submission, approval and publication. IDs, gate structure and the fixed policy remain locked.

## Closure-capacity contract

Root integrated `authoringClosureReserve` to protect both available publications and unpublished active drafts. The standalone proposal helper `authoring-retirement-reserve.mjs` remains outside the app as review evidence; production uses the integrated TypeScript implementation.

- `authoringRetirementReserve` remains publication-only for compatibility. `authoringClosureReserve` adds `draft`, `in_review` and `approved` draft closures. Published/archived drafts and retired publications require no further closure reservation.
- Use the largest **serialized JSON UTF-8** current member ID, including inactive members. New member acceptance changes the reserve and must pass both admission budgets. Restoring an existing role cannot introduce an unreserved identity.
- Clamp every author, reviewer, publisher, history and closure name snapshot to80 UTF-16 units. Normalize the trusted server timestamp to the24-character four-digit-year ISO form. These are assumptions of the bound.
- Retirement's worst shape changes `available` to `retired` and adds `{reason,actor,actorName,at}` with reason1000 units, name80 units and canonical clock24. NUL is the six-byte JSON worst case per UTF-16 unit.
- Archive's worst shape changes state to`archived`, increments revision, replaces updatedAt, and appends `{id36,actor,actorName80,action:'archived private practice draft',at24,note1000}`. The reserve retains any old approval, matching the final command's historical-evidence policy.
- The helper measures actual serialized before/after shapes, including commas, key overhead, state length, revision digit growth and an existing retirement field. It does not delete body/history to make space.
- Every authoring admission checks content bytes plus authoring closure reserve against650000, allowing shrinking effective legacy content. Every growing full-workspace admission checks Team bytes plus **support closure reserve plus authoring closure reserve** against1800000, including unrelated protective writes. Keep the existing ordinary1200000 content boundary and protective action classification.
- `content-retire` and `content-archive` are protective. Each final action consumes its own reservation; remaining closures keep theirs. After all final actions, raw bytes remain under the corresponding cap.
- Do not add an `archivedAt` or separate archive object without including its bytes in the bound. Root intentionally omits hot `Team.activity` growth for retire/archive; inline closure history and the durable D1 action audit provide provenance. Other content activity names are clipped to80 and timestamps normalized to24, verified by the final integrated regression.

Eight isolated proposal capacity tests executed and passed. Separately, the final integrated Team suite proves all eight available publications and four active draft phases can close at the effective650KB boundary while retaining bodies, hashes and histories. At the effective1.8MB boundary, unrelated protective growth fails while all authoring closures and a support withdrawal succeed. A wider new member ID is rejected when it would consume the reserved650KB content capacity. These are pure command/storage admission results; they do not prove the database transaction.

## Scope and replay integration

Never mutate or merge into the global registry. Resolve each Team's exact canonical snapshots in a request-local registry. Prefer an explicit trusted `{registry,allowedScopes:['global',team.id]}` context. If retaining the narrower sixth-argument registry capability, make its constructor reject publications whose snapshot scope is not exactly the host Team, and never construct it from multiple private workspaces.

The old proposed adapter derived allowed scope from the requested reference when a registry was supplied. Root instead integrated an explicit trusted content context. The final regression intentionally assembles a mixed registry and confirms a foreign snapshot is denied by the resolver and engine, becomes unavailable to planning, and is absent from the learner projection; the current Team's exact snapshot still resolves. The old prototype also exposed a corrupt canonical-publication lookup observation, **not a demonstrated client exploit**: exact-key command validation prevents clients from supplying a registry or publication record. Keep full-key and host-scope checks when changing these trusted constructors.

Compute needed references only from the server's already-authorized own enrollments, visible cohorts and current assignments. Removed members receive their own historical definitions; drafts, notes and unrelated definitions remain hidden. API query/body fields must never choose neededRefs, snapshots, registry, scope policy, actors or timestamps. Workspace switching replaces client definitions and retains the existing fetch-sequence fence.

Current owner authority must be checked before replaying a content command. Replaying an already committed action may return the current safe projection but must never provide owner draft fields after role loss. Removed-member replay remains forbidden. Same action ID with another command body remains409. New publication/closure actions still require the expected Team and draft revisions.

## Executed tests and remaining limits

- `retirement-reserve.test.mjs`:8 tests passed against the isolated helper and labeled archive transition.
- `authoring-required-regression.test.mjs`: all5 passed against an actual integrated bundle after the four reproduced prototype findings were fixed. It covers all three seed copies plus structural consistency.
- `integrated-team-security.test.mjs`: all10 passed against a fresh integrated bundle. Covers exact Team error translation, history100 closure, approval retention, terminal controls, both capacity boundaries, mixed-registry scope denial, immutable archive seed bytes, intentional duplicate markers, total24 cap, metadata/quiz/time validation, bounded names/clocks, and member-ID reservation growth.
- `authoring-observations.mjs`: executed against the old prototype; `prototype-observations.json` is historical evidence, not the final app behavior.
- `authoring-integrated-closures.test.mjs`: unexecuted older candidate, superseded for integrated evidence by `integrated-team-security.test.mjs`.
- Root's authoring domain/API/browser suites remain separate evidence. This workstream claims no new HTTP, D1, browser, hosted-identity or publication result.

Build review bundles from the project root:

```sh
node outputs/aplyd-academy-sprint/curriculum-authoring/security-review/build-integrated-review.mjs
node --test outputs/aplyd-academy-sprint/curriculum-authoring/security-review/integrated-team-security.test.mjs
```

`ACADEMY_APP_PATH` selects the actual checkout; `ACADEMY_INTEGRATED_SECURITY_RUNTIME` selects the bundle directory. The integrated builder hashes its six actual source entries and confirms they did not change during bundling. All class-sensitive checks share one bundle to avoid duplicate Error-class artifacts. `archive-security-entry.ts` is the copyable entry source; `copy-and-run.txt` gives exact test/entry targets and execution instructions.
