import assert from 'node:assert/strict';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {writeFileSync} from 'node:fs';
const here=dirname(fileURLToPath(import.meta.url)),runtime=resolve(process.env.ACADEMY_AUTHORING_SECURITY_RUNTIME??resolve(here,'runtime'));
const d=await import(pathToFileURL(resolve(runtime,'authoring.mjs')).href);
const {applyWorkspaceContentCommand:act,programs,previewDraft,validateDocument,requireAvailablePublication,createCurriculumRegistry,resolvePinnedWithRegistry}=d;
const now='2026-10-05T10:00:00.000Z',due='2027-10-05T10:00:00.000Z',a={userId:'author'},r={userId:'reviewer'};
const host=()=>({id:'tw-11111111-1111-1111-1111-111111111111',members:[{userId:a.userId,name:'Author',active:true,roles:['admin']},{userId:r.userId,name:'Reviewer',active:true,roles:['admin']}],cohorts:[]});
const last=t=>t.content.drafts.at(-1),checks={sources:true,answers:true,rubric:true,safety:true,accessibility:true};
const copy=(p=programs[1])=>act(host(),a,{type:'content-copy',sourceRef:{scope:'global',programId:p.id,versionId:'0.1-review-draft'}},now);
const submit=t=>act(t,a,{type:'content-submit',draftId:last(t).id,revision:last(t).revision,reviewerId:r.userId,reviewDueAt:due},now);
const approve=t=>act(t,r,{type:'content-review',draftId:last(t).id,revision:last(t).revision,decision:'approve',note:'Fictional source, quiz, rubric and responsible-use checks were declared.',checks},now);
const publish=t=>act(t,a,{type:'content-publish',draftId:last(t).id,revision:last(t).revision},now);
const observations={scope:'Outside-checkout prototype observations; no API, D1, hosted or client exploit is claimed.',seedCopy:[],shapeAndConsistency:{},lifecycle:{},trustedRegistry:{}};
for(const p of programs){const t=await copy(p);observations.seedCopy.push({programId:p.id,issues:previewDraft(t,a,last(t).id).issues});}
let t=await copy(),expected=structuredClone(last(t).document);
const changes={
 duplicateSourceId:doc=>doc.lessons[0].exercise.sourcePacket[1].sourceId=doc.lessons[0].exercise.sourcePacket[0].sourceId,
 emptySourceFact:doc=>doc.lessons[0].exercise.sourcePacket=[{sourceId:'F-1',content:''}],
 duplicateAnswerOption:doc=>doc.lessons[0].quiz[0].options[1]=doc.lessons[0].quiz[0].options[0],
 inconsistentTime:doc=>doc.estimatedMinutes=5,
};
for(const [name,change]of Object.entries(changes)){const doc=structuredClone(expected);change(doc);observations.shapeAndConsistency[name]={issues:validateDocument(doc,expected)};}
let history=await copy();for(let i=0;i<98;i++)history=await act(history,a,{type:'content-save',draftId:last(history).id,revision:last(history).revision,document:last(history).document},now);history=await submit(history);
observations.lifecycle.inReviewAtLimit={historyLength:last(history).history.length,state:last(history).state};
for(const [name,u,c]of [
 ['approve',r,{type:'content-review',draftId:last(history).id,revision:last(history).revision,decision:'approve',note:'Checked the complete fictional exercise and required review declarations.',checks}],
 ['recall',a,{type:'content-recall',draftId:last(history).id,revision:last(history).revision,reason:'Stop this review and preserve the latest draft safely.'}],
]){try{await act(history,u,c,now);observations.lifecycle[name]={accepted:true};}catch(e){observations.lifecycle[name]={accepted:false,status:e.status,error:e.message};}}
t=await publish(await approve(await submit(await copy())));const p=t.content.publications[0];
const foreign={...structuredClone(p.snapshot),ref:{...p.snapshot.ref,scope:'tw-22222222-2222-2222-2222-222222222222'},program:{...structuredClone(p.snapshot.program),title:'FOREIGN WORKSPACE CANARY'}};
const mixed=createCurriculumRegistry([p.snapshot,foreign]);
observations.trustedRegistry.refDerivedAllowedScope=resolvePinnedWithRegistry({programId:foreign.ref.programId,version:foreign.ref.versionId,contentRef:foreign.ref},mixed).program.title;
const corrupt=structuredClone(t);corrupt.content.publications[0].snapshot=foreign;
observations.trustedRegistry.corruptAvailabilityLookup=requireAvailablePublication(corrupt,p.snapshot.ref,now).ref;
// These are corruption/misassembled-trusted-context observations only. Client
// exact-key validation does not permit submitting either registry or publication.
// Seed normalization may be fixed by the authoring workstream between review
// rounds. Record current observations rather than asserting the earlier defect.
assert.equal(observations.lifecycle.approve.status,409);assert.equal(observations.lifecycle.recall.status,409);
writeFileSync(resolve(here,'prototype-observations.json'),JSON.stringify(observations,null,2));console.log(JSON.stringify(observations));
