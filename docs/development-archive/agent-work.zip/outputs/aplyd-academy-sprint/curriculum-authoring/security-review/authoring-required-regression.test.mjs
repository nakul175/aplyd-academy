// Deliberately failing baseline tests for review gaps. Do not label these passed
// until the lead implements and reruns the relevant constraints.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),runtime=resolve(process.env.ACADEMY_AUTHORING_SECURITY_RUNTIME??resolve(here,'runtime'));
const module=resolve(process.env.ACADEMY_AUTHORING_SECURITY_MODULE??resolve(runtime,'authoring.mjs'));
const {applyWorkspaceContentCommand:act,programs,previewDraft,validateDocument}=await import(pathToFileURL(module).href);
const a={userId:'author'},r={userId:'reviewer'},now='2026-10-05T10:00:00.000Z';
const host=()=>({id:'tw-11111111-1111-1111-1111-111111111111',members:[{userId:a.userId,name:'Author',active:true,roles:['admin']},{userId:r.userId,name:'Reviewer',active:true,roles:['admin']}]});
async function copied(p=programs[1]){return act(host(),a,{type:'content-copy',sourceRef:{scope:'global',programId:p.id,versionId:'0.1-review-draft'}},now);}
const doc=t=>t.content.drafts.at(-1).document;
test('every offered seed copies into a structurally complete private draft without modifying archived sources',async()=>{
 for(const p of programs){const before=JSON.stringify(p),t=await copied(p),d=t.content.drafts.at(-1);assert.deepEqual(previewDraft(t,a,d.id).issues,[],p.id+' must be usable immediately.');assert.equal(JSON.stringify(p),before);}
});
test('source references must be unique within an exercise after trimming',async()=>{
 const t=await copied(),expected=structuredClone(doc(t)),changed=structuredClone(expected);
 changed.lessons[0].exercise.sourcePacket[1].sourceId=' '+changed.lessons[0].exercise.sourcePacket[0].sourceId+' ';
 assert.ok(validateDocument(changed,expected).some(i=>i.path.includes('sourcePacket')),'Duplicate source references need an actionable validation issue.');
});
test('a source record requires at least one meaningful fact rather than empty/null placeholders',async()=>{
 const t=await copied(),expected=structuredClone(doc(t)),changed=structuredClone(expected);
 changed.lessons[0].exercise.sourcePacket=[{sourceId:'F-1',content:'',missing:null}];
 assert.ok(validateDocument(changed,expected).some(i=>i.path.includes('sourcePacket')),'Empty source evidence must not be ready for review.');
});
test('knowledge-check options must have distinct trimmed text',async()=>{
 const t=await copied(),expected=structuredClone(doc(t)),changed=structuredClone(expected);
 changed.lessons[0].quiz[0].options[1]=' '+changed.lessons[0].quiz[0].options[0]+' ';
 assert.ok(validateDocument(changed,expected).some(i=>i.path.includes('quiz')),'Identical options make the answer index impossible to distinguish.');
});
test('total estimated learning minutes cannot understate the sum of lesson estimates',async()=>{
 const t=await copied(),expected=structuredClone(doc(t)),changed=structuredClone(expected);changed.estimatedMinutes=5;
 assert.ok(validateDocument(changed,expected).some(i=>i.path.includes('estimatedMinutes')),'Total minutes must cover the listed lessons.');
});
