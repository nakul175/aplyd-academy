// Only substituted in isolated read-only QA bundles. Never copy into the Site.
import * as baseline from '../resolver-candidate/academy-curriculum';
export * from '../resolver-candidate/academy-curriculum';

export const CONTENT_VERSION='qa-only-latest-v2';
const latest=structuredClone(baseline.curriculum);
(latest as any).contentVersion=CONTENT_VERSION;
for(const p of latest.pathways as any[]){
 p.title='QA changed latest title: '+p.title;
 p.summary='QA changed latest summary: '+p.summary;
 for(const r of p.practicalAssessment.rubric)r.dimension='QA changed latest rubric: '+r.dimension;
}
export const curriculum=baseline.deepFreeze(latest);
export const programs=curriculum.pathways;
const original=baseline.programs.map(program=>baseline.resolvePinnedContent({programId:program.id,version:baseline.LEGACY_CONTENT_VERSION}));
const changed=programs.map(program=>({ref:baseline.contentRef({scope:'global',programId:program.id,versionId:CONTENT_VERSION}),program,language:curriculum.language,audience:curriculum.audience,classification:curriculum.status}));
export const curriculumRegistry=baseline.createCurriculumRegistry([...original,...changed]);
export function currentRef(programId:string){return baseline.contentRef({scope:'global',programId,versionId:CONTENT_VERSION})}
export function resolveCurrentProgram(programId:string){return curriculumRegistry.resolve(currentRef(programId)).program}
export function resolvePinnedContent(record:unknown,allowedScopes?:readonly baseline.ContentScope[]){return curriculumRegistry.resolve(baseline.pinnedRef(record),allowedScopes)}
export function resolvePinnedProgram(record:unknown,allowedScopes?:readonly baseline.ContentScope[]){return resolvePinnedContent(record,allowedScopes).program}
export function tryResolvePinnedContent(record:unknown,allowedScopes?:readonly baseline.ContentScope[]){
 try{return {available:true as const,snapshot:resolvePinnedContent(record,allowedScopes)}}
 catch(error){if(error instanceof baseline.ContentResolutionError)return {available:false as const,message:error.message};throw error}
}
export default curriculum;
