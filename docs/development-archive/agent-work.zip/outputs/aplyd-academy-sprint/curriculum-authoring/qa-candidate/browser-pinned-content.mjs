// Read-only UI fixtures intercept API reads. No enrollment, content or decision is saved.
import {chromium} from '/Users/athena/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {writeFile,mkdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {freshWorkspace,applyCommand,programs,CONTENT_VERSION} from './.compiled/engine.mjs';

const folder=path.dirname(fileURLToPath(import.meta.url)),origin=process.env.ACADEMY_QA_ORIGIN||'http://127.0.0.1:8787';
const p=programs.find(p=>p.id==='msme-customer-operations'),now='2026-10-05T09:00:00.000Z';
await mkdir(path.join(folder,'browser-evidence'),{recursive:true});
function fixture(stage,variant){
 let state=applyCommand(freshWorkspace(),{type:'enroll',programId:p.id},now),e=state.enrollments[0];
 e.completed=p.lessons.map(l=>l.id);
 e.attempts=[{id:'qa-saved-submission',number:1,fields:Object.fromEntries(p.practicalAssessment.submissionPrompts.map(f=>[f.id,'Fictional saved submitted evidence; this must never be reviewed against a newer rubric.'])),submittedAt:now,assisted:false,decision:null}];
 if(stage==='credentials')e.record={id:'qa-preserved-record',title:'Stored historical record title',claim:'Stored historical claim from original review',contentVersion:'unknown-pinned-version',kind:'Nonaccredited practice completion',status:'active',issuedAt:now,issuer:'Fictional private QA fixture',share:false};
 if(variant==='missing-legacy'){delete e.contentRef;delete e.version}
 if(variant==='unknown-legacy'){delete e.contentRef;e.version='unknown-pinned-version'}
 if(variant==='mixed-explicit')e.contentRef={scope:'global',programId:p.id,versionId:'unknown-explicit-version'};
 return state;
}
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
const results=[];
try{
 for(const variant of ['unknown-legacy','missing-legacy','mixed-explicit'])for(const stage of ['learn','studio','credentials']){
  const errors=[],mutations=[],state=fixture(stage,variant),context=await browser.newContext({viewport:{width:1100,height:900},extraHTTPHeaders:{'oai-authenticated-user-id':'curriculum-readonly-'+crypto.randomUUID(),'oai-authenticated-user-email':'readonly@curriculum.test'}}),page=await context.newPage();
  page.on('pageerror',error=>errors.push(error.message));
  await page.route('**/api/academy',async route=>{if(route.request().method()!=='GET'){mutations.push(route.request().method());return route.fulfill({status:409,contentType:'application/json',body:JSON.stringify({error:'QA fixture refuses all mutations.'})})}return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({state,revision:1,programs,user:{displayName:'Learner'},mode:'private-pilot'})})});
  await page.route('**/api/teams',route=>route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({workspaces:[]})}));
  const row={variant,stage,passed:false,pageErrors:errors,mutations};
  try{
   await page.goto(origin+'/#'+(stage==='learn'?'learn/'+p.id:stage));
   await page.getByText('Saved privately',{exact:true}).waitFor({timeout:15000});
   if(stage==='studio'){
    const queue=page.locator('.review-queue button');
    if(await queue.count()&&await queue.first().isEnabled())await queue.first().click();
   }
   if(stage==='credentials')await page.getByText('Record provenance & limits',{exact:true}).click();
   await page.waitForTimeout(150);
   const text=await page.locator('main').innerText();
   assert.match(text,/unavailable|invalid|references? disagree|reference is invalid|content.*not available/i);
   assert.ok(!text.includes(p.lessons[0].lessonText),'Current lesson text must not replace missing historical content.');
   assert.ok(!text.includes(p.practicalAssessment.scenario),'Current practical scenario must not replace missing historical content.');
   for(const r of p.practicalAssessment.rubric)assert.ok(!text.includes(r.anchors['3']),'Current rubric anchors must not replace missing historical content.');
   assert.equal(await page.getByRole('button',{name:'Save assessment decision',exact:true}).count(),0);
   if(stage==='credentials'){
    assert.ok(text.includes('Stored historical record title'));
    assert.ok(text.includes('Stored historical claim from original review'));
    const download=page.getByRole('button',{name:'Download my record',exact:true});
    assert.equal(await download.count(),1);
    assert.equal(await download.isEnabled(),true);
   }
   assert.deepEqual(errors,[]);assert.deepEqual(mutations,[]);
   row.passed=true;
  }catch(error){row.error=error.message}
  await page.screenshot({path:path.join(folder,'browser-evidence',variant+'-'+stage+'.png'),fullPage:true});
  results.push(row);await context.close();
 }
 // Known -> unavailable -> known review selection verifies wrapper/child hook stability.
 const errors=[],mutations=[],context=await browser.newContext({viewport:{width:1100,height:900},extraHTTPHeaders:{'oai-authenticated-user-id':'curriculum-switch-'+crypto.randomUUID(),'oai-authenticated-user-email':'readonly@curriculum.test'}}),page=await context.newPage();
 page.on('pageerror',error=>errors.push(error.message));
 const state=fixture('studio','unknown-legacy'),unavailable=state.enrollments[0];
 const validState=applyCommand(freshWorkspace(),{type:'enroll',programId:'farmer-work-records'},now),valid=validState.enrollments[0];
 valid.completed=programs.find(p=>p.id===valid.programId).lessons.map(l=>l.id);
 valid.attempts=[{id:'qa-valid-submission',number:1,fields:Object.fromEntries(programs.find(p=>p.id===valid.programId).practicalAssessment.submissionPrompts.map(f=>[f.id,'Fictional valid source-bound submitted response with checks and permitted inputs.'])),submittedAt:now,assisted:false,decision:null}];
 state.enrollments=[valid,unavailable];
 await page.route('**/api/academy',route=>{if(route.request().method()!=='GET'){mutations.push(route.request().method());return route.fulfill({status:409,contentType:'application/json',body:JSON.stringify({error:'QA fixture refuses mutations.'})})}return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({state,revision:1,programs,user:{displayName:'Learner'},mode:'private-pilot'})})});
 await page.route('**/api/teams',route=>route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({workspaces:[]})}));
 const row={variant:'known-unavailable-known',stage:'studio-switch',passed:false,pageErrors:errors,mutations};
 try{
  await page.goto(origin+'/#studio');await page.getByText('Saved privately',{exact:true}).waitFor({timeout:15000});
  await page.locator('.review-queue button').nth(0).click();await page.getByRole('heading',{name:'Review practical evidence',exact:true}).waitFor();
  await page.locator('.review-queue button').nth(1).click();await page.getByRole('heading',{name:'Pinned review content unavailable',exact:true}).waitFor();
  await page.locator('.review-queue button').nth(0).click();await page.getByRole('heading',{name:'Review practical evidence',exact:true}).waitFor();
  assert.deepEqual(errors,[]);assert.deepEqual(mutations,[]);row.passed=true;
 }catch(error){row.error=error.message}
 await page.screenshot({path:path.join(folder,'browser-evidence','review-switch.png'),fullPage:true});results.push(row);await context.close();
}finally{await browser.close()}
const evidence={status:'Actual local built UI with intercepted read-only malformed-history fixtures',origin,checkedAt:new Date().toISOString(),cases:results,passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).length};
await writeFile(path.join(folder,'browser-evidence','results.json'),JSON.stringify(evidence,null,2)+'\n');
console.log(JSON.stringify({passed:evidence.passed,failed:evidence.failed,artifact:path.join(folder,'browser-evidence','results.json')}));
if(evidence.failed)process.exitCode=1;
