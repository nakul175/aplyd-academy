import {readFile,mkdir,writeFile,access,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';

const folder=path.dirname(fileURLToPath(import.meta.url));
const workspace=path.resolve(folder,'../../../..');
const checkout=process.env.ACADEMY_QA_CHECKOUT||path.join(workspace,'work/aplyd-academy');
const output=path.join(folder,'.compiled');
await mkdir(output,{recursive:true});
const {build}=await import(pathToFileURL(path.join(checkout,'node_modules/esbuild/lib/main.js')));
const entries=(await readdir(path.join(checkout,'lib'))).filter(file=>/\.(?:m?ts|json)$/.test(file)).sort().map(file=>'lib/'+file);
const resolver=path.join(checkout,'lib/academy-curriculum.ts');
let resolverPresent=true;try{await access(resolver)}catch{resolverPresent=false}
if(resolverPresent)entries.push('lib/curriculum-versions/0.1-review-draft.json');
async function hashes(){return Object.fromEntries(await Promise.all(entries.map(async file=>[file,createHash('sha256').update(await readFile(path.join(checkout,file))).digest('hex')])))}
const before=await hashes();
await build({entryPoints:[path.join(checkout,'lib/academy-engine.ts')],bundle:true,format:'esm',platform:'node',outfile:path.join(output,'engine.mjs')});
await build({entryPoints:[path.join(checkout,'lib/academy-teams.ts')],bundle:true,format:'esm',platform:'node',outfile:path.join(output,'teams.mjs')});
if(resolverPresent){
 await build({entryPoints:[resolver],bundle:true,format:'esm',platform:'node',outfile:path.join(output,'resolver.mjs')});
 const plugin={name:'qa-only-later-catalog',setup(build){build.onLoad({filter:/academy-curriculum\.ts$/},async args=>{
  if(path.resolve(args.path)!==path.resolve(resolver))return undefined;
  return {loader:'ts',resolveDir:folder,contents:await readFile(path.join(folder,'later-catalog.fixture.ts'),'utf8')};
 })}};
 await build({entryPoints:[path.join(checkout,'lib/academy-engine.ts')],bundle:true,format:'esm',platform:'node',plugins:[plugin],outfile:path.join(output,'next-engine.mjs')});
 await build({entryPoints:[path.join(checkout,'lib/academy-teams.ts')],bundle:true,format:'esm',platform:'node',plugins:[plugin],outfile:path.join(output,'next-teams.mjs')});
}
const after=await hashes();
if(JSON.stringify(before)!==JSON.stringify(after))throw new Error('Checkout changed while creating read-only QA bundles; rerun against a stable candidate.');
const metadata={status:'Read-only source bundles; output files only',createdAt:new Date().toISOString(),checkout,resolverPresent,sourceSha256:before,laterCatalog:'test-only esbuild replacement; no production content changes'};
await writeFile(path.join(output,'source-evidence.json'),JSON.stringify(metadata,null,2)+'\n');
console.log(JSON.stringify({resolverPresent,output,sourceStable:true}));
