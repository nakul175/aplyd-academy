import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile,access} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
import * as engine from './.compiled/engine.mjs';
import * as teams from './.compiled/teams.mjs';

const root=path.dirname(fileURLToPath(import.meta.url)),manifest=JSON.parse(await readFile(new URL('./.compiled/source-evidence.json',import.meta.url),'utf8'));
const p=engine.programs.find(p=>p.id==='msme-customer-operations'),now='2026-10-05T09:00:00.000Z';
const apply=(s,c)=>engine.applyCommand(s,c,now),evidence=()=>Object.fromEntries(p.practicalAssessment.submissionPrompts.map(f=>[f.id,'Fictional source-bound work with checked figures, handling limits and human approval.']));
function enrolled(){return apply(engine.freshWorkspace(),{type:'enroll',programId:p.id})}
function learned(){let s=enrolled(),e=s.enrollments[0];for(const l of p.lessons)s=apply(s,{type:'lesson',enrollmentId:e.id,lessonId:l.id,answers:l.quiz.map(q=>q.correctOptionIndex),practice:'I checked the fictional packet, removed invented details and retained human review.'});return s}
function submitted(){let s=learned();return apply(s,{type:'submit',enrollmentId:s.enrollments[0].id,fields:evidence(),confirmed:true})}
function grade(s){return {type:'assess',enrollmentId:s.enrollments[0].id,attemptId:s.enrollments[0].attempts[0].id,actor:'assessor-a',scores:[4,4,4,4],gates:[true,true,true],notes:Array(4).fill('Checked the submitted field against the fictional packet.'),feedback:'Source mapping and careful information handling meet the synthetic practice standard.'}}
function appealed(){let s=submitted();s=apply(s,grade(s));return apply(s,{type:'appeal',enrollmentId:s.enrollments[0].id,attemptId:s.enrollments[0].attempts[0].id,reason:'Please inspect the source verification evidence independently and preserve history.'})}
function scenario(action){
 let s=['submit'].includes(action)?learned():action==='assess'?submitted():action==='resolve'?appealed():enrolled();
 const e=s.enrollments[0],l=p.lessons[0];let c;
 switch(action){
  case 'lesson-draft':c={type:action,enrollmentId:e.id,lessonId:l.id,practice:'Saved fictional work',answers:l.quiz.map(()=>null)};break;
  case 'lesson':c={type:action,enrollmentId:e.id,lessonId:l.id,practice:'Checked fictional work with a source mapping and human approval.',answers:l.quiz.map(q=>q.correctOptionIndex)};break;
  case 'draft':c={type:action,enrollmentId:e.id,fields:{task:'A private draft, preserved when content resolution fails.'}};break;
  case 'submit':c={type:action,enrollmentId:e.id,fields:evidence(),confirmed:true};break;
  case 'assess':c=grade(s);break;
  case 'resolve':c={...grade(s),type:'resolve',actor:'reviewer-b',appealId:e.appeals[0].id};delete c.attemptId;break;
 }
 return {s,c};
}
const ref=(e)=>({scope:'global',programId:e.programId,versionId:engine.CONTENT_VERSION});
const variants={
 'unknown legacy version':e=>{delete e.contentRef;e.version='unknown-pinned-version'},
 'missing legacy version without reference':e=>{delete e.contentRef;delete e.version},
 'unknown explicit version with unchanged legacy version':e=>{e.contentRef={...ref(e),versionId:'unknown-explicit-version'}},
 'mixed known reference and different legacy version':e=>{e.contentRef=ref(e);e.version='different-legacy-version'},
 'mixed reference and different program identity':e=>{e.contentRef={...ref(e),programId:'farmer-work-records'}},
 'foreign explicit scope':e=>{e.contentRef={...ref(e),scope:'tw-aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'}},
 'invalid explicit reference':e=>{e.contentRef=null},
};
for(const action of ['lesson-draft','lesson','draft','submit','assess','resolve'])for(const [name,mutate]of Object.entries(variants)){
 test(`${action} fails closed for ${name}`,()=>{const {s,c}=scenario(action);mutate(s.enrollments[0]);const original=JSON.stringify(s);assert.throws(()=>apply(s,c),e=>[404,409].includes(e.status)&&/content|curriculum|reference|version/i.test(e.message));assert.equal(JSON.stringify(s),original)});
}

test('legacy enrollment with known version and no explicit reference remains usable',()=>{const {s,c}=scenario('lesson');delete s.enrollments[0].contentRef;const next=apply(s,c);assert.deepEqual(next.enrollments[0].completed,[p.lessons[0].id]);assert.equal(next.enrollments[0].version,'0.1-review-draft')});
test('new personal enrollment carries an exact global reference',()=>{const e=enrolled().enrollments[0];assert.deepEqual(e.contentRef,{scope:'global',programId:p.id,versionId:engine.CONTENT_VERSION});assert.equal(e.version,e.contentRef.versionId)});
test('archive equals the original seed bytes and approved preservation hash',async()=>{const source=await readFile(path.join(manifest.checkout,'lib/curriculum.json')),archivePath=path.join(manifest.checkout,'lib/curriculum-versions/0.1-review-draft.json');await access(archivePath);const archive=await readFile(archivePath);assert.equal(archive.length,65054);assert.equal(createHash('sha256').update(archive).digest('hex'),'9fc83c8dd615456db8f49d140f56bff566e05c14d32ebb70a14cdcb73078b7e4');assert.deepEqual(source,archive)});

const owner={userId:'qa-content-owner',email:'owner@curriculum.test'},staff={userId:'qa-content-staff',email:'staff@curriculum.test'},teamNow=(t,u,c)=>teams.applyTeamCommand(t,u,c,now);
function cohort(){let t=teams.createTeam(owner,{name:'Content pin fixture',purpose:'Fictional immutable curriculum regression checks only.',context:'msme'},'tw-cccccccc-cccc-cccc-cccc-cccccccccccc',now);return teamNow(t,owner,{type:'cohort-create',title:'Pinned original pathway',programId:p.id,capacity:10})}
test('cohort enrollment refuses explicit content-version disagreement',()=>{const t=cohort();t.cohorts[0].contentRef={scope:'global',programId:p.id,versionId:'unknown-explicit-version'};assert.throws(()=>teamNow(t,owner,{type:'enroll',programId:p.id,cohortId:t.cohorts[0].id}),e=>[404,409].includes(e.status))});
test('assigned reviewer receives exact reference but never editable drafts',()=>{let t=cohort(),cid=t.cohorts[0].id;t=teamNow(t,owner,{type:'invite',email:staff.email,roles:['assessor'],scopes:[cid],tokenHash:'d'.repeat(64)});t=teamNow(t,staff,{type:'accept',tokenHash:'d'.repeat(64)});t=teamNow(t,owner,{type:'enroll',programId:p.id,cohortId:cid});let e=t.learners[0].state.enrollments[0];for(const l of p.lessons)t=teamNow(t,owner,{type:'lesson',enrollmentId:e.id,lessonId:l.id,answers:l.quiz.map(q=>q.correctOptionIndex),practice:'Checked a fictional practice task against its packet and review boundary.'});t=teamNow(t,owner,{type:'submit',enrollmentId:e.id,fields:evidence(),confirmed:true});e=t.learners[0].state.enrollments[0];t=teamNow(t,owner,{type:'draft',enrollmentId:e.id,fields:{task:'PRIVATE AFTER-SUBMISSION DRAFT CANARY'}});t=teamNow(t,owner,{type:'assign',kind:'assessment',targetId:e.attempts[0].id,staffId:staff.userId});const assigned=teams.projectTeam(t,staff).team.assigned[0];assert.equal(assigned.e.contentRef?.scope,'global');assert.deepEqual(assigned.e.contentRef,e.contentRef);assert.ok(!('draft' in assigned.e));assert.ok(!JSON.stringify(assigned).includes('PRIVATE AFTER-SUBMISSION DRAFT CANARY'))});

test('old cohort pins original content after a test-only catalog change',{skip:!manifest.resolverPresent},async()=>{const nextTeams=await import('./.compiled/next-teams.mjs'),nextEngine=await import('./.compiled/next-engine.mjs');let t=cohort();const oldReference=structuredClone(t.cohorts[0].contentRef),cid=t.cohorts[0].id;t=nextTeams.applyTeamCommand(t,owner,{type:'enroll',programId:p.id,cohortId:cid},now);const e=t.learners[0].state.enrollments[0];assert.equal(e.version,'0.1-review-draft');assert.deepEqual(e.contentRef,oldReference);const fresh=nextEngine.applyCommand(nextEngine.freshWorkspace(),{type:'enroll',programId:p.id},now);assert.equal(fresh.enrollments[0].version,'qa-only-latest-v2');assert.notEqual(fresh.enrollments[0].version,e.version)});
test('old assessed enrollment renders original title and rubric after test-only catalog change',{skip:!manifest.resolverPresent},async()=>{const nextEngine=await import('./.compiled/next-engine.mjs');const s=submitted(),next=nextEngine.applyCommand(s,grade(s),now);assert.equal(next.enrollments[0].record.title,p.title);assert.equal(next.enrollments[0].record.contentVersion,'0.1-review-draft');assert.equal(next.enrollments[0].record.status,'active')});
