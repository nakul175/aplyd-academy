# Continuing learning: bounded working slice

Workstream 4 of the four-hour development sprint. Prepared from the current working application and FSD F-11 / UX WF-14. This document is a proposed implementation contract, not evidence that the feature has shipped.

## Outcome

A learner chooses a work goal, sets a realistic weekly learning budget, schedules their own next actions, and returns to the correct saved activity. Optional reminders appear inside their learning workspace when they next open it. Recommendations explain the explicit learner choice that produced them. No email, push notification, AI inference, new published course, accreditation renewal, or external partner action is implied.

Current gaps: the overview has three static next steps and no persisted goal or plan; `LearningView` starts at lesson 1 even when later lessons are pending; continuing learning is limited to manually logging an active record's work reflection; optional before/after times currently coerce missing input to zero.

## Narrow release scope

1. A real **My learning plan** view with goal, weekly budget, scheduled activities, in-app reminder preference, and completed/skipped history.
2. A reusable next-action card on Overview. Derive it from saved evidence and authorized availability, never from an AI guess.
3. Save or dismiss a next-pathway suggestion. Show the reason and published effort; restoring dismissed suggestions is explicit.
4. Schedule a return-to-work reflection for a currently active reviewed practice record. Existing `followup` writes remain the evidence source.
5. Correct resume behavior. Opening an active pathway selects its first incomplete lesson; when lessons are complete, open practical assessment or feedback as appropriate.

The goal examples are task choices: **Organize work records**, **Check an AI draft**, **Write a clear response**, **Prepare expert questions**, or **Explore**. A free-text personal goal may supplement this choice, limited to 200 characters and accompanied by a private-data reminder. Do not infer learner capability, health, income, location, or literacy from any response.

## State: own learner aggregate only

Add an optional `learningPlan` field to the existing private learner `Workspace`. Read old persisted documents through a non-mutating default helper; do not require a destructive migration. Fresh workspaces receive the default. Add the field to own-data exports. Team administrative and facilitator summaries must not contain the goal, budget, dates, reminders, notes, saved suggestions, or dismissals.

```ts
type Goal = 'records' | 'check-draft' | 'clear-response' | 'expert-questions' | 'explore';
type LearningPlan = {
  goal: Goal;                          // Default explore
  personalGoal: string;                 // Default ''; max 200
  weeklyMinutes: number;                // Default 60; integer 10–600
  timeZone: string;                     // Valid IANA zone; default UTC until selected
  remindersEnabled: boolean;            // Default false; optional in-app only
  suggestionChoices: {
    key: string;                       // programId + immutable content version
    choice: 'saved' | 'dismissed';
    changedAt: string;                  // Server timestamp
  }[];                                 // At most 100, one choice per key
  items: {
    id: string;                        // Server-generated UUID
    kind: 'lesson' | 'practical' | 'reflection' | 'practice';
    enrollmentId: string | null;        // Required for linked activity kinds
    lessonId: string | null;            // Required only for lesson
    title: string;                     // Derived from pinned content for linked activity
    dueDate: string;                    // Date-only YYYY-MM-DD in stored plan timezone
    plannedMinutes: number;            // Integer 5–240; learner scheduling estimate
    note: string;                      // Max 500; private, permitted information only
    state: 'planned' | 'skipped' | 'cancelled';
    createdAt: string;
    updatedAt: string;
    completedAt: string | null;         // Manual completion allowed only for practice
  }[];                                 // At most 200 total, at most 30 open
};
```

The plan is private even when optional networking discovery is enabled. There is no sponsor-assigned plan in this slice. `plannedMinutes` measures a learner's intended allocation; completing an activity does not prove those minutes were spent. Show **planned minutes** and **activities completed**, not verified learning hours or measured productivity.

Linked completion is derived, not independently marked:

- Lesson: the enrollment has the exact pinned lesson in `completed`; use its practice completion timestamp when available.
- Practical: an attempt submitted after the item's `createdAt` exists; this completes a planned submission task, not the pathway or credential. Label **Evidence submitted**. Any assessment pass remains independently governed.
- Reflection: a followup for this enrollment with `createdAt >= item.createdAt` exists. Label **Reflection saved**. A later suspension of the practice record does not erase this historical self-report; suspension is shown separately and blocks new reflections under the current engine rule.
- Practice: a learner may mark their own task complete. Label **Self-reported practice** and never count it as course progress or assessed competence.

An old lesson already completed before planning cannot be offered as a new linked lesson task. A completed practical record cannot receive another submission task. A withdrawn, unavailable-version, or paused enrollment may retain its planned learning/submission item in history but it has a clear blocked reason and no progress action. Paused learning does not remove readable evidence or an otherwise permitted reflection on an active own record. Existing linked tasks never retarget to another enrollment or a newer curriculum version automatically.

## Commands and rules

Use the existing atomic action ID, request hash, current revision, and compare-and-swap API contract. Do not build a separate unaudited endpoint.

| Command | Allowed fields | Validation and effect |
|---|---|---|
| `plan-preferences` | `goal`, `personalGoal`, `weeklyMinutes`, `timeZone`, `remindersEnabled` | Exact keys; controlled goal; strings and limits above; finite integer weekly minutes; timezone validated with Intl; boolean required. Preserves items and suggestion choices. No privilege changes. |
| `plan-add` | `kind`, `enrollmentId?`, `lessonId?`, `title?`, `dueDate`, `plannedMinutes`, `note` | Exact keys; real calendar date, no impossible rollover such as 2026-02-30; validate own enrollment and pinned catalog. Require active/current permissions for linked task; pending prerequisites may be scheduled but shown as locked. Server generates ID. For linked tasks derive title, reject arbitrary title. Prevent duplicate open kind/enrollment/lesson. For practice use title length 3–100 and no enrollment/lesson fields. |
| `plan-change` | `itemId`, `dueDate?`, `plannedMinutes?`, `note?`, `state?`, `complete?` | Exact keys; own item only; at least one change; linked IDs/kind/title cannot change. State controlled. `complete: true` only for private practice; timestamp server-generated; may undo own practice completion with `complete: false`. A skipped/cancelled item may be restored if its linked availability still permits it. Retains history. |
| `suggestion-choice` | `programId`, `version`, `choice` | Exact keys; catalog must contain an accessible/safe-to-display published program version; choice saved/dismissed/clear. Update one key. Dismissed optional suggestions remain suppressed until explicit clear. Saving never enrolls, reserves a seat, adds permission, or upgrades an existing enrollment. |

In `applyTeamCommand`, include these own-only command cases. Reject `learnerId`, `actor`, role, cohort scope, assignment, or recipient fields; bind to authenticated member. Active members may edit their private goals and practice plan irrespective of staff role. Creating linked learning/submission items requires learner permission, as do actual learning actions. Reflection planning uses an active own record. Removed members retain readable history and export, with all writes disabled under the existing membership rule.

Plan commands do not change enrollments, rubric decisions, record status, sharing grants, or networking state. Keep the maximum existing aggregate sizes and produce a specific limit explanation before overfilling the plan.

## Deterministic next-action precedence

Use a pure helper accepting the current state, pinned authorized catalog, cohort availability, current role authority, and explicit `now`. It returns an action target, reason, effort or `null`, and whether the action is blocked. Do not use `Date.now()` inside tests or persist derived status.

1. **Removed membership:** Your own history remains available. Primary target history/export; no enrollment/progress button.
2. **Chosen enrollment withdrawn / pinned version unavailable:** Explain the exact state; no retargeting. Choose another enrollment or ask for support.
3. **Paused pathway/cohort:** Saved work retained; learning/review paused. Offer readable history; do not schedule/launch learning/submission progress. An existing active own record may still offer the historical reflection action already permitted by the engine.
4. **Open appeal:** Awaiting independent review; open feedback. Do not offer a resubmission.
5. **Undecided latest attempt:** Evidence is submitted and awaits review; open feedback. For lab use the explicit sample-review wording; for team use assigned-review wording.
6. **Active completion record:** Put the skill to work with permitted information; offer a reflection and a next-pathway choice. Show its nonaccredited status. Never invent an expiry or renewal date.
7. **Suspended record / maximum attempts used:** Open feedback and support route; no new submission. Only show an appeal option when the exact last decision is still appealable under the existing policy.
8. **Incomplete lessons:** Resume the first incomplete lesson in pinned order. Effort is the lesson's published estimate. If a saved draft exists, say **Your saved practice is ready to continue**.
9. **All lessons complete, no pending review:** Prepare or revise practical evidence. A prior failed decision offers feedback before revision; submission still requires the actual forms and checks.
10. **No active enrollment:** Show an explicit-choice-based available pathway, its reason and actual effort. In a team, a full/closed/no-permission offering is labeled with the missing condition and opens details; it is never presented as immediately startable.

Multiple active enrollments: prioritize an overdue linked planned activity that is still available, then earliest due planned item, then the learner's explicitly saved pathway, then an enrollment matching their selected work context. Break ties by stable enrollment start time and ID. A selected context is a relevance filter, not a permission grant. Feedback waiting states are visible alongside an available alternative, not a reason to suppress all other learning.

Resume correction can be shipped independently of full planning: derive `lessonIndex` from `p.lessons.findIndex(l => !e.completed.includes(l.id))` with a bounds check; choose `feedback` for pending review/open appeal, `assessment` for all lessons done without an active record, and `learn` otherwise. Recalculate when the enrollment target changes, not on every draft save, to avoid unexpectedly switching the learner's current tab.

## Truthful suggestions

Use only currently supplied authorized pathways. Explicit mapping is transparent:

- Records / expert questions + farmer context -> farm-record pathway.
- Clear response + MSME context -> customer-operations pathway.
- Clear response / checking drafts + public context -> source-brief pathway.
- Explore or goals with no exact mapping -> catalog; do not manufacture a fit.

Reason copy: **Suggested because you chose “Write a clear response” and “Public servant”.** Effort comes from `estimatedMinutes`, not an invented schedule. If the learner already holds an active record for that version, do not suggest that same version as a new qualification. Show its practice history or related real catalog choices. Future content versions are not automatically recommended as renewals.

## Date and reminder contract

Store due date separately from UTC timestamps. Render a plan's dates in its stored timezone; compute today from `new Intl.DateTimeFormat('en-CA', {timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now)` and compose YYYY-MM-DD explicitly rather than depending on locale separators. Compare valid date-only values lexically. Weekly range begins Monday in that local calendar. Daylight-saving transitions do not shift a stored due date.

Only `remindersEnabled: true` produces optional **Due today** / **Planned earlier** cards on next app opening. Disabling reminders hides those optional notices immediately, while the learner's plan remains readable. Saving due dates does not schedule a server job or send a message. Clear copy: **These reminders appear inside Academy when you open it. No email or phone notification is sent.** Never badge routine overdue activities as emergencies or promise delivery while the app is closed.

Essential operational states such as a paused cohort, failed save, or awaiting review remain visible independently of optional reminders. They are not marketing notifications. No essential notice is silently suppressed by the optional preference.

## UI contract

**Overview:** replace static right-rail steps with **Your next useful action**, saved goal, reason, exact activity, saved state, expected effort, and primary CTA. Optional due banner links to the plan. Keep clear context/workspace labels.

**My learning plan:** goal and preference panel; this week's planned minutes against the learner's chosen budget; compact today/upcoming list; schedule action dialog; history panel. Never display a red penalty for missing a self-chosen budget. Task row shows kind, title, due date, estimated/planned minutes, derived completion or blocked status, and permissible actions. Dates use a labeled date input and notes a short text field. All actions have accessible names and visible keyboard focus. Buttons wrap on phone layouts and 200% text.

**Achievements:** **Plan a work reflection** preselects the exact enrollment. A followup retains its existing source/provenance limits. Before/after times are nullable when not supplied; numeric zero is a valid explicit value, not a proxy for missing data. Explain **Your reported example**. Do not derive a verified productivity percentage from two unverified times.

**Settings:** optional in-app reminder switch and timezone choice; saved choice consistent with plan screen. Exports include the plan. Reset removes it as part of the existing private lab reset. Team history continues to use own-only export. Empty states explain no plan yet, all activities complete, and no usable suggestion without invented content.

## Integration points

- New pure module `lib/academy-plan.ts` can accept program/curriculum resolution functions instead of importing a single mutable seed; coordinate with the content-version workstream.
- `Workspace.learningPlan?` with default normalization preserves existing saved data. Schema storage is already JSON; no new D1 table is needed for this private planning slice.
- `applyCommand` delegates validated plan commands. `applyTeamCommand` admits only own private commands and applies current permission fences.
- A new `app/academy-plan.tsx` view and barrel export plus nav/hash route are sufficient; use installed UI controls and existing styling tokens.
- API GET must not mutate state or advance revision just to attach defaults. Defaults may be projected on read; next successful authorized mutation stores them atomically.
- No private plan data appears in network profiles, session RSVP roster, ecosystem payloads, shared moderation, review-assignment projection, or owner progress reports.

## Acceptance vectors

The companion JSON contains exact intended checks. They are planned tests, not executed results. Minimum ship evidence: meaningful pure rule tests; old-data compatibility; separate learner API identities; own-data export; a browser goal/schedule/complete/reload/reminder-off journey; phone and 200% text checks.
