# Independent learning-plan integration QA candidates

These files were prepared outside the Site checkout using the existing read-only `tests/local-qa.mjs` conventions. They operate only on a loopback synthetic test worker. Candidate preparation performed syntax checks; API/browser execution belongs to root's actual integrated build. No deployment, real invitation, email, or external service action is included.

## Files and adaptation

- `learning-plan-api.mjs`: personal persistence and nullable dates; own-only dispatch; owner/facilitator/assigned-assessor privacy canaries; removed membership and lost learner permission; paused cohort; exact own enrollment/domain; manual practice cannot alter course/record state; stale CAS/race and replay; optional reminder settings retain data without inventing sender results. Uses the existing helper's fixture, current revision and synthetic identity headers.
- `learning-plan-browser.mjs`: goal/budget/timezone persistence; undated practice; dated linked lesson; reminder on/off; manual completion; editing a date to null; correct next lesson; practical evidence submission; active-record reflection; absent/zero time distinction; own-data export; retained team plan after member removal; owner UI privacy canaries; no external POST in the actual journey; plan/dialog at desktop/tablet/phone and 200% text.
- `plan-pin-regression.mjs`: seven cloned-state tests invoking the actual bundled engine adapter. Unknown exact version, disagreeing legacy/ref versions, another known program, inaccessible private scope, malformed ref, and missing legacy version never fall back to current content. This fixture never corrupts D1 or exposes client-editable content refs.

Root may copy these three `.mjs` files into the checkout's `tests/` directory after reviewing. The API/browser files dynamically load that checkout's `tests/local-qa.mjs` by `ACADEMY_APP_PATH` and do not need helper copies. Existing `local-qa.mjs` defaults to local8787 and rejects non-loopback targets.

Browser accessible selectors are centralized in `const ui`. The reviewed UI now matches those labels and `data-plan-task-id`. If copy changes, adapt only that selector block while preserving assertions. Required runtime defaults match the existing test suite: bundled Playwright and the installed Google Chrome. Optional overrides: `ACADEMY_PLAYWRIGHT_MODULE`, `ACADEMY_CHROME_PATH`.

The pin regression expects fresh esbuild outputs `.sites-runtime/engine.mjs` and `.sites-runtime/plan.mjs`; rebuild them from the integrated engine and plan module before running it. A successful syntax check is not a passing integration journey.

## Run against the integrated local worker

From the Site checkout, with the current built local worker running at8787:

```sh
node tests/learning-plan-api.mjs
node --test tests/plan-pin-regression.mjs
node tests/learning-plan-browser.mjs
```

To run the candidates without copying, set `ACADEMY_APP_PATH` to the Site checkout and execute each candidate by its absolute path. Do not point these candidates at the published site. Optional `ACADEMY_QA_OUTPUT` controls output location; default is the checkout's ignored `.sites-runtime`.

Actual execution writes `learning-plan-api.json` / `learning-plan-browser.json` with genuine assertion counts, completed scenarios, failures and limits. Browser runs also save desktop/phone screenshots. Counts are assertions/checks, not independent test cases. Pin tests use Node's test runner output. Hosted dispatcher security and real recipient access remain outside these local fixtures.

The API test treats optional in-app reminders as a saved preference, not a delivered message. The browser verifies due notice behavior and no external POST during the executed journey; this does not claim independent auditing of every possible notification path.
