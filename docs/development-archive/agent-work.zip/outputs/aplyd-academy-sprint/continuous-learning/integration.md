# Candidate integration

Candidate source: `academy-plan.ts`. Standalone meaningful tests: `academy-plan.test.mjs`. The neighboring compiled `.mjs` exists only to run this candidate's tests outside the Site checkout. The Site checkout is unchanged by this workstream.

## Store and dispatch

1. Root reviews and copies source to `lib/academy-plan.ts`.
2. Extend `Workspace` with `learningPlan?: LearningPlan`; `freshWorkspace()` may include `freshLearningPlan()`. Existing saved aggregates without this field remain supported. A read helper returns detached defaults; it never advances a revision or edits enrollment data.
3. For lab planning commands, store `s.learningPlan = applyLearningPlanCommand(s, c, options)` inside the existing authenticated aggregate mutation. Translate `LearningPlanError` to existing `RuleError` with the same message/status so API errors remain controlled. Keep existing action hashing, audit replay and CAS fences; no new endpoint or table is required.
4. `options.resolveProgram(id, version)` must resolve that **exact** immutable pinned version and return `undefined` if missing. Do not fall back to current catalog. The module deliberately has no import of `academy-engine` or the seed, avoiding a circular dependency and allowing root's future version registry.
5. Team planning commands need a dedicated own-member branch. Resolve the existing authenticated own learner, then call the helper with `memberActive: m.active`, `canLearn: m.roles.includes('learner')`, and current `cohorts`. Passing through the lab dispatcher without these constraints would incorrectly default to learner permission. The top-level current membership check must still happen before any replay.
6. Never project `learningPlan` into facilitator/admin summaries, assigned assessment evidence, discovery profiles, session RSVPs, moderation, or partner payloads. Own-data/history exports may include it. Root's state source—not a request-supplied state or learner ID—defines ownership. Unsupported command fields, including `actor` and `learnerId`, are rejected.

Example adapter:

```ts
try {
  l.state.learningPlan = applyLearningPlanCommand(l.state, c, {
    now,
    resolveProgram: resolveExactPinnedProgram,
    memberActive: m.active,
    canLearn: m.roles.includes('learner'),
    cohorts: t.cohorts,
  });
} catch (error) {
  if (error instanceof LearningPlanError) throw new RuleError(error.message, error.status);
  throw error;
}
```

## Command contracts

All command fields are exact; partial preference edits are allowed. Date omission leaves the old date untouched on edits; explicit `null` clears the date. Creation defaults to unscheduled.

```json
{"type":"learning-plan","goal":"clear-response","personalGoal":"Write clearer replies","weeklyMinutes":60,"timeZone":"Asia/Kolkata","remindersEnabled":false}
{"type":"plan-task","kind":"practice","title":"Check a fictional customer draft","dueDate":null,"plannedMinutes":15,"note":"Keep private data out"}
{"type":"plan-task","kind":"lesson","enrollmentId":"OWN-ENROLLMENT","lessonId":"PINNED-LESSON","dueDate":"2026-10-07"}
{"type":"plan-task","kind":"practical","enrollmentId":"OWN-ENROLLMENT","dueDate":"2026-10-09"}
{"type":"plan-task","kind":"reflection","enrollmentId":"OWN-ENROLLMENT","dueDate":null}
{"type":"plan-task","taskId":"OWN-TASK","dueDate":null,"note":"Updated private planning note"}
{"type":"plan-task-status","taskId":"OWN-TASK","status":"skipped"}
{"type":"plan-task-status","taskId":"OWN-PRIVATE-PRACTICE-TASK","status":"done"}
{"type":"plan-task-remove","taskId":"OWN-TASK"}
```

Goals: explore, records, check-draft, clear-response, expert-questions. Weekly budget: integer 10–600 minutes. Task allocation: integer 5–240 minutes. Due date: nullable YYYY-MM-DD, validated against real calendar dates. Titles: 3–100 characters for private practice; linked titles are server-derived and cannot be changed. Private notes: maximum 500 characters. Maximum 30 open / 200 total activities. Deletion removes only the chosen private planning item, not linked course evidence.

Manual `done` applies only to private practice and is labeled **Self-reported practice**. Lesson completion, evidence submission, and saved reflection completion derive from the exact own stored course action; a planning command cannot create a credential, quiz completion or assessment decision. Submitted evidence means a submission task completed, not the pathway passed. A reflection completed earlier stays factual history when its practice record is later suspended.

## UI and resume

- Add a plan view/hash/nav entry and use `learningPlanSummary(state, options)` for rows, weekly **planned** allocation, actual saved activity completion dates, and due notices.
- Show optional reminders only from `summary.reminders`. They appear when Academy opens; no email, phone message, push notification, background schedule, or sender is provided. Turning reminders off leaves the plan readable.
- Bind a simple private practice planner first if UI time is limited; do not imply linked course planning is unavailable in the underlying rules.
- `learnerNextAction` chooses an available learner-planned task, then explicit context enrollment, then another saved enrollment. `enrollmentNextAction` can render one truthful card per enrollment so awaiting review does not hide another useful option.
- `LearnerNextAction.blocked` describes a learning/progress limitation. Its CTA can still safely navigate to retained history, feedback, or support. Do not indiscriminately disable readable history navigation when this flag is true.
- For a pathway's first render, use the returned `tab` and `lessonId` to select the correct saved activity. Recalculate when the enrollment target changes; do not reset the learner's tab after every draft save. Preserve the selected workspace when navigating.
- The next-action card is navigational. It never enrolls, submits, creates a role, bypasses lesson prerequisites, resolves an appeal, or shares data automatically.
- No personalized recommendations or saved/dismissed catalog choices are implemented by this narrower candidate. A learner without enrollment gets actual catalog exploration. No invented course, renewal or deadline is displayed.

## Executed evidence and remaining checks

Standalone candidate: 24 pure tests pass; strict standalone TypeScript check passes. Tests exercise original-state preservation, exact own references, unsupported fields, linked/manual completion, pinned versions, impossible/leap dates, timezone year/DST boundaries, duplicate restoration, open/total limits, actual review/appeal/suspension/exhaustion states, reminder-off preservation, and truthful planned versus evidence metrics.

These are candidate rule tests only. Root must run integrated lab/team API identity and CAS tests, own/staff projection tests, UI reload/goal/task/reminder journeys, keyboard and responsive checks, and normal build verification before publishing. The existing nullable reflection-time issue is identified but not changed here; it remains a separate root integration fix.
