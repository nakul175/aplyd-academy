# Accessibility and mobile review — workstream 6

Review scope: source inspection of the shared cohort network screen and its shell, primitives, and existing responsive tests. No published-site probes, application edits, or real participant accounts were used. This is a targeted review, not a WCAG certification.

## Concrete findings

1. **Two nested main landmarks.** `app/academy.tsx:29` uses an inner `<main id="main">`; its `SidebarInset` wrapper renders another `<main>` at `components/ui/sidebar.tsx:307–317`. Keep a single main landmark and retain the skip link's focusable target.

2. **Navigation replaces the page without moving focus.** `app/academy.tsx:22–24` updates the hash and page state, then scrolls. It never focuses the new page heading or main content. A keyboard learner activates “People & opportunities” and remains in the navigation while the content changes elsewhere. Focus the main target after an actual route transition; also cover browser back/forward. Do not move focus on routine saves.

3. **Controlled dialogs lack a return-focus target.** The network open buttons at `app/academy-network.tsx:19,27–28` are outside their dialog roots and do not use `DialogTrigger`. The installed Radix modal's `onCloseAutoFocus` prevents default restoration and focuses only `context.triggerRef.current` (`node_modules/@radix-ui/react-dialog/dist/index.mjs:154–157`). That ref is empty in these dialogs. Use a trigger or capture the opening button and restore it through `onCloseAutoFocus`. Verify Escape, close button, successful save, and cancel. The same construction appears elsewhere in the app.

4. **The current 200% test does not enlarge all text.** `app/globals.css:23` fixes `body` at `16px`; `tests/responsive-lab.mjs` and the shared journey change only the root font size. Rem-sized headings enlarge, but inherited body/input text can stay 16px. Use `body {font-size:1rem}` and assert the measured body and input sizes double. The candidate audit explicitly enlarges both root and body for a stronger check against the existing style.

5. **Network forms hide several requirements until submission.** `app/academy-network.tsx:30–32` uses `Field`, whose default limit is 10,000 characters (`app/academy-ui.tsx:4`). The server accepts introduction 10–300, purpose 20–1,000, instructions 10–2,000, cancellation reason 10–1,000, and attendance reason 10–500 (`lib/academy-network.ts:26,35,46,51`). Supply the appropriate `maxLength`, state the minimum where needed, and show the current count or inline error. Date rules also need visible help: future start, within 180 days, end after start, duration at most three hours (`lib/academy-network.ts:33`). `submitSession` silently returns for an invalid parsed date (`app/academy-network.tsx:18`); identify the offending field and explain how to correct it.

6. **There is no explanation for an unavailable directory choice.** When the learner has no eligible cohort, `app/academy-network.tsx:30` still offers sharing but displays an empty cohort fieldset and a disabled save button. Explain “Join a cohort before sharing your introduction” and keep the opt-out/removal action available for an existing profile.

7. **Session availability is frozen between rerenders.** `app/academy-network.tsx:23,27–28` reads `Date.now()` during rendering. An open page can continue offering a reservation after its start or keep attendance disabled after the start until another interaction rerenders. The server correctly rejects stale reservations. Refresh session availability on a modest timer and on page visibility changes, without announcing every timer tick. This is a functional reliability concern as well as an interaction issue.

## Positive foundations

The shell has a skip link; most text-entry fields have explicit labels; the select trigger receives an accessible name; network dialogs have titles and descriptions; cohort choice is a labelled fieldset; focus styling and reduced-motion styles exist; dialogs have a height limit and scroll; profile sharing is a separate explicit choice; sessions can be used without directory listing; dates expose the device timezone; the UI avoids mandatory media assets.

## Bounded browser QA

The accompanying `network-accessibility-candidate.mjs` runs only against a loopback preview. It creates a separate synthetic workspace through local fixture headers, seeds one cohort and two future sessions, and records:

- A single main landmark and focus after navigation.
- Dialog keyboard containment and focus restoration after Escape.
- Labelled directory controls and session inputs.
- 390, 768, and 1440 pixel layouts with normal and doubled text; measured text size, horizontal overflow, and dialog visibility/scrollability.
- A failed save retaining user input, with an accessible error alert.
- Reduced-motion behavior.

It produces observations and exits with a failing status for unmet structural/focus/layout checks. It is a **candidate, not executed evidence**. Do not count its assertions as completed tests until it runs against the reviewed build. Run with the bundled Node executable; the default preview is `http://127.0.0.1:8787`. The script rejects non-loopback origins.

Manual follow-up remains necessary: VoiceOver reading order, announcement quality, genuine browser zoom at 200% and 400%, touch targets and long translated names, screen-reader date picker behavior, weak connectivity during a save, and recovery after the connection returns. The application does not currently offer offline saving, and no offline capability is implied by this review.
